/*
 * runtime_features.c — Feature detection for Pocket Compiler v0.31
 *
 * This file is the SOLE implementation of runtime_init / runtime_scan_html /
 * runtime_tick / runtime_mark_event.  source/runtime.c is a stub that defers
 * to this file so there are no duplicate-symbol link errors.
 *
 * All field names match include/runtime_features.h exactly.
 */
#include "runtime_features.h"
#include <string.h>
#include <stdio.h>

/* Internal helper — returns 1 if needle is found anywhere in html. */
static int has_text(const char *html, const char *needle) {
    if (!html || !needle) return 0;
    return strstr(html, needle) != NULL;
}

/* ---------------------------------------------------------------- */
void runtime_init(FeatureRuntime *rt) {
    if (!rt) return;
    memset(rt, 0, sizeof(*rt));
    snprintf(rt->last_message, sizeof(rt->last_message), "Runtime ready.");
    snprintf(rt->status_msg,   sizeof(rt->status_msg),   "Runtime ready.");
}

/* ---------------------------------------------------------------- */
void runtime_scan_html(FeatureRuntime *rt, const char *html) {
    if (!rt || !html) return;

    /* DOM / events */
    rt->dom_events = has_text(html, "addEventListener") || has_text(html, "onclick");
    rt->dom        = rt->dom_events;

    /* fetch / network */
    rt->api_fetch  = has_text(html, "fetch(");
    rt->fetch      = rt->api_fetch;

    /* images */
    rt->images     = has_text(html, "<img");        /* 'images', NOT 'image' */

    /* audio */
    rt->web_audio  = has_text(html, "AudioContext") ||
                     has_text(html, "new Audio")    ||
                     has_text(html, "<audio");
    rt->audio      = rt->web_audio;

    /* storage */
    rt->local_storage = has_text(html, "localStorage")  ||
                        has_text(html, "sessionStorage");
    rt->storage       = rt->local_storage;
    rt->cache_api     = has_text(html, "caches.");

    /* canvas / webgl */
    rt->canvas    = has_text(html, "<canvas") || has_text(html, "getContext");
    rt->webgl     = has_text(html, "webgl")   || has_text(html, "WebGL");

    /* iframe / indexedDB */
    rt->iframe    = has_text(html, "<iframe");
    rt->indexeddb = has_text(html, "indexedDB");

    /* counters */
    rt->compile_count++;
    if (rt->canvas || rt->webgl)                         rt->draw_count++;
    if (rt->local_storage || rt->cache_api || rt->indexeddb) rt->storage_count++;

    snprintf(rt->last_message, sizeof(rt->last_message), "Compiled safely.");
    snprintf(rt->status_msg,   sizeof(rt->status_msg),   "Compiled safely.");
}

/* ---------------------------------------------------------------- */
void runtime_tick(FeatureRuntime *rt) {
    (void)rt;  /* reserved for future periodic tasks */
}

/* ---------------------------------------------------------------- */
void runtime_mark_event(FeatureRuntime *rt, const char *event_name) {
    if (!rt) return;
    rt->event_count++;
    snprintf(rt->last_message, sizeof(rt->last_message),
             "Event: %s", event_name ? event_name : "unknown");
    snprintf(rt->status_msg, sizeof(rt->status_msg),
             "Event: %s", event_name ? event_name : "unknown");
}
