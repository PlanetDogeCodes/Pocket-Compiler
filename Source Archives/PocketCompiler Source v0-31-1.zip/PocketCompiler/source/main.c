/*
 * main.c — Entry point for Pocket Compiler v0.31
 *
 * Circle-pad deadzone: values within ±DEADZONE are treated as zero.
 * Without this, tiny resting-state readings cause the cursor to drift
 * after the user releases the circle pad.
 */
#include <3ds.h>
#include <stdio.h>
#include <string.h>

#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include "ui.h"

/* ── static globals ─────────────────────────────────────────── */
static AppState       g_app;
static Editor         g_editor;
static FeatureRuntime g_runtime;

#define CURSOR_SPEED  0.18f

/* Circle-pad deadzone — readings within ±DEADZONE are treated as 0.
 * The 3DS circle pad reports small non-zero values at rest; without a
 * deadzone these accumulate and cause the cursor to drift. */
#define DEADZONE      14

static char g_fname[FE_FILENAME_MAX];

/* ── helpers ─────────────────────────────────────────────────── */

static void ensure_html_ext(char *buf, int sz) {
    size_t len = strlen(buf);
    if (len == 0) return;
    if (len < 5 || strcmp(buf + len - 5, ".html") != 0)
        if ((int)(len + 5) < sz) strcat(buf, ".html");
}

static bool kbd(const char *fill, const char *hint, char *out, int out_sz) {
    SwkbdState s;
    swkbdInit(&s, SWKBD_TYPE_NORMAL, 2, out_sz - 1);
    if (fill) swkbdSetInitialText(&s, fill);
    if (hint) swkbdSetHintText(&s, hint);
    return swkbdInputText(&s, out, (size_t)out_sz) == SWKBD_BUTTON_CONFIRM;
}

/* ── main ────────────────────────────────────────────────────── */

int main(void) {
    ui_init();
    runtime_init(&g_runtime);
    editor_init(&g_editor);
    fe_init(&g_app.fe);

    memset(&g_app, 0, sizeof(g_app));
    g_app.mode     = MODE_EDIT;
    g_app.cursor_x = 160.0f;
    g_app.cursor_y = 120.0f;

    ui_draw(&g_app, &g_editor, &g_runtime);

    while (aptMainLoop()) {
        hidScanInput();
        u32 held = hidKeysHeld(); (void)held;
        u32 down = hidKeysDown();

        /* ── Circle-pad cursor with deadzone ── */
        circlePosition cp;
        hidCircleRead(&cp);

        /* Clamp values inside the deadzone to exactly zero.
         * This prevents residual resting-state readings from drifting
         * the cursor after the user stops touching the circle pad. */
        if (cp.dx > -DEADZONE && cp.dx < DEADZONE) cp.dx = 0;
        if (cp.dy > -DEADZONE && cp.dy < DEADZONE) cp.dy = 0;

        bool dirty = false;

        if (cp.dx != 0 || cp.dy != 0) {
            g_app.cursor_x += cp.dx * CURSOR_SPEED;
            g_app.cursor_y -= cp.dy * CURSOR_SPEED;  /* Y axis inverted */
            if (g_app.cursor_x <   0) g_app.cursor_x =   0;
            if (g_app.cursor_x > 319) g_app.cursor_x = 319;
            if (g_app.cursor_y <   0) g_app.cursor_y =   0;
            if (g_app.cursor_y > 239) g_app.cursor_y = 239;
            dirty = true;
        }

        /* ════════════════════════════════════════════════════
         * EDIT MODE
         * ════════════════════════════════════════════════════ */
        if (g_app.mode == MODE_EDIT) {

            if (down & KEY_UP)   { editor_scroll_up(&g_editor);  dirty = true; }
            if (down & KEY_DOWN) { editor_scroll_down(&g_editor); dirty = true; }

            if (down & KEY_A) {
                char line_text[LINE_MAX], new_text[LINE_MAX];
                editor_get_line(&g_editor, g_editor.cursor_line,
                                line_text, sizeof(line_text));
                if (kbd(line_text, "Edit line", new_text, sizeof(new_text))) {
                    editor_snapshot(&g_editor);
                    editor_set_line(&g_editor, g_editor.cursor_line, new_text);
                }
                dirty = true;
            }

            if (down & KEY_B) { editor_undo(&g_editor); dirty = true; }

            if (down & KEY_X) {
                fe_scan(&g_app.fe);
                g_app.fe.cursor = 0;
                g_app.fe.scroll = 0;
                g_app.mode = MODE_SAVE;
                dirty = true;
            }

            if (down & KEY_Y) {
                fe_scan(&g_app.fe);
                g_app.fe.cursor = 0;
                g_app.fe.scroll = 0;
                g_app.mode = MODE_LOAD;
                dirty = true;
            }

            if (down & KEY_START) {
                runtime_scan_html(&g_runtime, g_editor.buf);
                dirty = true;
            }

            if (down & KEY_SELECT) { g_app.mode = MODE_CONTROLS; dirty = true; }

        /* ════════════════════════════════════════════════════
         * SAVE FILE EXPLORER
         * ════════════════════════════════════════════════════ */
        } else if (g_app.mode == MODE_SAVE) {

            int total = g_app.fe.count + 1;
            if (down & KEY_UP)   { fe_move_up(&g_app.fe);          dirty = true; }
            if (down & KEY_DOWN) { fe_move_down(&g_app.fe, total);  dirty = true; }

            if ((down & KEY_A) || (down & KEY_X)) {
                const char *prefill = (g_app.fe.cursor > 0)
                                    ? g_app.fe.names[g_app.fe.cursor - 1]
                                    : "";
                memset(g_fname, 0, sizeof(g_fname));
                if (kbd(prefill, "Filename (.html)", g_fname, sizeof(g_fname))
                    && strlen(g_fname) > 0) {
                    ensure_html_ext(g_fname, sizeof(g_fname));
                    if (fe_save_named(&g_editor, g_fname)) {
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg),
                                 "Saved: %s", g_fname);
                        snprintf(g_runtime.last_message,
                                 sizeof(g_runtime.last_message),
                                 "Saved: %s", g_fname);
                        g_app.mode = MODE_EDIT;
                    } else {
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg),
                                 "Save FAILED: %s", g_fname);
                    }
                }
                dirty = true;
            }

            if (down & KEY_B) { g_app.mode = MODE_EDIT; dirty = true; }

        /* ════════════════════════════════════════════════════
         * LOAD FILE EXPLORER
         * ════════════════════════════════════════════════════ */
        } else if (g_app.mode == MODE_LOAD) {

            if (down & KEY_UP)   { fe_move_up(&g_app.fe);                   dirty = true; }
            if (down & KEY_DOWN) { fe_move_down(&g_app.fe, g_app.fe.count); dirty = true; }

            if ((down & KEY_A) || (down & KEY_Y)) {
                if (g_app.fe.count > 0 &&
                    g_app.fe.cursor >= 0 &&
                    g_app.fe.cursor < g_app.fe.count) {
                    const char *fname = g_app.fe.names[g_app.fe.cursor];
                    if (fe_load_named(&g_editor, fname)) {
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg),
                                 "Loaded: %s", fname);
                        snprintf(g_runtime.last_message,
                                 sizeof(g_runtime.last_message),
                                 "Loaded: %s", fname);
                        g_app.mode = MODE_EDIT;
                    } else {
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg),
                                 "Load FAILED: %s", fname);
                    }
                }
                dirty = true;
            }

            if (down & KEY_B) { g_app.mode = MODE_EDIT; dirty = true; }

        /* ════════════════════════════════════════════════════
         * CONTROLS SCREEN
         * ════════════════════════════════════════════════════ */
        } else if (g_app.mode == MODE_CONTROLS) {
            if ((down & KEY_SELECT) || (down & KEY_B)) {
                g_app.mode = MODE_EDIT;
                dirty = true;
            }

        /* ════════════════════════════════════════════════════
         * PREVIEW MODE
         * ════════════════════════════════════════════════════ */
        } else if (g_app.mode == MODE_PREVIEW) {
            if ((down & KEY_B) || (down & KEY_START)) {
                g_app.mode = MODE_EDIT;
                dirty = true;
            }
        }

        if (dirty) ui_draw(&g_app, &g_editor, &g_runtime);
    }

    ui_exit();
    return 0;
}
