/*
 * ui.c — Citro2D UI for Pocket Compiler v0.31
 *
 * Colour scheme: pure-black background, solid-white non-syntax text.
 * Syntax highlighting colours are unchanged.
 */
#include "ui.h"
#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════
   COLOUR PALETTE
   ═══════════════════════════════════════════════════════════ */

/* Backgrounds */
#define C_BG      C2D_Color32(0x00,0x00,0x00,0xFF) /* pure black page bg   */
#define C_PANEL   C2D_Color32(0x0C,0x0C,0x0C,0xFF) /* card / panel bg      */
#define C_PANEL2  C2D_Color32(0x18,0x18,0x18,0xFF) /* elevated panel       */
#define C_BORDER  C2D_Color32(0x2E,0x2E,0x2E,0xFF) /* subtle border        */
#define C_SEL     C2D_Color32(0x18,0x24,0x34,0xFF) /* selected row tint    */
#define C_CURLINE C2D_Color32(0x12,0x1C,0x28,0xFF) /* cursor-line tint     */
#define C_ACCENT2 C2D_Color32(0x10,0x20,0x38,0xFF) /* dim blue badge bg    */
#define C_GREEN2  C2D_Color32(0x0A,0x20,0x10,0xFF) /* dim green badge bg   */

/* Text — ALL non-syntax text is solid white */
#define C_WHITE   C2D_Color32(0xFF,0xFF,0xFF,0xFF)
#define C_TEXT    C_WHITE
#define C_DIM     C_WHITE
#define C_ACCENT  C_WHITE
#define C_LNUM    C_WHITE

/* Status colours (used for borders / pill outlines only) */
#define C_GREEN   C2D_Color32(0x3F,0xB9,0x50,0xFF)
#define C_YELLOW  C2D_Color32(0xD2,0x99,0x22,0xFF)
#define C_RED     C2D_Color32(0xF8,0x51,0x49,0xFF)

/* Syntax highlighting — unchanged */
#define C_TAG     C2D_Color32(0x79,0xC0,0xFF,0xFF) /* HTML tag names       */
#define C_ATTR    C2D_Color32(0xFF,0xA6,0x57,0xFF) /* HTML attributes      */
#define C_VAL     C2D_Color32(0xA3,0xD9,0x91,0xFF) /* quoted values        */
#define C_CMT     C2D_Color32(0x57,0x5F,0x68,0xFF) /* comments             */
#define C_DOCTYPE C2D_Color32(0xFF,0xA6,0x57,0xFF) /* !DOCTYPE             */

/* Circle-pad cursor dot */
#define C_DOT     C2D_Color32(0xFF,0xFF,0xFF,0xBB) /* semi-transparent white */

/* ═══════════════════════════════════════════════════════════
   LAYOUT CONSTANTS  (unchanged)
   ═══════════════════════════════════════════════════════════ */
#define TOP_W  400.0f
#define TOP_H  240.0f
#define BOT_W  320.0f
#define BOT_H  240.0f

#define MAR    6.0f
#define PAD    5.0f
#define RAD    7.0f
#define RAD_S  4.0f

#define FS_ED  0.42f
#define FS_UI  0.50f
#define FS_H   0.58f

#define LH_ED  15.0f
#define LH_FE  21.0f

#define ED_X   (MAR)
#define ED_Y   (28.0f)
#define ED_W   (BOT_W - 2*MAR)
#define ED_H   (BOT_H - ED_Y - 32.0f)
#define LNUM_W 22.0f
#define CODE_X (ED_X + PAD + LNUM_W)
#define CODE_W (ED_W - PAD - LNUM_W - PAD)

#define FE_X   (MAR)
#define FE_Y   (28.0f)
#define FE_W   (BOT_W - 2*MAR)
#define FE_H   (BOT_H - FE_Y - 32.0f)

/* ═══════════════════════════════════════════════════════════
   STATIC STATE
   ═══════════════════════════════════════════════════════════ */
static C3D_RenderTarget *s_top;
static C3D_RenderTarget *s_bot;
static C2D_TextBuf       s_tb;

/* ═══════════════════════════════════════════════════════════
   DRAWING PRIMITIVES
   ═══════════════════════════════════════════════════════════ */

static void rr(float x, float y, float w, float h, float r, u32 col) {
    if (r > w * 0.5f) r = w * 0.5f;
    if (r > h * 0.5f) r = h * 0.5f;
    if (r < 1.0f) { C2D_DrawRectSolid(x, y, 0.5f, w, h, col); return; }
    C2D_DrawRectSolid (x+r,   y,     0.5f, w-2*r, h,     col);
    C2D_DrawRectSolid (x,     y+r,   0.5f, r,     h-2*r, col);
    C2D_DrawRectSolid (x+w-r, y+r,   0.5f, r,     h-2*r, col);
    C2D_DrawCircleSolid(x+r,   y+r,   0.5f, r, col);
    C2D_DrawCircleSolid(x+w-r, y+r,   0.5f, r, col);
    C2D_DrawCircleSolid(x+r,   y+h-r, 0.5f, r, col);
    C2D_DrawCircleSolid(x+w-r, y+h-r, 0.5f, r, col);
}

static void rr_outline(float x, float y, float w, float h,
                        float r, u32 border, u32 fill) {
    rr(x, y, w, h, r, border);
    float b = 1.5f;
    rr(x+b, y+b, w-2*b, h-2*b, r > b ? r-b : 0.0f, fill);
}

static void T(const char *s, float x, float y, float sc, u32 col) {
    if (!s || !*s) return;
    C2D_Text t;
    C2D_TextParse(&t, s_tb, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.5f, sc, sc, col);
}

static float TW(const char *s, float sc) {
    if (!s || !*s) return 0.0f;
    C2D_Text t;
    C2D_TextParse(&t, s_tb, s);
    float w = 0.0f, h = 0.0f;
    C2D_TextGetDimensions(&t, sc, sc, &w, &h);
    return w;
}

static void TC(const char *s, float cx, float y, float sc, u32 col) {
    T(s, cx - TW(s, sc) * 0.5f, y, sc, col);
}

/* ═══════════════════════════════════════════════════════════
   HTML SYNTAX HIGHLIGHTING  (logic unchanged)
   ═══════════════════════════════════════════════════════════ */
typedef struct { int start; int len; u32 color; } Span;
#define MAX_SPANS 40

static int tokenize(const char *line, Span *out, int max) {
    int  ns  = 0;
    int  len = (int)strlen(line);
    if (len == 0) return 0;

    if (strncmp(line, "<!--", 4) == 0) {
        out[0] = (Span){0, len, C_CMT};     return 1;
    }
    if (strncmp(line, "<!D", 3) == 0 || strncmp(line, "<!d", 3) == 0) {
        out[0] = (Span){0, len, C_DOCTYPE}; return 1;
    }

    typedef enum { S_NORM, S_TAG, S_VAL } St;
    St  st   = S_NORM;
    u32 curc = C_TEXT;
    int cs   = 0;

#define FLUSH(end) \
    if ((end) > cs && ns < max) { out[ns++] = (Span){cs,(end)-cs,curc}; cs=(end); }

    for (int i = 0; i <= len; i++) {
        char c = (i < len) ? line[i] : '\0';
        if (st == S_NORM) {
            if (c == '<') { FLUSH(i); st=S_TAG; curc=C_TAG; cs=i; }
        } else if (st == S_TAG) {
            if (c == '>') {
                FLUSH(i+1); st=S_NORM; curc=C_TEXT; cs=i+1; i++;
            } else if (c == '"') {
                FLUSH(i); st=S_VAL; curc=C_VAL; cs=i;
            }
        } else if (st == S_VAL) {
            if (c == '"') { FLUSH(i+1); st=S_TAG; curc=C_TAG; cs=i+1; i++; }
        }
        if (c == '\0') { FLUSH(len); }
    }
#undef FLUSH
    return ns;
}

static float draw_code_line(const char *line, float x, float y, float sc) {
    Span  spans[MAX_SPANS];
    char  buf[LINE_MAX];
    int   ns = tokenize(line, spans, MAX_SPANS);
    float cx = x;
    for (int i = 0; i < ns; i++) {
        int slen = spans[i].len;
        if (slen <= 0) continue;
        if (slen >= LINE_MAX) slen = LINE_MAX - 1;
        memcpy(buf, line + spans[i].start, slen);
        buf[slen] = '\0';
        T(buf, cx, y, sc, spans[i].color);
        cx += TW(buf, sc);
    }
    return cx;
}

/* ═══════════════════════════════════════════════════════════
   TOP SCREEN
   ═══════════════════════════════════════════════════════════ */

/* Feature pill: border is green (active) or grey (inactive); text is white */
static void pill(const char *label, float x, float y, bool active) {
    float pw = TW(label, 0.38f) + 8.0f;
    float ph = 12.0f;
    u32 bg  = active ? C_GREEN2  : C_PANEL2;
    u32 brd = active ? C_GREEN   : C_BORDER;
    rr_outline(x, y, pw, ph, RAD_S, brd, bg);
    T(label, x + 4.0f, y + 1.5f, 0.38f, C_WHITE);
}

static void draw_top(const Editor *e, const FeatureRuntime *rt) {
    rr(0.0f, 0.0f, TOP_W, 20.0f, 0.0f, C_PANEL);
    T("Pocket Compiler", MAR, 3.0f, FS_H, C_WHITE);
    T("v0.31", TOP_W - 36.0f, 4.5f, FS_UI, C_WHITE);

    float px = MAR, py = 25.0f;
    pill("DOM",     px,  py, rt->dom);      px += TW("DOM",     0.38f) + 14.0f;
    pill("Fetch",   px,  py, rt->fetch);    px += TW("Fetch",   0.38f) + 14.0f;
    pill("Img",     px,  py, rt->images);   px += TW("Img",     0.38f) + 14.0f;
    pill("Canvas",  px,  py, rt->canvas);   px += TW("Canvas",  0.38f) + 14.0f;
    pill("WebGL",   px,  py, rt->webgl);

    px = MAR; py = 41.0f;
    pill("Audio",   px,  py, rt->audio);    px += TW("Audio",   0.38f) + 14.0f;
    pill("Storage", px,  py, rt->storage);  px += TW("Storage", 0.38f) + 14.0f;
    pill("IDB",     px,  py, rt->indexeddb);px += TW("IDB",     0.38f) + 14.0f;
    pill("iframe",  px,  py, rt->iframe);

    rr(MAR, 57.0f, TOP_W - 2*MAR, 14.0f, RAD_S, C_PANEL2);
    char smsg[60];
    strncpy(smsg, rt->status_msg, 59); smsg[59] = '\0';
    T(smsg, MAR + PAD, 59.0f, 0.40f, C_WHITE);

    float panel_y = 75.0f;
    float panel_h = TOP_H - panel_y - MAR;
    rr_outline(MAR, panel_y, TOP_W - 2*MAR, panel_h, RAD, C_BORDER, C_PANEL);

    char line_buf[LINE_MAX];
    int   total = editor_line_count(e);
    float ty    = panel_y + PAD;
    float max_y = panel_y + panel_h - LH_ED;

    for (int i = 0; i < total && ty < max_y; i++) {
        editor_get_line(e, i, line_buf, sizeof(line_buf));
        line_buf[65] = '\0';
        draw_code_line(line_buf, MAR + PAD + 2.0f, ty, FS_ED);
        ty += LH_ED;
    }
    if (total == 0)
        TC("(empty)", (MAR + TOP_W - MAR) * 0.5f,
           panel_y + panel_h * 0.5f - 6.0f, FS_UI, C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — EDIT MODE
   ═══════════════════════════════════════════════════════════ */

static void draw_edit(const Editor *e) {
    rr(0.0f, 0.0f, BOT_W, 22.0f, 0.0f, C_PANEL);
    T("EDIT", MAR, 4.0f, FS_H, C_WHITE);

    char lc[24];
    snprintf(lc, sizeof(lc), "ln %d / %d",
             e->cursor_line + 1, editor_line_count(e));
    T(lc, BOT_W - TW(lc, 0.40f) - MAR, 5.5f, 0.40f, C_WHITE);

    rr_outline(ED_X, ED_Y, ED_W, ED_H, RAD, C_BORDER, C_PANEL);

    char line_buf[LINE_MAX];
    char lnum_buf[8];
    int  total  = editor_line_count(e);
    int  start  = e->scroll_offset;
    int  end_ln = start + CODE_AREA_H;
    if (end_ln > total) end_ln = total;

    for (int i = start; i < end_ln; i++) {
        float ry = ED_Y + PAD + (i - start) * LH_ED;

        if (i == e->cursor_line)
            rr(ED_X + 2.0f, ry - 1.0f, ED_W - 4.0f, LH_ED + 1.0f, RAD_S, C_CURLINE);

        snprintf(lnum_buf, sizeof(lnum_buf), "%3d", i + 1);
        T(lnum_buf, ED_X + PAD, ry, FS_ED, C_WHITE);

        C2D_DrawRectSolid(ED_X + PAD + LNUM_W - 3.0f, ry,
                          0.5f, 1.5f, LH_ED - 2.0f, C_BORDER);

        editor_get_line(e, i, line_buf, sizeof(line_buf));
        line_buf[38] = '\0';
        draw_code_line(line_buf, CODE_X, ry, FS_ED);
    }

    if (total > CODE_AREA_H) {
        float sb_x  = ED_X + ED_W - 5.0f;
        float sb_h  = ED_H - 2*PAD;
        float thumb = sb_h * CODE_AREA_H / (float)total;
        if (thumb < 10.0f) thumb = 10.0f;
        float ty2 = ED_Y + PAD + sb_h * e->scroll_offset / (float)total;
        C2D_DrawRectSolid(sb_x, ED_Y + PAD, 0.5f, 3.0f, sb_h, C_PANEL2);
        rr(sb_x, ty2, 3.0f, thumb, 1.5f, C_WHITE);
    }

    float fy = BOT_H - 18.0f;
    rr(0.0f, fy, BOT_W, 18.0f, 0.0f, C_PANEL);
    T("RUN:start  SAVE:x  LOAD:y  UNDO:b  ?:sel", MAR, fy + 2.5f, 0.35f, C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — SAVE FILE EXPLORER
   ═══════════════════════════════════════════════════════════ */

static void draw_save(const AppState *app) {
    const FileExplorer *fe = &app->fe;

    rr(0.0f, 0.0f, BOT_W, 22.0f, 0.0f, C_PANEL);
    T("SAVE PROJECT", MAR, 4.0f, FS_H, C_WHITE);
    T("A/X:save  B:back",
      BOT_W - TW("A/X:save  B:back", 0.38f) - MAR, 5.5f, 0.38f, C_WHITE);

    rr_outline(FE_X, FE_Y, FE_W, FE_H, RAD, C_BORDER, C_PANEL);

    float ry    = FE_Y + PAD;
    int total   = fe->count + 1;
    int vis_end = fe->scroll + FE_VISIBLE_ROWS;
    if (vis_end > total) vis_end = total;

    for (int row = fe->scroll; row < vis_end; row++) {
        bool sel = (row == fe->cursor);
        if (sel)
            rr(FE_X + 3.0f, ry - 1.0f, FE_W - 6.0f, LH_FE, RAD_S, C_SEL);

        if (row == 0) {
            rr_outline(FE_X + PAD, ry + 1.0f, FE_W - 2*PAD - 2.0f,
                       LH_FE - 4.0f, RAD_S,
                       sel ? C_WHITE : C_BORDER,
                       sel ? C_ACCENT2 : C_PANEL);
            T("+ New File", FE_X + 2*PAD, ry + 3.5f, FS_UI, C_WHITE);
        } else {
            int fi = row - 1;
            char fname[30];
            strncpy(fname, fe->names[fi], 29); fname[29] = '\0';
            char szbuf[10];
            fe_format_size(fe->sizes[fi], szbuf, sizeof(szbuf));
            T(fname, FE_X + 2*PAD, ry + 3.5f, FS_UI, C_WHITE);
            T(szbuf, FE_X + FE_W - TW(szbuf, 0.40f) - 2*PAD,
              ry + 4.5f, 0.40f, C_WHITE);
        }
        ry += LH_FE;
    }

    if (fe->count > FE_VISIBLE_ROWS - 1) {
        char ind[24];
        snprintf(ind, sizeof(ind), "%d files", fe->count);
        T(ind, FE_X + FE_W - TW(ind, 0.38f) - PAD,
          FE_Y + FE_H - 14.0f, 0.38f, C_WHITE);
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — LOAD FILE EXPLORER
   ═══════════════════════════════════════════════════════════ */

static void draw_load(const AppState *app) {
    const FileExplorer *fe = &app->fe;

    rr(0.0f, 0.0f, BOT_W, 22.0f, 0.0f, C_PANEL);
    T("LOAD PROJECT", MAR, 4.0f, FS_H, C_WHITE);
    T("Y/A:load  B:back",
      BOT_W - TW("Y/A:load  B:back", 0.38f) - MAR, 5.5f, 0.38f, C_WHITE);

    rr_outline(FE_X, FE_Y, FE_W, FE_H, RAD, C_BORDER, C_PANEL);

    if (fe->count == 0) {
        TC("No .html files on SD card",
           BOT_W * 0.5f, FE_Y + FE_H * 0.4f, FS_UI, C_WHITE);
        TC("Save a project first!",
           BOT_W * 0.5f, FE_Y + FE_H * 0.55f, 0.40f, C_WHITE);
        return;
    }

    float ry      = FE_Y + PAD;
    int   end_row = fe->scroll + FE_VISIBLE_ROWS;
    if (end_row > fe->count) end_row = fe->count;

    for (int row = fe->scroll; row < end_row; row++) {
        bool sel = (row == fe->cursor);
        if (sel)
            rr(FE_X + 3.0f, ry - 1.0f, FE_W - 6.0f, LH_FE, RAD_S, C_SEL);

        char fname[30];
        strncpy(fname, fe->names[row], 29); fname[29] = '\0';
        char szbuf[10];
        fe_format_size(fe->sizes[row], szbuf, sizeof(szbuf));

        T(fname, FE_X + 2*PAD, ry + 3.5f, FS_UI, C_WHITE);
        T(szbuf, FE_X + FE_W - TW(szbuf, 0.40f) - 2*PAD,
          ry + 4.5f, 0.40f, C_WHITE);

        ry += LH_FE;
    }

    if (fe->count > FE_VISIBLE_ROWS) {
        float sb_x  = FE_X + FE_W - 5.0f;
        float sb_y  = FE_Y + PAD;
        float sb_h  = FE_H - 2*PAD;
        float thumb = sb_h * FE_VISIBLE_ROWS / (float)fe->count;
        if (thumb < 10.0f) thumb = 10.0f;
        float ty2   = sb_y + sb_h * fe->scroll / (float)fe->count;
        C2D_DrawRectSolid(sb_x, sb_y, 0.5f, 3.0f, sb_h, C_PANEL2);
        rr(sb_x, ty2, 3.0f, thumb, 1.5f, C_WHITE);
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — CONTROLS REFERENCE
   ═══════════════════════════════════════════════════════════ */

static void draw_controls(void) {
    rr(0.0f, 0.0f, BOT_W, 22.0f, 0.0f, C_PANEL);
    TC("CONTROLS", BOT_W * 0.5f, 4.0f, FS_H, C_WHITE);

    rr_outline(MAR, 26.0f, BOT_W - 2*MAR, BOT_H - 44.0f, RAD, C_BORDER, C_PANEL);

    static const char *lbl[] = {
        "D-Pad",  "Scroll / arrow keys",
        "Circle", "Move cursor dot",
        "A",      "Edit current line (keyboard)",
        "B",      "Undo / Back",
        "X",      "Save project",
        "Y",      "Load project",
        "START",  "Compile / Run",
        "SELECT", "This screen",
        NULL, NULL
    };

    float row_y = 30.0f;
    for (int i = 0; lbl[i]; i += 2) {
        T(lbl[i],       MAR + PAD,         row_y, FS_UI, C_WHITE);
        T(lbl[i+1],     MAR + PAD + 52.0f, row_y, FS_UI, C_WHITE);
        row_y += 19.0f;
    }

    rr(0.0f, BOT_H - 18.0f, BOT_W, 18.0f, 0.0f, C_PANEL);
    TC("SELECT or B to close", BOT_W * 0.5f, BOT_H - 14.0f, 0.38f, C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   PUBLIC API
   ═══════════════════════════════════════════════════════════ */

void ui_init(void) {
    gfxInitDefault();
    gfxSet3D(false);
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    s_top = C2D_CreateScreenTarget(GFX_TOP,    GFX_LEFT);
    s_bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    s_tb  = C2D_TextBufNew(16384);
}

void ui_draw(const AppState *app, const Editor *e, const FeatureRuntime *rt) {
    if (!app || !e || !rt) return;

    C2D_TextBufClear(s_tb);

    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

    C2D_TargetClear(s_top, C_BG);
    C2D_SceneBegin(s_top);
    draw_top(e, rt);

    C2D_TargetClear(s_bot, C_BG);
    C2D_SceneBegin(s_bot);

    switch (app->mode) {
        case MODE_EDIT:     draw_edit(e);    break;
        case MODE_SAVE:     draw_save(app);  break;
        case MODE_LOAD:     draw_load(app);  break;
        case MODE_CONTROLS: draw_controls(); break;
        case MODE_PREVIEW:
            rr(0.0f, 0.0f, BOT_W, 22.0f, 0.0f, C_PANEL);
            TC("PREVIEW", BOT_W * 0.5f, 4.0f, FS_H, C_WHITE);
            TC("Press B or START to return",
               BOT_W * 0.5f, BOT_H * 0.5f, FS_UI, C_WHITE);
            break;
        default:
            draw_edit(e);
            break;
    }

    /* Circle-pad cursor dot */
    C2D_DrawCircleSolid(app->cursor_x, app->cursor_y, 0.6f, 3.5f, C_DOT);

    C3D_FrameEnd(0);
}

void ui_exit(void) {
    C2D_TextBufDelete(s_tb);
    C2D_Fini();
    C3D_Fini();
    gfxExit();
}
