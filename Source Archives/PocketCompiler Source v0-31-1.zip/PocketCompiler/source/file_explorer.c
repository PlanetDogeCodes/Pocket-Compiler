/*
 * file_explorer.c — Proper file explorer for Pocket Compiler v0.31
 *
 * Uses POSIX opendir/readdir (devkitPro newlib) to list .html files on
 * the SD card under FE_DIR, with file-size display via stat().
 *
 * Large buffers are static to avoid 3DS stack overflow.
 */
#include "file_explorer.h"
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

/* ----------------------------------------------------------------- init */

void fe_init(FileExplorer *fe) {
    if (!fe) return;
    memset(fe, 0, sizeof(*fe));
}

/* ----------------------------------------------------------------- scan */

/* Try to create the project directory (silently ignores EEXIST). */
static void ensure_dir(void) {
    mkdir(FE_DIR, 0777);
}

/* Returns 1 if 'name' ends with ".html" (case-sensitive). */
static int is_html(const char *name) {
    if (!name) return 0;
    size_t len = strlen(name);
    return len > 5 && strcmp(name + len - 5, ".html") == 0;
}

void fe_scan(FileExplorer *fe) {
    if (!fe) return;
    fe->count  = 0;
    fe->cursor = 0;
    fe->scroll = 0;

    ensure_dir();

    DIR *d = opendir(FE_DIR);
    if (!d) return;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && fe->count < FE_MAX_FILES) {
        if (!is_html(ent->d_name)) continue;

        strncpy(fe->names[fe->count], ent->d_name, FE_FILENAME_MAX - 1);
        fe->names[fe->count][FE_FILENAME_MAX - 1] = '\0';

        /* Get file size via stat */
        char path[128];
        snprintf(path, sizeof(path), "%s/%s", FE_DIR, ent->d_name);
        struct stat st;
        fe->sizes[fe->count] = (stat(path, &st) == 0) ? (long)st.st_size : -1L;

        fe->count++;
    }
    closedir(d);
}

/* --------------------------------------------------------------- cursor */

void fe_move_up(FileExplorer *fe) {
    if (!fe || fe->cursor <= 0) return;
    fe->cursor--;
    if (fe->cursor < fe->scroll)
        fe->scroll = fe->cursor;
}

void fe_move_down(FileExplorer *fe, int total_rows) {
    if (!fe || fe->cursor >= total_rows - 1) return;
    fe->cursor++;
    if (fe->cursor >= fe->scroll + FE_VISIBLE_ROWS)
        fe->scroll = fe->cursor - FE_VISIBLE_ROWS + 1;
}

/* ---------------------------------------------------------- size format */

void fe_format_size(long bytes, char *buf, int buf_sz) {
    if (!buf || buf_sz <= 0) return;
    if (bytes < 0) {
        snprintf(buf, buf_sz, "  ?.?  ");
    } else if (bytes < 1024L) {
        snprintf(buf, buf_sz, "%4ld B ", bytes);
    } else if (bytes < 1024L * 1024L) {
        snprintf(buf, buf_sz, "%4.1f KB", (double)bytes / 1024.0);
    } else {
        snprintf(buf, buf_sz, "%4.1f MB", (double)bytes / (1024.0 * 1024.0));
    }
}

/* ----------------------------------------------------------------- I/O */

bool fe_save_named(const Editor *e, const char *filename) {
    if (!e || !filename || filename[0] == '\0') return false;
    ensure_dir();

    char path[128];
    snprintf(path, sizeof(path), "%s/%s", FE_DIR, filename);

    FILE *f = fopen(path, "wb");
    if (!f) return false;

    size_t len     = strlen(e->buf);
    size_t written = fwrite(e->buf, 1, len, f);
    fclose(f);
    return written == len;
}

bool fe_load_named(Editor *e, const char *filename) {
    if (!e || !filename || filename[0] == '\0') return false;

    char path[128];
    snprintf(path, sizeof(path), "%s/%s", FE_DIR, filename);

    FILE *f = fopen(path, "rb");
    if (!f) return false;

    /* Static buffer avoids large stack allocation that crashes the 3DS */
    static char load_buf[EDITOR_MAX];

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (sz <= 0 || sz >= EDITOR_MAX) { fclose(f); return false; }

    size_t rd = fread(load_buf, 1, (size_t)sz, f);
    fclose(f);
    if ((long)rd != sz) return false;

    load_buf[sz] = '\0';
    memcpy(e->buf, load_buf, sz + 1);
    e->cursor_line   = 0;
    e->scroll_offset = 0;
    e->undo_valid    = false;
    return true;
}

/* --------------------------------------------------------- legacy slots */

static const char *slot_names[NUM_SLOTS] = {
    "project1.html", "project2.html", "project3.html",
    "project4.html", "project5.html"
};

const char *fe_slot_name(int slot) {
    if (slot < 0 || slot >= NUM_SLOTS) return "unknown.html";
    return slot_names[slot];
}

bool fe_save_slot(const Editor *e, int slot) {
    if (slot < 0 || slot >= NUM_SLOTS) return false;
    return fe_save_named(e, slot_names[slot]);
}

bool fe_load_slot(Editor *e, int slot) {
    if (slot < 0 || slot >= NUM_SLOTS) return false;
    return fe_load_named(e, slot_names[slot]);
}
