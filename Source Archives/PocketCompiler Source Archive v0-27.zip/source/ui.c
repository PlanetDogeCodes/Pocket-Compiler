#include "ui.h"

#include <3ds.h>
#include <stdio.h>
#include <string.h>

static PrintConsole s_top;
static PrintConsole s_bottom;
static bool s_ready = false;

/*
 * Clear the actual RGB framebuffer memory.
 *
 * The console renderer does not always visually clear every pixel of the
 * physical 3DS screen area, especially on the 400px-wide top screen. Clearing
 * the raw framebuffer prevents stale left/right edge pixels and vertical
 * black-line artifacts.
 */
static void clear_fb(gfxScreen_t screen, gfx3dSide_t side) {
    u16 w = 0;
    u16 h = 0;
    u8* fb = gfxGetFramebuffer(screen, side, &w, &h);
    if (!fb || w == 0 || h == 0) return;

    /*
     * libctru framebuffers are RGB8 here: 3 bytes per pixel.
     * w/h are provided by gfxGetFramebuffer, so this is safe for top/bottom.
     */
    memset(fb, 0, (size_t)w * (size_t)h * 3u);
}

static void clear_all_framebuffers(void) {
    clear_fb(GFX_TOP, GFX_LEFT);
    clear_fb(GFX_TOP, GFX_RIGHT);
    clear_fb(GFX_BOTTOM, GFX_LEFT);
}

static void print_limited(const char* s, int max_chars) {
    if (!s) return;
    for (int i = 0; s[i] && i < max_chars; i++) {
        putchar(s[i]);
    }
}

bool ui_init(void) {
    /*
     * Disable double buffering for console safe mode. This avoids one buffer
     * having stale edge pixels while the other buffer is freshly cleared.
     */
    gfxSetDoubleBuffering(GFX_TOP, false);
    gfxSetDoubleBuffering(GFX_BOTTOM, false);

    clear_all_framebuffers();

    consoleInit(GFX_TOP, &s_top);
    consoleInit(GFX_BOTTOM, &s_bottom);

    s_ready = true;
    return true;
}

void ui_shutdown(void) {
    s_ready = false;
}

/*
 * Editing a clicked line still uses the 3DS software keyboard.
 */
bool ui_edit_line(Editor* editor, int line, AppState* app) {
    if (!editor || line < 0) return false;

    char current[512];
    if (!editor_get_line(editor, line, current, sizeof(current))) {
        current[0] = 0;
    }

    SwkbdState kbd;
    char input[512];
    snprintf(input, sizeof(input), "%s", current);

    swkbdInit(&kbd, SWKBD_TYPE_NORMAL, 2, sizeof(input) - 1);
    swkbdSetInitialText(&kbd, input);
    swkbdSetHintText(&kbd, "Edit line");
    swkbdSetButton(&kbd, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&kbd, SWKBD_BUTTON_RIGHT, "Apply", true);

    if (swkbdInputText(&kbd, input, sizeof(input)) == SWKBD_BUTTON_RIGHT) {
        if (editor_replace_line(editor, line, input)) {
            if (app) app_status(app, "Edited line %d.", line + 1);
            return true;
        }
        if (app) app_status(app, "Line edit failed.");
    }

    return false;
}

void ui_draw(const AppState* app, const Editor* editor, const FeatureRuntime* rt) {
    if (!s_ready) return;

    /*
     * Full raw clear first, then console clear. This is the key visual fix.
     */
    clear_all_framebuffers();

    consoleSelect(&s_top);
    consoleClear();

    /*
     * Start text at column 1 instead of 0 to avoid edge artifacts on some
     * screens/capture conditions.
     */
    printf("\x1b[0;1HPocket Compiler v0.27 Safe Mode");
    printf("\x1b[1;1H----------------------------------------");

    if (rt) {
        printf("\x1b[3;1HCompile count: %d", rt->compile_count);
        printf("\x1b[4;1HEvents: %d  Draws: %d  Storage: %d",
               rt->event_count,
               rt->draw_count,
               rt->storage_count);

        printf("\x1b[6;1HDetected features:");
        printf("\x1b[7;1HDOM:%d iframe:%d IDB:%d fetch:%d",
               rt->dom_events,
               rt->iframe,
               rt->indexeddb,
               rt->api_fetch);

        printf("\x1b[8;1Hcanvas:%d webgl:%d img:%d audio:%d",
               rt->canvas,
               rt->webgl,
               rt->images,
               rt->web_audio);

        printf("\x1b[10;1H");
        print_limited(rt->last_message, 46);
    }

    if (app) {
        printf("\x1b[28;1H");
        print_limited(app->status, 46);
    }

    consoleSelect(&s_bottom);
    consoleClear();

    printf("\x1b[0;1HSTART Run  SELECT Help  A Edit  B Undo");
    printf("\x1b[1;1HX Save  Y Load  DPad Scroll/Move");
    printf("\x1b[2;1H--------------------------------------");

    if (editor) {
        const char* p = editor->text;
        int line_no = 0;
        int row = 3;

        while (*p && row < 28) {
            const char* start = p;
            int len = 0;

            while (p[len] && p[len] != '\n') len++;

            if (line_no >= editor->scroll_line) {
                printf("\x1b[%d;1H%02d ", row, line_no + 1);

                char line[64];
                int n = len < 33 ? len : 33;
                memcpy(line, start, (size_t)n);
                line[n] = 0;

                print_limited(line, 33);
                row++;
            }

            p += len;
            if (*p == '\n') p++;
            line_no++;
        }
    }

    if (app && app->show_controls) {
        consoleSelect(&s_bottom);
        consoleClear();

        printf("\x1b[0;1HControls");
        printf("\x1b[2;1HDPad: Scroll/move");
        printf("\x1b[3;1HA: Edit current visible line");
        printf("\x1b[4;1HB: Undo");
        printf("\x1b[5;1HX: Save to SD");
        printf("\x1b[6;1HY: Load from SD");
        printf("\x1b[7;1HSTART: Run/compile");
        printf("\x1b[8;1HSELECT: Close menu");
    }

    /*
     * Because double buffering is disabled, flush/wait is enough. main may
     * still call gfxFlushBuffers/gfxSwapBuffers/gspWaitForVBlank; that is okay,
     * but this keeps the UI self-contained too.
     */
    gfxFlushBuffers();
    gspWaitForVBlank();
}
