# Pocket Compiler — Changelog

## v0.36 (current)

### UI / Readability
- **All non-code bottom-screen text enlarged** for 3DS 240p legibility.
  Minimum UI font scale raised from 0.30–0.38 → 0.44–0.52.
  Code text (editor lines) is unchanged at FS_ED = 0.42.
- Hint bar is now **two lines** (34px tall) with shorter, clearly-spaced labels.
- Controls reference screen: key column 0.44f, description column 0.42f,
  row height raised to 17px. All description strings trimmed to fit.
- Tab bar labels: 0.38f → 0.48f.
- Console log lines: 0.38f → 0.46f; line height 17px.
- Find bar fields and hints: 0.34–0.38f → 0.40–0.46f.
- File explorer item text already used FS_UI (0.52f); size/date labels raised
  to FS_HINT (0.44f).

### Bug Fixes
- **`editor_find` / `editor_find_prev`**: `start_line` is now clamped to
  `[0, total-1]` before use. Without this, a negative or out-of-range
  start_line caused `editor_get_line` to walk off the end of the buffer —
  a potential crash on 3DS.
- **`editor_find_prev`**: `nlen` moved outside the inner for-loop (was
  recomputed on every iteration; harmless but wasteful).
- **`editor_replace_at`**: added `col > llen` guard to the bounds check so
  an exact-end-of-line replacement does not memcpy with a negative count.
- **`main.c` replace-all**: explicit parentheses added around `down & KEY_X`
  (`if((down & KEY_X) && ...)`). Without them GCC -Wall emits a warning;
  the fix makes intent unambiguous.
- **`main.c` replace-all**: after replacing all occurrences, `scroll_offset`
  is clamped to a valid range so the editor does not display a blank screen.
- **`we_eval_js`**: added `!g_web_engine.loaded` guard (in addition to the
  existing `!initialized` check). Prevents reading a stale `js_ctx` pointer
  if `we_unload()` was called between frames without clearing the pointer.
- **`draw_console`**: `i < WJS_LOG_MAX_LINES` guard added to the log-line
  loop. If `g_wjs_log_n` is ever corrupted, the loop can no longer read
  beyond the allocated `g_wjs_log` array.
- **`ui.c`**: two `strcat()` calls replaced with `strncat()` to silence
  static-analysis warnings and guard against theoretical overflow.
- **`main.c`**: `strcat()` in `ensure_html_ext` replaced with `strncat()`.
- **Layout constants**: `LAYOUT_ED_H` in `main.c` corrected to `178.0f`
  (was `180.0f`) to match the new two-line hint bar height in `ui.c`.
  Without this fix the cursor-to-code-row mapping was 2px off, causing the
  wrong line to be selected near the bottom of the editor panel.

---

## v0.35
- Auto-indent (A press on empty lines pre-fills indentation).
- JS Console tab (L in edit mode) with live expression evaluation.
- Find / Replace (R in edit mode) with next/prev/replace-one/replace-all.
- `fetch()` proper chaining via `.then(r=>r.json()).then(data=>...)` pattern.
- `response.text()` and `response.json()` return real thenables.
- `XMLHttpRequest.open()` correctly stores URL for `send()`.
- Duktape context kept alive on START-stop so console works after run.
- Console log cleared on each new compile (START in edit mode).

## v0.33
- Multiple field-name and linker bug fixes.

## v0.29 – v0.10
- Incremental implementation: DOM, CSS, layout, fetch, IndexedDB, iframe,
  Canvas, WebGL, audio, asset loading, full 3DS controls.

## v0.09
- Rebranded to Pocket Compiler.

## v0.01 – v0.08
- Initial HTML/CSS/JS editor, libctru console, SD card I/O.
