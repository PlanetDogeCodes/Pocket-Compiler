#pragma once
#include <stdbool.h>

#define EDITOR_MAX        65536
#define EDITOR_MAX_LINES    512
#define LINE_MAX            256

typedef struct {
    char  buf[EDITOR_MAX];
    int   cursor_line;
    int   scroll_offset;
    /* undo snapshot */
    char  undo_buf[EDITOR_MAX];
    int   undo_cursor_line;
    bool  undo_valid;   /* true only after at least one snapshot has been taken */
} Editor;

void editor_init(Editor *e);
void editor_snapshot(Editor *e);   /* save current state into undo_buf */
void editor_undo(Editor *e);       /* restore from undo_buf if undo_valid */
int  editor_line_count(const Editor *e);
void editor_get_line(const Editor *e, int line, char *out, int out_sz);
void editor_set_line(Editor *e, int line, const char *text);
void editor_insert_line(Editor *e, int line, const char *text);
void editor_delete_line(Editor *e, int line);
void editor_scroll_up(Editor *e);
void editor_scroll_down(Editor *e);

/* ── Auto-indent ─────────────────────────────────────────────────── */
/* Copy the leading whitespace of 'line' into 'out' (null-terminated).
 * Returns the number of indent characters copied. */
int  editor_get_indent(const Editor *e, int line, char *out, int out_sz);

/* ── Find / Replace ──────────────────────────────────────────────── */

/* Find the next occurrence of 'needle' starting search just after
 * (start_line, start_col).  Wraps around the buffer.
 * Returns true and sets *fl/*fc if found, false if not found. */
bool editor_find(const Editor *e, const char *needle,
                 int start_line, int start_col,
                 int *fl, int *fc);

/* Find the previous occurrence of 'needle' before (start_line, start_col).
 * Wraps around from the beginning to the end of the buffer. */
bool editor_find_prev(const Editor *e, const char *needle,
                      int start_line, int start_col,
                      int *fl, int *fc);

/* Replace exactly needle_len characters at (line, col) with 'replacement'.
 * Caller should call editor_snapshot() first if undo is needed.
 * Returns true on success, false if the replacement would overflow. */
bool editor_replace_at(Editor *e, int line, int col,
                       int needle_len, const char *replacement);
