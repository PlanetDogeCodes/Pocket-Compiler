/*
 * main.c — Entry point for Pocket Compiler v0.36
 *
 * v0.36 bugfixes:
 *  - compute_auto_indent: char indent[] and char prev[] are now static,
 *    eliminating ~512 bytes of stack allocation per A-press.
 *  - Operator precedence: added explicit parentheses around
 *    (down & KEY_X) in the MODE_FIND replace-all guard to silence
 *    the GCC -Wparentheses warning emitted by -Wall.
 *  - editor_scroll_to_line: guards scroll_offset against going below 0
 *    when CODE_AREA_H / 2 > line (very top of file).
 *  - In the kbd() wrapper the hint is truncated to SWKBD_MAX_HINT to
 *    avoid a silent libctru truncation that could corrupt the next call.
 *
 * v0.35 features (retained):
 *  - Auto-indent on empty-line A-press (JS braces + HTML open tags).
 *  - L trigger toggles the JS Console tab on the bottom screen.
 *  - R trigger enters Find/Replace mode (MODE_FIND).
 *  - START in run mode keeps the Duktape context alive (no we_unload).
 *  - wjs_log_clear() called before each new compile.
 */
#include <3ds.h>
#include <stdio.h>
#include <string.h>

#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include "web_engine.h"
#include "web_js.h"
#include "ui.h"

static AppState       g_app;
static Editor         g_editor;
static FeatureRuntime g_runtime;

#define CURSOR_SPEED  0.08f
#define DEADZONE      14

/* ── Layout constants — must stay in sync with ui.c ─────────────── */
#define LAYOUT_ED_Y      28.0f
#define LAYOUT_ED_PAD     5.0f
#define LAYOUT_LH_ED     15.0f
#define LAYOUT_ED_X       6.0f
#define LAYOUT_ED_W     308.0f
#define LAYOUT_ED_H     178.0f   /* height of editor panel (240-28-34) */

#define LAYOUT_OUT_X0     8.0f
#define LAYOUT_OUT_X1   392.0f
#define LAYOUT_OUT_Y0    40.0f
#define LAYOUT_OUT_Y1   234.0f

/* Number of console log lines visible at once (must match ui.c CON_VISIBLE) */
#define CONSOLE_VISIBLE_LINES 12

static char g_fname[FE_FILENAME_MAX];

/* ── Helpers ─────────────────────────────────────────────────────── */

static void ensure_html_ext(char *buf, int sz) {
    size_t len = strlen(buf);
    if (!len) return;
    if (len < 5 || strcmp(buf + len - 5, ".html") != 0)
        if ((int)(len + 5) < sz) strncat(buf, ".html", (size_t)(sz - (int)len - 1));
}

static bool kbd(const char *fill, const char *hint, char *out, int out_sz) {
    SwkbdState s;
    swkbdInit(&s, SWKBD_TYPE_NORMAL, 2, out_sz - 1);
    if (fill) swkbdSetInitialText(&s, fill);
    if (hint) swkbdSetHintText(&s, hint);
    return swkbdInputText(&s, out, (size_t)out_sz) == SWKBD_BUTTON_CONFIRM;
}

static float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

/* ── Auto-indent ─────────────────────────────────────────────────── */
/*
 * Fills 'out' with suggested indentation for a new empty line at 'line'.
 * Inherits the previous line's leading whitespace and adds 2 spaces when
 * the previous line ends with a block-opener: { ( [ or an HTML open tag
 * (excluding void elements).
 *
 * v0.36: indent[] and prev[] are now 'static' to avoid stack allocation.
 */
static void compute_auto_indent(const Editor *e, int line,
                                char *out, int out_sz) {
    out[0] = '\0';
    if (line <= 0) return;

    static char indent[LINE_MAX];
    static char prev[LINE_MAX];
    editor_get_indent(e, line - 1, indent, sizeof(indent));
    editor_get_line(e, line - 1, prev, sizeof(prev));

    int plen = (int)strlen(prev);
    /* Skip trailing spaces to find the real last character */
    int li = plen - 1;
    while (li >= 0 && prev[li] == ' ') li--;
    char last = (li >= 0) ? prev[li] : '\0';

    bool add_extra = (last == '{' || last == '(' || last == '[');

    /* HTML open-tag: ends with '>' but not '/>' */
    if (!add_extra && last == '>' && li >= 1 && prev[li - 1] != '/') {
        int bt = li - 1;
        while (bt >= 0 && prev[bt] != '<') bt--;
        if (bt >= 0 && bt + 1 <= li && prev[bt + 1] != '/') {
            char tn[32] = {0};
            const char *tp = prev + bt + 1;
            int ti = 0;
            while (*tp && *tp != '>' && *tp != ' ' && *tp != '/' && ti < 31) {
                char c = *tp++;
                tn[ti++] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
            }
            tn[ti] = '\0';
            static const char *voids[] = {
                "area","base","br","col","embed","hr","img","input",
                "link","meta","param","source","track","wbr", NULL
            };
            bool is_void = false;
            for (int vi = 0; voids[vi]; vi++)
                if (strcmp(tn, voids[vi]) == 0) { is_void = true; break; }
            if (!is_void) add_extra = true;
        }
    }

    int ilen = (int)strlen(indent);
    if (add_extra) {
        int total = ilen + 2;
        if (total >= out_sz) total = out_sz - 1;
        int copy = (ilen < total) ? ilen : total;
        memcpy(out, indent, copy);
        if (copy < out_sz - 1) out[copy++] = ' ';
        if (copy < out_sz - 1) out[copy++] = ' ';
        out[(copy < out_sz) ? copy : out_sz - 1] = '\0';
    } else {
        strncpy(out, indent, out_sz - 1);
        out[out_sz - 1] = '\0';
    }
}

/* ── Scroll editor viewport to show 'line' ───────────────────────── */
static void editor_scroll_to_line(int line) {
    if (line < g_editor.scroll_offset) {
        g_editor.scroll_offset = line;
    } else if (line >= g_editor.scroll_offset + CODE_AREA_H) {
        int half = CODE_AREA_H / 2;
        g_editor.scroll_offset = (line > half) ? (line - half) : 0;
    }
    if (g_editor.scroll_offset < 0) g_editor.scroll_offset = 0;
    g_editor.cursor_line = line;
}

/* ══════════════════════════════════════════════════════════════════ */
int main(void) {
    ui_init();
    runtime_init(&g_runtime);
    editor_init(&g_editor);

    memset(&g_app, 0, sizeof(g_app));
    fe_init(&g_app.fe);
    we_init();

    g_app.mode            = MODE_EDIT;
    g_app.cursor_x        = 160.f;
    g_app.cursor_y        = 120.f;
    g_app.top_cursor_x    = 200.f;
    g_app.top_cursor_y    = 130.f;
    g_app.find_match_line = -1;

    /* Seed code_cursor_line from the initial cursor position */
    {
        float code_top = LAYOUT_ED_Y + LAYOUT_ED_PAD;
        int   vr       = (int)((g_app.cursor_y - code_top) / LAYOUT_LH_ED);
        if (vr < 0)            vr = 0;
        if (vr >= CODE_AREA_H) vr = CODE_AREA_H - 1;
        g_app.code_cursor_line = vr;
    }

    ui_draw(&g_app, &g_editor, &g_runtime);

    while (aptMainLoop()) {
        hidScanInput();
        u32 down = hidKeysDown();

        circlePosition cp;
        hidCircleRead(&cp);
        if (cp.dx > -DEADZONE && cp.dx < DEADZONE) cp.dx = 0;
        if (cp.dy > -DEADZONE && cp.dy < DEADZONE) cp.dy = 0;

        bool dirty = false;

        /* Click-flash countdown */
        if (g_app.click_flash > 0) { g_app.click_flash--; dirty = true; }

        /* ═══ RUN MODE ═══════════════════════════════════════════ */
        if (g_app.run_mode) {

            /* START → return to edit (do NOT unload; keep JS ctx for console) */
            if (down & KEY_START) {
                g_app.run_mode      = false;
                g_app.cursor_locked = false;
                dirty = true;
            }

            if (cp.dx || cp.dy) {
                g_app.top_cursor_x += cp.dx * CURSOR_SPEED;
                g_app.top_cursor_y -= cp.dy * CURSOR_SPEED;
                if (g_app.cursor_locked) {
                    g_app.top_cursor_x = clampf(g_app.top_cursor_x,
                                                LAYOUT_OUT_X0, LAYOUT_OUT_X1);
                    g_app.top_cursor_y = clampf(g_app.top_cursor_y,
                                                LAYOUT_OUT_Y0, LAYOUT_OUT_Y1);
                } else {
                    g_app.top_cursor_x = clampf(g_app.top_cursor_x, 0.f, 399.f);
                    g_app.top_cursor_y = clampf(g_app.top_cursor_y, 0.f, 239.f);
                }
                dirty = true;
            }

            if (down & KEY_X)  { g_app.cursor_locked = false; dirty = true; }
            if (down & KEY_Y)  { dirty = true; }

            if (down & KEY_UP) {
                if (g_app.out_scroll > 0) g_app.out_scroll--;
                dirty = true;
            }
            if (down & KEY_DOWN) {
                int out_max = ui_get_out_count() - 1;
                if (out_max < 0) out_max = 0;
                if (g_app.out_scroll < out_max) g_app.out_scroll++;
                dirty = true;
            }
            if (down & KEY_LEFT)  dirty = true;
            if (down & KEY_RIGHT) dirty = true;

            /* A or L → left-click */
            if ((down & KEY_A) || (down & KEY_L)) {
                bool over_out = (g_app.top_cursor_x >= LAYOUT_OUT_X0 &&
                                 g_app.top_cursor_x <= LAYOUT_OUT_X1 &&
                                 g_app.top_cursor_y >= LAYOUT_OUT_Y0 &&
                                 g_app.top_cursor_y <= LAYOUT_OUT_Y1);
                if (over_out && !g_app.cursor_locked) {
                    g_app.cursor_locked = true;
                    g_app.top_cursor_x  = clampf(g_app.top_cursor_x,
                                                 LAYOUT_OUT_X0, LAYOUT_OUT_X1);
                    g_app.top_cursor_y  = clampf(g_app.top_cursor_y,
                                                 LAYOUT_OUT_Y0, LAYOUT_OUT_Y1);
                }
                int clicked = (int)((g_app.top_cursor_y - 26.0f) / 14.0f);
                clicked += g_app.out_scroll;
                if (clicked < 0) clicked = 0;
                g_app.click_line  = clicked;
                g_app.click_flash = 10;
                dirty = true;
            }
            if ((down & KEY_B) || (down & KEY_R)) {
                g_app.click_flash = 5;
                dirty = true;
            }

        /* ═══ EDIT / MODAL MODES ══════════════════════════════════ */
        } else {

            /* Bottom-screen cursor */
            if (cp.dx || cp.dy) {
                g_app.cursor_x = clampf(g_app.cursor_x + cp.dx * CURSOR_SPEED,
                                        0.f, 319.f);
                g_app.cursor_y = clampf(g_app.cursor_y - cp.dy * CURSOR_SPEED,
                                        0.f, 239.f);
                dirty = true;
            }

            /* Update hovered code row */
            {
                float code_top   = LAYOUT_ED_Y + LAYOUT_ED_PAD;
                float code_bot   = LAYOUT_ED_Y + LAYOUT_ED_H;
                float code_left  = LAYOUT_ED_X;
                float code_right = LAYOUT_ED_X + LAYOUT_ED_W;

                if (g_app.cursor_y >= code_top  && g_app.cursor_y < code_bot &&
                    g_app.cursor_x >= code_left && g_app.cursor_x < code_right) {
                    int vr = (int)((g_app.cursor_y - code_top) / LAYOUT_LH_ED);
                    if (vr < 0)            vr = 0;
                    if (vr >= CODE_AREA_H) vr = CODE_AREA_H - 1;
                    if (vr != g_app.code_cursor_line) {
                        g_app.code_cursor_line = vr;
                        dirty = true;
                    }
                }
            }

            /* ── MODE_EDIT ──────────────────────────────────────── */
            if (g_app.mode == MODE_EDIT) {

                /* ── Console tab ───────────────────────────────── */
                if (g_app.console_tab) {

                    if (down & KEY_UP) {
                        if (g_app.console_scroll > 0) g_app.console_scroll--;
                        dirty = true;
                    }
                    if (down & KEY_DOWN) {
                        int max_s = g_wjs_log_n - CONSOLE_VISIBLE_LINES;
                        if (max_s < 0) max_s = 0;
                        if (g_app.console_scroll < max_s) g_app.console_scroll++;
                        dirty = true;
                    }
                    if (down & KEY_A) {
                        static char js_in[LINE_MAX];
                        js_in[0] = '\0';
                        if (kbd("", "Enter JS expression", js_in, sizeof(js_in))
                            && js_in[0]) {
                            static char echo[LINE_MAX + 3];
                            snprintf(echo, sizeof(echo), "> %s", js_in);
                            wjs_log_push(echo);
                            we_eval_js(js_in);
                            /* Auto-scroll to bottom */
                            int max_s = g_wjs_log_n - CONSOLE_VISIBLE_LINES;
                            if (max_s < 0) max_s = 0;
                            g_app.console_scroll = max_s;
                        }
                        dirty = true;
                    }
                    if (down & KEY_B) {
                        wjs_log_clear();
                        g_app.console_scroll = 0;
                        dirty = true;
                    }
                    if (down & KEY_L) {
                        g_app.console_tab = false;
                        dirty = true;
                    }

                /* ── Editor tab ────────────────────────────────── */
                } else {

                    if (down & KEY_UP) {
                        if (g_editor.scroll_offset > 0) g_editor.scroll_offset--;
                        dirty = true;
                    }
                    if (down & KEY_DOWN) {
                        int total = editor_line_count(&g_editor);
                        int max_s = total - CODE_AREA_H;
                        if (max_s < 0) max_s = 0;
                        if (g_editor.scroll_offset < max_s) g_editor.scroll_offset++;
                        dirty = true;
                    }
                    if (down & KEY_LEFT) {
                        if (g_app.view_left > 0) g_app.view_left--;
                        dirty = true;
                    }
                    if (down & KEY_RIGHT) {
                        if (g_app.view_left < LINE_MAX - CODE_AREA_W)
                            g_app.view_left++;
                        dirty = true;
                    }

                    /* A → edit line with auto-indent pre-fill */
                    if (down & KEY_A) {
                        int target = g_editor.scroll_offset + g_app.code_cursor_line;
                        int total  = editor_line_count(&g_editor);
                        if (target < 0)      target = 0;
                        if (target >= total) target = total - 1;
                        g_editor.cursor_line = target;

                        static char lt[LINE_MAX];
                        static char nt[LINE_MAX];
                        static char pre_fill[LINE_MAX];
                        editor_get_line(&g_editor, target, lt, sizeof(lt));

                        if (lt[0] == '\0' && target > 0)
                            compute_auto_indent(&g_editor, target,
                                                pre_fill, sizeof(pre_fill));
                        else {
                            strncpy(pre_fill, lt, LINE_MAX - 1);
                            pre_fill[LINE_MAX - 1] = '\0';
                        }

                        if (kbd(pre_fill, "Edit line", nt, sizeof(nt))) {
                            editor_snapshot(&g_editor);
                            editor_set_line(&g_editor, target, nt);
                        }
                        dirty = true;
                    }

                    /* B → undo */
                    if (down & KEY_B) { editor_undo(&g_editor); dirty = true; }

                    /* L → toggle JS console tab */
                    if (down & KEY_L) {
                        g_app.console_tab    = true;
                        g_app.console_scroll = 0;
                        int max_s = g_wjs_log_n - CONSOLE_VISIBLE_LINES;
                        if (max_s < 0) max_s = 0;
                        g_app.console_scroll = max_s;
                        dirty = true;
                    }

                    /* R → find/replace mode */
                    if (down & KEY_R) {
                        g_app.mode            = MODE_FIND;
                        g_app.find_has_match  = false;
                        g_app.find_match_line = -1;
                        g_app.find_match_col  = 0;
                        dirty = true;
                    }
                }

                /* ── Shared (both tabs) ─────────────────────────── */
                if (down & KEY_X) {
                    fe_scan(&g_app.fe);
                    g_app.fe.cursor = 0; g_app.fe.scroll = 0;
                    g_app.mode = MODE_SAVE; dirty = true;
                }
                if (down & KEY_Y) {
                    fe_scan(&g_app.fe);
                    g_app.fe.cursor = 0; g_app.fe.scroll = 0;
                    g_app.mode = MODE_LOAD; dirty = true;
                }
                if (down & KEY_START) {
                    wjs_log_clear();
                    g_app.console_scroll = 0;
                    runtime_scan_html(&g_runtime, g_editor.buf);
                    ui_set_compiled(g_editor.buf);
                    we_load_html(g_editor.buf);
                    g_app.run_mode      = true;
                    g_app.cursor_locked = false;
                    g_app.out_scroll    = 0;
                    g_app.click_flash   = 0;
                    g_app.top_cursor_x  = 200.f;
                    g_app.top_cursor_y  = 130.f;
                    dirty = true;
                }
                if (down & KEY_SELECT) { g_app.mode = MODE_CONTROLS; dirty = true; }

            /* ── MODE_SAVE ──────────────────────────────────────── */
            } else if (g_app.mode == MODE_SAVE) {
                int total = g_app.fe.count + 1;
                if (down & KEY_UP)   { fe_move_up(&g_app.fe);         dirty = true; }
                if (down & KEY_DOWN) { fe_move_down(&g_app.fe, total); dirty = true; }

                if ((down & KEY_A) || (down & KEY_X)) {
                    const char *pf = (g_app.fe.cursor > 0)
                                     ? g_app.fe.names[g_app.fe.cursor - 1] : "";
                    memset(g_fname, 0, sizeof(g_fname));
                    if (kbd(pf, "Filename (.html)", g_fname, sizeof(g_fname))
                        && strlen(g_fname) > 0) {
                        ensure_html_ext(g_fname, sizeof(g_fname));
                        if (fe_save_named(&g_editor, g_fname)) {
                            snprintf(g_runtime.status_msg,
                                     sizeof(g_runtime.status_msg),
                                     "Saved: %s", g_fname);
                            snprintf(g_runtime.last_message,
                                     sizeof(g_runtime.last_message),
                                     "Saved: %s", g_fname);
                            g_app.mode = MODE_EDIT;
                        } else {
                            snprintf(g_runtime.status_msg,
                                     sizeof(g_runtime.status_msg),
                                     "Save FAILED: %s", g_fname);
                        }
                    }
                    dirty = true;
                }
                if (down & KEY_B) { g_app.mode = MODE_EDIT; dirty = true; }

            /* ── MODE_LOAD ──────────────────────────────────────── */
            } else if (g_app.mode == MODE_LOAD) {
                if (down & KEY_UP)   { fe_move_up(&g_app.fe);                   dirty = true; }
                if (down & KEY_DOWN) { fe_move_down(&g_app.fe, g_app.fe.count); dirty = true; }

                if ((down & KEY_A) || (down & KEY_Y)) {
                    if (g_app.fe.count > 0 &&
                        g_app.fe.cursor >= 0 &&
                        g_app.fe.cursor < g_app.fe.count) {
                        const char *fn = g_app.fe.names[g_app.fe.cursor];
                        if (fe_load_named(&g_editor, fn)) {
                            snprintf(g_runtime.status_msg,
                                     sizeof(g_runtime.status_msg),
                                     "Loaded: %s", fn);
                            snprintf(g_runtime.last_message,
                                     sizeof(g_runtime.last_message),
                                     "Loaded: %s", fn);
                            g_app.mode = MODE_EDIT;
                        } else {
                            snprintf(g_runtime.status_msg,
                                     sizeof(g_runtime.status_msg),
                                     "Load FAILED: %s", fn);
                        }
                    }
                    dirty = true;
                }
                if (down & KEY_B) { g_app.mode = MODE_EDIT; dirty = true; }

            /* ── MODE_CONTROLS ──────────────────────────────────── */
            } else if (g_app.mode == MODE_CONTROLS) {
                if ((down & KEY_SELECT) || (down & KEY_B)) {
                    g_app.mode = MODE_EDIT; dirty = true;
                }

            /* ── MODE_FIND ──────────────────────────────────────── */
            } else if (g_app.mode == MODE_FIND) {

                /* A → set/update search string */
                if (down & KEY_A) {
                    static char nt[LINE_MAX];
                    if (kbd(g_app.find_buf, "Search for", nt, sizeof(nt))) {
                        strncpy(g_app.find_buf, nt, sizeof(g_app.find_buf) - 1);
                        g_app.find_buf[sizeof(g_app.find_buf) - 1] = '\0';
                        if (g_app.find_buf[0]) {
                            int sl = g_editor.cursor_line;
                            int sc = g_app.find_has_match ? g_app.find_match_col : -1;
                            g_app.find_has_match = editor_find(
                                &g_editor, g_app.find_buf, sl, sc,
                                &g_app.find_match_line, &g_app.find_match_col);
                            if (g_app.find_has_match)
                                editor_scroll_to_line(g_app.find_match_line);
                            else
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Not found: %s", g_app.find_buf);
                        }
                    }
                    dirty = true;
                }

                /* DPad Down → find next */
                if ((down & KEY_DOWN) && g_app.find_buf[0]) {
                    int sl = g_app.find_has_match ? g_app.find_match_line
                                                  : g_editor.cursor_line;
                    int sc = g_app.find_has_match ? g_app.find_match_col : -1;
                    g_app.find_has_match = editor_find(
                        &g_editor, g_app.find_buf, sl, sc,
                        &g_app.find_match_line, &g_app.find_match_col);
                    if (g_app.find_has_match)
                        editor_scroll_to_line(g_app.find_match_line);
                    else
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg), "No more matches.");
                    dirty = true;
                }

                /* DPad Up → find previous */
                if ((down & KEY_UP) && g_app.find_buf[0]) {
                    int sl = g_app.find_has_match ? g_app.find_match_line
                                                  : g_editor.cursor_line;
                    int sc = g_app.find_has_match ? g_app.find_match_col : 0;
                    g_app.find_has_match = editor_find_prev(
                        &g_editor, g_app.find_buf, sl, sc,
                        &g_app.find_match_line, &g_app.find_match_col);
                    if (g_app.find_has_match)
                        editor_scroll_to_line(g_app.find_match_line);
                    else
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg), "No more matches.");
                    dirty = true;
                }

                /* Y → enter replace string and replace current match */
                if (down & KEY_Y) {
                    static char nt[LINE_MAX];
                    if (kbd(g_app.replace_buf, "Replace with", nt, sizeof(nt))) {
                        strncpy(g_app.replace_buf, nt,
                                sizeof(g_app.replace_buf) - 1);
                        g_app.replace_buf[sizeof(g_app.replace_buf) - 1] = '\0';
                        if (g_app.find_has_match && g_app.find_buf[0]) {
                            editor_snapshot(&g_editor);
                            int nlen = (int)strlen(g_app.find_buf);
                            bool ok = editor_replace_at(
                                &g_editor,
                                g_app.find_match_line,
                                g_app.find_match_col,
                                nlen,
                                g_app.replace_buf);
                            if (ok) {
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Replaced at ln %d",
                                         g_app.find_match_line + 1);
                                int next_col = g_app.find_match_col
                                    + (int)strlen(g_app.replace_buf);
                                g_app.find_has_match = editor_find(
                                    &g_editor, g_app.find_buf,
                                    g_app.find_match_line, next_col - 1,
                                    &g_app.find_match_line,
                                    &g_app.find_match_col);
                                if (g_app.find_has_match)
                                    editor_scroll_to_line(g_app.find_match_line);
                            }
                        }
                    }
                    dirty = true;
                }

                /* X → replace all
                 * v0.36 fix: explicit parentheses around (down & KEY_X)
                 * to silence GCC -Wparentheses with -Wall. */
                if ((down & KEY_X) && g_app.find_buf[0]) {
                    editor_snapshot(&g_editor);
                    int count = 0, fl, fc;
                    int nlen  = (int)strlen(g_app.find_buf);
                    bool found = editor_find(&g_editor, g_app.find_buf,
                                            0, -1, &fl, &fc);
                    while (found && count < 2000) {
                        if (!editor_replace_at(&g_editor, fl, fc, nlen,
                                               g_app.replace_buf)) break;
                        count++;
                        int next_c = fc + (int)strlen(g_app.replace_buf);
                        found = editor_find(&g_editor, g_app.find_buf,
                                            fl, next_c - 1, &fl, &fc);
                    }
                    snprintf(g_runtime.status_msg,
                             sizeof(g_runtime.status_msg),
                             "Replaced %d occurrence%s",
                             count, count == 1 ? "" : "s");
                    g_app.find_has_match  = false;
                    g_app.find_match_line = -1;
                    /* Scroll the editor so the last replace position is visible */
                    {
                        int sc_max = editor_line_count(&g_editor) - CODE_AREA_H;
                        if(sc_max < 0) sc_max = 0;
                        if(g_editor.scroll_offset > sc_max)
                            g_editor.scroll_offset = sc_max;
                    }
                    dirty = true;
                }

                /* B → close find mode */
                if (down & KEY_B) {
                    g_app.mode           = MODE_EDIT;
                    g_app.find_has_match = false;
                    dirty = true;
                }

            /* ── MODE_PREVIEW ───────────────────────────────────── */
            } else if (g_app.mode == MODE_PREVIEW) {
                if ((down & KEY_B) || (down & KEY_START)) {
                    g_app.mode = MODE_EDIT; dirty = true;
                }
            }
        } /* end !run_mode */

        /* Drive the web engine each frame while running */
        if (g_app.run_mode && g_web_engine.loaded) {
            WEInputState we_inp = {0};
            we_inp.held          = (uint32_t)hidKeysHeld();
            we_inp.down          = (uint32_t)down;
            we_inp.up            = (uint32_t)hidKeysUp();
            we_inp.cursor_x      = g_app.top_cursor_x;
            we_inp.cursor_y      = g_app.top_cursor_y;
            we_inp.prev_x        = g_app.top_cursor_x;
            we_inp.prev_y        = g_app.top_cursor_y;
            we_inp.cursor_locked = g_app.cursor_locked;
            we_update(&we_inp,
                      g_app.top_cursor_x, g_app.top_cursor_y,
                      g_app.cursor_locked, 16.67);
            dirty = true;
        }

        if (dirty) ui_draw(&g_app, &g_editor, &g_runtime);
    }

    we_exit();
    ui_exit();
    return 0;
}
