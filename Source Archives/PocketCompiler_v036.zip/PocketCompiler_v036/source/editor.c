/*
 * editor.c — Line-based text editor for Pocket Compiler v0.36
 *
 * v0.36 fixes:
 *  - editor_find / editor_find_prev: start_line is now clamped to [0,total-1]
 *    before use, preventing an off-the-end walk in editor_get_line().
 *  - editor_find_prev: nlen moved outside the inner for-loop (minor perf fix).
 *  - All large temporary buffers remain 'static' to keep stack usage minimal
 *    on the 3DS (default main-thread stack: 256 KB).
 */
#include "editor.h"
#include "app.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

/* ── Init ─────────────────────────────────────────────────────────── */

void editor_init(Editor *e) {
    if (!e) return;
    memset(e, 0, sizeof(*e));
    e->cursor_line   = 0;
    e->scroll_offset = 0;
    e->undo_valid    = false;
    strncpy(e->buf,
        "<!DOCTYPE html>\n<html>\n<head>\n  <title>My Page</title>\n</head>\n"
        "<body>\n  <h1>Hello, 3DS!</h1>\n</body>\n</html>\n",
        EDITOR_MAX - 1);
    e->buf[EDITOR_MAX - 1] = '\0';
}

/* ── Helpers ──────────────────────────────────────────────────────── */

int editor_line_count(const Editor *e) {
    if (!e) return 0;
    int count = 0;
    for (int i = 0; e->buf[i] != '\0'; i++)
        if (e->buf[i] == '\n') count++;
    return count + 1;
}

void editor_get_line(const Editor *e, int line, char *out, int out_sz) {
    if (!e || !out || out_sz <= 0) return;
    out[0] = '\0';
    if (line < 0) return;
    int cur = 0, n = 0;
    const char *p = e->buf;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    while (*p && *p != '\n' && n < out_sz - 1) out[n++] = *p++;
    out[n] = '\0';
}

void editor_set_line(Editor *e, int line, const char *text) {
    if (!e || !text) return;
    static char tmp[EDITOR_MAX];
    const char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    const char *ls = p;
    while (*p && *p != '\n') p++;
    int pfx  = (int)(ls - e->buf);
    int sfx  = (int)(p  - e->buf);
    int tlen = (int)strlen(text);
    int blen = (int)strlen(e->buf);
    int nlen = pfx + tlen + (blen - sfx);
    if (nlen >= EDITOR_MAX) return;
    memcpy(tmp, e->buf, pfx);
    memcpy(tmp + pfx, text, tlen);
    memcpy(tmp + pfx + tlen, e->buf + sfx, blen - sfx + 1);
    memcpy(e->buf, tmp, nlen + 1);
}

void editor_insert_line(Editor *e, int line, const char *text) {
    if (!e || !text) return;
    static char tmp[EDITOR_MAX];
    const char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    int pfx  = (int)(p - e->buf);
    int tlen = (int)strlen(text);
    int blen = (int)strlen(e->buf);
    int nlen = pfx + tlen + 1 + (blen - pfx);
    if (nlen >= EDITOR_MAX) return;
    memcpy(tmp, e->buf, pfx);
    memcpy(tmp + pfx, text, tlen);
    tmp[pfx + tlen] = '\n';
    memcpy(tmp + pfx + tlen + 1, e->buf + pfx, blen - pfx + 1);
    memcpy(e->buf, tmp, nlen + 1);
}

void editor_delete_line(Editor *e, int line) {
    if (!e) return;
    char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    char *ls = p;
    while (*p && *p != '\n') p++;
    if (*p == '\n') p++;
    memmove(ls, p, strlen(p) + 1);
}

void editor_scroll_up(Editor *e) {
    if (!e) return;
    if (e->scroll_offset > 0) e->scroll_offset--;
    if (e->cursor_line   > 0) e->cursor_line--;
}

void editor_scroll_down(Editor *e) {
    if (!e) return;
    int total = editor_line_count(e);
    if (e->cursor_line < total - 1) {
        e->cursor_line++;
        if (e->cursor_line >= e->scroll_offset + CODE_AREA_H)
            e->scroll_offset++;
    }
}

/* ── Undo ─────────────────────────────────────────────────────────── */

void editor_snapshot(Editor *e) {
    if (!e) return;
    memcpy(e->undo_buf, e->buf, EDITOR_MAX);
    e->undo_cursor_line = e->cursor_line;
    e->undo_valid = true;
}

void editor_undo(Editor *e) {
    if (!e || !e->undo_valid) return;
    memcpy(e->buf, e->undo_buf, EDITOR_MAX);
    e->cursor_line = e->undo_cursor_line;
    e->undo_valid  = false;
}

/* ── Auto-indent ─────────────────────────────────────────────────── */

int editor_get_indent(const Editor *e, int line, char *out, int out_sz) {
    if (!e || !out || out_sz <= 0) {
        if (out && out_sz > 0) out[0] = '\0';
        return 0;
    }
    static char lb[LINE_MAX];
    editor_get_line(e, line, lb, sizeof(lb));
    int n = 0;
    while ((lb[n] == ' ' || lb[n] == '\t') && n < out_sz - 1) {
        out[n] = lb[n];
        n++;
    }
    out[n] = '\0';
    return n;
}

/* ── Find (forward, wraps around) ────────────────────────────────── */

bool editor_find(const Editor *e, const char *needle,
                 int start_line, int start_col,
                 int *fl, int *fc) {
    if (!e || !needle || !*needle || !fl || !fc) return false;
    int total = editor_line_count(e);
    if (total <= 0) return false;

    /* Clamp start_line to a valid range (bug fix: prevents off-end walk) */
    if (start_line < 0)      start_line = 0;
    if (start_line >= total) start_line = total - 1;

    static char lb[LINE_MAX];

    for (int pass = 0; pass < 2; pass++) {
        int lo = (pass == 0) ? start_line : 0;
        int hi = (pass == 0) ? total      : start_line + 1;
        for (int li = lo; li < hi; li++) {
            editor_get_line(e, li, lb, sizeof(lb));
            int col0 = 0;
            if (pass == 0 && li == start_line) {
                /* Search from one past start_col; -1 means "from col 0" */
                col0 = (start_col >= 0) ? start_col + 1 : 0;
            }
            int llen = (int)strlen(lb);
            if (col0 > llen) continue;
            const char *found = strstr(lb + col0, needle);
            if (found) {
                *fl = li;
                *fc = (int)(found - lb);
                return true;
            }
        }
    }
    return false;
}

/* ── Find (backward, wraps around) ──────────────────────────────── */

bool editor_find_prev(const Editor *e, const char *needle,
                      int start_line, int start_col,
                      int *fl, int *fc) {
    if (!e || !needle || !*needle || !fl || !fc) return false;
    int total = editor_line_count(e);
    if (total <= 0) return false;

    /* Clamp start_line (bug fix) */
    if (start_line < 0)      start_line = 0;
    if (start_line >= total) start_line = total - 1;

    static char lb[LINE_MAX];
    int nlen = (int)strlen(needle); /* moved outside inner loops */

    for (int pass = 0; pass < 2; pass++) {
        /* pass 0: backward from start_line down to 0
         * pass 1: wrap — from last line down to start_line             */
        int lo = (pass == 0) ? 0           : start_line;
        int hi = (pass == 0) ? start_line + 1 : total;

        for (int li = hi - 1; li >= lo; li--) {
            editor_get_line(e, li, lb, sizeof(lb));
            int llen = (int)strlen(lb);

            /* On the starting line in pass 0, restrict to cols < start_col */
            int search_end = llen;
            if (pass == 0 && li == start_line) {
                search_end = start_col; /* exclusive upper bound */
                if (search_end <= 0) continue;
                if (search_end > llen) search_end = llen;
            }

            /* Find the last occurrence of needle in lb[0..search_end-1] */
            int best = -1;
            int sc   = 0;
            while (sc + nlen <= search_end) {
                const char *found = strstr(lb + sc, needle);
                if (!found) break;
                int col = (int)(found - lb);
                if (col < search_end) {
                    best = col;
                    sc   = col + 1;
                } else {
                    break;
                }
            }
            if (best >= 0) {
                *fl = li;
                *fc = best;
                return true;
            }
        }
    }
    return false;
}

/* ── Replace ─────────────────────────────────────────────────────── */

bool editor_replace_at(Editor *e, int line, int col,
                       int needle_len, const char *replacement) {
    if (!e || !replacement || needle_len < 0 || col < 0) return false;
    static char lb[LINE_MAX];
    static char nb[LINE_MAX];
    editor_get_line(e, line, lb, sizeof(lb));
    int llen = (int)strlen(lb);
    if (col > llen || col + needle_len > llen) return false;
    int rlen    = (int)strlen(replacement);
    int new_len = llen - needle_len + rlen;
    if (new_len < 0 || new_len >= LINE_MAX) return false;
    memcpy(nb,               lb,              col);
    memcpy(nb + col,         replacement,     rlen);
    memcpy(nb + col + rlen,  lb + col + needle_len,
           (size_t)(llen - col - needle_len));
    nb[new_len] = '\0';
    editor_set_line(e, line, nb);
    return true;
}
