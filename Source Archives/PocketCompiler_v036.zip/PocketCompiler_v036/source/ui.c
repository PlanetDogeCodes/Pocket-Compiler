/*
 * ui.c — Citro2D UI for Pocket Compiler v0.36
 *
 * v0.36 changes (over v0.35):
 *  - ALL non-code bottom-screen text enlarged for 3DS 240p readability.
 *    Minimum UI font scale raised from 0.30–0.38 to 0.44–0.52.
 *  - Hint bar is now TWO lines (32px tall) with shorter, clearer labels.
 *  - Controls screen text enlarged (0.44f key / 0.42f description) with
 *    per-row height raised to 17px; all description strings shortened to fit.
 *  - Tab bar labels enlarged from 0.38f to 0.48f.
 *  - Console log lines enlarged from 0.38f to 0.46f; line height 17px.
 *  - Find bar text enlarged; find-bar hint uses a single clear T() call.
 *  - draw_console(): i < WJS_LOG_MAX_LINES guard added (crash fix).
 *  - Version string updated to v0.36.
 */
#include "ui.h"
#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include "web_js.h"
#include "web_engine.h"
#include "web_render.h"
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════
   COLOUR PALETTE
   ═══════════════════════════════════════════════════════════ */
#define C_BG       C2D_Color32(0x00,0x00,0x00,0xFF)
#define C_PANEL    C2D_Color32(0x0C,0x0C,0x0C,0xFF)
#define C_PANEL2   C2D_Color32(0x18,0x18,0x18,0xFF)
#define C_BORDER   C2D_Color32(0x2E,0x2E,0x2E,0xFF)
#define C_SEL      C2D_Color32(0x22,0x22,0x22,0xFF)
#define C_CURLINE  C2D_Color32(0x1A,0x1A,0x1A,0xFF)
#define C_HOVER    C2D_Color32(0x18,0x18,0x18,0xFF)
#define C_MIDGREY  C2D_Color32(0x22,0x22,0x22,0xFF)
#define C_MATCH    C2D_Color32(0x2A,0x2A,0x2A,0xFF)
#define C_WHITE    C2D_Color32(0xFF,0xFF,0xFF,0xFF)
#define C_TEXT     C_WHITE
#define C_DIM      C2D_Color32(0xAA,0xAA,0xAA,0xFF)
#define C_BORDER2  C2D_Color32(0x44,0x44,0x44,0xFF)

/* Syntax highlight colours */
#define C_TAG      C2D_Color32(0x79,0xC0,0xFF,0xFF)
#define C_VAL      C2D_Color32(0xA3,0xD9,0x91,0xFF)
#define C_CMT      C2D_Color32(0x57,0x5F,0x68,0xFF)
#define C_DOCTYPE  C2D_Color32(0xFF,0xA6,0x57,0xFF)

/* Console entry colours */
#define C_LOG_CMD  C2D_Color32(0xAA,0xAA,0xAA,0xFF)
#define C_LOG_RES  C2D_Color32(0x79,0xC0,0xFF,0xFF)
#define C_LOG_ERR  C2D_Color32(0xFF,0x80,0x80,0xFF)
#define C_LOG_NOTE C2D_Color32(0xFF,0xC0,0x60,0xFF)

/* Cursors */
#define C_DOT_BOT  C2D_Color32(0xFF,0xFF,0xFF,0xBB)
#define C_DOT_TOP  C2D_Color32(0xFF,0xFF,0xFF,0xBB)
#define C_DOT_LCK  C2D_Color32(0xCC,0xCC,0xCC,0xCC)

/* ═══════════════════════════════════════════════════════════
   FONT SCALES
   Code text stays at FS_ED; all UI text uses the larger scales.
   ═══════════════════════════════════════════════════════════ */
#define FS_ED    0.42f   /* code lines in editor — unchanged         */
#define FS_UI    0.52f   /* main UI text (headers, labels, FE items) */
#define FS_H     0.60f   /* section headers / mode titles            */
#define FS_HINT  0.44f   /* hint-bar lines                           */
#define FS_TAB   0.48f   /* tab bar labels                           */
#define FS_CTRL  0.44f   /* controls screen — key column             */
#define FS_CTRD  0.42f   /* controls screen — description column     */
#define FS_CON   0.46f   /* console log lines                        */
#define FS_FIND  0.46f   /* find bar text                            */
#define FS_PILL  0.40f   /* feature pills on top screen              */

/* ═══════════════════════════════════════════════════════════
   LAYOUT
   ═══════════════════════════════════════════════════════════ */
#define TOP_W   400.0f
#define TOP_H   240.0f
#define BOT_W   320.0f
#define BOT_H   240.0f
#define MAR       6.0f
#define PAD       5.0f
#define RAD       7.0f
#define RAD_S     4.0f
#define LH_ED    15.0f   /* code line height */

/* Editor panel — occupies the middle of the bottom screen.
 * TAB_H must match LAYOUT_ED_Y in main.c (both are 26).            */
#define TAB_H    26.0f   /* tab bar height                           */
#define ED_X     (MAR)
#define ED_Y     (TAB_H + 2.0f)   /* = 28.0  — matches main.c       */
#define ED_W     (BOT_W - 2*MAR)
#define HINT_H   34.0f             /* two-line hint bar               */
#define ED_H     (BOT_H - ED_Y - HINT_H)   /* 240-28-34 = 178        */
#define LNUM_W   22.0f
#define CODE_X   (ED_X + PAD + LNUM_W)

/* File explorer */
#define FE_X     (MAR)
#define FE_Y     (TAB_H + 2.0f)
#define FE_W     (BOT_W - 2*MAR)
#define FE_H     (BOT_H - FE_Y - HINT_H)
#define LH_FE    23.0f

/* Console */
#define CON_VISIBLE  10
#define CON_LH       17.0f

/* Find bar (overlaid at bottom over the hint area) */
#define FIND_ROW1_H  17.0f
#define FIND_ROW2_H  17.0f
#define FIND_BAR_H   (FIND_ROW1_H + FIND_ROW2_H + 4.0f)  /* 38 */

/* ═══════════════════════════════════════════════════════════
   COMPILED HTML SNAPSHOT
   ═══════════════════════════════════════════════════════════ */
static char s_compiled_html[EDITOR_MAX];
static bool s_has_compiled  = false;
static bool s_render_dirty  = false;
static int  s_out_n         = 0;

int  ui_get_out_count(void){ return s_out_n; }
void ui_set_compiled(const char *html){
    if(html){ strncpy(s_compiled_html,html,EDITOR_MAX-1); s_compiled_html[EDITOR_MAX-1]='\0'; }
    else { s_compiled_html[0]='\0'; }
    s_has_compiled = (html != NULL);
    s_render_dirty = true;
}

/* ═══════════════════════════════════════════════════════════
   RENDER STATE
   ═══════════════════════════════════════════════════════════ */
static C3D_RenderTarget *s_top;
static C3D_RenderTarget *s_bot;
static C2D_TextBuf       s_tb;

/* ═══════════════════════════════════════════════════════════
   DRAWING PRIMITIVES
   ═══════════════════════════════════════════════════════════ */
static void rr(float x,float y,float w,float h,float r,u32 c){
    if(r>w*.5f)r=w*.5f; if(r>h*.5f)r=h*.5f;
    if(r<1.f){C2D_DrawRectSolid(x,y,.5f,w,h,c);return;}
    C2D_DrawRectSolid(x+r,y,.5f,w-2*r,h,c);
    C2D_DrawRectSolid(x,y+r,.5f,r,h-2*r,c);
    C2D_DrawRectSolid(x+w-r,y+r,.5f,r,h-2*r,c);
    C2D_DrawCircleSolid(x+r,y+r,.5f,r,c);
    C2D_DrawCircleSolid(x+w-r,y+r,.5f,r,c);
    C2D_DrawCircleSolid(x+r,y+h-r,.5f,r,c);
    C2D_DrawCircleSolid(x+w-r,y+h-r,.5f,r,c);
}
static void rr_out(float x,float y,float w,float h,float r,u32 bd,u32 fl){
    rr(x,y,w,h,r,bd);
    float b=1.5f; rr(x+b,y+b,w-2*b,h-2*b,r>b?r-b:0.f,fl);
}
static void T(const char *s,float x,float y,float sc,u32 col){
    if(!s||!*s)return;
    C2D_Text t; C2D_TextParse(&t,s_tb,s); C2D_TextOptimize(&t);
    C2D_DrawText(&t,C2D_WithColor,x,y,.5f,sc,sc,col);
}
static float TW(const char *s,float sc){
    if(!s||!*s)return 0.f;
    C2D_Text t; C2D_TextParse(&t,s_tb,s); float w=0,h=0;
    C2D_TextGetDimensions(&t,sc,sc,&w,&h); return w;
}
static void TC(const char *s,float cx,float y,float sc,u32 col){
    T(s,cx-TW(s,sc)*.5f,y,sc,col);
}

/* ═══════════════════════════════════════════════════════════
   HTML SYNTAX HIGHLIGHTER (editor display only)
   ═══════════════════════════════════════════════════════════ */
typedef struct{int start;int len;u32 color;}Span;
#define MAX_SPANS 40

static int tokenize(const char *line,Span *out,int max){
    int ns=0,len=(int)strlen(line);
    if(!len)return 0;
    if(strncmp(line,"<!--",4)==0){out[0]=(Span){0,len,C_CMT};return 1;}
    if(strncmp(line,"<!D",3)==0||strncmp(line,"<!d",3)==0){out[0]=(Span){0,len,C_DOCTYPE};return 1;}
    typedef enum{S_N,S_T,S_V}St;
    St st=S_N; u32 cc=C_TEXT; int cs=0;
#define FL(e) if((e)>cs&&ns<max){out[ns++]=(Span){cs,(e)-cs,cc};cs=(e);}
    for(int i=0;i<=len;i++){
        char c=(i<len)?line[i]:'\0';
        if(st==S_N){if(c=='<'){FL(i);st=S_T;cc=C_TAG;cs=i;}}
        else if(st==S_T){if(c=='>'){FL(i+1);st=S_N;cc=C_TEXT;cs=i+1;}else if(c=='"'){FL(i);st=S_V;cc=C_VAL;cs=i;}}
        else if(st==S_V){if(c=='"'){FL(i+1);st=S_T;cc=C_TAG;cs=i+1;}}
        if(c=='\0')FL(len);
    }
#undef FL
    return ns;
}
static void draw_code_line(const char *line,float x,float y,float sc){
    Span spans[MAX_SPANS]; char buf[LINE_MAX];
    int ns=tokenize(line,spans,MAX_SPANS); float cx=x;
    for(int i=0;i<ns;i++){
        int sl=spans[i].len; if(sl<=0)continue; if(sl>=LINE_MAX)sl=LINE_MAX-1;
        memcpy(buf,line+spans[i].start,sl); buf[sl]='\0';
        T(buf,cx,y,sc,spans[i].color); cx+=TW(buf,sc);
    }
}

/* ═══════════════════════════════════════════════════════════
   HTML OUTPUT RENDERER  (fallback top-screen text display)
   ═══════════════════════════════════════════════════════════ */
#define OUT_MAX  22
#define OUT_LINE 64
typedef struct{char text[OUT_LINE];int level;bool interactive;}OutLine;
static OutLine s_out[OUT_MAX];

static void get_tag_name(const char *raw,char *dst,int sz){
    int i=0; const char *p=raw;
    if(*p=='/'&&i<sz-1){dst[i++]='/';p++;}
    while(*p&&*p!=' '&&*p!='/'&&*p!='>'&&i<sz-1){char c=(*p>='A'&&*p<='Z')?*p+32:*p;dst[i++]=c;p++;}
    dst[i]='\0';
}

static void html_render(const char *html){
    s_out_n=0; if(!html||!*html)return;
    char lbuf[OUT_LINE];int lpos=0;
    int level=0; bool skip=false,in_body=false,in_tag=false,in_cmt=false,in_ia=false;
    char tagbuf[128];int tpos=0; bool last_sp=false;
    if(!strstr(html,"<body")&&!strstr(html,"<BODY"))in_body=true;
    memset(lbuf,0,sizeof(lbuf));

#define CMT()  do{lbuf[lpos]='\0';while(lpos>0&&lbuf[lpos-1]==' ')lbuf[--lpos]='\0';\
    if(lpos>0&&s_out_n<OUT_MAX){strncpy(s_out[s_out_n].text,lbuf,OUT_LINE-1);\
    s_out[s_out_n].level=level;s_out[s_out_n].interactive=in_ia;s_out_n++;}\
    lpos=0;last_sp=false;memset(lbuf,0,sizeof(lbuf));}while(0)
#define APD(ch) do{char _c=(ch);if(_c==' '||_c=='\t'){if(!last_sp&&lpos>0&&lpos<OUT_LINE-1){lbuf[lpos++]=' ';last_sp=true;}}else if(lpos<OUT_LINE-1){lbuf[lpos++]=_c;last_sp=false;}}while(0)

    const char *p=html;
    while(*p){
        char c=*p;
        if(!in_tag&&!in_cmt&&c=='<'&&strncmp(p,"<!--",4)==0){in_cmt=true;p+=4;continue;}
        if(in_cmt){if(strncmp(p,"-->",3)==0){in_cmt=false;p+=3;}else p++;continue;}
        if(c=='<'){in_tag=true;tpos=0;memset(tagbuf,0,sizeof(tagbuf));}
        else if(in_tag){
            if(c=='>'){
                in_tag=false;tagbuf[tpos]='\0';
                char tn[32];get_tag_name(tagbuf,tn,sizeof(tn));
                if(!strcmp(tn,"head")||!strcmp(tn,"script")||!strcmp(tn,"style")||!strcmp(tn,"title")||!strcmp(tn,"meta")||!strcmp(tn,"link"))skip=true;
                else if(!strcmp(tn,"/head")||!strcmp(tn,"/script")||!strcmp(tn,"/style")||!strcmp(tn,"/title"))skip=false;
                else if(!strncmp(tn,"body",4)){in_body=true;skip=false;}
                else if(in_body&&!skip){
                    if(!strcmp(tn,"h1")){CMT();level=1;}
                    else if(!strcmp(tn,"h2")){CMT();level=2;}
                    else if(!strcmp(tn,"h3")||!strcmp(tn,"h4")||!strcmp(tn,"h5")||!strcmp(tn,"h6")){CMT();level=3;}
                    else if(tn[0]=='/'&&tn[1]=='h'&&tn[2]>='1'&&tn[2]<='6'){CMT();level=0;}
                    else if(!strcmp(tn,"p")||!strcmp(tn,"/p")||!strcmp(tn,"div")||!strcmp(tn,"/div")||!strcmp(tn,"section")||!strcmp(tn,"/section")||!strcmp(tn,"article")||!strcmp(tn,"/article")){CMT();}
                    else if(!strcmp(tn,"br")||!strcmp(tn,"br/")){CMT();}
                    else if(!strcmp(tn,"li")){CMT();level=4;if(lpos+2<OUT_LINE-1){lbuf[lpos++]='-';lbuf[lpos++]=' ';last_sp=true;}}
                    else if(!strcmp(tn,"/li")){CMT();level=0;}
                    else if(!strcmp(tn,"ul")||!strcmp(tn,"/ul")||!strcmp(tn,"ol")||!strcmp(tn,"/ol")){CMT();}
                    else if(!strcmp(tn,"hr")){CMT();strncpy(s_out[s_out_n].text,"--------------------",OUT_LINE-1);s_out[s_out_n].level=0;s_out[s_out_n].interactive=false;if(s_out_n<OUT_MAX)s_out_n++;}
                    else if(!strcmp(tn,"a")||!strcmp(tn,"button")){CMT();in_ia=true;}
                    else if(!strcmp(tn,"/a")||!strcmp(tn,"/button")){CMT();in_ia=false;}
                    else if(!strcmp(tn,"img")){
                        CMT();
                        const char *alt=strstr(tagbuf,"alt=\"");
                        if(alt){alt+=5;const char *ae=strchr(alt,'"');int al=ae?(int)(ae-alt):0;
                            if(al>0&&al<OUT_LINE-12){char ib[OUT_LINE]="[";strncat(ib,alt,(size_t)al);strncat(ib,"]",1);strncpy(s_out[s_out_n].text,ib,OUT_LINE-1);}
                            else strncpy(s_out[s_out_n].text,"[image]",OUT_LINE-1);}
                        else strncpy(s_out[s_out_n].text,"[image]",OUT_LINE-1);
                        s_out[s_out_n].level=0;s_out[s_out_n].interactive=false;if(s_out_n<OUT_MAX)s_out_n++;
                    }
                }
            }else{if(tpos<126)tagbuf[tpos++]=c;}
        }else if(in_body&&!skip){
            if(c=='\n'||c=='\r'||c=='\t'){APD(' ');}
            else if(c=='&'){
                const char *e=p+1;char ent[12]={0};int ei=0;
                while(*e&&*e!=';'&&*e!='<'&&*e!=' '&&ei<10)ent[ei++]=*e++;
                if(*e==';'){char ec=0;
                    if(!strcmp(ent,"amp"))ec='&';else if(!strcmp(ent,"lt"))ec='<';
                    else if(!strcmp(ent,"gt"))ec='>';else if(!strcmp(ent,"nbsp"))ec=' ';
                    else if(!strcmp(ent,"quot"))ec='"';else if(!strcmp(ent,"apos")||!strcmp(ent,"#39"))ec='\'';
                    if(ec){APD(ec);p=e;}else APD(c);}else APD(c);
            }else APD(c);
        }
        p++;
    }
    CMT();
#undef CMT
#undef APD
}

/* ═══════════════════════════════════════════════════════════
   FEATURE PILLS  (top screen)
   ═══════════════════════════════════════════════════════════ */
static void pill(const char *lbl,float x,float y,bool active){
    float pw=TW(lbl,FS_PILL)+8.f,ph=13.f;
    rr_out(x,y,pw,ph,RAD_S,active?C_WHITE:C_BORDER,active?C_MIDGREY:C_PANEL2);
    T(lbl,x+4.f,y+2.f,FS_PILL,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   TOP SCREEN
   ═══════════════════════════════════════════════════════════ */
static void draw_top(const AppState *app,const Editor *e,const FeatureRuntime *rt){
    (void)e;
    if(s_render_dirty){
        if(s_has_compiled)html_render(s_compiled_html); else s_out_n=0;
        s_render_dirty=false;
    }

    if(app->run_mode){
        if(g_web_engine.loaded){
            we_render();
            wrender_cursor(app->top_cursor_x,app->top_cursor_y,app->cursor_locked);
            C2D_DrawRectSolid(0,0,0,TOP_W,14,C2D_Color32(0x0E,0x0E,0x0E,0xFF));
            C2D_DrawRectSolid(0,13,0,TOP_W,1,C2D_Color32(0x33,0x33,0x33,0xFF));
            T("RUNNING",MAR,1.5f,0.40f,C_WHITE);
            T(app->cursor_locked?"LOCKED":"ACTIVE",TOP_W-52.f,1.5f,0.38f,C_WHITE);
            const char *pg=we_get_title();
            if(pg&&*pg)T(pg,60.f,1.5f,0.38f,C_DIM);
        }else{
            rr(0,0,TOP_W,20,0,C_PANEL);
            T("RUNNING",MAR,3.f,FS_H,C_WHITE);
            T(app->cursor_locked?"LOCKED":"ACTIVE",TOP_W-56.f,4.5f,FS_UI,C_WHITE);
            float py0=22.f,ph=TOP_H-py0-3.f;
            rr_out(MAR,py0,TOP_W-2*MAR,ph,RAD,C_BORDER,C_PANEL);
            float ty=py0+4.f,my=py0+ph-4.f;
            int scroll=app->out_scroll;
            if(scroll<0)scroll=0; if(scroll>=s_out_n&&s_out_n>0)scroll=s_out_n-1;
            if(s_out_n==0){TC("(no output)",(MAR+TOP_W-MAR)*.5f,py0+ph*.5f-6.f,FS_UI,C_WHITE);}
            else for(int i=scroll;i<s_out_n&&ty<my;i++){
                float sc,lh;
                switch(s_out[i].level){case 1:sc=FS_H;lh=19.f;break;case 2:sc=FS_UI;lh=17.f;break;case 3:sc=0.48f;lh=16.f;break;default:sc=FS_ED;lh=14.f;break;}
                bool isf=(app->click_flash>0&&app->click_line==i);
                bool ish=(!isf&&app->top_cursor_y>=ty&&app->top_cursor_y<ty+lh);
                if(isf)rr(MAR+2,ty-1,TOP_W-2*MAR-4,lh+1,RAD_S,C2D_Color32(0x2A,0x2A,0x2A,0xFF));
                else if(ish)rr(MAR+2,ty-1,TOP_W-2*MAR-4,lh+1,RAD_S,C_HOVER);
                char tb[OUT_LINE];strncpy(tb,s_out[i].text,OUT_LINE-1);tb[OUT_LINE-1]='\0';
                T(tb,MAR+PAD+2.f,ty,sc,s_out[i].interactive?C_TAG:C_WHITE);
                ty+=lh;
            }
            if(s_out_n>14){float sx=MAR+TOP_W-2*MAR-8,sy=py0+4,sh=ph-8;
                float fr=(s_out_n>1)?(float)scroll/(float)(s_out_n-1):0.f;
                C2D_DrawRectSolid(sx,sy,.5f,3,sh,C_PANEL2);rr(sx,sy+fr*(sh-10),3,10,1.5f,C_WHITE);}
            u32 cd=app->cursor_locked?C_DOT_LCK:C_DOT_TOP;
            C2D_DrawCircleSolid(app->top_cursor_x,app->top_cursor_y,.6f,4.f,cd);
        }
        return;
    }

    /* Normal mode top screen */
    rr(0,0,TOP_W,20,0,C_PANEL);
    T("Pocket Compiler",MAR,3.f,FS_H,C_WHITE);
    T("v0.36",TOP_W-40.f,4.5f,FS_UI,C_WHITE);

    float px=MAR,py=26.f;
    pill("DOM",   px,py,rt->dom);      px+=TW("DOM",   FS_PILL)+14;
    pill("Fetch", px,py,rt->fetch);    px+=TW("Fetch", FS_PILL)+14;
    pill("Img",   px,py,rt->images);   px+=TW("Img",   FS_PILL)+14;
    pill("Canvas",px,py,rt->canvas);   px+=TW("Canvas",FS_PILL)+14;
    pill("WebGL", px,py,rt->webgl);
    px=MAR; py=43.f;
    pill("Audio",  px,py,rt->audio);   px+=TW("Audio",  FS_PILL)+14;
    pill("Storage",px,py,rt->storage); px+=TW("Storage",FS_PILL)+14;
    pill("IDB",    px,py,rt->indexeddb);px+=TW("IDB",  FS_PILL)+14;
    pill("iframe", px,py,rt->iframe);

    rr(MAR,60.f,TOP_W-2*MAR,15.f,RAD_S,C_PANEL2);
    char sm[60];strncpy(sm,rt->status_msg,59);sm[59]='\0';
    T(sm,MAR+PAD,62.f,.42f,C_WHITE);

    float py0=79.f,ph=TOP_H-py0-MAR;
    rr_out(MAR,py0,TOP_W-2*MAR,ph,RAD,C_BORDER,C_PANEL);
    T("OUTPUT",MAR+PAD,py0+3.f,0.40f,C_WHITE);
    C2D_DrawRectSolid(MAR+2,py0+14.f,.5f,TOP_W-2*MAR-4.f,1.f,C_BORDER);
    float ty=py0+18.f,my=py0+ph-4.f;
    if(s_out_n==0){TC("(press START to compile)",(MAR+TOP_W-MAR)*.5f,py0+ph*.5f-6.f,FS_UI,C_WHITE);}
    else for(int i=0;i<s_out_n&&ty<my;i++){
        float sc,lh;
        switch(s_out[i].level){case 1:sc=FS_H;lh=19.f;break;case 2:sc=FS_UI;lh=17.f;break;case 3:sc=0.48f;lh=16.f;break;default:sc=FS_ED;lh=14.f;break;}
        char tb[OUT_LINE];strncpy(tb,s_out[i].text,OUT_LINE-1);tb[OUT_LINE-1]='\0';
        T(tb,MAR+PAD+2.f,ty,sc,s_out[i].interactive?C_TAG:C_WHITE);ty+=lh;
    }
}

/* ═══════════════════════════════════════════════════════════
   TAB BAR  (top of bottom screen in edit / find mode)
   ═══════════════════════════════════════════════════════════ */
static void draw_tab_bar(bool console_active){
    rr(0,0,BOT_W,TAB_H,0,C_PANEL);
    float tw=(BOT_W-2*MAR)*0.5f-2.f;

    /* EDITOR tab */
    bool ea=!console_active;
    rr_out(MAR,3.f,tw,TAB_H-5.f,RAD_S,ea?C_WHITE:C_BORDER,ea?C_MIDGREY:C_PANEL2);
    TC("EDITOR",MAR+tw*.5f,5.5f,FS_TAB,C_WHITE);

    /* CONSOLE tab */
    float tx=MAR+tw+4.f;
    bool ca=console_active;
    rr_out(tx,3.f,tw,TAB_H-5.f,RAD_S,ca?C_WHITE:C_BORDER,ca?C_MIDGREY:C_PANEL2);
    TC("CONSOLE",tx+tw*.5f,5.5f,FS_TAB,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — EDITOR TAB
   ═══════════════════════════════════════════════════════════ */
static void draw_edit(const AppState *app,const Editor *e){
    draw_tab_bar(false);

    /* Line counter in top-right of tab bar */
    int total=editor_line_count(e);
    int hover_line=e->scroll_offset+app->code_cursor_line;
    if(hover_line>=total)hover_line=total-1;
    char lc[24]; snprintf(lc,sizeof(lc),"%d/%d",hover_line+1,total);
    T(lc,BOT_W-TW(lc,FS_HINT)-MAR,6.f,FS_HINT,C_WHITE);

    /* Editor panel */
    rr_out(ED_X,ED_Y,ED_W,ED_H,RAD,C_BORDER,C_PANEL);

    int start=e->scroll_offset;
    int end_l=start+CODE_AREA_H; if(end_l>total)end_l=total;
    int vl=app->view_left;
    bool in_code=(app->cursor_x>=ED_X&&app->cursor_x<ED_X+ED_W&&
                  app->cursor_y>=ED_Y+PAD&&app->cursor_y<ED_Y+ED_H);
    bool in_find=(app->mode==MODE_FIND);
    bool has_match=(in_find&&app->find_has_match&&app->find_match_line>=0);

    char lb[LINE_MAX],nb[8];
    for(int i=start;i<end_l;i++){
        float ry=ED_Y+PAD+(i-start)*LH_ED;
        bool ia=(i==e->cursor_line);
        bool ih=(in_code&&(i-start)==app->code_cursor_line);
        bool im=(has_match&&i==app->find_match_line);
        if(im)      rr_out(ED_X+2,ry-1,ED_W-4,LH_ED+1,RAD_S,C_WHITE,C_MATCH);
        else if(ia) rr(ED_X+2,ry-1,ED_W-4,LH_ED+1,RAD_S,C_CURLINE);
        else if(ih) rr(ED_X+2,ry-1,ED_W-4,LH_ED+1,RAD_S,C_HOVER);
        snprintf(nb,sizeof(nb),"%3d",i+1);
        T(nb,ED_X+PAD,ry,FS_ED,C_WHITE);
        C2D_DrawRectSolid(ED_X+PAD+LNUM_W-3,ry,.5f,1.5f,LH_ED-2,C_BORDER);
        editor_get_line(e,i,lb,sizeof(lb));
        char disp[CODE_AREA_W+2];
        int ll=(int)strlen(lb);
        if(vl>=ll)disp[0]='\0';
        else{strncpy(disp,lb+vl,CODE_AREA_W);disp[CODE_AREA_W]='\0';}
        draw_code_line(disp,CODE_X,ry,FS_ED);
    }

    /* Scrollbar */
    if(total>CODE_AREA_H){
        float sx=ED_X+ED_W-5,sh=ED_H-2*PAD;
        float th=sh*CODE_AREA_H/(float)total; if(th<10)th=10;
        float ty2=ED_Y+PAD+sh*e->scroll_offset/(float)total;
        C2D_DrawRectSolid(sx,ED_Y+PAD,.5f,3,sh,C_PANEL2);
        rr(sx,ty2,3,th,1.5f,C_WHITE);
    }

    /* Horizontal scroll indicator */
    if(vl>0){
        char hsi[14]; snprintf(hsi,sizeof(hsi),"<col%d",vl+1);
        float hx=ED_X+ED_W-TW(hsi,.38f)-PAD, hy=ED_Y+ED_H-12.f;
        rr(hx-2,hy-1,TW(hsi,.38f)+4,11,RAD_S,C_PANEL2);
        T(hsi,hx,hy,.38f,C_WHITE);
    }

    /* Two-line hint bar */
    float hy=ED_Y+ED_H+2.f;
    rr(0,hy,BOT_W,HINT_H,0,C_PANEL);
    C2D_DrawRectSolid(0,hy,.5f,BOT_W,1.f,C_BORDER);
    T("A:edit  B:undo  L:console  R:find",  MAR,hy+3.f,  FS_HINT,C_WHITE);
    T("X:save  Y:load  START:run  SEL:help",MAR,hy+17.f, FS_HINT,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — FIND BAR OVERLAY  (drawn after draw_edit)
   ═══════════════════════════════════════════════════════════ */
static void draw_find_bar(const AppState *app){
    /* Cover the two-line hint area with the find bar */
    float fy=ED_Y+ED_H+2.f;
    rr(0,fy,BOT_W,HINT_H,0,C2D_Color32(0x10,0x10,0x10,0xFF));
    C2D_DrawRectSolid(0,fy,.5f,BOT_W,1.f,C_WHITE);

    /* Row 1: FIND: [query]   match info */
    float y1=fy+3.f;
    T("FIND:",MAR,y1,FS_FIND,C_WHITE);
    float fx=MAR+TW("FIND:",FS_FIND)+4.f;
    float fw=BOT_W*0.56f;

    if(app->find_buf[0]){
        char disp[36]; strncpy(disp,app->find_buf,35); disp[35]='\0';
        rr_out(fx,y1-1.f,fw,FIND_ROW1_H-1.f,RAD_S,C_BORDER2,C_PANEL);
        T(disp,fx+3.f,y1+1.f,FS_FIND,C_TAG);
        /* Match status on right */
        if(app->find_has_match){
            char mi[20]; snprintf(mi,sizeof(mi),"line %d",app->find_match_line+1);
            T(mi,BOT_W-TW(mi,FS_FIND)-MAR,y1+1.f,FS_FIND,C_VAL);
        }else{
            T("no match",BOT_W-TW("no match",FS_FIND)-MAR,y1+1.f,FS_FIND,C_LOG_ERR);
        }
    }else{
        rr_out(fx,y1-1.f,fw,FIND_ROW1_H-1.f,RAD_S,C_BORDER,C_PANEL);
        T("press A to type",fx+3.f,y1+1.f,FS_FIND,C_DIM);
    }

    /* Row 2: REPL field (if set) OR key hints */
    float y2=y1+FIND_ROW1_H+2.f;
    if(app->replace_buf[0]){
        T("REPL:",MAR,y2,FS_FIND,C_WHITE);
        float rx=MAR+TW("REPL:",FS_FIND)+4.f;
        char rd[28]; strncpy(rd,app->replace_buf,27); rd[27]='\0';
        rr_out(rx,y2-1.f,fw,FIND_ROW2_H-1.f,RAD_S,C_BORDER2,C_PANEL);
        T(rd,rx+3.f,y2+1.f,FS_FIND,C_VAL);
    }else{
        T("A:search  Up/Dn:nav  Y:replace  X:all  B:close",
          MAR,y2+1.f,0.40f,C_WHITE);
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — JS CONSOLE TAB
   ═══════════════════════════════════════════════════════════ */
static void draw_console(const AppState *app){
    draw_tab_bar(true);

    float py=TAB_H+2.f;
    float ph=BOT_H-py-HINT_H;
    rr_out(MAR,py,BOT_W-2*MAR,ph,RAD,C_BORDER,C_PANEL);

    int scroll=app->console_scroll;
    if(scroll<0)scroll=0;
    if(scroll>g_wjs_log_n)scroll=g_wjs_log_n;

    float ty=py+PAD, my=py+ph-PAD;

    if(g_wjs_log_n==0){
        TC("(no console output)",BOT_W*.5f,py+ph*.35f,FS_CON,C_DIM);
        if(!g_web_engine.loaded)
            TC("Compile a page first  (START)",BOT_W*.5f,py+ph*.55f,FS_HINT,C_DIM);
    }else{
        /* Bug fix: also guard i < WJS_LOG_MAX_LINES */
        for(int i=scroll; i<g_wjs_log_n && i<WJS_LOG_MAX_LINES && ty<my; i++){
            const char *ln=g_wjs_log[i];
            u32 col=C_WHITE;
            if(ln[0]=='>')         col=C_LOG_CMD;
            else if(ln[0]=='=')    col=C_LOG_RES;
            else if(strncmp(ln,"[Error]",7)==0) col=C_LOG_ERR;
            else if(ln[0]=='[')    col=C_LOG_NOTE;
            char disp[56]; strncpy(disp,ln,55); disp[55]='\0';
            T(disp,MAR+PAD,ty,FS_CON,col);
            ty+=CON_LH;
        }
    }

    /* Scrollbar */
    if(g_wjs_log_n>CON_VISIBLE){
        float sx=MAR+BOT_W-2*MAR-5,sy=py+PAD,sh=ph-2*PAD;
        int   avail=g_wjs_log_n-CON_VISIBLE; if(avail<1)avail=1;
        float fr=(float)scroll/(float)avail; if(fr>1.f)fr=1.f;
        C2D_DrawRectSolid(sx,sy,.5f,3,sh,C_PANEL2);
        rr(sx,sy+fr*(sh-12),3,12,1.5f,C_WHITE);
    }

    /* Two-line hint bar */
    float hy=py+ph+2.f;
    rr(0,hy,BOT_W,HINT_H,0,C_PANEL);
    C2D_DrawRectSolid(0,hy,.5f,BOT_W,1.f,C_BORDER);
    if(g_web_engine.loaded){
        T("A:eval JS    B:clear log    L:editor",MAR,hy+3.f, FS_HINT,C_WHITE);
        T("START:recompile    X:save    Y:load", MAR,hy+17.f,FS_HINT,C_WHITE);
    }else{
        T("No page loaded — START to compile",  MAR,hy+3.f, FS_HINT,C_WHITE);
        T("L:editor    X:save    Y:load",        MAR,hy+17.f,FS_HINT,C_WHITE);
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — RUN MODE
   ═══════════════════════════════════════════════════════════ */
static void draw_running_bot(const AppState *app){
    rr(0,0,BOT_W,BOT_H,0,C_BG);
    rr(MAR,BOT_H*.33f-10,BOT_W-2*MAR,22,RAD,C_PANEL2);
    TC("OUTPUT RUNNING",BOT_W*.5f,BOT_H*.33f-7.f,FS_H,C_WHITE);
    if(app->cursor_locked){
        TC("Cursor LOCKED to output", BOT_W*.5f,BOT_H*.50f,FS_UI,C_WHITE);
        TC("Press X to release",      BOT_W*.5f,BOT_H*.62f,FS_UI,C_WHITE);
    }else{
        TC("Click output to lock cursor",BOT_W*.5f,BOT_H*.50f,FS_UI,C_WHITE);
    }
    float hy=BOT_H-HINT_H;
    rr(0,hy,BOT_W,HINT_H,0,C_PANEL);
    C2D_DrawRectSolid(0,hy,.5f,BOT_W,1.f,C_BORDER);
    T("START:stop    DPad:scroll",            MAR,hy+3.f, FS_HINT,C_WHITE);
    T("A/L:click    B/R:r-click    X:unlock", MAR,hy+17.f,FS_HINT,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — SAVE EXPLORER
   ═══════════════════════════════════════════════════════════ */
static void draw_save(const AppState *app){
    const FileExplorer *fe=&app->fe;
    rr(0,0,BOT_W,TAB_H,0,C_PANEL);
    T("SAVE",MAR,5.f,FS_H,C_WHITE);
    T("A:save  B:back",BOT_W-TW("A:save  B:back",FS_HINT)-MAR,6.f,FS_HINT,C_WHITE);
    rr_out(FE_X,FE_Y,FE_W,FE_H,RAD,C_BORDER,C_PANEL);
    float ry=FE_Y+PAD;
    int total=fe->count+1;
    int ve=fe->scroll+FE_VISIBLE_ROWS; if(ve>total)ve=total;
    for(int row=fe->scroll;row<ve;row++){
        bool sel=(row==fe->cursor);
        if(sel)rr(FE_X+3,ry-1,FE_W-6,LH_FE,RAD_S,C_SEL);
        if(row==0){
            rr_out(FE_X+PAD,ry+1,FE_W-2*PAD-2,LH_FE-4,RAD_S,sel?C_WHITE:C_BORDER,sel?C_MIDGREY:C_PANEL);
            T("+ New File",FE_X+2*PAD,ry+4.f,FS_UI,C_WHITE);
        }else{
            int fi=row-1;
            char fn[32]; strncpy(fn,fe->names[fi],31); fn[31]='\0';
            char sz[10]; fe_format_size(fe->sizes[fi],sz,sizeof(sz));
            T(fn,FE_X+2*PAD,ry+4.f,FS_UI,C_WHITE);
            T(sz,FE_X+FE_W-TW(sz,FS_HINT)-2*PAD,ry+5.f,FS_HINT,C_WHITE);
        }
        ry+=LH_FE;
    }
    float hy=FE_Y+FE_H+2.f;
    rr(0,hy,BOT_W,HINT_H,0,C_PANEL);
    C2D_DrawRectSolid(0,hy,.5f,BOT_W,1.f,C_BORDER);
    if(fe->count>0){char inf[20];snprintf(inf,sizeof(inf),"%d file(s)",fe->count);T(inf,MAR,hy+8.f,FS_HINT,C_WHITE);}
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — LOAD EXPLORER
   ═══════════════════════════════════════════════════════════ */
static void draw_load(const AppState *app){
    const FileExplorer *fe=&app->fe;
    rr(0,0,BOT_W,TAB_H,0,C_PANEL);
    T("LOAD",MAR,5.f,FS_H,C_WHITE);
    T("A:load  B:back",BOT_W-TW("A:load  B:back",FS_HINT)-MAR,6.f,FS_HINT,C_WHITE);
    rr_out(FE_X,FE_Y,FE_W,FE_H,RAD,C_BORDER,C_PANEL);
    if(fe->count==0){
        TC("No .html files on SD card",BOT_W*.5f,FE_Y+FE_H*.35f,FS_UI,C_WHITE);
        TC("Save a project first",    BOT_W*.5f,FE_Y+FE_H*.52f,FS_UI,C_WHITE);
    }else{
        float ry=FE_Y+PAD;
        int er=fe->scroll+FE_VISIBLE_ROWS; if(er>fe->count)er=fe->count;
        for(int row=fe->scroll;row<er;row++){
            bool sel=(row==fe->cursor);
            if(sel)rr(FE_X+3,ry-1,FE_W-6,LH_FE,RAD_S,C_SEL);
            char fn[32]; strncpy(fn,fe->names[row],31); fn[31]='\0';
            char sz[10]; fe_format_size(fe->sizes[row],sz,sizeof(sz));
            T(fn,FE_X+2*PAD,ry+4.f,FS_UI,C_WHITE);
            T(sz,FE_X+FE_W-TW(sz,FS_HINT)-2*PAD,ry+5.f,FS_HINT,C_WHITE);
            ry+=LH_FE;
        }
        if(fe->count>FE_VISIBLE_ROWS){
            float sx=FE_X+FE_W-5,sy=FE_Y+PAD,sh=FE_H-2*PAD;
            float th=sh*FE_VISIBLE_ROWS/(float)fe->count; if(th<10)th=10;
            float ty=sy+sh*fe->scroll/(float)fe->count;
            C2D_DrawRectSolid(sx,sy,.5f,3,sh,C_PANEL2);
            rr(sx,ty,3,th,1.5f,C_WHITE);
        }
    }
    float hy=FE_Y+FE_H+2.f;
    rr(0,hy,BOT_W,HINT_H,0,C_PANEL);
    C2D_DrawRectSolid(0,hy,.5f,BOT_W,1.f,C_BORDER);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — CONTROLS REFERENCE
   ═══════════════════════════════════════════════════════════ */
static void draw_controls(void){
    rr(0,0,BOT_W,TAB_H,0,C_PANEL);
    TC("CONTROLS  (SELECT/B to close)",BOT_W*.5f,6.f,FS_UI,C_WHITE);

    rr_out(MAR,TAB_H+2,BOT_W-2*MAR,BOT_H-TAB_H-2-HINT_H,RAD,C_BORDER,C_PANEL);

    /* Key col starts at x=11, desc col at x=80 */
#define KX  (MAR+PAD)
#define DX  (MAR+PAD+74.f)
    static const char *lbl[]={
        "DPad (edit)", "Scroll code  (L/R=cols, U/D=lines)",
        "DPad (run)",  "Scroll output  U/D",
        "Circle pad",  "Move cursor (bottom / top screen)",
        "A",           "Edit line / Left-click (run)",
        "B",           "Undo / Right-click (run)",
        "X",           "Save file / Unlock cursor (run)",
        "Y",           "Load file / Space (run)",
        "L (edit)",    "Toggle JS Console tab",
        "R (edit)",    "Enter Find / Replace",
        "L/R (run)",   "Left / Right mouse click",
        "START",       "Compile+Run / Stop",
        "SELECT",      "This help screen",
        NULL, NULL
    };
    float ry=TAB_H+6.f;
    for(int i=0;lbl[i];i+=2){
        T(lbl[i],  KX, ry, FS_CTRL, C_WHITE);
        T(lbl[i+1],DX, ry, FS_CTRD, C_DIM);
        ry+=17.f;
    }
#undef KX
#undef DX

    float hy=BOT_H-HINT_H;
    rr(0,hy,BOT_W,HINT_H,0,C_PANEL);
    C2D_DrawRectSolid(0,hy,.5f,BOT_W,1.f,C_BORDER);
    TC("SELECT or B to close",BOT_W*.5f,hy+10.f,FS_HINT,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   PUBLIC API
   ═══════════════════════════════════════════════════════════ */
void ui_init(void){
    gfxInitDefault();
    gfxSet3D(false);
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    s_top=C2D_CreateScreenTarget(GFX_TOP,    GFX_LEFT);
    s_bot=C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    s_tb =C2D_TextBufNew(16384);
}

void ui_draw(const AppState *app,const Editor *e,const FeatureRuntime *rt){
    if(!app||!e||!rt)return;
    C2D_TextBufClear(s_tb);
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

    C2D_TargetClear(s_top,C_BG); C2D_SceneBegin(s_top);
    draw_top(app,e,rt);

    C2D_TargetClear(s_bot,C_BG); C2D_SceneBegin(s_bot);
    if(app->run_mode){
        draw_running_bot(app);
    }else{
        switch(app->mode){
            case MODE_EDIT:
                if(app->console_tab) draw_console(app);
                else                 draw_edit(app,e);
                break;
            case MODE_FIND:
                draw_edit(app,e);       /* editor with match highlight */
                draw_find_bar(app);     /* overlaid find bar           */
                break;
            case MODE_SAVE:     draw_save(app);    break;
            case MODE_LOAD:     draw_load(app);    break;
            case MODE_CONTROLS: draw_controls();   break;
            case MODE_PREVIEW:
                rr(0,0,BOT_W,TAB_H,0,C_PANEL);
                TC("PREVIEW",BOT_W*.5f,6.f,FS_H,C_WHITE);
                TC("Press B or START to return",BOT_W*.5f,BOT_H*.5f,FS_UI,C_WHITE);
                break;
            default:
                draw_edit(app,e);
                break;
        }
        /* Bottom-screen cursor dot; hide when find bar covers that y */
        float hide_y=ED_Y+ED_H+2.f;
        if(!(app->mode==MODE_FIND && app->cursor_y>hide_y))
            C2D_DrawCircleSolid(app->cursor_x,app->cursor_y,.6f,3.5f,C_DOT_BOT);
    }
    C3D_FrameEnd(0);
}

void ui_exit(void){
    C2D_TextBufDelete(s_tb);
    C2D_Fini(); C3D_Fini(); gfxExit();
}
