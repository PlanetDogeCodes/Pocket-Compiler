# Pocket Compiler — Changelog

## v0.40 (current) — Rendering audit pass

A full audit of the HTML/CSS/JS rendering pipeline. Every CSS property
in `apply_property()`, every HTML tag in `html_render()` and
`wep_is_block_tag()`, and every computed-style field in the cascade
MERGE was checked for correctness. The render engine was checked for
every parsed style it actually applies. The layout engine was checked
for flex, block, inline, position, and overflow paths.

The single biggest class of bug: **many CSS properties were parsed
and stored on the style struct but never actually used by the
renderer or layout engine.** `opacity`, `font-weight` (bold),
`font-style` (italic), `text-decoration` (underline/strikethrough),
`flex_grow`, and `align-items:stretch` were all silently no-ops. This
pass makes all of them work.

### CSS — cascade MERGE fixes (web_css.c)

- **MERGE cascade was missing ~10 fields.** The cascade step that
  merges stylesheet rules into computed style had `MERGE_*` lines for
  only about 20 of the ~30 fields `apply_property()` actually parses.
  Stylesheet rules setting `align_self`, `overflow_x`, `overflow_y`,
  `min_width`, `min_height`, `max_width`, `max_height`, `z_index`,
  `translate_x`, or `translate_y` were silently dropped. Each now has
  a MERGE line with the correct default-sentinel guard (e.g.
  `MERGE_I16_NEG` for fields where -1 means "auto/unset").

### CSS — shorthand fixes (web_css.c)

- **`background` shorthand misrouted image URLs to color parser.**
  `background: url(bg.png)` would try to parse "url(bg.png)" as a
  color, silently fall back to transparent black, and the element's
  background would vanish. Now: if the value contains `url(`, the
  url() part is stripped and any remaining color token is parsed
  separately (so `background: url(bg.png) red` correctly sets red).
- **`border` shorthand only handled `solid` and used `strrchr(v,' ')`
  to find the color**, which broke on multi-word values and ignored
  all other border styles. Now properly tokenises: width tokens (has
  px/em/rem or starts with a digit), style tokens (solid/dashed/
  dotted/double/none/hidden/groove/ridge/inset/outset), and color
  tokens (everything else). Also handles `border-top/right/bottom/
  left` per-side variants (previously silently dropped).
- **`margin` and `padding` shorthands missing the 3-value form.**
  `margin: 10px 20px 5px` (T / L+R / B) used to fall through to the
  2-value branch and silently drop the third value. Added `vc==3`
  handling matching the CSS spec.
- **`font` shorthand not supported.** Added: tokenises
  `italic bold 14px/16px Arial, sans-serif` into font-style,
  font-weight, font-size (with line-height after `/`), and ignores
  font-family (renderer uses the system font).

### Render engine fixes (web_render.c)

- **`opacity` was parsed but never applied.** The renderer read
  `n->style.opacity` into a local `alpha` and immediately cast it to
  `(void)`. Now scales the alpha byte of every color drawn (text,
  background, border) by `(opacity/255)`, so `opacity:0.5` actually
  makes an element semi-transparent.
- **`font-weight: bold` was parsed but never rendered.** The
  `wrender_text` function accepted a `weight` param and cast it to
  `(void)`. Now fakes bold by drawing the text twice with a 1px
  horizontal offset (standard bitmap-font boldening; the citro2d
  system font has no bold variant).
- **`font-style: italic` was parsed but never rendered.** Added a
  `style` parameter to `wrender_text` and fakes italic by drawing
  twice with a vertical-shear horizontal offset. All 5 call sites
  (text node, input/textarea, canvas fillText/strokeText, engine
  splash, console overlay) updated to the new 10-param signature.
- **`text-decoration: underline/line-through` was parsed but never
  rendered.** Now draws a solid rectangle: underline below the
  baseline, line-through through the vertical middle, both spanning
  the text width.

### Layout engine fixes (web_layout.c)

- **`flex_grow` was parsed but never distributed.** The flex layout
  computed free space along the main axis and used it only for
  `justify-content`. `flex-grow:1` on flex children did nothing. Now:
  if any child has `flex_grow>0`, free space is distributed
  proportionally to grow factors before justify-content runs (and
  consumes all free space, so justify-content becomes a no-op —
  matching browser behaviour).
- **`align-items: stretch` was a no-op.** The flex layout only
  handled `center` (2) and `end` (1); `stretch` (3) fell through to
  the default (start) and did nothing. Now stretches children along
  the cross axis for both row and column directions.

### DOM / tag classification fixes (web_dom.c)

- **`wep_is_block_tag` misclassified invisible tags.** `script`,
  `style`, `title`, `head`, `meta`, `link` were in the block list,
  so they got `display:block` — meaning `<style>foo{}</style>` would
  render "foo{}" as visible block text on the page. Removed from the
  block list; `dom_new_element` now explicitly sets `display:none`
  for these tags, matching browser UA-stylesheet behaviour.
- **`pre` was missing from the block list** (it's block-level).
  Added. Also added `picture`, `dialog`, `menu` for completeness.

### Housekeeping

- On-screen version string bumped to v0.40.
- `navigator.userAgent` updated from "0.38" to "0.40".
- `wrender_text` signature widened from 9 to 10 params (added
  `uint8_t style` for font-style). All 5 call sites updated.

### Verification performed this pass

- `gcc -fsyntax-only -D__3DS__` against every modified file using
  host-side stub headers (all pass clean; remaining errors are
  preexisting stub-only symbols — `C3D_Tex.data`, `svcSleepThread`,
  `ndspInit`, etc. — that are real citro2d/ctru/libndsp symbols not
  present in the host stubs).
- Brace/paren balance checker on all 8 modified files: all OK.
- Cross-reference: every CSS property parsed by `apply_property()`
  now has a corresponding `MERGE_*` line in the cascade; every style
  field read by the renderer is actually populated by the parser;
  every `wrender_text` call site passes the new 10th parameter.

---

## v0.39

Feature pass over v0.38. The theme of this pass is "editor quality-of-
life and never-lose-work resilience" — every change is additive and
none of the v0.38 hardening is regressed. Two genuine bugs found
during the audit are also fixed (see Bug Fixes).

### Editor quality-of-life

- **Multi-level undo.** The editor's undo system was a single buffer
  (one undo step). Expanded into a 5-step ring (`EDITOR_UNDO_STEPS`)
  in `editor.h`/`editor.c`; `editor_snapshot()` and `editor_undo()`
  keep their existing signatures so the three call sites in `main.c`
  are unchanged. Each step holds a full `EDITOR_MAX` snapshot of the
  buffer + cursor line. Ring memory (5 × 64 KB = 320 KB) lives in
  `g_editor`'s BSS — safe because no Editor is ever stack-allocated.
- **Line duplication.** New `editor_duplicate_line()` helper inserts a
  copy of the line at the cursor directly below it and advances the
  cursor onto the new line. Wired to the Actions menu's "Duplicate"
  row. Snapshots first so undo rolls it back.
- **Go-to-line.** New `MODE_GOTO` overlay mirrors the find-bar
  geometry. A types a line number; START or Y jumps to it (1-based,
  clamped to the buffer's line count). B closes the overlay.
- **Block comment/uncomment toggle.** New `editor_toggle_comment()`
  is context-aware: if the buffer looks like an HTML document
  (contains `<!DOCTYPE` or `<html`, case-insensitive) it wraps/unwraps
  the line in `<!-- ` … ` -->`; otherwise (JS/CSS) it toggles a
  leading `// ` after any indentation. Idempotent. Wired to the
  Actions menu's "Comment" row.
- **R is now the Actions menu gateway.** Every face/shoulder button
  in the editor tab was already assigned, so R was repurposed from
  direct find/replace entry to opening a scrollable `MODE_ACTIONS`
  list. The menu is the gateway to Find/Replace (row 0, unchanged
  behavior), Go-to-line, Duplicate line, Comment toggle, Rename file,
  Delete file, Sort cycling, and Export console log. Follows the
  `draw_controls()` scrollable-list pattern verbatim (single
  source-of-truth row array, scrollbar, `PANEL_VISIBLE_ROWS`
  clamping).

### File explorer

- **Sort by name / size / date.** `fe_scan()` previously returned
  results in arbitrary FAT directory order. It now `qsort`s them
  alphabetically by default (`FE_SORT_NAME`), with size-ascending and
  date-as-directory-order selectable via `fe->sort_mode`. The Actions
  menu's "Sort" row cycles the mode and rescans.
- **Delete file.** New `MODE_DELETE` mirrors `MODE_LOAD`'s geometry
  but with a two-step confirm: first A arms (header turns red, hint
  reads "A:CONFIRM B:cancel"), second A deletes. B cancels the arm or
  exits the screen. Touch-tap on a row selects but does not delete.
- **Rename file.** New `MODE_RENAME` mirrors `MODE_DELETE`'s geometry
  but is single-step — the rename keyboard itself is the cancel path.
  Pre-fills with the current filename, auto-appends `.html` if missing
  (mirroring `ensure_html_ext`). If the renamed file was the
  last-opened one, `fe_save_last()` is called so the next launch
  loads the renamed file under its new name.
- **Remember last-opened file.** On any successful save or load,
  `fe_save_last()` persists the filename to `config.txt` (one line,
  null-terminated). On startup, `fe_load_last()` reads it back and
  silently restores the file. First run = no config file = nothing
  happens (correct).
- **Auto-save draft.** Writes the editor buffer to `autosave.html`
  on every compile and after ~10s of input idle (resets the idle
  counter on any button/touch/non-deadzone Circle-Pad movement). Pure
  addition; never touches the normal save/load path. A battery death
  or crash now costs at most one editing session since the last
  compile.

### Console / debugging

- **Console-log timestamps.** Every `wjs_log_push()` line is now
  prefixed with `MM:SS ` (elapsed since first push). The boot-time
  anchor is captured lazily on the first push to avoid cross-TU
  init-order pitfalls with `osGetTime()`.
- **Export console log to SD.** New `wjs_export_log()` appends the
  entire current log to `console_log.txt` with a timestamped header
  (successive exports accumulate a session transcript). Wired to the
  Actions menu's "Export log" row. Non-fatal on any I/O error.

### Web engine (additive)

- **A few more HTML tags** in `html_render()` (`ui.c`): `blockquote`,
  `pre`/`code`, `strong`/`b`, `em`/`i`, `span`/`label`. Each is a
  pure addition to the existing if/else-if chain; no existing tag
  handling is touched. Block tags break the line; inline tags are
  no-ops (their text content already flows through the existing
  per-character append path).
- **A few more CSS properties** in `apply_property()` (`web_css.c`),
  all using fields already present in `CSSStyle`:
  - `align-self` — was in the struct but had no parser case. Mirrors
    `align-items`'s value mapping.
  - `flex-flow` — shorthand setting both `flex-direction` and
    `flex-wrap` from a single `row wrap` / `column nowrap` /
    etc. declaration. Tokenises on whitespace; unknown tokens are
    silently ignored (matching browser leniency).
  - `inset` — shorthand setting `top`/`right`/`bottom`/`left` in one
    declaration. 1/2/3/4-value forms mirror the existing
    `margin`/`padding` shorthand pattern.

### Bug fixes (found during audit)

- **MODE_ACTIONS cursor was stuck on row 0.** The Actions-menu handler
  computed `max_scroll = row_count - PANEL_VISIBLE_ROWS` and clamped
  to 0 — but the menu has fewer rows than the panel fits (9 rows < 10
  visible), so `max_scroll` was always 0 and the DOWN button became a
  no-op, leaving the cursor permanently on "Find/Replace". Fixed by
  using `row_count - 1` as the cursor max (matching how `draw_actions`
  reads `actions_scroll` as both cursor and scroll), so the cursor can
  reach every row.
- **`draw_actions` `sel` variable was computed but never drawn.** The
  existing code computed `bool sel=(i==app->actions_scroll)` and then
  cast it to `(void)sel` to suppress the unused-variable warning. The
  selected row now gets a `C_SEL` highlight band matching every other
  selectable list in the app.
- **`draw_actions` scroll clamp let `scroll==ROW_COUNT` draw nothing.**
  The clamp `if(scroll>ROW_COUNT) scroll=ROW_COUNT` allowed the
  boundary value through, which made the render loop's
  `for(i=scroll; i<ROW_COUNT; ...)` body never execute. Tightened to
  `if(scroll>=ROW_COUNT) scroll=ROW_COUNT-1` with a defensive
  still-empty-table guard.
- **MODE_RENAME overwrote config.txt unconditionally.** The rename
  handler called `fe_save_last(nn)` after every successful rename,
  regardless of whether the renamed file was the last-opened one. If
  the user renamed an unrelated file, `config.txt` would be
  overwritten with a filename they never opened, and the next launch
  would load the wrong file. Fixed: now reads the current config,
  compares against the old filename, and only calls `fe_save_last(nn)`
  if they match.
- **MODE_DELETE left stale config.txt.** If the deleted file was the
  last-opened one, `config.txt` still pointed at the now-nonexistent
  file, and every subsequent launch would silently fail the
  `fe_load_named` call. Fixed: after a successful delete, reads config
  and calls `fe_clear_last()` if the deleted filename matches.
- **Startup gave no feedback on missing last-opened file.** If
  `fe_load_last` succeeded but `fe_load_named` failed (file deleted
  externally, SD card swapped, etc.), the editor silently fell back
  to the default template with no message. Fixed: now shows
  "File not found: X — starting fresh" and calls `fe_clear_last()` to
  prevent repeated failed loads on subsequent launches.
- **Auto-save wrote the same buffer repeatedly during idle.** The
  `autosave_dirty` flag was set to `true` after the first idle
  autosave but never checked or reset, so every subsequent 10-second
  idle window wrote the same buffer to SD again — forever, as long as
  the user was idle. Wasteful SD I/O. Fixed: the idle path now checks
  `!autosave_dirty` before writing, and any input resets
  `autosave_dirty=false` alongside `idle_frames=0`. The compile-time
  force path still always writes.
- **`<code>` tag was treated as block-level in html_render.** The v0.39
  tag additions put `<code>` in the block group (triggering `CMT()` =
  line break), but `<code>` is an inline element. A line like
  `<p>Use <code>printf</code> here</p>` would render as three separate
  lines. Fixed: moved `code`/`/code` to the inline no-op group where
  it belongs (alongside `strong`/`b`/`em`/`i`/`span`/`label`).
- **`wjs_log_push` FIFO branch missing defensive NUL.** The append
  branch had `g_wjs_log[n][WJS_LOG_LINE_LEN-1]='\0'` after `strncpy`
  but the FIFO branch didn't. Not strictly needed (the `prefixed`
  buffer is already guaranteed NUL-terminated within bounds), but the
  asymmetry was a code-smell. Added for belt-and-suspenders
  consistency.
- **`file_explorer.c` used `qsort()` without `<stdlib.h>`.** Worked
  transitively under devkitARM's newlib but is non-portable and
  fragile. Added the explicit include.

### Features added during audit

- **Recover autosave action.** The auto-save draft feature wrote the
  buffer to `FE_AUTOSAVE` on compile and after 10s of idle, but
  nothing ever read it back — the file just sat on the SD card. Added
  a new "Recover auto…" row to the Actions menu (`ACT_RECOVER`) that
  loads `FE_AUTOSAVE` into the editor via the new `fe_load_autosave()`
  function. Mirrors `fe_load_named`'s buffer-loading + undo-ring-reset
  logic. Does NOT touch `config.txt` (the recovered buffer might not
  belong to any named file). The user can then save it to a named file
  via the normal Save path.

### Housekeeping

- On-screen version string bumped to v0.39.
- `navigator.userAgent` retained at v0.38 wording (no JS-runtime
  changes this pass that affect the user-agent string).

### Verification performed this pass

- `gcc -fsyntax-only -D__3DS__` against every modified file using the
  project's real headers plus host-side stub `<3ds.h>`/`<citro2d.h>`
  (all pass clean; remaining stub-only symbols like `C2D_TextOptimize`,
  `C2D_WithColor`, `C3D_TexDelete`, `C2D_DrawImageAt`,
  `shaderProgram_s`, `Result`, `R_SUCCEEDED` are real citro2d/ctru
  symbols not present in the host stubs and are unchanged from
  v0.38).
- Layout-constant cross-check between `main.c` (touch hit-testing)
  and `ui.c` (render geometry): the v0.37 constants remain the
  single source of truth and are untouched by this pass.
- Cross-reference sweep confirming every v0.39 feature claim above is
  actually present in the delivered source (grep for the relevant
  symbols, function names, and enum values).

---

## v0.38

This is a deep-audit bugfix pass covering the JS runtime, DOM/event
system, CSS parser, and layout engine — areas not touched by the
v0.37 UI pass. Every C source file in the project was read in full;
the issues below are every genuine bug found, ranging from a silent
JS runtime break to defensive hardening against 3DS stack-overflow
scenarios.

### Crash / Correctness Fixes

- **Canvas 2D context setup silently broken.** `wc_install_bindings()`
  built its property-accessor setup script (defining `fillStyle`,
  `strokeStyle`, `lineWidth`, `globalAlpha`, `font`, `textAlign`,
  `textBaseline` as getter/setter pairs on the canvas context) via
  `snprintf()` into a 512-byte buffer — but the literal script is 854
  bytes. `snprintf` silently truncated it mid-statement, which broke
  **every** canvas property setter at runtime with zero visible error;
  code like `ctx.fillStyle = 'red'` would silently do nothing. Fixed
  by passing the (fully static, no-interpolation) script directly to
  `duk_eval_string` as a literal — no buffer, no size limit, no
  truncation possible.

- **Event-listener ref truncation.** `DOMEvent.js_ref` was a `uint8_t`
  (max 255), but the ref counter driving it climbs by one on every
  `addEventListener()` call. Past the 255th listener registered in a
  session, the ref silently wrapped and the **wrong** JS callback
  could fire for a given event — a correctness bug with no error or
  warning. Widened to `uint16_t` (65,535 listeners of headroom, far
  beyond anything reachable given the 1024-node DOM pool cap).

- **Event-listener ref counter never reset across page reloads.** The
  counter backing the fix above was a function-local `static int`
  inside `js_node_addEventListener` that persisted for the entire
  program lifetime. Every recompile (START) creates a brand-new
  Duktape heap/stash, but the ref counter kept climbing from the
  previous session instead of resetting alongside it — over a very
  long editing session with many recompiles, this could still
  eventually approach the (now much larger) `uint16_t` ceiling. Moved
  to file scope with an explicit reset, now called from
  `wjs_create_context()` on every fresh page load, matching the fresh
  heap/stash it already gets.

- **`we_document_open()` used unchecked raw array indexing.** Its
  child-removal loop read `g_dom_nodes[ch]` directly while walking a
  `next_sib` chain. If that chain were ever corrupted by an unrelated
  bug, this had no bounds check and could read out-of-bounds memory or
  feed a garbage index into `dom_remove_child()`. Switched to the
  existing bounds-checked `dom_node()` accessor, which returns `NULL`
  safely and lets the loop terminate instead.

### Stack-Safety Hardening (3DS has a 256 KB main-thread stack)

- **CSS parser: ~3 KB combined stack buffers in one call chain.**
  `css_parse_inline()`'s 2048-byte buffer and `css_parse_stylesheet()`'s
  1024-byte `decl_buf` were both ordinary (non-`static`) stack
  buffers — and the former is called from inside the latter while its
  locals are still live, putting over 3 KB on the stack simultaneously
  in a single call chain. Both made `static`, matching the pattern
  already used for large buffers elsewhere in this codebase (see
  `editor.c`, `file_explorer.c`). Verified safe: CSS parsing is
  strictly sequential and never re-entrant — no call site invokes
  either function while another call is already in progress.

- **Layout engine had no recursion depth limit.** `layout_node()` and
  `layout_children()` mutually recurse once per level of DOM nesting,
  with no cap. The DOM pool allows up to 1024 nodes, so a pathological
  linear chain of nested elements — whether pasted directly as HTML or
  built at runtime via a JS loop calling `appendChild()` — could
  recurse roughly 1024 levels deep, which at even a conservative
  ~100–150 bytes per stack frame risks 100 KB+ of the 3DS's stack on
  top of whatever the rest of the call chain is already using. Added a
  depth guard (`MAX_LAYOUT_DEPTH = 80`, well beyond any realistic
  page's nesting) — beyond the cap, layout simply stops descending
  into further children rather than risking a stack overflow.

### Housekeeping

- `navigator.userAgent` updated from the stale `"Pocket Compiler/0.33
  (3DS)"` to the current version.
- On-screen version string bumped to v0.38.

### Verification performed this pass

- Full manual read of every `.c`/`.h` file in `source/` and `include/`
  (excluding the vendored, unmodified `duktape.c`/`lodepng.c`
  libraries) — not a targeted diff, a complete audit.
- Grep sweeps for classically unsafe patterns across the whole
  codebase: unbounded `sprintf`/`strcpy`/`strcat`/`gets` (none found
  outside vendored libraries), large non-`static` stack buffers,
  `uint8_t`-width fields storing counters that could exceed 255,
  fatal-error propagation paths.
- Confirmed every project-owned call into the Duktape JS engine goes
  through a protected `duk_pcall`/`duk_peval_string` — the only raw
  `duk_call()` sites are inside the vendored `duktape.c` library
  itself, meaning ordinary JS exceptions are always caught and never
  reach the fatal-error handler (reserved for genuine internal
  Duktape faults like OOM).
- `gcc -fsyntax-only -D__3DS__` against every modified file, using the
  project's real headers plus host-side stub `<3ds.h>`/`<citro2d.h>`
  headers (all pass clean).
- Custom brace/paren-balance parser (correctly handles string/char
  literals and block comments) run on every modified file.
- Cross-file layout-constant verification confirming `main.c`'s touch
  hit-testing geometry still matches `ui.c`'s actual render geometry
  pixel-for-pixel (unchanged from v0.37, re-verified after this pass).
- Grep-based integrity sweep confirming every fix described above is
  actually present in the delivered source, not just in this changelog.

---

## v0.37

### Bug Fixes — Reported Issues
- **Console tab could not be touched/tapped.** Root cause: `main.c`
  never called `hidTouchRead()` at all — the bottom-screen cursor was
  Circle-Pad-only. Touching the screen did nothing for *any* UI
  element, not just the console tab. Real touchscreen support has been
  added: while the screen is being touched, the cursor snaps to the
  touch position every frame (touch takes priority over the Circle
  Pad; releasing the screen returns control to the Circle Pad from
  wherever the cursor was left). A tap on the EDITOR/CONSOLE tab bar
  now switches tabs directly, a tap on a code line edits that line,
  and a tap on a Save/Load file row selects and acts on it.
- **Hint/control bar glitching under the editor/console tab.** Two
  separate root causes, both fixed:
  1. The "ln X/Y" line counter was drawn directly on top of the tab
     bar at the same position as the CONSOLE tab's label, visually
     colliding with it. It has been moved into the hint bar's first
     row (right-aligned, dimmed) where nothing else overlaps it.
  2. A systemic off-by-2 bug: `draw_edit`, `draw_console`, `draw_save`,
     `draw_load`, and `draw_find_bar` all positioned their hint bar
     2px lower than `draw_running_bot` did, pushing their hint bar
     (and, for the find bar, both its rows) past the bottom edge of
     the 240px-tall screen — `draw_find_bar` overflowed by up to 6px.
     Every screen's hint/find bar now starts at exactly the same
     y-coordinate and ends flush with the bottom of the screen.
- **Could not scroll the SELECT controls/help screen.** It previously
  had no scroll state at all; its rows silently overflowed the panel
  with several hidden behind the hint bar. `controls_scroll` is now a
  tracked field, DPad Up/Down scrolls the list, and a scrollbar shows
  there's more content. The row table is also now a single
  source-of-truth array (`s_ctrl_rows`) shared between rendering and
  the row-count main.c uses to clamp scrolling — no separately
  maintained "row count" constant to drift out of sync. A new "Touch"
  row documents the v0.37 tap gestures.

### Bug Fixes — Found During Audit (not user-reported)
- **Console under-scroll.** `main.c` used a constant
  (`CONSOLE_VISIBLE_LINES = 12`) that didn't match `ui.c`'s actual
  rendering capacity (10 visible rows). Both the auto-scroll-to-bottom
  on eval and the manual DPad scroll under-shot by 2 rows, making the
  newest 1–2 log entries permanently unreachable once the log grew
  long enough. Both files now reference one shared constant,
  `PANEL_VISIBLE_ROWS` (app.h), eliminating the possibility of drift.
- **File explorer row overflow.** `FE_VISIBLE_ROWS` was still 8, a
  leftover from before v0.36 enlarged the file-list row height
  (`LH_FE`) from 21px to 23px for readability. `8 × 23 = 184px`
  overflowed the panel's ~168px usable height by up to 16px, so the
  bottom-most Save/Load row could bleed into the hint bar. Corrected
  to 7 rows (161px), which fits cleanly. A defensive pixel-bound check
  was also added to the render loop as a second line of defense.

### Internal / Architecture
- Extracted shared helper functions (`do_edit_line_action`,
  `do_save_dialog_action`, `do_load_file_action`,
  `do_switch_to_editor_tab`, `do_switch_to_console_tab`) so a button
  press and an equivalent touch tap always run the exact same code —
  there is no way for the two input paths to drift out of sync.
- Tab-bar tap hit-test region (y 3–24) and the editor code-area hit
  region (y 33–206) are verified non-overlapping, so a tap can never
  ambiguously trigger both a tab switch and a line edit.

---

## v0.36

### UI / Readability
- **All non-code bottom-screen text enlarged** for 3DS 240p legibility.
  Minimum UI font scale raised from 0.30–0.38 → 0.44–0.52.
  Code text (editor lines) is unchanged at FS_ED = 0.42.
- Hint bar is now **two lines** (34px tall) with shorter, clearly-spaced labels.
- Controls reference screen: key column 0.44f, description column 0.42f,
  row height raised to 17px. All description strings trimmed to fit.
- Tab bar labels: 0.38f → 0.48f.
- Console log lines: 0.38f → 0.46f; line height 17px.
- Find bar fields and hints: 0.34–0.38f → 0.40–0.46f.
- File explorer item text already used FS_UI (0.52f); size/date labels raised
  to FS_HINT (0.44f).

### Bug Fixes
- **`editor_find` / `editor_find_prev`**: `start_line` is now clamped to
  `[0, total-1]` before use. Without this, a negative or out-of-range
  start_line caused `editor_get_line` to walk off the end of the buffer —
  a potential crash on 3DS.
- **`editor_find_prev`**: `nlen` moved outside the inner for-loop (was
  recomputed on every iteration; harmless but wasteful).
- **`editor_replace_at`**: added `col > llen` guard to the bounds check so
  an exact-end-of-line replacement does not memcpy with a negative count.
- **`main.c` replace-all**: explicit parentheses added around `down & KEY_X`
  (`if((down & KEY_X) && ...)`). Without them GCC -Wall emits a warning;
  the fix makes intent unambiguous.
- **`main.c` replace-all**: after replacing all occurrences, `scroll_offset`
  is clamped to a valid range so the editor does not display a blank screen.
- **`we_eval_js`**: added `!g_web_engine.loaded` guard (in addition to the
  existing `!initialized` check). Prevents reading a stale `js_ctx` pointer
  if `we_unload()` was called between frames without clearing the pointer.
- **`draw_console`**: `i < WJS_LOG_MAX_LINES` guard added to the log-line
  loop. If `g_wjs_log_n` is ever corrupted, the loop can no longer read
  beyond the allocated `g_wjs_log` array.
- **`ui.c`**: two `strcat()` calls replaced with `strncat()` to silence
  static-analysis warnings and guard against theoretical overflow.
- **`main.c`**: `strcat()` in `ensure_html_ext` replaced with `strncat()`.
- **Layout constants**: `LAYOUT_ED_H` in `main.c` corrected to `178.0f`
  (was `180.0f`) to match the new two-line hint bar height in `ui.c`.
  Without this fix the cursor-to-code-row mapping was 2px off, causing the
  wrong line to be selected near the bottom of the editor panel.

---

## v0.35
- Auto-indent (A press on empty lines pre-fills indentation).
- JS Console tab (L in edit mode) with live expression evaluation.
- Find / Replace (R in edit mode) with next/prev/replace-one/replace-all.
- `fetch()` proper chaining via `.then(r=>r.json()).then(data=>...)` pattern.
- `response.text()` and `response.json()` return real thenables.
- `XMLHttpRequest.open()` correctly stores URL for `send()`.
- Duktape context kept alive on START-stop so console works after run.
- Console log cleared on each new compile (START in edit mode).

## v0.33
- Multiple field-name and linker bug fixes.

## v0.29 – v0.10
- Incremental implementation: DOM, CSS, layout, fetch, IndexedDB, iframe,
  Canvas, WebGL, audio, asset loading, full 3DS controls.

## v0.09
- Rebranded to Pocket Compiler.

## v0.01 – v0.08
- Initial HTML/CSS/JS editor, libctru console, SD card I/O.
