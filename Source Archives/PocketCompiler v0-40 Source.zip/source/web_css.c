/*
 * web_css.c  —  CSS parser & cascade
 *
 * v0.39 additions (additive; no existing parse case touched):
 *  - apply_property() now recognises three more declarations, all
 *    using fields already present in CSSStyle:
 *      • align-self   — was in the struct but had no parser case.
 *      • flex-flow    — shorthand setting flex-direction + flex-wrap.
 *      • inset        — shorthand setting top/right/bottom/left,
 *                       mirroring the existing margin/padding shorthand.
 *
 * v0.38 BUG FIX: css_parse_inline's 2048-byte buffer and
 * css_parse_stylesheet's 1024-byte decl_buf were both non-static
 * stack buffers, and the former is called from inside the latter
 * while its locals are still live — over 3KB combined in one call
 * chain. Both made static (parsing is strictly sequential, never
 * reentrant, so this is safe) to reduce 3DS stack pressure.
 */
#include "web_css.h"
#include "web_dom.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>

CSSRule g_css_rules[CSS_MAX_RULES];
int     g_css_rule_n=0;

/* ── Color parsing ──────────────────────────────────────────────── */

/* Named color table */
static const struct { const char *name; uint32_t rgba; } s_named[]={
    {"black",      0x000000FF},{"white",      0xFFFFFFFF},
    {"red",        0xFF0000FF},{"green",      0x008000FF},
    {"blue",       0x0000FFFF},{"yellow",     0xFFFF00FF},
    {"cyan",       0x00FFFFFF},{"magenta",    0xFF00FFFF},
    {"orange",     0xFF8000FF},{"purple",     0x800080FF},
    {"pink",       0xFFC0CBFF},{"lime",       0x00FF00FF},
    {"teal",       0x008080FF},{"navy",       0x000080FF},
    {"maroon",     0x800000FF},{"olive",      0x808000FF},
    {"silver",     0xC0C0C0FF},{"gray",       0x808080FF},
    {"grey",       0x808080FF},{"darkgray",   0xA9A9A9FF},
    {"darkgrey",   0xA9A9A9FF},{"lightgray",  0xD3D3D3FF},
    {"lightgrey",  0xD3D3D3FF},{"whitesmoke", 0xF5F5F5FF},
    {"crimson",    0xDC143CFF},{"coral",      0xFF7F50FF},
    {"salmon",     0xFA8072FF},{"gold",       0xFFD700FF},
    {"khaki",      0xF0E68CFF},{"violet",     0xEE82EEFF},
    {"indigo",     0x4B0082FF},{"turquoise",  0x40E0D0FF},
    {"chocolate",  0xD2691EFF},{"tomato",     0xFF6347FF},
    {"dodgerblue", 0x1E90FFFF},{"skyblue",    0x87CEEBFF},
    {"steelblue",  0x4682B4FF},{"slateblue",  0x6A5ACDFF},
    {"sienna",     0xA0522DFF},{"tan",        0xD2B48CFF},
    {"beige",      0xF5F5DCFF},{"ivory",      0xFFFFF0FF},
    {"lavender",   0xE6E6FAFF},{"linen",      0xFAF0E6FF},
    {"transparent",0x00000000},
    {NULL,0}
};

uint32_t css_named_color(const char *name){
    char buf[32]; int i=0;
    while(name[i]&&i<31){ buf[i]=tolower((unsigned char)name[i]); i++; }
    buf[i]='\0';
    for(int j=0;s_named[j].name;j++)
        if(strcmp(s_named[j].name,buf)==0) return s_named[j].rgba;
    return 0x888888FF;
}

uint32_t css_parse_color(const char *s){
    if(!s||!*s) return 0x888888FF;
    while(*s==' ')s++;
    if(s[0]=='#'){
        s++;
        int len=(int)strlen(s);
        unsigned r=0,g=0,b=0,a=255;
        if(len>=6){
            sscanf(s,"%02x%02x%02x",&r,&g,&b);
            if(len>=8) sscanf(s+6,"%02x",&a);
        } else if(len>=3){
            /* shorthand #RGB */
            sscanf(s,"%1x%1x%1x",&r,&g,&b);
            r|=r<<4; g|=g<<4; b|=b<<4;
        }
        return ((r&0xFF)<<24)|((g&0xFF)<<16)|((b&0xFF)<<8)|(a&0xFF);
    }
    if(strncmp(s,"rgb(",4)==0||strncmp(s,"rgba(",5)==0){
        int r=0,g=0,b=0; float a=1.0f;
        sscanf(s+(s[3]=='('?4:5),"%d,%d,%d,%f",&r,&g,&b,&a);
        int ai=(int)(a*255.f); if(ai<0)ai=0; if(ai>255)ai=255;
        return ((r&0xFF)<<24)|((g&0xFF)<<16)|((b&0xFF)<<8)|(ai);
    }
    if(strncmp(s,"hsl(",4)==0){
        float h=0,sv=0,lv=0; float a=1.0f;
        sscanf(s+4,"%f,%f%%,%f%%",&h,&sv,&lv);
        sv/=100.f; lv/=100.f;
        float c=(1-fabsf(2*lv-1))*sv;
        float x=c*(1-fabsf(fmodf(h/60.f,2)-1));
        float m=lv-c/2;
        float rf=0,gf=0,bf=0;
        if(h<60){rf=c;gf=x;}
        else if(h<120){rf=x;gf=c;}
        else if(h<180){gf=c;bf=x;}
        else if(h<240){gf=x;bf=c;}
        else if(h<300){rf=x;bf=c;}
        else{rf=c;bf=x;}
        int r=(int)((rf+m)*255),g=(int)((gf+m)*255),b=(int)((bf+m)*255);
        int ai=(int)(a*255.f);
        return ((r&0xFF)<<24)|((g&0xFF)<<16)|((b&0xFF)<<8)|(ai);
    }
    return css_named_color(s);
}

/* ── Length parsing ─────────────────────────────────────────────── */

int16_t css_parse_length(const char *s, int parent_px, int font_px){
    if(!s||!*s) return 0;
    while(*s==' ')s++;
    if(strcmp(s,"auto")==0) return -1;
    char *end;
    float v=(float)strtod(s,&end);
    while(*end==' ')end++;
    /* Use CSS_DEFAULT_FONT_SIZE as em fallback when font_px is 0 */
    int fp = (font_px > 0) ? font_px : CSS_DEFAULT_FONT_SIZE;
    if(strncmp(end,"px",2)==0) return (int16_t)(v);
    if(strncmp(end,"rem",3)==0)return (int16_t)(v*CSS_DEFAULT_FONT_SIZE);
    if(strncmp(end,"em",2)==0) return (int16_t)(v*fp);
    if(strncmp(end,"vw",2)==0) return (int16_t)(v*4.0f);/* 1vw=4px (400/100) */
    if(strncmp(end,"vh",2)==0) return (int16_t)(v*2.4f);/* 1vh=2.4px (240/100) */
    if(strncmp(end,"%",1)==0)  return (int16_t)(v*parent_px/100.f);
    if(*end=='\0') return (int16_t)(v);  /* assume px */
    return 0;
}

/* ── Inline CSS parser ──────────────────────────────────────────── */

static void trim(char *s){
    /* ltrim */
    char *p=s; while(*p==' '||*p=='\t'||*p=='\n'||*p=='\r') p++;
    if(p!=s) memmove(s,p,strlen(p)+1);
    /* rtrim */
    int l=(int)strlen(s);
    while(l>0&&(s[l-1]==' '||s[l-1]=='\t'||s[l-1]=='\n'||s[l-1]=='\r'))
        s[--l]='\0';
}

static void apply_property(CSSStyle *st, const char *prop, const char *val){
    if(!prop||!val||!*prop) return;
    char p[64]; strncpy(p,prop,63); p[63]=0; trim(p);
    char v[256]; strncpy(v,val,255); v[255]=0; trim(v);

    /* Color properties.
     * v0.40 audit fix: `background` is a shorthand that can contain
     * a color, an image url(), or both. The old code routed every
     * `background:` value to css_parse_color(), which would try to
     * parse "url(foo.png)" as a color and silently fall back to the
     * named-color lookup (returning 0 = transparent black). Now:
     *   - background-color: always a color
     *   - background: if it contains "url(", treat as image (no-op
     *     for now — image loading is handled at render time via the
     *     <img>/<canvas> paths, not CSS background-image); otherwise
     *     parse the last token as a color (handles "red", "#f00",
     *     "no-repeat center" etc. by extracting the color-looking token). */
    if(strcmp(p,"color")==0){ st->color=css_parse_color(v); return; }
    if(strcmp(p,"background-color")==0){
        st->background=css_parse_color(v); return;
    }
    if(strcmp(p,"background")==0){
        if(strstr(v,"url(")){
            /* background-image — not yet supported in the renderer.
             * Silently ignore the url() so any color in the same
             * shorthand still gets applied. */
            /* Try to extract a color token from the rest of the value
             * (e.g. "url(bg.png) red" → red). Strip the url(...) part. */
            char tmp[256]; strncpy(tmp,v,255); tmp[255]=0;
            char *url_start=strstr(tmp,"url(");
            if(url_start){
                char *url_end=strchr(url_start,')');
                if(url_end){
                    memmove(url_start,url_end+1,strlen(url_end+1)+1);
                    char *t=tmp; while(*t==' ')t++;
                    if(*t) st->background=css_parse_color(t);
                }
            }
        } else {
            st->background=css_parse_color(v);
        }
        return;
    }
    if(strcmp(p,"border-color")==0){ st->border_color=css_parse_color(v); return; }

    /* Display */
    if(strcmp(p,"display")==0){
        if(strcmp(v,"none")==0)         st->display=4;
        else if(strcmp(v,"flex")==0)    st->display=3;
        else if(strcmp(v,"inline-block")==0) st->display=2;
        else if(strcmp(v,"inline")==0)  st->display=1;
        else if(strcmp(v,"grid")==0)    st->display=5;
        else                            st->display=0; /* block */
        return;
    }

    /* Flex */
    if(strcmp(p,"flex-direction")==0){
        if(strcmp(v,"column")==0)         st->flex_direction=1;
        else if(strcmp(v,"row-reverse")==0)st->flex_direction=2;
        else if(strcmp(v,"column-reverse")==0)st->flex_direction=3;
        else st->flex_direction=0;
        return;
    }
    if(strcmp(p,"justify-content")==0){
        if(strcmp(v,"flex-end")==0||strcmp(v,"end")==0)    st->justify_content=1;
        else if(strcmp(v,"center")==0)                     st->justify_content=2;
        else if(strcmp(v,"space-between")==0)              st->justify_content=3;
        else if(strcmp(v,"space-around")==0)               st->justify_content=4;
        else st->justify_content=0;
        return;
    }
    if(strcmp(p,"align-items")==0){
        if(strcmp(v,"flex-end")==0||strcmp(v,"end")==0)    st->align_items=1;
        else if(strcmp(v,"center")==0)                     st->align_items=2;
        else if(strcmp(v,"stretch")==0)                    st->align_items=3;
        else st->align_items=0;
        return;
    }
    if(strcmp(p,"flex-wrap")==0){
        st->flex_wrap=(strcmp(v,"wrap")==0)?1:(strcmp(v,"wrap-reverse")==0)?2:0;
        return;
    }
    if(strcmp(p,"flex-grow")==0){ st->flex_grow=(int16_t)atoi(v); return; }
    if(strcmp(p,"gap")==0){ st->gap=(int16_t)css_parse_length(v,400,CSS_DEFAULT_FONT_SIZE); return; }

    /* v0.39: align-self (was in CSSStyle but never parsed). Mirrors
     * the align-items value mapping — auto/flex-start map to 0 (the
     * struct's "follow align-items" sentinel), flex-end→1, center→2,
     * stretch→3. Pure addition; no existing case touched. */
    if(strcmp(p,"align-self")==0){
        if(strcmp(v,"flex-end")==0||strcmp(v,"end")==0)    st->align_self=1;
        else if(strcmp(v,"center")==0)                     st->align_self=2;
        else if(strcmp(v,"stretch")==0)                    st->align_self=3;
        else st->align_self=0;   /* auto / flex-start / start */
        return;
    }

    /* v0.39: flex-flow shorthand — sets BOTH flex-direction and
     * flex-wrap from a single "row wrap" / "column nowrap" / etc.
     * declaration. Tokenises on whitespace; each token is matched
     * against the direction and wrap value sets. Tokens that match
     * neither are silently ignored (matching browser leniency for
     * unknown shorthand components). */
    if(strcmp(p,"flex-flow")==0){
        char tmp[64]; strncpy(tmp,v,63); tmp[63]=0;
        char *tok = strtok(tmp, " ");
        while(tok){
            if     (strcmp(tok,"row")==0)            st->flex_direction=0;
            else if(strcmp(tok,"column")==0)         st->flex_direction=1;
            else if(strcmp(tok,"row-reverse")==0)    st->flex_direction=2;
            else if(strcmp(tok,"column-reverse")==0) st->flex_direction=3;
            else if(strcmp(tok,"wrap")==0)           st->flex_wrap=1;
            else if(strcmp(tok,"wrap-reverse")==0)   st->flex_wrap=2;
            else if(strcmp(tok,"nowrap")==0)         st->flex_wrap=0;
            tok = strtok(NULL, " ");
        }
        return;
    }

    /* Position */
    if(strcmp(p,"position")==0){
        if(strcmp(v,"relative")==0)  st->position=1;
        else if(strcmp(v,"absolute")==0) st->position=2;
        else if(strcmp(v,"fixed")==0)    st->position=3;
        else st->position=0;
        return;
    }
    int fpos=st->font_size?st->font_size:CSS_DEFAULT_FONT_SIZE;
    if(strcmp(p,"left")==0)  { st->left  =css_parse_length(v,400,fpos); return;}
    if(strcmp(p,"top")==0)   { st->top   =css_parse_length(v,240,fpos); return;}
    if(strcmp(p,"right")==0) { st->right =css_parse_length(v,400,fpos); return;}
    if(strcmp(p,"bottom")==0){ st->bottom=css_parse_length(v,240,fpos); return;}
    if(strcmp(p,"z-index")==0){ st->z_index=(int16_t)atoi(v); return; }

    /* v0.39: inset shorthand — sets top/right/bottom/left in one
     * declaration, mirroring the margin/padding shorthand pattern
     * already in this file. 1 value = all four; 2 values = T/B + L/R;
     * 3 values = T + L/R + B; 4 values = T R B L. Uses the same
     * font-size-relative length parsing as the individual sides. */
    if(strcmp(p,"inset")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t vals[4]={0,0,0,0}; int vc=0;
        char *tok=strtok(tmp," ");
        while(tok&&vc<4){
            /* top/bottom use the 240 parent (screen height); left/right
             * use 400 (screen width). We approximate by using 240 for
             * all four, which is what the existing individual-property
             * path does for any of top/bottom — and the 3DS screen is
             * near-square anyway, so the relative difference is small. */
            vals[vc++]=(int16_t)css_parse_length(tok,240,fpos);
            tok=strtok(NULL," ");
        }
        if(vc==1){ st->top=st->right=st->bottom=st->left=vals[0]; }
        else if(vc==2){ st->top=st->bottom=vals[0]; st->left=st->right=vals[1]; }
        else if(vc==3){ st->top=vals[0]; st->left=st->right=vals[1]; st->bottom=vals[2]; }
        else if(vc==4){ st->top=vals[0]; st->right=vals[1]; st->bottom=vals[2]; st->left=vals[3]; }
        return;
    }

    /* Box model */
    int fp=st->font_size?st->font_size:CSS_DEFAULT_FONT_SIZE;
    if(strcmp(p,"width")==0)     { st->width      =css_parse_length(v,400,fp); return; }
    if(strcmp(p,"height")==0)    { st->height     =css_parse_length(v,240,fp); return; }
    if(strcmp(p,"min-width")==0) { st->min_width  =css_parse_length(v,400,fp); return; }
    if(strcmp(p,"min-height")==0){ st->min_height =css_parse_length(v,240,fp); return; }
    if(strcmp(p,"max-width")==0) { st->max_width  =css_parse_length(v,400,fp); return; }
    if(strcmp(p,"max-height")==0){ st->max_height =css_parse_length(v,240,fp); return; }

    /* v0.40 audit fix: border shorthand now properly tokenises.
     * The old code only checked for "solid" and used strrchr(v,' ')
     * to find the color, which broke on "1px solid #ccc" if the
     * color had a leading space variant, and completely ignored
     * border-style. Now tokenises on whitespace and classifies
     * each token: width (has "px"/"em"/number), style (solid/dashed/
     * dotted/double/none/hidden), color (everything else).
     * Also handles the per-side variants (border-top, border-right,
     * border-bottom, border-left) which the old code silently dropped. */
    if(strcmp(p,"border")==0||strcmp(p,"border-top")==0||
       strcmp(p,"border-right")==0||strcmp(p,"border-bottom")==0||
       strcmp(p,"border-left")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t bw=0; uint32_t bc=0; bool bc_set=false;
        char *tok=strtok(tmp," ");
        while(tok){
            if(strstr(tok,"px")||strstr(tok,"em")||strstr(tok,"rem")||
               (tok[0]>='0'&&tok[0]<='9')){
                bw=(int16_t)css_parse_length(tok,0,fp);
            } else if(strcmp(tok,"solid")==0||strcmp(tok,"dashed")==0||
                      strcmp(tok,"dotted")==0||strcmp(tok,"double")==0||
                      strcmp(tok,"none")==0||strcmp(tok,"hidden")==0||
                      strcmp(tok,"groove")==0||strcmp(tok,"ridge")==0||
                      strcmp(tok,"inset")==0||strcmp(tok,"outset")==0){
                /* style — accepted but not stored (renderer only
                 * draws solid borders). */
            } else {
                bc=css_parse_color(tok); bc_set=true;
            }
            tok=strtok(NULL," ");
        }
        /* Apply to all four sides for "border", or the specific side
         * for the per-side variants. Since CSSStyle only has a single
         * border_width/border_color (no per-side fields), we apply
         * to the unified field for all variants — this matches the
         * renderer's render_border() which draws all four sides. */
        st->border_width=bw;
        if(bc_set) st->border_color=bc;
        return;
    }
    if(strcmp(p,"border-width")==0){
        st->border_width=(int16_t)css_parse_length(v,0,fp); return;
    }
    if(strcmp(p,"border-radius")==0){ st->border_radius=(int16_t)css_parse_length(v,0,fp); return; }

    /* Margin shorthand.
     * v0.40 audit fix: added the 3-value form (T L/R B) which was
     * missing — "margin: 10px 20px 5px" used to fall through to the
     * vc==2 branch and silently drop the third value. */
    if(strcmp(p,"margin")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t vals[4]={0,0,0,0}; int vc=0;
        char *tok=strtok(tmp," ");
        while(tok&&vc<4){ vals[vc++]=(int16_t)css_parse_length(tok,0,fp); tok=strtok(NULL," "); }
        if(vc==1){ st->margin_top=st->margin_right=st->margin_bottom=st->margin_left=vals[0]; }
        else if(vc==2){ st->margin_top=st->margin_bottom=vals[0]; st->margin_left=st->margin_right=vals[1]; }
        else if(vc==3){ st->margin_top=vals[0]; st->margin_left=st->margin_right=vals[1]; st->margin_bottom=vals[2]; }
        else if(vc==4){ st->margin_top=vals[0];st->margin_right=vals[1];st->margin_bottom=vals[2];st->margin_left=vals[3];}
        return;
    }
    if(strcmp(p,"margin-top")==0)   { st->margin_top   =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"margin-right")==0) { st->margin_right =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"margin-bottom")==0){ st->margin_bottom=css_parse_length(v,0,fp); return; }
    if(strcmp(p,"margin-left")==0)  { st->margin_left  =css_parse_length(v,0,fp); return; }

    /* Padding shorthand.
     * v0.40 audit fix: same 3-value fix as margin. */
    if(strcmp(p,"padding")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t vals[4]={0,0,0,0}; int vc=0;
        char *tok=strtok(tmp," ");
        while(tok&&vc<4){ vals[vc++]=(int16_t)css_parse_length(tok,0,fp); tok=strtok(NULL," "); }
        if(vc==1){ st->padding_top=st->padding_right=st->padding_bottom=st->padding_left=vals[0]; }
        else if(vc==2){ st->padding_top=st->padding_bottom=vals[0]; st->padding_left=st->padding_right=vals[1]; }
        else if(vc==3){ st->padding_top=vals[0]; st->padding_left=st->padding_right=vals[1]; st->padding_bottom=vals[2]; }
        else if(vc==4){ st->padding_top=vals[0];st->padding_right=vals[1];st->padding_bottom=vals[2];st->padding_left=vals[3];}
        return;
    }
    if(strcmp(p,"padding-top")==0)   { st->padding_top   =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"padding-right")==0) { st->padding_right =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"padding-bottom")==0){ st->padding_bottom=css_parse_length(v,0,fp); return; }
    if(strcmp(p,"padding-left")==0)  { st->padding_left  =css_parse_length(v,0,fp); return; }

    /* Text */
    /* v0.40: font shorthand — "italic bold 14px/16px Arial, sans-serif".
     * Tokenises on whitespace. Recognises: font-style (italic/oblique),
     * font-weight (bold/bolder/number), font-size (has px/em/rem/% or
     * is a named size), line-height (after the size, separated by '/'),
     * font-family (everything else, ignored — renderer uses system font).
     * This is additive to the individual property handlers below. */
    if(strcmp(p,"font")==0){
        char tmp[256]; strncpy(tmp,v,255); tmp[255]=0;
        char *tok=strtok(tmp," ");
        while(tok){
            if(strcmp(tok,"italic")==0||strcmp(tok,"oblique")==0){
                st->font_style=1;
            } else if(strcmp(tok,"bold")==0||strcmp(tok,"bolder")==0||
                      (tok[0]>='0'&&tok[0]<='9'&&atoi(tok)>=700)){
                st->font_weight=1;
            } else if(strcmp(tok,"normal")==0||strcmp(tok,"lighter")==0){
                /* "normal" resets both style and weight to default;
                 * "lighter" just unsets bold */
                if(strcmp(tok,"normal")==0) st->font_style=0;
                st->font_weight=0;
            } else if(strcmp(tok,"small")==0){ st->font_size=9; }
            else if(strcmp(tok,"medium")==0){ st->font_size=14; }
            else if(strcmp(tok,"large")==0){ st->font_size=18; }
            else if(strcmp(tok,"x-large")==0){ st->font_size=22; }
            else if(strcmp(tok,"xx-large")==0){ st->font_size=26; }
            else if(strstr(tok,"px")||strstr(tok,"em")||strstr(tok,"rem")){
                /* Could be "14px" or "14px/16px" (size/line-height) */
                st->font_size=(int16_t)css_parse_length(tok,0,fp);
            } else if(tok[0]>='0'&&tok[0]<='9'&&strchr(tok,'/')){
                /* "14/16" size/line-height with no unit */
                char *slash=strchr(tok,'/');
                if(slash) *slash='\0';
                st->font_size=(int16_t)atoi(tok);
            }
            /* font-family tokens (Arial, sans-serif, etc.) are
             * silently ignored — renderer uses the citro2d system font. */
            tok=strtok(NULL," ");
        }
        return;
    }
    if(strcmp(p,"font-size")==0){
        /* handle named sizes */
        if(strcmp(v,"small")==0)  { st->font_size=9;  return; }
        if(strcmp(v,"medium")==0) { st->font_size=14; return; }
        if(strcmp(v,"large")==0)  { st->font_size=18; return; }
        if(strcmp(v,"x-large")==0){ st->font_size=22; return; }
        st->font_size=(int16_t)css_parse_length(v,CSS_DEFAULT_FONT_SIZE,fp); return;
    }
    if(strcmp(p,"font-weight")==0){
        if(strcmp(v,"bold")==0||strcmp(v,"bolder")==0||atoi(v)>=700)
            st->font_weight=1;
        else st->font_weight=0;
        return;
    }
    if(strcmp(p,"font-style")==0){
        st->font_style=(strcmp(v,"italic")==0||strcmp(v,"oblique")==0)?1:0; return; }
    if(strcmp(p,"text-align")==0){
        if(strcmp(v,"center")==0)        st->text_align=1;
        else if(strcmp(v,"right")==0)    st->text_align=2;
        else if(strcmp(v,"justify")==0)  st->text_align=3;
        else st->text_align=0;
        return;
    }
    if(strcmp(p,"text-decoration")==0){
        if(strstr(v,"underline"))     st->text_decoration=1;
        else if(strstr(v,"line-through")) st->text_decoration=2;
        else st->text_decoration=0;
        return;
    }
    if(strcmp(p,"white-space")==0){
        if(strcmp(v,"nowrap")==0)  st->white_space=1;
        else if(strcmp(v,"pre")==0||strcmp(v,"pre-wrap")==0) st->white_space=2;
        else st->white_space=0;
        return;
    }

    /* Overflow */
    if(strcmp(p,"overflow")==0||strcmp(p,"overflow-y")==0||strcmp(p,"overflow-x")==0){
        uint8_t ov=0;
        if(strcmp(v,"hidden")==0) ov=1;
        else if(strcmp(v,"scroll")==0) ov=2;
        else if(strcmp(v,"auto")==0) ov=3;
        if(strcmp(p,"overflow")==0||strcmp(p,"overflow-y")==0) st->overflow_y=ov;
        if(strcmp(p,"overflow")==0||strcmp(p,"overflow-x")==0) st->overflow_x=ov;
        st->overflow=ov;
        return;
    }

    /* Opacity / visibility */
    if(strcmp(p,"opacity")==0){
        float f=(float)atof(v);
        if(f<0)f=0; if(f>1)f=1;
        st->opacity=(uint8_t)(f*255);
        return;
    }
    if(strcmp(p,"visibility")==0){
        st->visibility=(strcmp(v,"hidden")==0)?1:(strcmp(v,"collapse")==0)?2:0; return; }

    /* Cursor */
    if(strcmp(p,"cursor")==0){
        if(strcmp(v,"pointer")==0)  st->cursor=1;
        else if(strcmp(v,"text")==0)st->cursor=2;
        else if(strcmp(v,"none")==0)st->cursor=3;
        else st->cursor=0;
        return;
    }

    /* Transform (simple) */
    if(strcmp(p,"transform")==0){
        if(strncmp(v,"rotate(",7)==0){
            float deg=(float)atof(v+7);
            st->rotate_deg=deg;
        } else if(strncmp(v,"scale(",6)==0){
            float sx=1,sy=1;
            sscanf(v+6,"%f,%f",&sx,&sy);
            st->scale_x=sx; st->scale_y=sy;
        } else if(strncmp(v,"translate(",10)==0){
            float tx=0,ty=0;
            sscanf(v+10,"%f,%f",&tx,&ty);
            st->translate_x=tx; st->translate_y=ty;
        }
        return;
    }
}

/* Expanded inline CSS buffer to handle longer style attributes.
 * v0.38 BUG FIX: buf[] was a non-static 2048-byte stack buffer, and
 * this function is called from inside css_parse_stylesheet() while
 * that function's own ~1KB+ of locals are still live on the stack —
 * over 3KB combined in a single call chain. Made static, matching the
 * pattern already used for large buffers elsewhere in this codebase
 * (see editor.c, file_explorer.c) to keep 3DS stack usage minimal.
 * Safe: CSS parsing is strictly sequential/non-reentrant — no call
 * site invokes this function while another call is already in
 * progress. */
void css_parse_inline(const char *inline_css, CSSStyle *out){
    if(!inline_css||!out) return;
    static char buf[2048];
    strncpy(buf,inline_css,2047); buf[2047]=0;
    char *p=buf;
    while(*p){
        /* find ':' */
        char *colon=strchr(p,':');
        if(!colon) break;
        *colon='\0';
        char *prop=p;
        char *val=colon+1;
        /* find ';' */
        char *semi=strchr(val,';');
        if(semi) *semi='\0';
        trim(prop); trim(val);
        apply_property(out,prop,val);
        if(!semi) break;
        p=semi+1;
    }
}

/* ── Stylesheet parser ──────────────────────────────────────────── */

void css_parse_stylesheet(const char *css_text){
    if(!css_text) return;
    const char *p=css_text;
    while(*p){
        /* skip whitespace/comments */
        while(*p&&isspace((unsigned char)*p)) p++;
        if(!*p) break;
        /* skip block comment */
        if(p[0]=='/'&&p[1]=='*'){
            const char *end=strstr(p+2,"*/");
            if(!end) break;
            p=end+2; continue;
        }
        /* read selector up to '{' */
        const char *sel_start=p;
        while(*p&&*p!='{') p++;
        if(!*p) break;
        char sel[CSS_SEL_LEN]; int sl=(int)(p-sel_start);
        if(sl>=CSS_SEL_LEN) sl=CSS_SEL_LEN-1;
        memcpy(sel,sel_start,sl); sel[sl]='\0'; trim(sel);
        p++; /* skip '{' */
        /* read declarations up to '}' */
        const char *decl_start=p;
        while(*p&&*p!='}') p++;
        /* v0.38 BUG FIX: was a non-static 1024-byte stack buffer,
         * combined with css_parse_inline's (now also static) 2048-byte
         * buffer for over 3KB in one call chain. See css_parse_inline's
         * comment above for the full rationale. */
        static char decl_buf[1024];
        int dl=(int)(p-decl_start);
        if(dl>=1024) dl=1023;
        memcpy(decl_buf,decl_start,dl); decl_buf[dl]='\0';
        if(*p=='}') p++;
        /* create rule */
        if(g_css_rule_n<CSS_MAX_RULES&&*sel){
            CSSRule *r=&g_css_rules[g_css_rule_n];
            strncpy(r->selector,sel,CSS_SEL_LEN-1);
            r->selector[CSS_SEL_LEN-1]='\0';
            r->style=css_default_style();
            r->used=1;
            /* compute rough specificity */
            if(strchr(sel,'#')) r->specificity=100;
            else if(strchr(sel,'.')) r->specificity=10;
            else r->specificity=1;
            css_parse_inline(decl_buf,&r->style);
            g_css_rule_n++;
        }
    }
}

/* ── Default style ──────────────────────────────────────────────── */

CSSStyle css_default_style(void){
    CSSStyle s; memset(&s,0,sizeof(s));
    s.color      = CSS_DEFAULT_COLOR;
    s.background = 0x00000000; /* transparent */
    /* font_size = 0 means "unset / inherit".
     * css_compute_node resolves this to CSS_DEFAULT_FONT_SIZE
     * at the end of the cascade if still 0.                  */
    s.font_size  = 0;
    s.opacity    = 255;
    s.display    = 0; /* block */
    s.width      = -1; s.height=-1;
    s.max_width  = -1; s.max_height=-1;
    s.scale_x    = 1.f; s.scale_y=1.f;
    return s;
}

/* ── Style inheritance ──────────────────────────────────────────── */

void css_inherit(CSSStyle *child, const CSSStyle *parent){
    /* inherited properties */
    if(child->color==CSS_DEFAULT_COLOR)  child->color=parent->color;
    if(child->font_size==0)              child->font_size=parent->font_size;
    if(child->font_weight==0)            child->font_weight=parent->font_weight;
    if(child->font_style==0)             child->font_style=parent->font_style;
    if(child->text_align==0)             child->text_align=parent->text_align;
    if(child->white_space==0)            child->white_space=parent->white_space;
    if(child->cursor==0)                 child->cursor=parent->cursor;
}

/* ── Cascade for a document ─────────────────────────────────────── */

/* Check if selector matches node (simple: tag, .class, #id, tag.class) */
static bool selector_matches(const char *sel, int16_t node_id){
    if(!sel||!*sel) return false;
    DOMNode *n=dom_node(node_id);
    if(!n||n->type!=NT_ELEMENT) return false;
    const char *tag=dom_str(n->tag_off);
    /* #id */
    if(sel[0]=='#'){
        const char *id=dom_get_attr(node_id,"id");
        return id&&strcmp(id,sel+1)==0;
    }
    /* .class */
    if(sel[0]=='.'){
        const char *cls=dom_get_attr(node_id,"class");
        if(!cls) return false;
        char buf[256]; strncpy(buf,cls,255); buf[255]=0;
        char *tok=strtok(buf," ");
        while(tok){ if(strcmp(tok,sel+1)==0)return true; tok=strtok(NULL," "); }
        return false;
    }
    /* tag.class */
    const char *dot=strchr(sel,'.');
    if(dot){
        char tbuf[32]; int tl=(int)(dot-sel); if(tl>=32)tl=31;
        memcpy(tbuf,sel,tl); tbuf[tl]=0;
        if(strcmp(tag,tbuf)!=0) return false;
        const char *cls=dom_get_attr(node_id,"class");
        if(!cls) return false;
        char cbuf[256]; strncpy(cbuf,cls,255); cbuf[255]=0;
        char *tok=strtok(cbuf," ");
        while(tok){ if(strcmp(tok,dot+1)==0)return true; tok=strtok(NULL," "); }
        return false;
    }
    /* tag */
    if(strcmp(sel,"*")==0) return true;
    return strcmp(sel,tag)==0;
}

void css_compute_node(int16_t node_id){
    DOMNode *n=dom_node(node_id);
    if(!n) return;
    /* start with defaults (font_size=0 = unset) */
    CSSStyle st=css_default_style();
    /* inherit from parent (font_size propagates if parent has it set) */
    if(n->parent>=0) css_inherit(&st,&g_dom_nodes[n->parent].style);
    /* apply stylesheet rules (in order, for simple cascade) */
    for(int i=0;i<g_css_rule_n;i++){
        if(!g_css_rules[i].used) continue;
        if(selector_matches(g_css_rules[i].selector,node_id)){
            /* merge: non-default wins.
             * v0.40 audit fix: the previous MERGE block was missing
             * several fields that apply_property() actually parses,
             * so stylesheet rules setting those properties were
             * silently dropped during cascade. Added: align_self,
             * overflow_x, overflow_y, min_width, min_height,
             * max_width, max_height, z_index, translate_x,
             * translate_y. Each uses a default-sentinel guard so a
             * legitimately-set 0 still wins over the default. */
            CSSStyle *rs=&g_css_rules[i].style;
            #define MERGE_U32(f) if(rs->f) st.f=rs->f
            #define MERGE_I16(f) if(rs->f) st.f=rs->f
            #define MERGE_I16_NEG(f) if(rs->f!=-1) st.f=rs->f
            #define MERGE_U8(f)  if(rs->f) st.f=rs->f
            MERGE_U32(color); MERGE_U32(background); MERGE_U32(border_color);
            MERGE_I16(margin_top);MERGE_I16(margin_right);
            MERGE_I16(margin_bottom);MERGE_I16(margin_left);
            MERGE_I16(padding_top);MERGE_I16(padding_right);
            MERGE_I16(padding_bottom);MERGE_I16(padding_left);
            MERGE_I16(border_width); MERGE_I16(border_radius);
            MERGE_I16_NEG(width); MERGE_I16_NEG(height);
            MERGE_I16_NEG(min_width); MERGE_I16_NEG(min_height);
            MERGE_I16_NEG(max_width); MERGE_I16_NEG(max_height);
            MERGE_U8(position); MERGE_U8(display);
            MERGE_U8(flex_direction); MERGE_U8(justify_content);
            MERGE_U8(align_items); MERGE_U8(align_self);
            MERGE_U8(flex_wrap);
            MERGE_I16(flex_grow); MERGE_I16(gap);
            MERGE_U8(font_weight); MERGE_U8(font_style);
            if(rs->font_size) st.font_size=rs->font_size;
            MERGE_U8(text_align); MERGE_U8(text_decoration);
            MERGE_U8(white_space);
            MERGE_U8(overflow); MERGE_U8(overflow_x); MERGE_U8(overflow_y);
            if(rs->opacity!=255&&rs->opacity!=0) st.opacity=rs->opacity;
            MERGE_U8(visibility); MERGE_U8(cursor);
            MERGE_I16(left); MERGE_I16(top);
            MERGE_I16(right); MERGE_I16(bottom);
            MERGE_I16(z_index);
            if(rs->rotate_deg) st.rotate_deg=rs->rotate_deg;
            if(rs->scale_x!=1.f) st.scale_x=rs->scale_x;
            if(rs->scale_y!=1.f) st.scale_y=rs->scale_y;
            if(rs->translate_x) st.translate_x=rs->translate_x;
            if(rs->translate_y) st.translate_y=rs->translate_y;
        }
    }
    /* apply inline style (highest priority) */
    const char *inl=dom_get_attr(node_id,"style");
    if(inl) css_parse_inline(inl,&st);
    /* resolve unset font_size to fallback */
    if(!st.font_size) st.font_size=CSS_DEFAULT_FONT_SIZE;
    n->style=st;
}

void css_cascade(uint8_t doc_id){
    for(int i=0;i<g_dom_node_n;i++){
        if(g_dom_nodes[i].doc_id==doc_id&&
           g_dom_nodes[i].type==NT_ELEMENT)
            css_compute_node((int16_t)i);
    }
}

void css_reset(void){
    g_css_rule_n=0;
    memset(g_css_rules,0,sizeof(g_css_rules));
}

/* ── Browser default (UA) stylesheet ───────────────────────────── */
/*
 * Injected before user stylesheets so user rules always win.
 * Sizes are calibrated for the 3DS top screen (400x240 px):
 *   - body margin-top:16px keeps content below the 14px RUNNING bar
 *   - font sizes chosen so scale = size/30.0f gives readable results
 */
void css_apply_ua_defaults(void){
    static const char s_ua_css[] =
        "html{font-size:14px;}"
        "body{margin-top:16px;margin-right:3px;"
              "margin-bottom:3px;margin-left:3px;}"
        "h1{font-size:22px;font-weight:bold;}"
        "h2{font-size:18px;font-weight:bold;}"
        "h3{font-size:15px;font-weight:bold;}"
        "h4{font-size:14px;font-weight:bold;}"
        "h5{font-size:13px;font-weight:bold;}"
        "h6{font-size:12px;font-weight:bold;}"
        "b{font-weight:bold;}"
        "strong{font-weight:bold;}"
        "i{font-style:italic;}"
        "em{font-style:italic;}"
        "a{color:#79c0ff;}"
        "pre{white-space:pre;}"
        "code{white-space:pre;}";
    css_parse_stylesheet(s_ua_css);
}
