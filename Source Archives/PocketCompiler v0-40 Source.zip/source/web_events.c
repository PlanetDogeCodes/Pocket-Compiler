/*
 * web_events.c  —  Event system: 3DS input → DOM events
 *
 * v0.38: we_add_listener's js_ref cast fixed from (uint8_t) to
 * (uint16_t) to match DOMEvent.js_ref's widened type (see web_dom.h).
 */
#include "web_events.h"
#include "duktape.h"
#include "web_dom.h"
#include "web_layout.h"
#include "web_js.h"
#include <string.h>
#include <3ds.h>

/* ── Key mappings ────────────────────────────────────────────────── */

const char *we_key_string(uint32_t ds_key){
    switch(ds_key){
        case KEY_UP:     return "ArrowUp";
        case KEY_DOWN:   return "ArrowDown";
        case KEY_LEFT:   return "ArrowLeft";
        case KEY_RIGHT:  return "ArrowRight";
        case KEY_A:      return "a";
        case KEY_B:      return "b";
        case KEY_X:      return "Escape";
        case KEY_Y:      return " ";
        case KEY_L:      return "l";
        case KEY_R:      return "r";
        case KEY_START:  return "F2";
        case KEY_SELECT: return "F1";
        default:         return "";
    }
}

int16_t we_key_code(uint32_t ds_key){
    switch(ds_key){
        case KEY_UP:     return WE_KEY_UP;
        case KEY_DOWN:   return WE_KEY_DOWN;
        case KEY_LEFT:   return WE_KEY_LEFT;
        case KEY_RIGHT:  return WE_KEY_RIGHT;
        case KEY_A:      return WE_KEY_A;
        case KEY_B:      return WE_KEY_B;
        case KEY_X:      return WE_KEY_ESCAPE;
        case KEY_Y:      return WE_KEY_SPACE;
        case KEY_L:      return WE_KEY_L;
        case KEY_R:      return WE_KEY_R;
        case KEY_START:  return WE_KEY_F2;
        case KEY_SELECT: return WE_KEY_F1;
        default:         return 0;
    }
}

/* ── Dispatch helpers ────────────────────────────────────────────── */

void we_dispatch(uint8_t doc_id, int16_t target, WEEvent *ev){
    if(!ev) return;
    ev->doc_id=doc_id;
    ev->target=target;
    /* bubble up from target */
    int16_t node=target;
    while(node>=0){
        we_invoke_js(doc_id,node,ev);
        /* check if inline handler exists */
        DOMNode *n=dom_node(node);
        if(!n) break;
        /* check for onclick etc. attribute handlers */
        const char *attr=NULL;
        switch(ev->type){
            case WE_EV_CLICK:     attr=dom_get_attr(node,"onclick"); break;
            case WE_EV_MOUSEDOWN: attr=dom_get_attr(node,"onmousedown"); break;
            case WE_EV_MOUSEUP:   attr=dom_get_attr(node,"onmouseup"); break;
            case WE_EV_MOUSEMOVE: attr=dom_get_attr(node,"onmousemove"); break;
            case WE_EV_KEYDOWN:   attr=dom_get_attr(node,"onkeydown"); break;
            case WE_EV_KEYUP:     attr=dom_get_attr(node,"onkeyup"); break;
            case WE_EV_FOCUS:     attr=dom_get_attr(node,"onfocus"); break;
            case WE_EV_BLUR:      attr=dom_get_attr(node,"onblur"); break;
            case WE_EV_CHANGE:    attr=dom_get_attr(node,"onchange"); break;
            case WE_EV_INPUT:     attr=dom_get_attr(node,"oninput"); break;
            case WE_EV_SUBMIT:    attr=dom_get_attr(node,"onsubmit"); break;
            case WE_EV_SCROLL:    attr=dom_get_attr(node,"onscroll"); break;
            default: break;
        }
        if(attr&&*attr){
            DOMDocument *d=dom_doc(doc_id);
            if(d&&d->js_ctx) wjs_eval((duk_context*)d->js_ctx,attr);
        }
        /* stop bubbling for certain events */
        if(ev->type==WE_EV_FOCUS||ev->type==WE_EV_BLUR) break;
        node=n->parent;
    }
}

void we_add_listener(int16_t node, WEEventType t, int js_ref){
    if(g_dom_event_n>=WE_MAX_EVENTS) return;
    g_dom_events[g_dom_event_n].node_id=(uint16_t)node;
    g_dom_events[g_dom_event_n].event_type=(uint8_t)t;
    g_dom_events[g_dom_event_n].js_ref=(uint16_t)js_ref; /* v0.38: was (uint8_t) */
    g_dom_event_n++;
}

void we_remove_listener(int16_t node, WEEventType t){
    for(int i=0;i<g_dom_event_n;i++){
        if(g_dom_events[i].node_id==(uint16_t)node&&
           g_dom_events[i].event_type==(uint8_t)t){
            /* tombstone */
            g_dom_events[i].event_type=WE_EV_NONE;
        }
    }
}

void we_invoke_js(uint8_t doc_id, int16_t node, const WEEvent *ev){
    DOMDocument *d=dom_doc(doc_id);
    if(!d||!d->js_ctx||!d->js_ready) return;
    duk_context *ctx=(duk_context*)d->js_ctx;
    for(int i=0;i<g_dom_event_n;i++){
        if(g_dom_events[i].event_type==(uint8_t)ev->type&&
           g_dom_events[i].node_id==(uint16_t)node&&
           g_dom_events[i].event_type!=WE_EV_NONE){
            wjs_fire_event(ctx,g_dom_events[i].js_ref,ev);
        }
    }
}

/* ── Focus ───────────────────────────────────────────────────────── */

void we_focus(uint8_t doc_id, int16_t node){
    DOMDocument *d=dom_doc(doc_id);
    if(!d) return;
    int16_t prev=d->focused_node;
    if(prev==node) return;
    /* blur previous */
    if(prev>=0){
        g_dom_nodes[prev].focused=0;
        WEEvent blr={0}; blr.type=WE_EV_BLUR; blr.target=prev;
        we_dispatch(doc_id,prev,&blr);
    }
    d->focused_node=node;
    if(node>=0){
        g_dom_nodes[node].focused=1;
        WEEvent foc={0}; foc.type=WE_EV_FOCUS; foc.target=node;
        we_dispatch(doc_id,node,&foc);
    }
}

void we_blur(uint8_t doc_id){
    we_focus(doc_id,-1);
}

/* ── Scroll ──────────────────────────────────────────────────────── */

void we_scroll_by(int16_t node_id, int16_t dx, int16_t dy){
    DOMNode *n=dom_node(node_id); if(!n) return;
    int16_t msx,msy; layout_scroll_extents(node_id,&msx,&msy);
    n->scroll_x+=dx; if(n->scroll_x<0)n->scroll_x=0; if(n->scroll_x>msx)n->scroll_x=msx;
    n->scroll_y+=dy; if(n->scroll_y<0)n->scroll_y=0; if(n->scroll_y>msy)n->scroll_y=msy;
}

void we_scroll_to(int16_t node_id, int16_t x, int16_t y){
    DOMNode *n=dom_node(node_id); if(!n) return;
    int16_t msx,msy; layout_scroll_extents(node_id,&msx,&msy);
    n->scroll_x=x; if(n->scroll_x<0)n->scroll_x=0; if(n->scroll_x>msx)n->scroll_x=msx;
    n->scroll_y=y; if(n->scroll_y<0)n->scroll_y=0; if(n->scroll_y>msy)n->scroll_y=msy;
}

/* ── Frame event update ──────────────────────────────────────────── */

static int16_t s_prev_hover=-1;
static bool    s_left_down=false;
static bool    s_right_down=false;
static double  s_last_click_time=0;
static int16_t s_last_click_node=-1;
static int     s_click_count=0;

void we_events_update(uint8_t doc_id, const WEInputState *inp){
    if(!inp) return;

    /* ── cursor move ──────────────────────────────────────────── */
    float cx=inp->cursor_x, cy=inp->cursor_y;
    int16_t hover=layout_hit(doc_id,(int16_t)cx,(int16_t)cy);

    /* mouseleave / mouseenter */
    if(hover!=s_prev_hover){
        if(s_prev_hover>=0){
            g_dom_nodes[s_prev_hover].hover=0;
            WEEvent ev={0}; ev.type=WE_EV_MOUSELEAVE;
            ev.client_x=cx; ev.client_y=cy;
            we_dispatch(doc_id,s_prev_hover,&ev);
        }
        if(hover>=0){
            g_dom_nodes[hover].hover=1;
            WEEvent ev={0}; ev.type=WE_EV_MOUSEENTER;
            ev.client_x=cx; ev.client_y=cy;
            we_dispatch(doc_id,hover,&ev);
        }
        s_prev_hover=hover;
    }

    /* mousemove */
    if(inp->cursor_x!=inp->prev_x||inp->cursor_y!=inp->prev_y){
        WEEvent ev={0}; ev.type=WE_EV_MOUSEMOVE;
        ev.client_x=cx; ev.client_y=cy;
        ev.target=hover;
        if(hover>=0){
            DOMNode *n=dom_node(hover);
            ev.offset_x=cx-n->lay_x;
            ev.offset_y=cy-n->lay_y;
        }
        we_dispatch(doc_id,hover>=0?hover:0,&ev);
    }

    /* ── mouse buttons ────────────────────────────────────────── */
    bool left_now  =(inp->down&KEY_A)||(inp->down&KEY_L)?true:
                    (inp->held&KEY_A)||(inp->held&KEY_L)?s_left_down:false;
    bool right_now =(inp->down&KEY_B)||(inp->down&KEY_R)?true:
                    (inp->held&KEY_B)||(inp->held&KEY_R)?s_right_down:false;

    /* mousedown left */
    if(((inp->down&KEY_A)||(inp->down&KEY_L))&&!s_left_down){
        s_left_down=true;
        if(hover>=0){
            g_dom_nodes[hover].active=1;
            WEEvent ev={0}; ev.type=WE_EV_MOUSEDOWN;
            ev.client_x=cx; ev.client_y=cy; ev.button=0;
            we_dispatch(doc_id,hover,&ev);
            we_focus(doc_id,layout_find_focusable(hover));
        }
    }
    /* mouseup left → click */
    if(s_left_down&&!((inp->held&KEY_A)||(inp->held&KEY_L))){
        s_left_down=false;
        if(hover>=0){
            g_dom_nodes[hover].active=0;
            WEEvent ev={0}; ev.type=WE_EV_MOUSEUP;
            ev.client_x=cx; ev.client_y=cy; ev.button=0;
            we_dispatch(doc_id,hover,&ev);
            /* click */
            WEEvent cev={0}; cev.type=WE_EV_CLICK;
            cev.client_x=cx; cev.client_y=cy; cev.button=0;
            we_dispatch(doc_id,hover,&cev);
            /* handle <a href="..."> navigation */
            const char *href=dom_get_attr(hover,"href");
            if(!href){
                /* check parent chain for <a> */
                int16_t pa=g_dom_nodes[hover].parent;
                while(pa>=0){
                    if(strcmp(dom_tag(pa),"a")==0){
                        href=dom_get_attr(pa,"href");
                        break;
                    }
                    pa=g_dom_nodes[pa].parent;
                }
            }
            /* href navigation handled by web_engine.c */
            (void)href;
        }
        left_now=false;
    }
    (void)left_now;

    /* mousedown/up right */
    if(((inp->down&KEY_B)||(inp->down&KEY_R))&&!s_right_down){
        s_right_down=true;
        if(hover>=0){
            WEEvent ev={0}; ev.type=WE_EV_MOUSEDOWN;
            ev.client_x=cx; ev.client_y=cy; ev.button=2;
            we_dispatch(doc_id,hover,&ev);
            WEEvent cev={0}; cev.type=WE_EV_CONTEXTMENU;
            cev.client_x=cx; cev.client_y=cy;
            we_dispatch(doc_id,hover,&cev);
        }
    }
    if(s_right_down&&!((inp->held&KEY_B)||(inp->held&KEY_R))){
        s_right_down=false;
        right_now=false;
        if(hover>=0){
            WEEvent ev={0}; ev.type=WE_EV_MOUSEUP;
            ev.client_x=cx; ev.client_y=cy; ev.button=2;
            we_dispatch(doc_id,hover,&ev);
        }
    }
    (void)right_now;

    /* ── keyboard (DPad / face buttons) ──────────────────────── */
    static const uint32_t KEY_MAP[]={
        KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,
        KEY_Y,  /* Y = space */
        0
    };
    for(int ki=0;KEY_MAP[ki];ki++){
        uint32_t k=KEY_MAP[ki];
        if(inp->down&k){
            DOMDocument *d=dom_doc(doc_id);
            int16_t focused=d?d->focused_node:-1;
            WEEvent ev={0}; ev.type=WE_EV_KEYDOWN;
            ev.key_code=we_key_code(k);
            strncpy(ev.key_str,we_key_string(k),7);
            we_dispatch(doc_id,focused>=0?focused:0,&ev);
            /* keypress for printable */
            if(ev.key_code==WE_KEY_SPACE||ev.key_code==WE_KEY_ENTER){
                WEEvent kp={0}; kp.type=WE_EV_KEYPRESS;
                kp.key_code=ev.key_code;
                strncpy(kp.key_str,ev.key_str,7);
                we_dispatch(doc_id,focused>=0?focused:0,&kp);
            }
        }
        if(inp->up&k){
            DOMDocument *d=dom_doc(doc_id);
            int16_t focused=d?d->focused_node:-1;
            WEEvent ev={0}; ev.type=WE_EV_KEYUP;
            ev.key_code=we_key_code(k);
            strncpy(ev.key_str,we_key_string(k),7);
            we_dispatch(doc_id,focused>=0?focused:0,&ev);
        }
    }

    /* ── touch (stylus on bottom screen — if applicable) ──────── */
    /* Note: on 3DS, bottom screen is blocked in run_mode.
       If we ever extend to bottom-screen web content, touch events
       would fire here from hidTouchRead().                        */
    if(inp->touched&&!inp->was_touched){
        WEEvent ev={0}; ev.type=WE_EV_TOUCHSTART;
        ev.client_x=inp->touch.px; ev.client_y=inp->touch.py;
        ev.touch_id=0;
        we_dispatch(doc_id,hover>=0?hover:0,&ev);
    }
    if(!inp->touched&&inp->was_touched){
        WEEvent ev={0}; ev.type=WE_EV_TOUCHEND;
        ev.client_x=inp->prev_touch.px; ev.client_y=inp->prev_touch.py;
        ev.touch_id=0;
        we_dispatch(doc_id,hover>=0?hover:0,&ev);
    }
}
