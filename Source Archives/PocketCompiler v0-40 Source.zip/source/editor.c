/*
 * editor.c — Line-based text editor for Pocket Compiler v0.36
 *
 * v0.36 fixes:
 *  - editor_find / editor_find_prev: start_line is now clamped to [0,total-1]
 *    before use, preventing an off-the-end walk in editor_get_line().
 *  - editor_find_prev: nlen moved outside the inner for-loop (minor perf fix).
 *  - All large temporary buffers remain 'static' to keep stack usage minimal
 *    on the 3DS (default main-thread stack: 256 KB).
 */
#include "editor.h"
#include "app.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

/* ── Init ─────────────────────────────────────────────────────────── */

void editor_init(Editor *e) {
    if (!e) return;
    memset(e, 0, sizeof(*e));
    e->cursor_line   = 0;
    e->scroll_offset = 0;
    e->undo_head     = 0;
    e->undo_count    = 0;
    strncpy(e->buf,
        "<!DOCTYPE html>\n<html>\n<head>\n  <title>My Page</title>\n</head>\n"
        "<body>\n  <h1>Hello, 3DS!</h1>\n</body>\n</html>\n",
        EDITOR_MAX - 1);
    e->buf[EDITOR_MAX - 1] = '\0';
}

/* ── Helpers ──────────────────────────────────────────────────────── */

int editor_line_count(const Editor *e) {
    if (!e) return 0;
    int count = 0;
    for (int i = 0; e->buf[i] != '\0'; i++)
        if (e->buf[i] == '\n') count++;
    return count + 1;
}

void editor_get_line(const Editor *e, int line, char *out, int out_sz) {
    if (!e || !out || out_sz <= 0) return;
    out[0] = '\0';
    if (line < 0) return;
    int cur = 0, n = 0;
    const char *p = e->buf;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    while (*p && *p != '\n' && n < out_sz - 1) out[n++] = *p++;
    out[n] = '\0';
}

void editor_set_line(Editor *e, int line, const char *text) {
    if (!e || !text) return;
    static char tmp[EDITOR_MAX];
    const char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    const char *ls = p;
    while (*p && *p != '\n') p++;
    int pfx  = (int)(ls - e->buf);
    int sfx  = (int)(p  - e->buf);
    int tlen = (int)strlen(text);
    int blen = (int)strlen(e->buf);
    int nlen = pfx + tlen + (blen - sfx);
    if (nlen >= EDITOR_MAX) return;
    memcpy(tmp, e->buf, pfx);
    memcpy(tmp + pfx, text, tlen);
    memcpy(tmp + pfx + tlen, e->buf + sfx, blen - sfx + 1);
    memcpy(e->buf, tmp, nlen + 1);
}

void editor_insert_line(Editor *e, int line, const char *text) {
    if (!e || !text) return;
    static char tmp[EDITOR_MAX];
    const char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    int pfx  = (int)(p - e->buf);
    int tlen = (int)strlen(text);
    int blen = (int)strlen(e->buf);
    int nlen = pfx + tlen + 1 + (blen - pfx);
    if (nlen >= EDITOR_MAX) return;
    memcpy(tmp, e->buf, pfx);
    memcpy(tmp + pfx, text, tlen);
    tmp[pfx + tlen] = '\n';
    memcpy(tmp + pfx + tlen + 1, e->buf + pfx, blen - pfx + 1);
    memcpy(e->buf, tmp, nlen + 1);
}

void editor_delete_line(Editor *e, int line) {
    if (!e) return;
    char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    char *ls = p;
    while (*p && *p != '\n') p++;
    if (*p == '\n') p++;
    memmove(ls, p, strlen(p) + 1);
}

void editor_scroll_up(Editor *e) {
    if (!e) return;
    if (e->scroll_offset > 0) e->scroll_offset--;
    if (e->cursor_line   > 0) e->cursor_line--;
}

void editor_scroll_down(Editor *e) {
    if (!e) return;
    int total = editor_line_count(e);
    if (e->cursor_line < total - 1) {
        e->cursor_line++;
        if (e->cursor_line >= e->scroll_offset + CODE_AREA_H)
            e->scroll_offset++;
    }
}

/* ── Undo ring (v0.39) ────────────────────────────────────────────── */
/* editor_snapshot() captures the current buf+cursor into the next ring
 * slot, advancing the head and growing undo_count up to EDITOR_UNDO_STEPS.
 * editor_undo() restores the most recent slot and shrinks undo_count;
 * repeated calls walk back through up to STEPS prior states, then undo
 * becomes a no-op. Both keep their original (Editor*) signatures so the
 * three existing call sites in main.c need no change. */

void editor_snapshot(Editor *e) {
    if (!e) return;
    int slot = e->undo_head;
    memcpy(e->undo_buf[slot], e->buf, EDITOR_MAX);
    e->undo_cursor[slot] = e->cursor_line;
    e->undo_head = (slot + 1) % EDITOR_UNDO_STEPS;
    if (e->undo_count < EDITOR_UNDO_STEPS) e->undo_count++;
}

void editor_undo(Editor *e) {
    if (!e || e->undo_count <= 0) return;
    /* The most recently written slot is one behind the head (which points
     * at the NEXT slot to write). */
    int slot = (e->undo_head + EDITOR_UNDO_STEPS - 1) % EDITOR_UNDO_STEPS;
    memcpy(e->buf, e->undo_buf[slot], EDITOR_MAX);
    e->cursor_line = e->undo_cursor[slot];
    e->undo_head   = slot;
    e->undo_count--;
}

/* ── Auto-indent ─────────────────────────────────────────────────── */

int editor_get_indent(const Editor *e, int line, char *out, int out_sz) {
    if (!e || !out || out_sz <= 0) {
        if (out && out_sz > 0) out[0] = '\0';
        return 0;
    }
    static char lb[LINE_MAX];
    editor_get_line(e, line, lb, sizeof(lb));
    int n = 0;
    while ((lb[n] == ' ' || lb[n] == '\t') && n < out_sz - 1) {
        out[n] = lb[n];
        n++;
    }
    out[n] = '\0';
    return n;
}

/* ── Find (forward, wraps around) ────────────────────────────────── */

bool editor_find(const Editor *e, const char *needle,
                 int start_line, int start_col,
                 int *fl, int *fc) {
    if (!e || !needle || !*needle || !fl || !fc) return false;
    int total = editor_line_count(e);
    if (total <= 0) return false;

    /* Clamp start_line to a valid range (bug fix: prevents off-end walk) */
    if (start_line < 0)      start_line = 0;
    if (start_line >= total) start_line = total - 1;

    static char lb[LINE_MAX];

    for (int pass = 0; pass < 2; pass++) {
        int lo = (pass == 0) ? start_line : 0;
        int hi = (pass == 0) ? total      : start_line + 1;
        for (int li = lo; li < hi; li++) {
            editor_get_line(e, li, lb, sizeof(lb));
            int col0 = 0;
            if (pass == 0 && li == start_line) {
                /* Search from one past start_col; -1 means "from col 0" */
                col0 = (start_col >= 0) ? start_col + 1 : 0;
            }
            int llen = (int)strlen(lb);
            if (col0 > llen) continue;
            const char *found = strstr(lb + col0, needle);
            if (found) {
                *fl = li;
                *fc = (int)(found - lb);
                return true;
            }
        }
    }
    return false;
}

/* ── Find (backward, wraps around) ──────────────────────────────── */

bool editor_find_prev(const Editor *e, const char *needle,
                      int start_line, int start_col,
                      int *fl, int *fc) {
    if (!e || !needle || !*needle || !fl || !fc) return false;
    int total = editor_line_count(e);
    if (total <= 0) return false;

    /* Clamp start_line (bug fix) */
    if (start_line < 0)      start_line = 0;
    if (start_line >= total) start_line = total - 1;

    static char lb[LINE_MAX];
    int nlen = (int)strlen(needle); /* moved outside inner loops */

    for (int pass = 0; pass < 2; pass++) {
        /* pass 0: backward from start_line down to 0
         * pass 1: wrap — from last line down to start_line             */
        int lo = (pass == 0) ? 0           : start_line;
        int hi = (pass == 0) ? start_line + 1 : total;

        for (int li = hi - 1; li >= lo; li--) {
            editor_get_line(e, li, lb, sizeof(lb));
            int llen = (int)strlen(lb);

            /* On the starting line in pass 0, restrict to cols < start_col */
            int search_end = llen;
            if (pass == 0 && li == start_line) {
                search_end = start_col; /* exclusive upper bound */
                if (search_end <= 0) continue;
                if (search_end > llen) search_end = llen;
            }

            /* Find the last occurrence of needle in lb[0..search_end-1] */
            int best = -1;
            int sc   = 0;
            while (sc + nlen <= search_end) {
                const char *found = strstr(lb + sc, needle);
                if (!found) break;
                int col = (int)(found - lb);
                if (col < search_end) {
                    best = col;
                    sc   = col + 1;
                } else {
                    break;
                }
            }
            if (best >= 0) {
                *fl = li;
                *fc = best;
                return true;
            }
        }
    }
    return false;
}

/* ── Replace ─────────────────────────────────────────────────────── */

bool editor_replace_at(Editor *e, int line, int col,
                       int needle_len, const char *replacement) {
    if (!e || !replacement || needle_len < 0 || col < 0) return false;
    static char lb[LINE_MAX];
    static char nb[LINE_MAX];
    editor_get_line(e, line, lb, sizeof(lb));
    int llen = (int)strlen(lb);
    if (col > llen || col + needle_len > llen) return false;
    int rlen    = (int)strlen(replacement);
    int new_len = llen - needle_len + rlen;
    if (new_len < 0 || new_len >= LINE_MAX) return false;
    memcpy(nb,               lb,              col);
    memcpy(nb + col,         replacement,     rlen);
    memcpy(nb + col + rlen,  lb + col + needle_len,
           (size_t)(llen - col - needle_len));
    nb[new_len] = '\0';
    editor_set_line(e, line, nb);
    return true;
}

/* ── v0.39: Duplicate line ────────────────────────────────────────── */
/* Copies the line at e->cursor_line and inserts the copy directly below
 * it as a brand-new line, then advances cursor_line onto the new line so
 * a second press duplicates again (the freshly-inserted line). Uses the
 * static-line buffer pattern already used everywhere else in this file
 * to keep stack usage minimal on the 3DS. Caller snapshots first. */
void editor_duplicate_line(Editor *e){
    if(!e) return;
    int total = editor_line_count(e);
    if(total <= 0) return;
    int line = e->cursor_line;
    if(line < 0)         line = 0;
    if(line >= total)    line = total - 1;

    static char text[LINE_MAX];
    editor_get_line(e, line, text, sizeof(text));
    editor_insert_line(e, line + 1, text);
    e->cursor_line = line + 1;
}

/* ── v0.39: Toggle line comment ───────────────────────────────────── */
/* Context-aware single-line comment toggle.
 *
 * HTML context (buffer contains <!DOCTYPE or <html, case-insensitive):
 *   wraps the line in "<!-- " .. " -->". If the line already starts
 *   with "<!-- " and ends with " -->" (after trim), it is unwrapped.
 *
 * JS/CSS context (anything else):
 *   prefixes "// ". If the line (after leading whitespace) already
 *   starts with "// ", that prefix is removed (preserving indentation).
 *
 * Idempotent: toggling twice returns the original line. Caller
 * snapshots first. No-op on an out-of-range cursor_line. */
static int buf_is_html(const Editor *e){
    /* Case-insensitive substring search for "<!doctype" / "<html". */
    const char needle_d[] = "<!doctype";
    const char needle_h[] = "<html";
    const char *s = e->buf;
    for(const char *p = s; *p; p++){
        char c0 = (*p >= 'A' && *p <= 'Z') ? (char)(*p + 32) : *p;
        if(c0 == needle_d[0]){
            int match = 1;
            for(int i = 1; needle_d[i]; i++){
                char c = p[i];
                if(!c){ match = 0; break; }
                char lc = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
                if(lc != needle_d[i]){ match = 0; break; }
            }
            if(match) return 1;
        }
        if(c0 == needle_h[0]){
            int match = 1;
            for(int i = 1; needle_h[i]; i++){
                char c = p[i];
                if(!c){ match = 0; break; }
                char lc = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
                if(lc != needle_h[i]){ match = 0; break; }
            }
            if(match) return 1;
        }
    }
    return 0;
}

void editor_toggle_comment(Editor *e){
    if(!e) return;
    int total = editor_line_count(e);
    if(total <= 0) return;
    int line = e->cursor_line;
    if(line < 0)      line = 0;
    if(line >= total) line = total - 1;

    static char lb[LINE_MAX];
    editor_get_line(e, line, lb, sizeof(lb));
    int len = (int)strlen(lb);

    if(buf_is_html(e)){
        /* HTML context: toggle <!-- ... --> */
        /* Find leading whitespace */
        int lead = 0;
        while(lead < len && (lb[lead] == ' ' || lb[lead] == '\t')) lead++;
        /* Check if already commented: "<!-- " at lead, " -->" at end */
        int has_open  = (lead + 5 <= len &&
                         lb[lead]   == '<' && lb[lead+1] == '!' &&
                         lb[lead+2] == '-' && lb[lead+3] == '-' &&
                         lb[lead+4] == ' ');
        /* Trim trailing spaces to test for the close marker */
        int end = len;
        while(end > lead && (lb[end-1] == ' ' || lb[end-1] == '\t')) end--;
        int has_close = (end - lead >= 4 &&
                         lb[end-4] == ' ' && lb[end-3] == '-' &&
                         lb[end-2] == '-' && lb[end-1] == '>');

        if(has_open && has_close){
            /* Unwrap: keep leading ws, drop "<!-- " (5) and " -->" (4) */
            static char nb[LINE_MAX];
            int n = 0;
            for(int i = 0; i < lead && n < LINE_MAX - 1; i++) nb[n++] = lb[i];
            /* content runs from lead+5 .. end-4 */
            for(int i = lead + 5; i < end - 4 && n < LINE_MAX - 1; i++)
                nb[n++] = lb[i];
            /* re-append trailing whitespace that was there (end..len) */
            for(int i = end; i < len && n < LINE_MAX - 1; i++)
                nb[n++] = lb[i];
            nb[n] = '\0';
            editor_set_line(e, line, nb);
        } else {
            /* Wrap: "<lead><!-- " + content + " -->" + trailing */
            static char nb[LINE_MAX];
            int n = 0;
            for(int i = 0; i < lead && n < LINE_MAX - 1; i++) nb[n++] = lb[i];
            const char *op = "<!-- ";
            while(*op && n < LINE_MAX - 1) nb[n++] = *op++;
            for(int i = lead; i < len && n < LINE_MAX - 1; i++) nb[n++] = lb[i];
            const char *cl = " -->";
            while(*cl && n < LINE_MAX - 1) nb[n++] = *cl++;
            nb[n] = '\0';
            editor_set_line(e, line, nb);
        }
    } else {
        /* JS/CSS context: toggle "// " after leading whitespace. */
        int lead = 0;
        while(lead < len && (lb[lead] == ' ' || lb[lead] == '\t')) lead++;
        int has = (lead + 3 <= len &&
                   lb[lead] == '/' && lb[lead+1] == '/' && lb[lead+2] == ' ');
        if(has){
            /* Remove the 3 chars at position lead. */
            static char nb[LINE_MAX];
            int n = 0;
            for(int i = 0; i < lead && n < LINE_MAX - 1; i++) nb[n++] = lb[i];
            for(int i = lead + 3; i < len && n < LINE_MAX - 1; i++)
                nb[n++] = lb[i];
            nb[n] = '\0';
            editor_set_line(e, line, nb);
        } else {
            /* Insert "// " after leading whitespace. */
            static char nb[LINE_MAX];
            int n = 0;
            for(int i = 0; i < lead && n < LINE_MAX - 1; i++) nb[n++] = lb[i];
            const char *pfx = "// ";
            while(*pfx && n < LINE_MAX - 1) nb[n++] = *pfx++;
            for(int i = lead; i < len && n < LINE_MAX - 1; i++) nb[n++] = lb[i];
            nb[n] = '\0';
            editor_set_line(e, line, nb);
        }
    }
}
