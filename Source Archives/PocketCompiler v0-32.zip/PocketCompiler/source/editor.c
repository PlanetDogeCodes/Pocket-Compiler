/*
 * editor.c — Multi-line text editor for Pocket Compiler v0.32
 *
 * All large temporary buffers are 'static' to avoid 3DS stack overflow.
 */
#include "editor.h"
#include "app.h"      /* CODE_AREA_H, CODE_AREA_W */
#include <string.h>
#include <stdio.h>

void editor_init(Editor *e) {
    if (!e) return;
    memset(e, 0, sizeof(*e));
    e->cursor_line    = 0;
    e->scroll_offset  = 0;
    e->undo_valid     = false;
    strncpy(e->buf, "<!DOCTYPE html>\n<html>\n<head>\n  <title>My Page</title>\n</head>\n<body>\n  <h1>Hello, 3DS!</h1>\n</body>\n</html>\n", EDITOR_MAX - 1);
}

/* ------------------------------------------------------------------ helpers */

/* Count the number of newlines (= lines) in the buffer. */
int editor_line_count(const Editor *e) {
    if (!e) return 0;
    int count = 0;
    for (int i = 0; e->buf[i] != '\0'; i++) {
        if (e->buf[i] == '\n') count++;
    }
    return count + 1;  /* last line may have no trailing \n */
}

/* Copy line 'line' (0-based) into 'out', stripping the '\n'. */
void editor_get_line(const Editor *e, int line, char *out, int out_sz) {
    if (!e || !out || out_sz <= 0) return;
    out[0] = '\0';
    int cur = 0, n = 0;
    const char *p = e->buf;
    while (*p && cur < line) {
        if (*p == '\n') cur++;
        p++;
    }
    while (*p && *p != '\n' && n < out_sz - 1) {
        out[n++] = *p++;
    }
    out[n] = '\0';
}

/* Replace line 'line' with 'text'.  Uses a static buffer — safe on 3DS. */
void editor_set_line(Editor *e, int line, const char *text) {
    if (!e || !text) return;
    static char tmp[EDITOR_MAX];

    const char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    const char *line_start = p;
    while (*p && *p != '\n') p++;
    const char *line_end = p;

    int prefix_len   = (int)(line_start - e->buf);
    int suffix_start = (int)(line_end - e->buf);

    int tlen    = (int)strlen(text);
    int blen    = (int)strlen(e->buf);
    int new_len = prefix_len + tlen + (blen - suffix_start);
    if (new_len >= EDITOR_MAX) return;

    memcpy(tmp, e->buf, prefix_len);
    memcpy(tmp + prefix_len, text, tlen);
    memcpy(tmp + prefix_len + tlen, e->buf + suffix_start, blen - suffix_start + 1);
    memcpy(e->buf, tmp, new_len + 1);
}

/* Insert 'text' as a new line BEFORE 'line'. */
void editor_insert_line(Editor *e, int line, const char *text) {
    if (!e || !text) return;
    static char tmp[EDITOR_MAX];

    const char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    int prefix_len = (int)(p - e->buf);

    int tlen    = (int)strlen(text);
    int blen    = (int)strlen(e->buf);
    int new_len = prefix_len + tlen + 1 + (blen - prefix_len);
    if (new_len >= EDITOR_MAX) return;

    memcpy(tmp, e->buf, prefix_len);
    memcpy(tmp + prefix_len, text, tlen);
    tmp[prefix_len + tlen] = '\n';
    memcpy(tmp + prefix_len + tlen + 1, e->buf + prefix_len, blen - prefix_len + 1);
    memcpy(e->buf, tmp, new_len + 1);
}

/* Delete line 'line' from the buffer. */
void editor_delete_line(Editor *e, int line) {
    if (!e) return;
    char *p = e->buf;
    int cur = 0;
    while (*p && cur < line) { if (*p == '\n') cur++; p++; }
    char *line_start = p;
    while (*p && *p != '\n') p++;
    if (*p == '\n') p++;
    memmove(line_start, p, strlen(p) + 1);
}

/* ----------------------------------------------------------- scroll helpers */

void editor_scroll_up(Editor *e) {
    if (!e) return;
    if (e->scroll_offset > 0) e->scroll_offset--;
    if (e->cursor_line > 0)   e->cursor_line--;
}

void editor_scroll_down(Editor *e) {
    if (!e) return;
    int total = editor_line_count(e);
    if (e->cursor_line < total - 1) {
        e->cursor_line++;
        if (e->cursor_line >= e->scroll_offset + CODE_AREA_H)
            e->scroll_offset++;
    }
}

/* -------------------------------------------------------------------- undo */

void editor_snapshot(Editor *e) {
    if (!e) return;
    memcpy(e->undo_buf, e->buf, EDITOR_MAX);
    e->undo_cursor_line = e->cursor_line;
    e->undo_valid = true;
}

void editor_undo(Editor *e) {
    if (!e || !e->undo_valid) return;
    memcpy(e->buf, e->undo_buf, EDITOR_MAX);
    e->cursor_line = e->undo_cursor_line;
    e->undo_valid  = false;
}
