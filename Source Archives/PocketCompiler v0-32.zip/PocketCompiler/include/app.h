#pragma once
#include <stdbool.h>
#include "file_explorer.h"

/* CODE_AREA_H must match the number of lines the Citro2D editor actually
 * displays. The editor scroll logic uses this to advance the viewport. */
#define CODE_AREA_W   42
#define CODE_AREA_H   10    /* visible lines in the Citro2D editor panel */

typedef enum {
    MODE_EDIT = 0,
    MODE_SAVE,
    MODE_LOAD,
    MODE_CONTROLS,
    MODE_PREVIEW
} AppMode;

typedef struct {
    AppMode      mode;
    bool         running;
    int          slot_cursor;   /* legacy */
    FileExplorer fe;            /* proper file explorer state */
    float        cursor_x;     /* circle-pad cursor (bottom screen) */
    float        cursor_y;
} AppState;
