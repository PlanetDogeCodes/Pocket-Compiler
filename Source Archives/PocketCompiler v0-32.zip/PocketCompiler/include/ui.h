#pragma once
#include "app.h"
#include "editor.h"
#include "runtime_features.h"

/* Initialise Citro2D render targets and text buffer.
 * Call once before any ui_draw() calls. */
void ui_init(void);

/* Redraw both screens for the current application state. */
void ui_draw(const AppState *app, const Editor *e, const FeatureRuntime *rt);

/* Clean shutdown — frees Citro2D resources and calls gfxExit(). */
void ui_exit(void);
