# Pocket Compiler — Changelog

## v0.32 (current)
- **FIXED**: `source/runtime.c` was using old field names `rt->message` and `rt->image`.
  Correct names are `rt->status_msg` and `rt->images` per `runtime_features.h`.
  This caused compile errors:
    `error: 'FeatureRuntime' has no member named 'message'`
    `error: 'FeatureRuntime' has no member named 'image'`
- **FIXED**: All source files regenerated in a single pass so field names are 100% in sync.
- **FIXED**: `gfxSet3D(false)` confirmed present in `ui.c` (eliminates black-stripe artifact).
- **FIXED**: `editor_undo()` checks `undo_valid` before restoring — no crash on first B press.
- **FIXED**: `fe_load_slot()` uses `static char load_buf[EDITOR_MAX]` — no stack overflow crash.
- **FIXED**: `override LD := $(CC)` in Makefile — no `ld: command not found` linker errors.
- **FIXED**: APP_TITLE/DESCRIPTION/AUTHOR commented out — no banner/SMDH build step triggered.

## v0.30 (patch series)
- Progressive patch series adding `file_explorer.h`, `runtime_tick()`, `RuntimeInfo` typedef.
- Multiple partial patches applied; root cause of recurring errors was stale `runtime.c`.

## v0.29 — v0.10
- Phase 1–11 implementation: QuickJS, DOM bindings, fetch, IndexedDB, iframe, Canvas, WebGL,
  audio, asset loading, full 3DS controls mapping, HTTPS/TLS scaffold with mbedTLS/wolfSSL,
  CA bundle embedding, gzip/deflate, stb_image PNG/JPEG decoding.

## v0.09
- Rebranded from original name to Pocket Compiler.

## v0.01 — v0.08
- Initial HTML/CSS/JS editor, libctru console rendering, SD card I/O,
  HTTP socket support, redirect/chunked transfer, CA bundle.
