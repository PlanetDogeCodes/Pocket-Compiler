/*
 * web_html_parser.c  —  HTML5-subset tokenizer → DOM builder
 */
#include "web_html_parser.h"
#include "duktape.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_js.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>

/* ── Helpers ────────────────────────────────────────────────────── */

bool wep_is_void(const char *tag){
    static const char *voids[]={
        "area","base","br","col","embed","hr","img","input",
        "link","meta","param","source","track","wbr",NULL};
    for(int i=0;voids[i];i++) if(strcmp(tag,voids[i])==0) return true;
    return false;
}

bool wep_is_block(const char *tag){ return wep_is_block_tag(tag); }

void wep_unescape(const char *in, char *out, int out_sz){
    int o=0;
    const char *p=in;
    while(*p&&o<out_sz-1){
        if(*p=='&'){
            if(strncmp(p,"&amp;",5)==0){  out[o++]='&'; p+=5; }
            else if(strncmp(p,"&lt;",4)==0){  out[o++]='<'; p+=4; }
            else if(strncmp(p,"&gt;",4)==0){  out[o++]='>'; p+=4; }
            else if(strncmp(p,"&quot;",6)==0){ out[o++]='"'; p+=6; }
            else if(strncmp(p,"&apos;",6)==0){ out[o++]='\'';p+=6; }
            else if(strncmp(p,"&nbsp;",6)==0){ out[o++]=' '; p+=6; }
            else if(p[1]=='#'){
                /* &#NNN; or &#xHH; */
                int code=0;
                const char *q=p+2;
                if(*q=='x'||*q=='X'){
                    code=(int)strtol(q+1,NULL,16);
                } else {
                    code=atoi(q);
                }
                /* encode as UTF-8 (only ASCII for simplicity) */
                if(code>0&&code<128) out[o++]=(char)code;
                const char *semi=strchr(p,';');
                if(semi) p=semi+1; else p++;
            } else { out[o++]=*p++; }
        } else {
            out[o++]=*p++;
        }
    }
    out[o]='\0';
}

/* ── Parser state ───────────────────────────────────────────────── */

#define BUF_SZ  512

typedef struct {
    const char *src;
    int         pos;
    int         len;
    uint8_t     doc_id;
    int16_t     stack[64];   /* open element stack */
    int         stack_n;
    /* pending style/script nodes list */
    int16_t     script_nodes[32];
    int         script_n;
    int16_t     style_nodes[32];
    int         style_n;
} ParseState;

static char s_tok[BUF_SZ];
static char s_aname[64];
static char s_aval[512];
static char s_text[512];

static int16_t ps_top(ParseState *ps){
    if(ps->stack_n<=0) return -1;
    return ps->stack[ps->stack_n-1];
}

static void ps_push(ParseState *ps, int16_t node){
    if(ps->stack_n<64) ps->stack[ps->stack_n++]=node;
}

static char ps_peek(ParseState *ps){
    if(ps->pos>=ps->len) return '\0';
    return ps->src[ps->pos];
}

static void ps_skip_ws(ParseState *ps){
    while(ps->pos<ps->len&&isspace((unsigned char)ps->src[ps->pos])) ps->pos++;
}

/* Read until 'stop' char (or EOF), store in buf[buf_sz] */
static int read_until(ParseState *ps, char stop, char *buf, int buf_sz){
    int n=0;
    while(ps->pos<ps->len){
        char c=ps->src[ps->pos];
        if(c==stop) break;
        if(n<buf_sz-1) buf[n++]=c;
        ps->pos++;
    }
    buf[n]='\0';
    return n;
}

/* Read until pattern (case-insensitive), return content before it */
static int read_until_str(ParseState *ps, const char *pat, char *buf, int buf_sz){
    int n=0; int pl=(int)strlen(pat);
    while(ps->pos<ps->len){
        if(strncasecmp(ps->src+ps->pos,pat,pl)==0){ ps->pos+=pl; break; }
        if(n<buf_sz-1) buf[n++]=ps->src[ps->pos];
        ps->pos++;
    }
    buf[n]='\0';
    return n;
}

/* ── Tag parsing ────────────────────────────────────────────────── */

static void lowercase(char *s){
    for(;*s;s++) *s=(char)tolower((unsigned char)*s);
}

/* Find matching closing tag in stack, pop to it */
static void pop_to_tag(ParseState *ps, const char *tag){
    for(int i=ps->stack_n-1;i>=0;i--){
        if(strcmp(dom_tag(ps->stack[i]),tag)==0){
            ps->stack_n=i;
            return;
        }
    }
}

static void handle_open_tag(ParseState *ps){
    /* read tag name */
    int ni=0;
    while(ps->pos<ps->len){
        char c=ps->src[ps->pos];
        if(isspace((unsigned char)c)||c=='>'||c=='/') break;
        if(ni<BUF_SZ-1) s_tok[ni++]=c;
        ps->pos++;
    }
    s_tok[ni]='\0'; lowercase(s_tok);
    if(!*s_tok) return;
    bool is_void=wep_is_void(s_tok);

    /* create element */
    int16_t parent=ps_top(ps);
    /* special: if inside <head>, accept head-only tags */
    int16_t node=dom_new_element(ps->doc_id,s_tok);
    if(node<0) return;
    if(parent>=0) dom_append_child(parent,node);
    else {
        DOMDocument *d=dom_doc(ps->doc_id);
        if(d&&d->root_node<0) d->root_node=node;
    }

    /* update doc shortcuts */
    DOMDocument *d=dom_doc(ps->doc_id);
    if(d){
        if(strcmp(s_tok,"head")==0) d->head_node=node;
        else if(strcmp(s_tok,"body")==0) d->body_node=node;
        else if(strcmp(s_tok,"title")==0) d->title_node=node;
    }

    /* read attributes */
    while(ps->pos<ps->len){
        ps_skip_ws(ps);
        char c=ps_peek(ps);
        if(c=='>'||c=='\0') break;
        if(c=='/'){
            ps->pos++;
            ps_skip_ws(ps);
            if(ps_peek(ps)=='>') break;
            continue;
        }
        /* read attr name */
        int ai=0;
        while(ps->pos<ps->len){
            char ac=ps->src[ps->pos];
            if(isspace((unsigned char)ac)||ac=='='||ac=='>'||ac=='/') break;
            if(ai<63) s_aname[ai++]=ac;
            ps->pos++;
        }
        s_aname[ai]='\0'; lowercase(s_aname);
        ps_skip_ws(ps);
        if(ps_peek(ps)=='='){
            ps->pos++; /* consume '=' */
            ps_skip_ws(ps);
            char q=ps_peek(ps);
            int vi=0;
            if(q=='"'||q=='\''){
                ps->pos++;
                while(ps->pos<ps->len){
                    char vc=ps->src[ps->pos++];
                    if(vc==q) break;
                    if(vi<511) s_aval[vi++]=vc;
                }
            } else {
                while(ps->pos<ps->len){
                    char vc=ps->src[ps->pos];
                    if(isspace((unsigned char)vc)||vc=='>') break;
                    if(vi<511) s_aval[vi++]=vc;
                    ps->pos++;
                }
            }
            s_aval[vi]='\0';
            if(*s_aname) dom_set_attr(node,s_aname,s_aval);
        } else {
            if(*s_aname) dom_set_attr(node,s_aname,""); /* boolean attr */
        }
    }
    /* consume '>' */
    if(ps_peek(ps)=='>') ps->pos++;

    /* apply inline style */
    const char *inl=dom_get_attr(node,"style");
    if(inl) css_parse_inline(inl,&g_dom_nodes[node].style);

    /* handle special tags */
    if(strcmp(s_tok,"script")==0){
        /* read script content */
        static char scbuf[16384]; int scl=read_until_str(ps,"</script>",scbuf,sizeof(scbuf));
        (void)scl;
        /* store as text child */
        if(*scbuf){
            int16_t tn=dom_new_text(ps->doc_id,scbuf);
            if(tn>=0) dom_append_child(node,tn);
            if(ps->script_n<32) ps->script_nodes[ps->script_n++]=node;
        }
        return; /* don't push to stack */
    }
    if(strcmp(s_tok,"style")==0){
        static char stbuf[8192]; int stl=read_until_str(ps,"</style>",stbuf,sizeof(stbuf));
        (void)stl;
        if(*stbuf){
            int16_t tn=dom_new_text(ps->doc_id,stbuf);
            if(tn>=0) dom_append_child(node,tn);
            if(ps->style_n<32) ps->style_nodes[ps->style_n++]=node;
        }
        return;
    }

    if(!is_void) ps_push(ps,node);
}

static void handle_close_tag(ParseState *ps){
    int ni=0;
    while(ps->pos<ps->len){
        char c=ps->src[ps->pos];
        if(isspace((unsigned char)c)||c=='>') break;
        if(ni<BUF_SZ-1) s_tok[ni++]=c;
        ps->pos++;
    }
    s_tok[ni]='\0'; lowercase(s_tok);
    if(ps_peek(ps)=='>') ps->pos++;
    /* pop matching open tag */
    pop_to_tag(ps,s_tok);
}

static void handle_text(ParseState *ps, const char *text){
    /* strip if only whitespace (unless pre context) */
    bool all_ws=true;
    for(const char *p=text;*p;p++) if(!isspace((unsigned char)*p)){ all_ws=false; break; }
    if(all_ws) return;
    /* unescape */
    char unesc[512]; wep_unescape(text,unesc,sizeof(unesc));
    int16_t parent=ps_top(ps);
    int16_t tn=dom_new_text(ps->doc_id,unesc);
    if(tn>=0&&parent>=0) dom_append_child(parent,tn);
}

/* ── Main parse loop ────────────────────────────────────────────── */

int16_t wep_parse(const char *html, const WEParseOpts *opts){
    if(!html||!opts) return -1;
    static ParseState ps;
    memset(&ps,0,sizeof(ps));
    ps.src=html;
    ps.len=(int)strlen(html);
    ps.doc_id=opts->doc_id;

    DOMDocument *d=dom_doc(opts->doc_id);
    if(!d) return -1;

    /* create root document node if full document */
    if(!opts->fragment_mode){
        int16_t doc_node=dom_new_element(opts->doc_id,"#document");
        if(doc_node>=0){ d->root_node=doc_node; ps_push(&ps,doc_node); }
    } else {
        if(opts->fragment_parent>=0) ps_push(&ps,opts->fragment_parent);
    }

    while(ps.pos<ps.len){
        char c=ps.src[ps.pos];
        if(c=='<'){
            ps.pos++;
            char nc=ps_peek(&ps);
            if(nc=='!'){
                /* comment or DOCTYPE */
                ps.pos++;
                if(strncmp(ps.src+ps.pos,"--",2)==0){
                    ps.pos+=2;
                    read_until_str(&ps,"-->",s_text,sizeof(s_text));
                } else if(strncasecmp(ps.src+ps.pos,"DOCTYPE",7)==0){
                    read_until(&ps,'>',s_text,sizeof(s_text));
                    if(ps_peek(&ps)=='>') ps.pos++;
                } else if(strncmp(ps.src+ps.pos,"[CDATA[",7)==0){
                    ps.pos+=7;
                    read_until_str(&ps,"]]>",s_text,sizeof(s_text));
                } else {
                    read_until(&ps,'>',s_text,sizeof(s_text));
                    if(ps_peek(&ps)=='>') ps.pos++;
                }
            } else if(nc=='/'){
                ps.pos++;
                handle_close_tag(&ps);
            } else {
                handle_open_tag(&ps);
            }
        } else {
            /* text content */
            int ti=0;
            while(ps.pos<ps.len&&ps.src[ps.pos]!='<'){
                if(ti<511) s_text[ti++]=ps.src[ps.pos];
                ps.pos++;
            }
            s_text[ti]='\0';
            handle_text(&ps,s_text);
        }
    }

    /* run style blocks */
    for(int i=0;i<ps.style_n;i++){
        int16_t sn=ps.style_nodes[i];
        int16_t tc=g_dom_nodes[sn].first_child;
        if(tc>=0){
            const char *css=dom_text(g_dom_nodes[tc].text_off);
            if(css) css_parse_stylesheet(css);
        }
    }

    /* cascade computed styles */
    css_cascade(opts->doc_id);

    /* store script nodes for later execution */
    for(int i=0;i<ps.script_n;i++){
        /* These get run by wep_run_scripts() */
        /* For now, just mark them */
        (void)ps.script_nodes[i];
    }

    return d->body_node>=0 ? d->body_node : d->root_node;
}

void wep_run_scripts(uint8_t doc_id){
    DOMDocument *d=dom_doc(doc_id);
    if(!d||!d->js_ready||!d->js_ctx) return;
    duk_context *ctx=(duk_context*)d->js_ctx;
    /* find all <script> elements */
    int16_t node=dom_get_by_tag(doc_id,"script",-1);
    while(node>=0){
        /* check for src attribute */
        const char *src=dom_get_attr(node,"src");
        if(src&&*src){
            wjs_eval_file(ctx,src);
        } else {
            /* inline script: get text child */
            int16_t tc=g_dom_nodes[node].first_child;
            if(tc>=0){
                const char *script=dom_text(g_dom_nodes[tc].text_off);
                if(script&&*script) wjs_eval(ctx,script);
            }
        }
        node=dom_get_by_tag(doc_id,"script",node);
    }
    /* fire DOMContentLoaded */
    wjs_call(ctx,"_we_dcl");
}

void wep_run_styles(uint8_t doc_id){
    int16_t node=dom_get_by_tag(doc_id,"style",-1);
    while(node>=0){
        int16_t tc=g_dom_nodes[node].first_child;
        if(tc>=0){
            const char *css=dom_text(g_dom_nodes[tc].text_off);
            if(css) css_parse_stylesheet(css);
        }
        node=dom_get_by_tag(doc_id,"style",node);
    }
    css_cascade(doc_id);
}

void wep_parse_css(const char *css, uint8_t doc_id){
    css_parse_stylesheet(css);
    css_cascade(doc_id);
}
