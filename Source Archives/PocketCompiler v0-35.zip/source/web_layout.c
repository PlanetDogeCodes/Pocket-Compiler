/*
 * web_layout.c  —  Layout engine: block, inline, flex, absolute, fixed
 */
#include "web_layout.h"
#include "web_dom.h"
#include "web_css.h"
#include <string.h>
#include <stdlib.h>

/* Font metrics (approximate) */
#define CH_W   6   /* character width at font_size=11 */
#define CH_H  13   /* character height at font_size=11 */

static int char_width(int font_size){
    return (font_size * CH_W + 10) / 11;
}
static int line_height(int font_size){
    return (font_size * CH_H + 10) / 11 + 2;
}

/* ── Measure text width ─────────────────────────────────────────── */
static int measure_text(const char *s, int font_size){
    if(!s) return 0;
    int n=0; for(const char *p=s;*p;p++) n++;
    return n * char_width(font_size);
}

/* ── Clamp layout result ─────────────────────────────────────────── */
static int16_t clamp_w(DOMNode *n, int16_t w){
    if(n->style.min_width>0&&w<n->style.min_width) w=n->style.min_width;
    if(n->style.max_width>0&&w>n->style.max_width) w=n->style.max_width;
    return w;
}
static int16_t clamp_h(DOMNode *n, int16_t h){
    if(n->style.min_height>0&&h<n->style.min_height) h=n->style.min_height;
    if(n->style.max_height>0&&h>n->style.max_height) h=n->style.max_height;
    return h;
}

/* ── Forward declarations ───────────────────────────────────────── */
static void layout_children(int16_t node_id, LayoutCtx *ctx);

/* ── Node layout ────────────────────────────────────────────────── */

void layout_node(int16_t node_id, LayoutCtx *ctx){
    if(node_id<0) return;
    DOMNode *n=dom_node(node_id);
    if(!n) return;

    /* skip invisible */
    if(n->style.display==4||n->style.visibility==1){
        n->lay_w=0; n->lay_h=0; return;
    }

    /* text node */
    if(n->type==NT_TEXT){
        const char *t=dom_text(n->text_off);
        int fs=g_dom_nodes[n->parent>=0?n->parent:node_id].style.font_size;
        if(fs<=0) fs=CSS_DEFAULT_FONT_SIZE;
        int tw=measure_text(t,fs);
        int th=line_height(fs);
        n->lay_x=(int16_t)ctx->cursor_x;
        n->lay_y=(int16_t)ctx->cursor_y;
        /* wrap: if text wider than available, split at words */
        if(tw>ctx->avail_w&&ctx->avail_w>0){
            int lines=(tw/ctx->avail_w)+1;
            n->lay_w=(int16_t)ctx->avail_w;
            n->lay_h=(int16_t)(th*lines);
        } else {
            /* Always use avail_w as lay_w so text alignment works correctly.
             * The renderer uses lay_w as the container width for centering. */
            n->lay_w=(ctx->avail_w>0)?(int16_t)ctx->avail_w:(int16_t)tw;
            n->lay_h=(int16_t)th;
        }
        return;
    }

    if(n->type!=NT_ELEMENT) return;

    CSSStyle *st=&n->style;
    int fs=st->font_size>0?st->font_size:CSS_DEFAULT_FONT_SIZE;
    (void)fs;

    /* absolute / fixed positioning */
    if(st->position==2||st->position==3){
        int16_t px=(st->position==3)?0:ctx->base_x;
        int16_t py=(st->position==3)?0:ctx->base_y;
        n->lay_x=(int16_t)(px+st->left);
        n->lay_y=(int16_t)(py+st->top);
        int16_t aw=(st->width>0)?st->width:(ctx->avail_w-st->left-st->right);
        int16_t ah=(st->height>0)?st->height:(ctx->avail_h-st->top-st->bottom);
        if(aw<0) aw=64; if(ah<0) ah=32;
        n->lay_w=clamp_w(n,aw); n->lay_h=clamp_h(n,ah);
        LayoutCtx child_ctx={
            .avail_w=(int16_t)(n->lay_w-st->padding_left-st->padding_right),
            .avail_h=(int16_t)(n->lay_h-st->padding_top-st->padding_bottom),
            .base_x=(int16_t)(n->lay_x+st->padding_left),
            .base_y=(int16_t)(n->lay_y+st->padding_top),
            .cursor_x=(int16_t)(n->lay_x+st->padding_left),
            .cursor_y=(int16_t)(n->lay_y+st->padding_top),
            .doc_id=ctx->doc_id
        };
        layout_children(node_id,&child_ctx);
        if(st->height<=0) n->lay_h=clamp_h(n,(int16_t)(child_ctx.cursor_y-n->lay_y+st->padding_bottom));
        return;
    }

    /* determine element width */
    int16_t el_w;
    if(st->width>0)  el_w=st->width;
    else if(st->display==0||st->display==5) el_w=(int16_t)(ctx->avail_w-st->margin_left-st->margin_right);
    else el_w=0;

    /* position element */
    if(st->display==0||st->display==3||st->display==5){
        n->lay_x=(int16_t)(ctx->base_x+st->margin_left);
        n->lay_y=(int16_t)(ctx->cursor_y+st->margin_top);
    } else {
        n->lay_x=(int16_t)(ctx->cursor_x+st->margin_left);
        n->lay_y=(int16_t)(ctx->cursor_y+st->margin_top);
    }

    if(el_w<0) el_w=0;
    n->lay_w=clamp_w(n,el_w);

    /* layout children */
    LayoutCtx child_ctx={
        .avail_w=(int16_t)(n->lay_w-st->padding_left-st->padding_right-2*st->border_width),
        .avail_h=(st->height>0)?(int16_t)(st->height-st->padding_top-st->padding_bottom):WE_VIEWPORT_H,
        .base_x=(int16_t)(n->lay_x+st->padding_left+st->border_width),
        .base_y=(int16_t)(n->lay_y+st->padding_top+st->border_width),
        .cursor_x=(int16_t)(n->lay_x+st->padding_left+st->border_width),
        .cursor_y=(int16_t)(n->lay_y+st->padding_top+st->border_width),
        .doc_id=ctx->doc_id
    };
    if(child_ctx.avail_w<0) child_ctx.avail_w=1;

    if(st->display==3) layout_flex(node_id,&child_ctx);
    else               layout_children(node_id,&child_ctx);

    /* compute height from content if auto */
    int16_t content_h=(int16_t)(child_ctx.cursor_y-(n->lay_y+st->padding_top+st->border_width));
    if(content_h<0) content_h=0;
    if(st->height>0) n->lay_h=clamp_h(n,st->height);
    else n->lay_h=clamp_h(n,(int16_t)(content_h+st->padding_top+st->padding_bottom+2*st->border_width));
    if(n->lay_h<1) n->lay_h=1;

    /* if explicit width was 0 (inline-block): measure content width */
    if(el_w==0){
        int16_t max_x=n->lay_x;
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            DOMNode *c=dom_node(ch);
            if(c&&c->lay_x+c->lay_w>max_x) max_x=c->lay_x+c->lay_w;
        }
        n->lay_w=clamp_w(n,(int16_t)(max_x-n->lay_x+st->padding_right));
    }

    /* update parent cursor */
    if(st->display==0||st->display==3||st->display==5){
        ctx->cursor_y=(int16_t)(n->lay_y+n->lay_h+st->margin_bottom);
        ctx->cursor_x=ctx->base_x;
        ctx->line_h=0;
    } else {
        ctx->cursor_x=(int16_t)(n->lay_x+n->lay_w+st->margin_right);
        if(n->lay_h>ctx->line_h) ctx->line_h=n->lay_h;
    }
}

/* ── Children layout ─────────────────────────────────────────────── */

static void layout_children(int16_t node_id, LayoutCtx *ctx){
    DOMNode *n=dom_node(node_id);
    if(!n) return;
    for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
        layout_node(ch,ctx);
        DOMNode *c=dom_node(ch);
        if(c&&c->type==NT_ELEMENT&&c->style.display==0){
            /* block already advances cursor_y via layout_node */
        } else if(c&&c->type==NT_TEXT){
            ctx->cursor_x=(int16_t)(c->lay_x+c->lay_w);
            if(c->lay_h>ctx->line_h) ctx->line_h=c->lay_h;
            if(ctx->cursor_x>ctx->base_x+ctx->avail_w){
                ctx->cursor_y+=(int16_t)ctx->line_h;
                ctx->cursor_x=ctx->base_x;
                ctx->line_h=0;
                c->lay_x=ctx->cursor_x;
                c->lay_y=ctx->cursor_y;
            }
        }
    }
    if(ctx->line_h>0) ctx->cursor_y+=(int16_t)ctx->line_h;
}

/* ── Flex layout ─────────────────────────────────────────────────── */

void layout_flex(int16_t node_id, LayoutCtx *ctx){
    DOMNode *n=dom_node(node_id);
    if(!n) return;
    CSSStyle *st=&n->style;
    bool row=(st->flex_direction==0||st->flex_direction==2);
    bool rev=(st->flex_direction==2||st->flex_direction==3);

    int16_t children[64]; int nc=0;
    for(int16_t ch=n->first_child;ch>=0&&nc<64;ch=g_dom_nodes[ch].next_sib)
        children[nc++]=(int16_t)ch;

    LayoutCtx child_ctx=*ctx;
    for(int i=0;i<nc;i++){
        int16_t ci=rev?children[nc-1-i]:children[i];
        child_ctx.cursor_x=ctx->base_x;
        child_ctx.cursor_y=ctx->base_y;
        layout_node(ci,&child_ctx);
    }

    int total_main=0, total_cross=0;
    for(int i=0;i<nc;i++){
        DOMNode *c=dom_node(children[i]);
        if(!c) continue;
        CSSStyle *cs=&c->style;
        if(row) total_main+=c->lay_w+cs->margin_left+cs->margin_right+st->gap;
        else    total_main+=c->lay_h+cs->margin_top+cs->margin_bottom+st->gap;
        int cross=row?(c->lay_h+cs->margin_top+cs->margin_bottom):(c->lay_w+cs->margin_left+cs->margin_right);
        if(cross>total_cross) total_cross=cross;
    }
    if(nc>0&&st->gap>0) total_main-=st->gap;

    int avail=(row?ctx->avail_w:ctx->avail_h);
    int space=avail-total_main;
    int offset=0, gap_extra=0;
    if(st->justify_content==1)   offset=space;
    else if(st->justify_content==2) offset=space/2;
    else if(st->justify_content==3&&nc>1) gap_extra=space/(nc-1);
    else if(st->justify_content==4&&nc>0) { offset=space/(nc*2+2); gap_extra=space/(nc+1); }

    int cursor=offset;
    for(int i=0;i<nc;i++){
        int16_t ci=rev?children[nc-1-i]:children[i];
        DOMNode *c=dom_node(ci);
        if(!c) continue;
        CSSStyle *cs=&c->style;
        if(row){
            c->lay_x=(int16_t)(ctx->base_x+cursor+cs->margin_left);
            if(st->align_items==2) c->lay_y=(int16_t)(ctx->base_y+(total_cross-c->lay_h)/2);
            else if(st->align_items==1) c->lay_y=(int16_t)(ctx->base_y+total_cross-c->lay_h-cs->margin_bottom);
            else c->lay_y=(int16_t)(ctx->base_y+cs->margin_top);
            cursor+=c->lay_w+cs->margin_left+cs->margin_right+st->gap+gap_extra;
        } else {
            c->lay_y=(int16_t)(ctx->base_y+cursor+cs->margin_top);
            if(st->align_items==2) c->lay_x=(int16_t)(ctx->base_x+(total_cross-c->lay_w)/2);
            else c->lay_x=(int16_t)(ctx->base_x+cs->margin_left);
            cursor+=c->lay_h+cs->margin_top+cs->margin_bottom+st->gap+gap_extra;
        }
    }

    ctx->cursor_y=(int16_t)(n->lay_y+n->lay_h+n->style.margin_bottom);
}

/* ── Document layout ─────────────────────────────────────────────── */

void layout_document(uint8_t doc_id){
    DOMDocument *d=dom_doc(doc_id);
    if(!d) return;
    LayoutCtx ctx={
        .avail_w=WE_VIEWPORT_W,
        .avail_h=WE_VIEWPORT_H,
        .base_x=0,.base_y=0,
        .cursor_x=0,.cursor_y=0,
        .doc_id=doc_id
    };
    int16_t body=d->body_node>=0?d->body_node:d->root_node;
    if(body>=0){
        DOMNode *bn=dom_node(body);
        if(bn){
            bn->lay_x=0; bn->lay_y=0;
            bn->lay_w=WE_VIEWPORT_W; bn->lay_h=WE_VIEWPORT_H;
            /* FIX: was 2*margin_left — must use margin_left + margin_right */
            LayoutCtx bctx={
                .avail_w=(int16_t)(WE_VIEWPORT_W
                                   -bn->style.padding_left
                                   -bn->style.padding_right
                                   -bn->style.margin_left
                                   -bn->style.margin_right),
                .avail_h=WE_VIEWPORT_H,
                .base_x=(int16_t)(bn->style.margin_left+bn->style.padding_left),
                .base_y=(int16_t)(bn->style.margin_top+bn->style.padding_top),
                .cursor_x=(int16_t)(bn->style.margin_left+bn->style.padding_left),
                .cursor_y=(int16_t)(bn->style.margin_top+bn->style.padding_top),
                .doc_id=doc_id
            };
            if(bctx.avail_w<0) bctx.avail_w=1;
            if(bn->style.display==3) layout_flex(body,&bctx);
            else layout_children(body,&bctx);
        }
    }
    dom_clear_dirty(doc_id);
}

/* ── Hit test ────────────────────────────────────────────────────── */

void layout_scroll_extents(int16_t node_id, int16_t *max_sx, int16_t *max_sy){
    *max_sx=0; *max_sy=0;
    DOMNode *n=dom_node(node_id); if(!n) return;
    int16_t max_x=0, max_y=0;
    for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
        DOMNode *c=dom_node(ch);
        if(!c) continue;
        int16_t ex=c->lay_x+c->lay_w-n->lay_x;
        int16_t ey=c->lay_y+c->lay_h-n->lay_y;
        if(ex>max_x) max_x=ex;
        if(ey>max_y) max_y=ey;
    }
    *max_sx=(max_x>n->lay_w)?max_x-n->lay_w:0;
    *max_sy=(max_y>n->lay_h)?max_y-n->lay_h:0;
}

int16_t layout_hit(uint8_t doc_id, int16_t x, int16_t y){
    int16_t best=-1;
    int16_t best_z=-32768;
    for(int i=g_dom_node_n-1;i>=0;i--){
        DOMNode *n=&g_dom_nodes[i];
        if(n->doc_id!=doc_id) continue;
        if(n->type!=NT_ELEMENT) continue;
        if(n->style.display==4||n->style.visibility==1) continue;
        if(x>=n->lay_x&&x<n->lay_x+n->lay_w&&
           y>=n->lay_y&&y<n->lay_y+n->lay_h){
            if(n->style.z_index>=best_z){
                best_z=n->style.z_index;
                best=(int16_t)i;
            }
        }
    }
    return best;
}

int16_t layout_find_focusable(int16_t node_id){
    if(node_id<0) return -1;
    DOMNode *n=dom_node(node_id);
    if(!n) return -1;
    const char *tag=dom_tag(node_id);
    if(strcmp(tag,"a")==0||strcmp(tag,"button")==0||
       strcmp(tag,"input")==0||strcmp(tag,"select")==0||
       strcmp(tag,"textarea")==0) return node_id;
    if(dom_has_attr(node_id,"tabindex")) return node_id;
    return layout_find_focusable(n->parent);
}
