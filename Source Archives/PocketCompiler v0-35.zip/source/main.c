/*
 * main.c — Entry point for Pocket Compiler v0.33
 *
 * Input model:
 *   EDIT MODE (not run_mode):
 *     Circle pad  → move cursor dot on bottom screen
 *     DPad U/D    → scroll code vertically
 *     DPad L/R    → scroll code horizontally (view_left)
 *     A           → edit the line the cursor dot is hovering over
 *     B           → undo
 *     X           → open Save explorer
 *     Y           → open Load explorer
 *     START       → compile & enter run mode
 *     SELECT      → controls reference screen
 *
 *   RUN MODE (run_mode == true):
 *     START       → stop output, return to edit mode
 *     Circle pad  → move top-screen cursor
 *     DPad U/D    → scroll output
 *     DPad L/R    → (reserved / future horizontal output scroll)
 *     A / L trig  → left-click (first click over output enables cursor lock)
 *     B / R trig  → right-click
 *     X           → ESC: release cursor lock
 *     Y           → Space
 *     (all other buttons ignored while run_mode is active)
 */
#include <3ds.h>
#include <stdio.h>
#include <string.h>

#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include "web_engine.h"
#include "ui.h"

static AppState       g_app;
static Editor         g_editor;
static FeatureRuntime g_runtime;

#define CURSOR_SPEED  0.08f   /* reduced from 0.18f for finer control */
#define DEADZONE      14      /* circle-pad dead zone — prevents drift  */

/* ── Layout constants (must match ui.c) ─────────────────────────── */
/* These are used to map cursor_y → code row in the editor panel.    */
#define LAYOUT_ED_Y      28.0f   /* top of editor panel              */
#define LAYOUT_ED_PAD     5.0f   /* inner padding                    */
#define LAYOUT_LH_ED     15.0f   /* line height in editor            */
#define LAYOUT_ED_X       6.0f   /* left edge of editor panel        */
#define LAYOUT_ED_W     308.0f   /* width  of editor panel           */
#define LAYOUT_ED_H     180.0f   /* height of editor panel (240-28-32)*/

/* Top-screen output panel bounds (run_mode) */
#define LAYOUT_OUT_X0     8.0f
#define LAYOUT_OUT_X1   392.0f
#define LAYOUT_OUT_Y0    40.0f   /* top of scrollable content area   */
#define LAYOUT_OUT_Y1   234.0f

static char g_fname[FE_FILENAME_MAX];

static void ensure_html_ext(char *buf, int sz){
    size_t len=strlen(buf);
    if(!len)return;
    if(len<5||strcmp(buf+len-5,".html")!=0)
        if((int)(len+5)<sz)strcat(buf,".html");
}

static bool kbd(const char *fill,const char *hint,char *out,int out_sz){
    SwkbdState s;
    swkbdInit(&s,SWKBD_TYPE_NORMAL,2,out_sz-1);
    if(fill)swkbdSetInitialText(&s,fill);
    if(hint)swkbdSetHintText(&s,hint);
    return swkbdInputText(&s,out,(size_t)out_sz)==SWKBD_BUTTON_CONFIRM;
}

/* Clamp a float to [lo, hi]. */
static float clampf(float v,float lo,float hi){
    if(v<lo)return lo;
    if(v>hi)return hi;
    return v;
}

int main(void){
    ui_init();
    runtime_init(&g_runtime);
    editor_init(&g_editor);

    /* memset first, then initialise sub-structs that live inside g_app */
    memset(&g_app,0,sizeof(g_app));
    fe_init(&g_app.fe);
    we_init();            /* fe_init just zeros — must come AFTER memset */
    g_app.mode         = MODE_EDIT;
    g_app.cursor_x     = 160.f;
    g_app.cursor_y     = 120.f;
    g_app.top_cursor_x = 200.f;
    g_app.top_cursor_y = 130.f;

    /* Bug fix: seed code_cursor_line from the initial cursor position so
     * the hover highlight is correct before the user touches the circle pad. */
    {
        float code_top = LAYOUT_ED_Y + LAYOUT_ED_PAD;
        int   vr       = (int)((g_app.cursor_y - code_top) / LAYOUT_LH_ED);
        if(vr<0)          vr=0;
        if(vr>=CODE_AREA_H) vr=CODE_AREA_H-1;
        g_app.code_cursor_line = vr;
    }

    ui_draw(&g_app,&g_editor,&g_runtime);

    while(aptMainLoop()){
        hidScanInput();
        u32 held = hidKeysHeld(); (void)held;
        u32 down = hidKeysDown();

        /* Circle pad — apply deadzone first */
        circlePosition cp;
        hidCircleRead(&cp);
        if(cp.dx>-DEADZONE&&cp.dx<DEADZONE) cp.dx=0;
        if(cp.dy>-DEADZONE&&cp.dy<DEADZONE) cp.dy=0;

        bool dirty = false;

        /* ── Click-flash countdown (fires every frame) ──────────── */
        if(g_app.click_flash>0){
            g_app.click_flash--;
            dirty=true;
        }

        /* ═══════════════════════════════════════════════════════
           RUN MODE — top screen active, bottom screen locked
           ═══════════════════════════════════════════════════════ */
        if(g_app.run_mode){

            /* START → stop output, return to edit */
            if(down&KEY_START){
                g_app.run_mode     = false;
                g_app.cursor_locked= false;
                we_unload();
                dirty=true;
            }

            /* Circle pad → move top-screen cursor */
            if(cp.dx||cp.dy){
                g_app.top_cursor_x += cp.dx*CURSOR_SPEED;
                g_app.top_cursor_y -= cp.dy*CURSOR_SPEED;
                if(g_app.cursor_locked){
                    g_app.top_cursor_x=clampf(g_app.top_cursor_x,LAYOUT_OUT_X0,LAYOUT_OUT_X1);
                    g_app.top_cursor_y=clampf(g_app.top_cursor_y,LAYOUT_OUT_Y0,LAYOUT_OUT_Y1);
                } else {
                    g_app.top_cursor_x=clampf(g_app.top_cursor_x,0.f,399.f);
                    g_app.top_cursor_y=clampf(g_app.top_cursor_y,0.f,239.f);
                }
                dirty=true;
            }

            /* X → ESC: release cursor lock */
            if(down&KEY_X){
                g_app.cursor_locked=false;
                dirty=true;
            }

            /* Y → Space (visual feedback; no JS engine) */
            if(down&KEY_Y){
                dirty=true;
            }

            /* DPad → scroll output */
            if(down&KEY_UP){
                if(g_app.out_scroll>0)g_app.out_scroll--;
                dirty=true;
            }
            if(down&KEY_DOWN){
                /* Clamp to actual number of output lines, not a magic constant */
                int out_max=ui_get_out_count()-1;
                if(out_max<0) out_max=0;
                if(g_app.out_scroll<out_max) g_app.out_scroll++;
                dirty=true;
            }
            /* DPad L/R reserved for future horizontal output scroll */
            if(down&KEY_LEFT)  dirty=true;
            if(down&KEY_RIGHT) dirty=true;

            /* A or L trigger → left-click */
            if((down&KEY_A)||(down&KEY_L)){
                bool over_out=(g_app.top_cursor_x>=LAYOUT_OUT_X0&&
                               g_app.top_cursor_x<=LAYOUT_OUT_X1&&
                               g_app.top_cursor_y>=LAYOUT_OUT_Y0&&
                               g_app.top_cursor_y<=LAYOUT_OUT_Y1);
                /* First click over output enables cursor lock */
                if(over_out&&!g_app.cursor_locked){
                    g_app.cursor_locked=true;
                    /* Snap cursor into bounds */
                    g_app.top_cursor_x=clampf(g_app.top_cursor_x,LAYOUT_OUT_X0,LAYOUT_OUT_X1);
                    g_app.top_cursor_y=clampf(g_app.top_cursor_y,LAYOUT_OUT_Y0,LAYOUT_OUT_Y1);
                }
                /* Determine which output line was clicked.
                 * Content starts after header (≈22px) + 4px inner pad = 26px;
                 * average line height ≈ 14px.                              */
                float content_y0 = 26.0f;
                float avg_lh     = 14.0f;
                int   clicked    = (int)((g_app.top_cursor_y - content_y0) / avg_lh);
                clicked += g_app.out_scroll;
                if(clicked<0) clicked=0;
                g_app.click_line  = clicked;
                g_app.click_flash = 10;
                dirty=true;
            }

            /* B or R trigger → right-click (visual only) */
            if((down&KEY_B)||(down&KEY_R)){
                g_app.click_flash = 5;
                dirty=true;
            }

        /* ═══════════════════════════════════════════════════════
           NORMAL (EDIT/SAVE/LOAD/CONTROLS) MODE
           ═══════════════════════════════════════════════════════ */
        } else {

            /* Circle pad → move bottom-screen cursor */
            if(cp.dx||cp.dy){
                g_app.cursor_x=clampf(g_app.cursor_x+cp.dx*CURSOR_SPEED,0.f,319.f);
                g_app.cursor_y=clampf(g_app.cursor_y-cp.dy*CURSOR_SPEED,0.f,239.f);
                dirty=true;
            }

            /* Always update which code row the cursor is hovering.
             * Uses layout constants matching ui.c's editor panel.  */
            {
                float code_top  = LAYOUT_ED_Y + LAYOUT_ED_PAD; /* 33.0 */
                float code_bot  = LAYOUT_ED_Y + LAYOUT_ED_H;   /* 208.0 */
                float code_left = LAYOUT_ED_X;
                float code_right= LAYOUT_ED_X + LAYOUT_ED_W;

                if(g_app.cursor_y>=code_top  && g_app.cursor_y<code_bot &&
                   g_app.cursor_x>=code_left && g_app.cursor_x<code_right){
                    int vr=(int)((g_app.cursor_y-code_top)/LAYOUT_LH_ED);
                    if(vr<0)         vr=0;
                    if(vr>=CODE_AREA_H) vr=CODE_AREA_H-1;
                    if(vr!=g_app.code_cursor_line){
                        g_app.code_cursor_line=vr;
                        dirty=true;
                    }
                }
            }

            /* ── EDIT ─────────────────────────────────────────── */
            if(g_app.mode==MODE_EDIT){

                /* DPad U/D → vertical scroll (scroll_offset only, no cursor_line move) */
                if(down&KEY_UP){
                    if(g_editor.scroll_offset>0) g_editor.scroll_offset--;
                    dirty=true;
                }
                if(down&KEY_DOWN){
                    int total=editor_line_count(&g_editor);
                    int max_s=total-CODE_AREA_H;
                    if(max_s<0)max_s=0;
                    if(g_editor.scroll_offset<max_s) g_editor.scroll_offset++;
                    dirty=true;
                }

                /* DPad L/R → horizontal scroll */
                if(down&KEY_LEFT){
                    if(g_app.view_left>0) g_app.view_left--;
                    dirty=true;
                }
                if(down&KEY_RIGHT){
                    if(g_app.view_left<LINE_MAX-CODE_AREA_W)
                        g_app.view_left++;
                    dirty=true;
                }

                /* A → edit the line the cursor dot is currently hovering */
                if(down&KEY_A){
                    int target=g_editor.scroll_offset+g_app.code_cursor_line;
                    int total =editor_line_count(&g_editor);
                    if(target<0)       target=0;
                    if(target>=total)  target=total-1;
                    /* Update editor cursor_line to reflect selection */
                    g_editor.cursor_line=target;

                    char lt[LINE_MAX],nt[LINE_MAX];
                    editor_get_line(&g_editor,target,lt,sizeof(lt));
                    if(kbd(lt,"Edit line",nt,sizeof(nt))){
                        editor_snapshot(&g_editor);
                        editor_set_line(&g_editor,target,nt);
                    }
                    dirty=true;
                }

                /* B → undo */
                if(down&KEY_B){editor_undo(&g_editor);dirty=true;}

                /* X → save explorer */
                if(down&KEY_X){
                    fe_scan(&g_app.fe);
                    g_app.fe.cursor=0; g_app.fe.scroll=0;
                    g_app.mode=MODE_SAVE; dirty=true;
                }
                /* Y → load explorer */
                if(down&KEY_Y){
                    fe_scan(&g_app.fe);
                    g_app.fe.cursor=0; g_app.fe.scroll=0;
                    g_app.mode=MODE_LOAD; dirty=true;
                }

                /* START → compile + enter run mode */
                if(down&KEY_START){
                    runtime_scan_html(&g_runtime,g_editor.buf);
                    ui_set_compiled(g_editor.buf);
                    we_load_html(g_editor.buf);
                    g_app.run_mode      = true;
                    g_app.cursor_locked = false;
                    g_app.out_scroll    = 0;
                    g_app.click_flash   = 0;
                    /* Place top cursor at centre of output panel */
                    g_app.top_cursor_x  = 200.f;
                    g_app.top_cursor_y  = 130.f;
                    dirty=true;
                }

                if(down&KEY_SELECT){g_app.mode=MODE_CONTROLS;dirty=true;}

            /* ── SAVE ─────────────────────────────────────────── */
            }else if(g_app.mode==MODE_SAVE){
                int total=g_app.fe.count+1;
                if(down&KEY_UP)  {fe_move_up(&g_app.fe);          dirty=true;}
                if(down&KEY_DOWN){fe_move_down(&g_app.fe,total);   dirty=true;}

                if((down&KEY_A)||(down&KEY_X)){
                    const char *pf=(g_app.fe.cursor>0)
                                   ?g_app.fe.names[g_app.fe.cursor-1]:"";
                    memset(g_fname,0,sizeof(g_fname));
                    if(kbd(pf,"Filename (.html)",g_fname,sizeof(g_fname))
                       &&strlen(g_fname)>0){
                        ensure_html_ext(g_fname,sizeof(g_fname));
                        if(fe_save_named(&g_editor,g_fname)){
                            snprintf(g_runtime.status_msg,sizeof(g_runtime.status_msg),
                                     "Saved: %s",g_fname);
                            snprintf(g_runtime.last_message,sizeof(g_runtime.last_message),
                                     "Saved: %s",g_fname);
                            g_app.mode=MODE_EDIT;
                        }else{
                            snprintf(g_runtime.status_msg,sizeof(g_runtime.status_msg),
                                     "Save FAILED: %s",g_fname);
                        }
                    }
                    dirty=true;
                }
                if(down&KEY_B){g_app.mode=MODE_EDIT;dirty=true;}

            /* ── LOAD ─────────────────────────────────────────── */
            }else if(g_app.mode==MODE_LOAD){
                if(down&KEY_UP)  {fe_move_up(&g_app.fe);                 dirty=true;}
                if(down&KEY_DOWN){fe_move_down(&g_app.fe,g_app.fe.count);dirty=true;}

                if((down&KEY_A)||(down&KEY_Y)){
                    if(g_app.fe.count>0&&
                       g_app.fe.cursor>=0&&
                       g_app.fe.cursor<g_app.fe.count){
                        const char *fn=g_app.fe.names[g_app.fe.cursor];
                        if(fe_load_named(&g_editor,fn)){
                            snprintf(g_runtime.status_msg,sizeof(g_runtime.status_msg),
                                     "Loaded: %s",fn);
                            snprintf(g_runtime.last_message,sizeof(g_runtime.last_message),
                                     "Loaded: %s",fn);
                            g_app.mode=MODE_EDIT;
                        }else{
                            snprintf(g_runtime.status_msg,sizeof(g_runtime.status_msg),
                                     "Load FAILED: %s",fn);
                        }
                    }
                    dirty=true;
                }
                if(down&KEY_B){g_app.mode=MODE_EDIT;dirty=true;}

            /* ── CONTROLS ─────────────────────────────────────── */
            }else if(g_app.mode==MODE_CONTROLS){
                if((down&KEY_SELECT)||(down&KEY_B)){g_app.mode=MODE_EDIT;dirty=true;}

            /* ── PREVIEW ──────────────────────────────────────── */
            }else if(g_app.mode==MODE_PREVIEW){
                if((down&KEY_B)||(down&KEY_START)){g_app.mode=MODE_EDIT;dirty=true;}
            }
        } /* end normal mode */

        /* Update web engine if in run mode */
        if(g_app.run_mode && g_web_engine.loaded){
            WEInputState we_inp = {0};
            we_inp.held = (uint32_t)hidKeysHeld(); we_inp.down = (uint32_t)down; we_inp.up = (uint32_t)hidKeysUp();
            we_inp.cursor_x = g_app.top_cursor_x;
            we_inp.cursor_y = g_app.top_cursor_y;
            we_inp.prev_x = g_app.top_cursor_x;
            we_inp.prev_y = g_app.top_cursor_y;
            we_inp.cursor_locked = g_app.cursor_locked;
            we_update(&we_inp, g_app.top_cursor_x, g_app.top_cursor_y,
                      g_app.cursor_locked, 16.67);
            dirty = true; /* always redraw when running */
        }
        if(dirty) ui_draw(&g_app,&g_editor,&g_runtime);
    }

    we_exit();
    ui_exit();
    return 0;
}
