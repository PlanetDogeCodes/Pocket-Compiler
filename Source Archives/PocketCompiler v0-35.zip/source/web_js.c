/*
 * web_js.c  —  Duktape JS runtime bindings
 *
 * fix7 changes (on top of fix6):
 *  - LAZY children/childNodes/parentNode/firstChild/lastChild/
 *    nextSibling/previousSibling — these are now accessor properties
 *    on the shared prototype instead of eagerly-built arrays.
 *    push_node_obj is now O(1) instead of O(subtree_size).
 *    wjs_install_dom creates exactly 3 flat objects at startup instead
 *    of recursively building the full DOM tree 3× over.
 *  - Added firstElementChild, outerHTML, tagName (live via prototype).
 *  - All fix6 changes preserved: shared prototype, duk_push_this in
 *    every method, fixed childNodes obj_idx, js_noop void-cast fix.
 */
#include "web_js.h"
#include "duktape.h"
#include "web_render.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "web_events.h"
#include "web_html_parser.h"
#include "web_fetch.h"
#include "web_storage.h"
#include "web_audio.h"
#include "web_canvas.h"
#include "web_webgl.h"
#include "web_iframe.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <setjmp.h>
#include <3ds.h>

/* ── Log buffer ─────────────────────────────────────────────────── */
char g_wjs_log[WJS_LOG_MAX_LINES][WJS_LOG_LINE_LEN];
int  g_wjs_log_n=0;

void wjs_log_push(const char *line){
    if(g_wjs_log_n<WJS_LOG_MAX_LINES){
        strncpy(g_wjs_log[g_wjs_log_n],line,WJS_LOG_LINE_LEN-1);
        g_wjs_log[g_wjs_log_n][WJS_LOG_LINE_LEN-1]='\0';
        g_wjs_log_n++;
    } else {
        for(int i=0;i<WJS_LOG_MAX_LINES-1;i++)
            memcpy(g_wjs_log[i],g_wjs_log[i+1],WJS_LOG_LINE_LEN);
        strncpy(g_wjs_log[WJS_LOG_MAX_LINES-1],line,WJS_LOG_LINE_LEN-1);
    }
}
void wjs_log_clear(void){ g_wjs_log_n=0; }

/* ── Timer system ────────────────────────────────────────────────── */
#define WJS_MAX_TIMERS 32
typedef struct {
    bool   used;
    bool   interval;
    double fire_at;
    double interval_ms;
    int    js_ref;
    int    id;
} WJSTimer;

static WJSTimer s_timers[WJS_MAX_TIMERS];
static int      s_timer_next_id=1;
static double   s_time_ms=0;

/* ── RAF system ──────────────────────────────────────────────────── */
#define WJS_MAX_RAF 8
static int s_raf_n=0;

/* ── Shared prototype stash key ──────────────────────────────────── */
#define WJS_STASH_NODE_PROTO "\xFF" "node_proto"

/* ── Duktape helpers ─────────────────────────────────────────────── */

static uint8_t get_doc_id(duk_context *ctx){
    duk_push_heap_stash(ctx);
    duk_get_prop_string(ctx,-1,WJS_STASH_DOCID);
    uint8_t id=(uint8_t)duk_to_int(ctx,-1);
    duk_pop_2(ctx);
    return id;
}

static int16_t get_node_from_obj(duk_context *ctx, duk_idx_t idx){
    duk_get_prop_string(ctx,idx,"__node_id");
    int16_t nid=(int16_t)duk_to_int(ctx,-1);
    duk_pop(ctx);
    return nid;
}

/* forward declaration */
static void push_node_obj(duk_context *ctx, int16_t node_id);

/* ── console ─────────────────────────────────────────────────────── */

static duk_ret_t js_console_log(duk_context *ctx){
    int n=duk_get_top(ctx);
    char buf[WJS_LOG_LINE_LEN]; buf[0]='\0'; int pos=0;
    for(int i=0;i<n;i++){
        const char *s=duk_safe_to_string(ctx,i);
        if(s&&pos<WJS_LOG_LINE_LEN-2){
            int l=(int)strlen(s);
            if(pos+l>=WJS_LOG_LINE_LEN-1) l=WJS_LOG_LINE_LEN-1-pos;
            memcpy(buf+pos,s,l); pos+=l;
            if(i<n-1&&pos<WJS_LOG_LINE_LEN-1) buf[pos++]=' ';
        }
    }
    buf[pos]='\0';
    wjs_log_push(buf);
    return 0;
}

void wjs_install_console(duk_context *ctx){
    duk_push_global_object(ctx);
    duk_push_object(ctx);
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"log");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"warn");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"error");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"info");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"debug");
    duk_put_prop_string(ctx,-2,"console");
    duk_pop(ctx);
}

/* ── setTimeout / setInterval / clearTimeout / requestAnimationFrame */

static duk_ret_t js_setTimeout(duk_context *ctx){
    if(!duk_is_function(ctx,0)){ duk_push_int(ctx,0); return 1; }
    double ms=duk_get_number_default(ctx,1,0);
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(!s_timers[i].used){
            duk_dup(ctx,0);
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timer_next_id);
            duk_dup(ctx,-2); duk_put_prop_string(ctx,-2,key);
            duk_pop_2(ctx);
            s_timers[i].used=true;
            s_timers[i].interval=false;
            s_timers[i].fire_at=s_time_ms+ms;
            s_timers[i].interval_ms=ms;
            s_timers[i].js_ref=s_timer_next_id;
            s_timers[i].id=s_timer_next_id++;
            duk_push_int(ctx,s_timers[i].id);
            return 1;
        }
    }
    duk_push_int(ctx,0); return 1;
}

static duk_ret_t js_setInterval(duk_context *ctx){
    if(!duk_is_function(ctx,0)){ duk_push_int(ctx,0); return 1; }
    double ms=duk_get_number_default(ctx,1,16);
    if(ms<16) ms=16;
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(!s_timers[i].used){
            duk_dup(ctx,0);
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timer_next_id);
            duk_dup(ctx,-2); duk_put_prop_string(ctx,-2,key);
            duk_pop_2(ctx);
            s_timers[i].used=true;
            s_timers[i].interval=true;
            s_timers[i].fire_at=s_time_ms+ms;
            s_timers[i].interval_ms=ms;
            s_timers[i].js_ref=s_timer_next_id;
            s_timers[i].id=s_timer_next_id++;
            duk_push_int(ctx,s_timers[i].id);
            return 1;
        }
    }
    duk_push_int(ctx,0); return 1;
}

static duk_ret_t js_clearTimeout(duk_context *ctx){
    int id=duk_to_int(ctx,0);
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(s_timers[i].used&&s_timers[i].id==id){
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timers[i].js_ref);
            duk_del_prop_string(ctx,-1,key);
            duk_pop(ctx);
            s_timers[i].used=false;
        }
    }
    return 0;
}

static duk_ret_t js_raf(duk_context *ctx){
    if(duk_is_function(ctx,0)&&s_raf_n<WJS_MAX_RAF){
        duk_push_heap_stash(ctx);
        char key[16]; snprintf(key,16,"raf%d",s_raf_n);
        duk_dup(ctx,0); duk_put_prop_string(ctx,-2,key);
        duk_pop(ctx);
        s_raf_n++;
    }
    duk_push_int(ctx,0); return 1;
}

void wjs_tick_timers(duk_context *ctx){
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(!s_timers[i].used) continue;
        if(s_time_ms>=s_timers[i].fire_at){
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timers[i].js_ref);
            duk_get_prop_string(ctx,-1,key);
            if(duk_is_function(ctx,-1)){
                if(duk_pcall(ctx,0)!=0)
                    wjs_log_push(duk_safe_to_string(ctx,-1));
            }
            duk_pop(ctx);
            if(s_timers[i].interval){
                s_timers[i].fire_at+=s_timers[i].interval_ms;
            } else {
                duk_del_prop_string(ctx,-1,key);
                s_timers[i].used=false;
            }
            duk_pop(ctx);
        }
    }
}

void wjs_tick_raf(duk_context *ctx, double timestamp_ms){
    s_time_ms=timestamp_ms;
    int n=s_raf_n; s_raf_n=0;
    duk_push_heap_stash(ctx);
    for(int i=0;i<n;i++){
        char key[16]; snprintf(key,16,"raf%d",i);
        duk_get_prop_string(ctx,-1,key);
        if(duk_is_function(ctx,-1)){
            duk_push_number(ctx,timestamp_ms);
            if(duk_pcall(ctx,1)!=0)
                wjs_log_push(duk_safe_to_string(ctx,-1));
            duk_pop(ctx);
        } else { duk_pop(ctx); }
        duk_del_prop_string(ctx,-1,key);
    }
    duk_pop(ctx);
}

/* ── Utility: no-op C function (proper duk_ret_t return) ────────── */
static duk_ret_t js_noop(duk_context *ctx){ (void)ctx; return 0; }

/* ── Event firing ────────────────────────────────────────────────── */

void wjs_fire_event(duk_context *ctx, int js_ref, const WEEvent *ev){
    duk_push_heap_stash(ctx);
    char key[16]; snprintf(key,16,"ev%d",js_ref);
    duk_get_prop_string(ctx,-1,key);
    if(!duk_is_function(ctx,-1)){ duk_pop_2(ctx); return; }
    duk_push_object(ctx);
    duk_push_int(ctx,ev->type);        duk_put_prop_string(ctx,-2,"type");
    duk_push_number(ctx,ev->client_x); duk_put_prop_string(ctx,-2,"clientX");
    duk_push_number(ctx,ev->client_y); duk_put_prop_string(ctx,-2,"clientY");
    duk_push_number(ctx,ev->offset_x); duk_put_prop_string(ctx,-2,"offsetX");
    duk_push_number(ctx,ev->offset_y); duk_put_prop_string(ctx,-2,"offsetY");
    duk_push_int(ctx,ev->key_code);    duk_put_prop_string(ctx,-2,"keyCode");
    duk_push_string(ctx,ev->key_str);  duk_put_prop_string(ctx,-2,"key");
    duk_push_int(ctx,ev->button);      duk_put_prop_string(ctx,-2,"button");
    duk_push_boolean(ctx,ev->shift);   duk_put_prop_string(ctx,-2,"shiftKey");
    duk_push_boolean(ctx,ev->ctrl);    duk_put_prop_string(ctx,-2,"ctrlKey");
    duk_push_boolean(ctx,ev->alt);     duk_put_prop_string(ctx,-2,"altKey");
    /* safe no-ops — fixes void-cast UB from before fix6 */
    duk_push_c_function(ctx,js_noop,0); duk_put_prop_string(ctx,-2,"preventDefault");
    duk_push_c_function(ctx,js_noop,0); duk_put_prop_string(ctx,-2,"stopPropagation");
    if(duk_pcall(ctx,1)!=0)
        wjs_log_push(duk_safe_to_string(ctx,-1));
    duk_pop_2(ctx);
}

/* ─────────────────────────────────────────────────────────────────
 * DOM PROPERTY ACCESSORS
 * All live accessors use duk_push_this to get 'this', then pop it.
 * ────────────────────────────────────────────────────────────────*/

/* innerHTML / textContent / innerText */
static duk_ret_t dom_get_innerHTML(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    duk_push_string(ctx,dom_text_content(nid)); return 1;
}
static duk_ret_t dom_set_innerHTML(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    DOMNode *n=dom_node(nid); if(!n) return 0;
    const char *html=duk_safe_to_string(ctx,0);
    uint8_t doc_id=n->doc_id;
    int16_t ch=n->first_child;
    while(ch>=0){ int16_t nx=g_dom_nodes[ch].next_sib; dom_remove_child(nid,ch); ch=nx; }
    WEParseOpts opts={.doc_id=doc_id,.fragment_mode=true,.fragment_parent=nid};
    wep_parse(html,&opts);
    css_cascade(doc_id); dom_mark_dirty(nid);
    return 0;
}
static duk_ret_t dom_get_textContent(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    duk_push_string(ctx,dom_text_content(nid)); return 1;
}
static duk_ret_t dom_set_textContent(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    DOMNode *n=dom_node(nid); if(!n) return 0;
    const char *txt=duk_safe_to_string(ctx,0);
    int16_t ch=n->first_child;
    while(ch>=0){ int16_t nx=g_dom_nodes[ch].next_sib; dom_remove_child(nid,ch); ch=nx; }
    int16_t tn=dom_new_text(n->doc_id,txt);
    if(tn>=0) dom_append_child(nid,tn);
    dom_mark_dirty(nid);
    return 0;
}

/* value */
static duk_ret_t dom_get_value(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *v=dom_get_attr(nid,"value");
    duk_push_string(ctx,v?v:""); return 1;
}
static duk_ret_t dom_set_value(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    dom_set_attr(nid,"value",duk_safe_to_string(ctx,0));
    DOMNode *n=dom_node(nid);
    if(n){ WEEvent ev={0}; ev.type=WE_EV_INPUT; we_dispatch(n->doc_id,nid,&ev); }
    return 0;
}

/* className */
static duk_ret_t dom_get_className(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *v=dom_get_attr(nid,"class");
    duk_push_string(ctx,v?v:""); return 1;
}
static duk_ret_t dom_set_className(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    dom_set_attr(nid,"class",duk_safe_to_string(ctx,0));
    css_compute_node(nid);
    return 0;
}

/* id */
static duk_ret_t dom_get_id(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *v=dom_get_attr(nid,"id");
    duk_push_string(ctx,v?v:""); return 1;
}
static duk_ret_t dom_set_id(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid>=0) dom_set_attr(nid,"id",duk_safe_to_string(ctx,0));
    return 0;
}

/* checked / disabled */
static duk_ret_t dom_get_checked(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_boolean(ctx,n?n->checked:0); return 1;
}
static duk_ret_t dom_set_checked(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->checked=duk_to_boolean(ctx,0)?1:0;
    return 0;
}
static duk_ret_t dom_get_disabled(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_boolean(ctx,n?n->disabled:0); return 1;
}
static duk_ret_t dom_set_disabled(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->disabled=duk_to_boolean(ctx,0)?1:0;
    return 0;
}

/* scrollLeft / scrollTop */
static duk_ret_t dom_get_scrollLeft(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_int(ctx,n?n->scroll_x:0); return 1;
}
static duk_ret_t dom_set_scrollLeft(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->scroll_x=(int16_t)duk_to_int(ctx,0);
    return 0;
}
static duk_ret_t dom_get_scrollTop(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_int(ctx,n?n->scroll_y:0); return 1;
}
static duk_ret_t dom_set_scrollTop(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->scroll_y=(int16_t)duk_to_int(ctx,0);
    return 0;
}

/* ── LAZY TREE NAVIGATION (prototype getters, no upfront recursion) */

/* helper: push array of element-only children */
static duk_ret_t dom_get_children(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_array(ctx);
    if(n){
        int ci=0;
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            if(g_dom_nodes[ch].type==NT_ELEMENT){
                push_node_obj(ctx,ch);
                duk_put_prop_index(ctx,-2,(duk_uarridx_t)ci++);
            }
        }
    }
    return 1;
}

/* childNodes: all children including text */
static duk_ret_t dom_get_childNodes(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_array(ctx);
    if(n){
        int ci=0;
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            push_node_obj(ctx,ch);
            duk_put_prop_index(ctx,-2,(duk_uarridx_t)ci++);
        }
    }
    return 1;
}

static duk_ret_t dom_get_parentNode(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    push_node_obj(ctx, n ? n->parent : -1);
    return 1;
}
static duk_ret_t dom_get_firstChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    push_node_obj(ctx, n ? n->first_child : -1);
    return 1;
}
static duk_ret_t dom_get_lastChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    push_node_obj(ctx, n ? n->last_child : -1);
    return 1;
}
static duk_ret_t dom_get_nextSibling(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    push_node_obj(ctx, n ? n->next_sib : -1);
    return 1;
}
static duk_ret_t dom_get_previousSibling(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    push_node_obj(ctx, n ? n->prev_sib : -1);
    return 1;
}
static duk_ret_t dom_get_firstElementChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    int16_t found=-1;
    if(n){
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            if(g_dom_nodes[ch].type==NT_ELEMENT){ found=ch; break; }
        }
    }
    push_node_obj(ctx, found);
    return 1;
}
static duk_ret_t dom_get_lastElementChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    int16_t found=-1;
    if(n){
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            if(g_dom_nodes[ch].type==NT_ELEMENT) found=ch;
        }
    }
    push_node_obj(ctx, found);
    return 1;
}
static duk_ret_t dom_get_nextElementSibling(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    int16_t found=-1;
    if(n){
        for(int16_t s=n->next_sib;s>=0;s=g_dom_nodes[s].next_sib){
            if(g_dom_nodes[s].type==NT_ELEMENT){ found=s; break; }
        }
    }
    push_node_obj(ctx, found);
    return 1;
}
static duk_ret_t dom_get_previousElementSibling(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    int16_t found=-1;
    if(n){
        for(int16_t s=n->prev_sib;s>=0;s=g_dom_nodes[s].prev_sib){
            if(g_dom_nodes[s].type==NT_ELEMENT){ found=s; break; }
        }
    }
    push_node_obj(ctx, found);
    return 1;
}
/* childElementCount */
static duk_ret_t dom_get_childElementCount(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    int cnt=0;
    if(n)
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib)
            if(g_dom_nodes[ch].type==NT_ELEMENT) cnt++;
    duk_push_int(ctx,cnt); return 1;
}

/* ── DOM Node methods ────────────────────────────────────────────── */
/* All methods call duk_push_this, then get_node_from_obj(ctx,-1),
   then duk_pop — this is the fix for the wrong-index bug from fix5. */

static duk_ret_t js_node_addEventListener(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *type=duk_get_string(ctx,0);
    if(!duk_is_function(ctx,1)||!type) return 0;
    WEEventType evt=WE_EV_NONE;
    if(strcmp(type,"click")==0)        evt=WE_EV_CLICK;
    else if(strcmp(type,"mousedown")==0)  evt=WE_EV_MOUSEDOWN;
    else if(strcmp(type,"mouseup")==0)    evt=WE_EV_MOUSEUP;
    else if(strcmp(type,"mousemove")==0)  evt=WE_EV_MOUSEMOVE;
    else if(strcmp(type,"mouseenter")==0) evt=WE_EV_MOUSEENTER;
    else if(strcmp(type,"mouseleave")==0) evt=WE_EV_MOUSELEAVE;
    else if(strcmp(type,"keydown")==0)    evt=WE_EV_KEYDOWN;
    else if(strcmp(type,"keyup")==0)      evt=WE_EV_KEYUP;
    else if(strcmp(type,"keypress")==0)   evt=WE_EV_KEYPRESS;
    else if(strcmp(type,"focus")==0)      evt=WE_EV_FOCUS;
    else if(strcmp(type,"blur")==0)       evt=WE_EV_BLUR;
    else if(strcmp(type,"input")==0)      evt=WE_EV_INPUT;
    else if(strcmp(type,"change")==0)     evt=WE_EV_CHANGE;
    else if(strcmp(type,"submit")==0)     evt=WE_EV_SUBMIT;
    else if(strcmp(type,"scroll")==0)     evt=WE_EV_SCROLL;
    else if(strcmp(type,"load")==0)       evt=WE_EV_LOAD;
    else if(strcmp(type,"touchstart")==0) evt=WE_EV_TOUCHSTART;
    else if(strcmp(type,"touchend")==0)   evt=WE_EV_TOUCHEND;
    else if(strcmp(type,"touchmove")==0)  evt=WE_EV_TOUCHMOVE;
    if(evt==WE_EV_NONE) return 0;
    static int s_ref=0;
    duk_push_heap_stash(ctx);
    char key[16]; snprintf(key,16,"ev%d",++s_ref);
    duk_dup(ctx,1); duk_put_prop_string(ctx,-2,key);
    duk_pop(ctx);
    we_add_listener(nid,evt,s_ref);
    return 0;
}
static duk_ret_t js_node_setAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    const char *val=duk_safe_to_string(ctx,1);
    if(name) dom_set_attr(nid,name,val);
    if(name&&strcmp(name,"style")==0) css_compute_node(nid);
    return 0;
}
static duk_ret_t js_node_getAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    const char *val=dom_get_attr(nid,name?name:"");
    if(val) duk_push_string(ctx,val); else duk_push_null(ctx);
    return 1;
}
static duk_ret_t js_node_removeAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    if(name) dom_remove_attr(nid,name);
    return 0;
}
static duk_ret_t js_node_hasAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    duk_push_boolean(ctx,dom_has_attr(nid,name?name:""));
    return 1;
}
static duk_ret_t js_node_appendChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t par=get_node_from_obj(ctx,-1); duk_pop(ctx);
    int16_t child=get_node_from_obj(ctx,0);
    dom_append_child(par,child);
    push_node_obj(ctx,child); return 1;
}
static duk_ret_t js_node_removeChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t par=get_node_from_obj(ctx,-1); duk_pop(ctx);
    int16_t child=get_node_from_obj(ctx,0);
    dom_remove_child(par,child);
    push_node_obj(ctx,child); return 1;
}
static duk_ret_t js_node_insertBefore(duk_context *ctx){
    int16_t newnode=get_node_from_obj(ctx,0);
    int16_t ref    =get_node_from_obj(ctx,1);
    dom_insert_before(ref,newnode);
    push_node_obj(ctx,newnode); return 1;
}
static duk_ret_t js_node_replaceChild(duk_context *ctx){
    int16_t newn=get_node_from_obj(ctx,0);
    int16_t oldn=get_node_from_obj(ctx,1);
    dom_replace_child(oldn,newn);
    push_node_obj(ctx,oldn); return 1;
}
static duk_ret_t js_node_cloneNode(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid); if(!n){ duk_push_null(ctx); return 1; }
    int16_t clone=dom_new_element(n->doc_id,dom_tag(nid));
    push_node_obj(ctx,clone); return 1;
}
static duk_ret_t js_node_focus(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) we_focus(n->doc_id,nid);
    return 0;
}
static duk_ret_t js_node_blur(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) we_blur(n->doc_id);
    return 0;
}
static duk_ret_t js_node_click(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid); if(!n) return 0;
    WEEvent ev={0}; ev.type=WE_EV_CLICK;
    we_dispatch(n->doc_id,nid,&ev);
    return 0;
}
static duk_ret_t js_node_scrollIntoView(duk_context *ctx){ (void)ctx; return 0; }
static duk_ret_t js_node_getBoundingClientRect(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_object(ctx);
    if(n){
        duk_push_number(ctx,n->lay_x);          duk_put_prop_string(ctx,-2,"left");
        duk_push_number(ctx,n->lay_y);          duk_put_prop_string(ctx,-2,"top");
        duk_push_number(ctx,n->lay_x+n->lay_w); duk_put_prop_string(ctx,-2,"right");
        duk_push_number(ctx,n->lay_y+n->lay_h); duk_put_prop_string(ctx,-2,"bottom");
        duk_push_number(ctx,n->lay_w);          duk_put_prop_string(ctx,-2,"width");
        duk_push_number(ctx,n->lay_h);          duk_put_prop_string(ctx,-2,"height");
        duk_push_number(ctx,n->lay_x);          duk_put_prop_string(ctx,-2,"x");
        duk_push_number(ctx,n->lay_y);          duk_put_prop_string(ctx,-2,"y");
    } else {
        const char *fields[]={"left","top","right","bottom","width","height","x","y"};
        for(int i=0;i<8;i++){
            duk_push_number(ctx,0); duk_put_prop_string(ctx,-2,fields[i]);
        }
    }
    return 1;
}
/* contains(other): true if other is a descendant of this */
static duk_ret_t js_node_contains(duk_context *ctx){
    duk_push_this(ctx);
    int16_t self=get_node_from_obj(ctx,-1); duk_pop(ctx);
    int16_t other=get_node_from_obj(ctx,0);
    if(self<0||other<0){ duk_push_false(ctx); return 1; }
    /* walk up from other's parents */
    int16_t cur=other;
    while(cur>=0){
        if(cur==self){ duk_push_true(ctx); return 1; }
        DOMNode *n2=dom_node(cur);
        cur=n2?n2->parent:-1;
    }
    duk_push_false(ctx); return 1;
}
/* matches(sel): basic CSS selector match */
static duk_ret_t js_node_matches(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *sel=duk_get_string(ctx,0);
    if(!sel||!*sel){ duk_push_false(ctx); return 1; }
    /* handle #id, .class, tagname */
    bool match=false;
    if(sel[0]=='#'){
        const char *id=dom_get_attr(nid,"id");
        match=id&&strcmp(id,sel+1)==0;
    } else if(sel[0]=='.'){
        const char *cls=dom_get_attr(nid,"class");
        match=cls&&(strstr(cls,sel+1)!=NULL);
    } else {
        const char *tag=dom_tag(nid);
        match=tag&&strcmp(tag,sel)==0;
    }
    duk_push_boolean(ctx,match); return 1;
}
/* querySelector / querySelectorAll on element scope */
static duk_ret_t js_node_querySelector(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid); if(!n){ duk_push_null(ctx); return 1; }
    const char *sel=duk_get_string(ctx,0);
    /* delegate to document-wide query (simple impl) */
    int16_t found=dom_query_selector(n->doc_id,sel?sel:"");
    push_node_obj(ctx,found); return 1;
}
static duk_ret_t js_node_querySelectorAll(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_array(ctx);
    if(!n) return 1;
    const char *sel=duk_get_string(ctx,0);
    if(!sel||!*sel) return 1;
    int i=0;
    if(sel[0]=='#'){
        int16_t fn=dom_get_by_id(n->doc_id,sel+1);
        if(fn>=0){ push_node_obj(ctx,fn); duk_put_prop_index(ctx,-2,0); }
        return 1;
    }
    if(sel[0]=='.'){
        int16_t out[64]; int cnt=0;
        dom_get_by_class(n->doc_id,sel+1,out,&cnt,64);
        for(int j=0;j<cnt;j++){ push_node_obj(ctx,out[j]); duk_put_prop_index(ctx,-2,(duk_uarridx_t)j); }
        return 1;
    }
    int16_t fn=dom_get_by_tag(n->doc_id,sel,-1);
    while(fn>=0){ push_node_obj(ctx,fn); duk_put_prop_index(ctx,-2,(duk_uarridx_t)i++); fn=dom_get_by_tag(n->doc_id,sel,fn); }
    return 1;
}
/* getContext for canvas */
static duk_ret_t js_node_getContext(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *type=duk_get_string(ctx,0);
    DOMNode *n=dom_node(nid);
    if(!n||!type){ duk_push_null(ctx); return 1; }
    if(n->canvas_id==0){
        int16_t cw=n->lay_w>0?n->lay_w:300;
        int16_t ch=n->lay_h>0?n->lay_h:150;
        const char *ws=dom_get_attr(nid,"width");
        const char *hs=dom_get_attr(nid,"height");
        if(ws) cw=(int16_t)atoi(ws);
        if(hs) ch=(int16_t)atoi(hs);
        n->canvas_id=wrender_new_canvas((uint16_t)cw,(uint16_t)ch);
    }
    if(strcmp(type,"2d")==0){
        wc_install_bindings(ctx,(uint16_t)n->canvas_id); return 1;
    }
    if(strcmp(type,"webgl")==0||strcmp(type,"experimental-webgl")==0){
        wgl_install_bindings(ctx,(int)n->canvas_id,(int)n->doc_id); return 1;
    }
    duk_push_null(ctx); return 1;
}

/* ── SHARED NODE PROTOTYPE ───────────────────────────────────────── */
/*
 * Created ONCE per Duktape heap, stored in the heap stash.
 * Every node instance's [[Prototype]] points here.
 * Accessing 'element.children' triggers dom_get_children at call time —
 * no upfront tree construction.  push_node_obj is now O(1).
 */
static void ensure_node_prototype(duk_context *ctx){
    duk_push_heap_stash(ctx);
    if(duk_has_prop_string(ctx,-1,WJS_STASH_NODE_PROTO)){
        duk_pop(ctx); return;
    }
    duk_push_object(ctx);
    duk_idx_t proto_idx=duk_get_top_index(ctx);

    /* ── Methods ── */
    #define METH(name,fn,nargs) \
        duk_push_c_function(ctx,fn,nargs); \
        duk_put_prop_string(ctx,proto_idx,name)
    METH("addEventListener",      js_node_addEventListener,      3);
    METH("setAttribute",          js_node_setAttribute,          2);
    METH("getAttribute",          js_node_getAttribute,          1);
    METH("removeAttribute",       js_node_removeAttribute,       1);
    METH("hasAttribute",          js_node_hasAttribute,          1);
    METH("appendChild",           js_node_appendChild,           1);
    METH("removeChild",           js_node_removeChild,           1);
    METH("insertBefore",          js_node_insertBefore,          2);
    METH("replaceChild",          js_node_replaceChild,          2);
    METH("cloneNode",             js_node_cloneNode,             1);
    METH("focus",                 js_node_focus,                 0);
    METH("blur",                  js_node_blur,                  0);
    METH("click",                 js_node_click,                 0);
    METH("scrollIntoView",        js_node_scrollIntoView,        0);
    METH("getBoundingClientRect", js_node_getBoundingClientRect, 0);
    METH("getContext",            js_node_getContext,            1);
    METH("contains",              js_node_contains,              1);
    METH("matches",               js_node_matches,               1);
    METH("querySelector",         js_node_querySelector,         1);
    METH("querySelectorAll",      js_node_querySelectorAll,      1);
    #undef METH

    /* ── Value / state accessor pairs ── */
    #define ACCESSOR(prop,getter,setter) \
        duk_push_string(ctx,prop); \
        duk_push_c_function(ctx,getter,0); \
        duk_push_c_function(ctx,setter,1); \
        duk_def_prop(ctx,proto_idx, \
            DUK_DEFPROP_HAVE_GETTER|DUK_DEFPROP_HAVE_SETTER| \
            DUK_DEFPROP_HAVE_CONFIGURABLE|DUK_DEFPROP_CONFIGURABLE| \
            DUK_DEFPROP_HAVE_ENUMERABLE|DUK_DEFPROP_ENUMERABLE)
    ACCESSOR("innerHTML",   dom_get_innerHTML,   dom_set_innerHTML);
    ACCESSOR("textContent", dom_get_textContent, dom_set_textContent);
    ACCESSOR("innerText",   dom_get_textContent, dom_set_textContent);
    ACCESSOR("value",       dom_get_value,       dom_set_value);
    ACCESSOR("className",   dom_get_className,   dom_set_className);
    ACCESSOR("id",          dom_get_id,          dom_set_id);
    ACCESSOR("checked",     dom_get_checked,     dom_set_checked);
    ACCESSOR("disabled",    dom_get_disabled,    dom_set_disabled);
    ACCESSOR("scrollLeft",  dom_get_scrollLeft,  dom_set_scrollLeft);
    ACCESSOR("scrollTop",   dom_get_scrollTop,   dom_set_scrollTop);

    /* ── Lazy tree navigation (read-only, noop setter) ── */
    ACCESSOR("children",              dom_get_children,              js_noop);
    ACCESSOR("childNodes",            dom_get_childNodes,            js_noop);
    ACCESSOR("parentNode",            dom_get_parentNode,            js_noop);
    ACCESSOR("parentElement",         dom_get_parentNode,            js_noop);
    ACCESSOR("firstChild",            dom_get_firstChild,            js_noop);
    ACCESSOR("lastChild",             dom_get_lastChild,             js_noop);
    ACCESSOR("nextSibling",           dom_get_nextSibling,           js_noop);
    ACCESSOR("previousSibling",       dom_get_previousSibling,       js_noop);
    ACCESSOR("firstElementChild",     dom_get_firstElementChild,     js_noop);
    ACCESSOR("lastElementChild",      dom_get_lastElementChild,      js_noop);
    ACCESSOR("nextElementSibling",    dom_get_nextElementSibling,    js_noop);
    ACCESSOR("previousElementSibling",dom_get_previousElementSibling,js_noop);
    ACCESSOR("childElementCount",     dom_get_childElementCount,     js_noop);
    #undef ACCESSOR

    /* put proto into stash, then pop stash */
    duk_put_prop_string(ctx,-2,WJS_STASH_NODE_PROTO);
    duk_pop(ctx);
}

/* ─────────────────────────────────────────────────────────────────
 * push_node_obj  —  O(1): creates a FLAT instance object only.
 * Children, siblings, parent are all accessed lazily via prototype
 * getters — no recursive traversal at construction time.
 * ────────────────────────────────────────────────────────────────*/
static void push_node_obj(duk_context *ctx, int16_t node_id){
    if(node_id<0){ duk_push_null(ctx); return; }

    ensure_node_prototype(ctx);   /* O(1) after first call */

    duk_push_object(ctx);
    duk_idx_t obj_idx=duk_get_top_index(ctx);

    /* link to shared prototype */
    duk_push_heap_stash(ctx);
    duk_get_prop_string(ctx,-1,WJS_STASH_NODE_PROTO);
    duk_set_prototype(ctx,obj_idx);   /* pops proto */
    duk_pop(ctx);                     /* pop stash  */

    /* per-instance: identity */
    duk_push_int(ctx,(int)node_id);
    duk_put_prop_string(ctx,obj_idx,"__node_id");

    DOMNode *n=dom_node(node_id);
    if(n){
        /* per-instance: static metadata (tag, type, layout snapshot) */
        const char *tag=dom_tag(node_id);
        duk_push_string(ctx,tag?tag:"");  duk_put_prop_string(ctx,obj_idx,"tagName");
        duk_push_string(ctx,tag?tag:"");  duk_put_prop_string(ctx,obj_idx,"nodeName");
        duk_push_int(ctx,n->type);        duk_put_prop_string(ctx,obj_idx,"nodeType");
        /* layout snapshot (static; updated if layout re-runs) */
        duk_push_int(ctx,n->lay_x);       duk_put_prop_string(ctx,obj_idx,"offsetLeft");
        duk_push_int(ctx,n->lay_y);       duk_put_prop_string(ctx,obj_idx,"offsetTop");
        duk_push_int(ctx,n->lay_w);       duk_put_prop_string(ctx,obj_idx,"offsetWidth");
        duk_push_int(ctx,n->lay_h);       duk_put_prop_string(ctx,obj_idx,"offsetHeight");
        duk_push_int(ctx,n->lay_w);       duk_put_prop_string(ctx,obj_idx,"clientWidth");
        duk_push_int(ctx,n->lay_h);       duk_put_prop_string(ctx,obj_idx,"clientHeight");
        /* href / src */
        const char *href=dom_get_attr(node_id,"href");
        duk_push_string(ctx,href?href:""); duk_put_prop_string(ctx,obj_idx,"href");
        const char *src=dom_get_attr(node_id,"src");
        duk_push_string(ctx,src?src:"");   duk_put_prop_string(ctx,obj_idx,"src");
        /* style object (mutable sub-object keyed by __node_id) */
        duk_push_object(ctx);
        duk_push_int(ctx,(int)node_id);
        duk_put_prop_string(ctx,-2,"__node_id");
        duk_put_prop_string(ctx,obj_idx,"style");
        /* dataset placeholder */
        duk_push_object(ctx);
        duk_put_prop_string(ctx,obj_idx,"dataset");
        /* iframe contentWindow (only for iframe elements) */
        if(n->type==NT_ELEMENT && tag && strcmp(tag,"iframe")==0){
            int slot=wif_find(node_id);
            if(slot>=0){
                duk_push_object(ctx);
                duk_push_int(ctx,slot);
                duk_put_prop_string(ctx,-2,"__iframe_idx");
                duk_push_c_function(ctx,wif_js_postMessage,2);
                duk_put_prop_string(ctx,-2,"postMessage");
                duk_put_prop_string(ctx,obj_idx,"contentWindow");
            }
        }
    } else {
        /* text / comment node: expose nodeValue */
        duk_push_int(ctx,(int)node_id);
        duk_put_prop_string(ctx,obj_idx,"nodeType");
    }
}

/* ── document object ─────────────────────────────────────────────── */

static duk_ret_t js_doc_getElementById(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *id=duk_get_string(ctx,0);
    int16_t node=dom_get_by_id(doc_id,id?id:"");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_getElementsByTagName(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *tag=duk_get_string(ctx,0);
    duk_push_array(ctx);
    int16_t n=dom_get_by_tag(doc_id,tag?tag:"",-1); int i=0;
    while(n>=0){
        push_node_obj(ctx,n);
        duk_put_prop_index(ctx,-2,(duk_uarridx_t)i++);
        n=dom_get_by_tag(doc_id,tag,n);
    }
    return 1;
}
static duk_ret_t js_doc_getElementsByClassName(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *cls=duk_get_string(ctx,0);
    int16_t out[64]; int n=0;
    dom_get_by_class(doc_id,cls?cls:"",out,&n,64);
    duk_push_array(ctx);
    for(int i=0;i<n;i++){
        push_node_obj(ctx,out[i]);
        duk_put_prop_index(ctx,-2,(duk_uarridx_t)i);
    }
    return 1;
}
static duk_ret_t js_doc_querySelector(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *sel=duk_get_string(ctx,0);
    int16_t node=dom_query_selector(doc_id,sel?sel:"");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_querySelectorAll(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *sel=duk_get_string(ctx,0);
    duk_push_array(ctx);
    if(!sel||!*sel) return 1;
    int i=0;
    if(sel[0]=='#'){
        int16_t n=dom_get_by_id(doc_id,sel+1);
        if(n>=0){ push_node_obj(ctx,n); duk_put_prop_index(ctx,-2,0); }
        return 1;
    }
    if(sel[0]=='.'){
        int16_t out[64]; int n=0;
        dom_get_by_class(doc_id,sel+1,out,&n,64);
        for(int j=0;j<n;j++){
            push_node_obj(ctx,out[j]);
            duk_put_prop_index(ctx,-2,(duk_uarridx_t)j);
        }
        return 1;
    }
    int16_t n=dom_get_by_tag(doc_id,sel,-1);
    while(n>=0){
        push_node_obj(ctx,n);
        duk_put_prop_index(ctx,-2,(duk_uarridx_t)i++);
        n=dom_get_by_tag(doc_id,sel,n);
    }
    return 1;
}
static duk_ret_t js_doc_createElement(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *tag=duk_get_string(ctx,0);
    int16_t node=dom_new_element(doc_id,tag?tag:"div");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_createTextNode(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *txt=duk_safe_to_string(ctx,0);
    int16_t node=dom_new_text(doc_id,txt);
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_createDocumentFragment(duk_context *ctx){
    /* return a lightweight object that acts as a detached container */
    uint8_t doc_id=get_doc_id(ctx);
    int16_t node=dom_new_element(doc_id,"fragment");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_write(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *html=duk_safe_to_string(ctx,0);
    DOMDocument *d=dom_doc(doc_id);
    if(!d||d->body_node<0) return 0;
    WEParseOpts opts={.doc_id=doc_id,.fragment_mode=true,.fragment_parent=d->body_node};
    wep_parse(html,&opts);
    css_cascade(doc_id);
    return 0;
}
static duk_ret_t js_doc_writeln(duk_context *ctx){
    js_doc_write(ctx);
    uint8_t doc_id=get_doc_id(ctx);
    DOMDocument *d=dom_doc(doc_id);
    if(d&&d->body_node>=0){
        int16_t br=dom_new_element(doc_id,"br");
        if(br>=0) dom_append_child(d->body_node,br);
    }
    return 0;
}

void wjs_install_dom(duk_context *ctx, uint8_t doc_id){
    duk_push_global_object(ctx);
    duk_push_object(ctx);
    duk_push_int(ctx,(int)doc_id); duk_put_prop_string(ctx,-2,"__doc_id");

    DOMDocument *d=dom_doc(doc_id);
    if(d){
        /* Each push_node_obj is now O(1) — no recursive tree walk */
        push_node_obj(ctx,d->body_node); duk_put_prop_string(ctx,-2,"body");
        push_node_obj(ctx,d->head_node); duk_put_prop_string(ctx,-2,"head");
        push_node_obj(ctx,d->root_node); duk_put_prop_string(ctx,-2,"documentElement");
    }
    duk_push_string(ctx,"complete"); duk_put_prop_string(ctx,-2,"readyState");
    /* document methods */
    duk_push_c_function(ctx,js_doc_getElementById,          1); duk_put_prop_string(ctx,-2,"getElementById");
    duk_push_c_function(ctx,js_doc_getElementsByTagName,    1); duk_put_prop_string(ctx,-2,"getElementsByTagName");
    duk_push_c_function(ctx,js_doc_getElementsByClassName,  1); duk_put_prop_string(ctx,-2,"getElementsByClassName");
    duk_push_c_function(ctx,js_doc_querySelector,           1); duk_put_prop_string(ctx,-2,"querySelector");
    duk_push_c_function(ctx,js_doc_querySelectorAll,        1); duk_put_prop_string(ctx,-2,"querySelectorAll");
    duk_push_c_function(ctx,js_doc_createElement,           1); duk_put_prop_string(ctx,-2,"createElement");
    duk_push_c_function(ctx,js_doc_createTextNode,          1); duk_put_prop_string(ctx,-2,"createTextNode");
    duk_push_c_function(ctx,js_doc_createDocumentFragment,  0); duk_put_prop_string(ctx,-2,"createDocumentFragment");
    duk_push_c_function(ctx,js_doc_write,                   1); duk_put_prop_string(ctx,-2,"write");
    duk_push_c_function(ctx,js_doc_writeln,                 1); duk_put_prop_string(ctx,-2,"writeln");
    duk_push_c_function(ctx,js_node_addEventListener,       3); duk_put_prop_string(ctx,-2,"addEventListener");
    duk_put_prop_string(ctx,-2,"document");
    duk_pop(ctx);
}

/* ── window / navigator / screen / location ─────────────────────── */

void wjs_install_window(duk_context *ctx, uint8_t doc_id){
    duk_push_global_object(ctx);
    duk_dup(ctx,-1); duk_put_prop_string(ctx,-2,"window");
    duk_push_c_function(ctx,js_setTimeout,   -1); duk_put_prop_string(ctx,-2,"setTimeout");
    duk_push_c_function(ctx,js_setInterval,  -1); duk_put_prop_string(ctx,-2,"setInterval");
    duk_push_c_function(ctx,js_clearTimeout,  1); duk_put_prop_string(ctx,-2,"clearTimeout");
    duk_push_c_function(ctx,js_clearTimeout,  1); duk_put_prop_string(ctx,-2,"clearInterval");
    duk_push_c_function(ctx,js_raf,           1); duk_put_prop_string(ctx,-2,"requestAnimationFrame");
    duk_push_c_function(ctx,js_noop,          1); duk_put_prop_string(ctx,-2,"cancelAnimationFrame");
    /* screen */
    duk_push_object(ctx);
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"width");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"height");
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"availWidth");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"availHeight");
    duk_push_int(ctx,24);            duk_put_prop_string(ctx,-2,"colorDepth");
    duk_put_prop_string(ctx,-2,"screen");
    /* navigator */
    duk_push_object(ctx);
    duk_push_string(ctx,"Nintendo 3DS");                duk_put_prop_string(ctx,-2,"platform");
    duk_push_string(ctx,"Pocket Compiler/0.33 (3DS)"); duk_put_prop_string(ctx,-2,"userAgent");
    duk_push_string(ctx,"en-US");                       duk_put_prop_string(ctx,-2,"language");
    duk_push_boolean(ctx,1);                            duk_put_prop_string(ctx,-2,"onLine");
    duk_put_prop_string(ctx,-2,"navigator");
    /* location */
    duk_push_object(ctx);
    duk_push_string(ctx,"3ds://app"); duk_put_prop_string(ctx,-2,"href");
    duk_push_string(ctx,"3ds");       duk_put_prop_string(ctx,-2,"protocol");
    duk_push_string(ctx,"app");       duk_put_prop_string(ctx,-2,"pathname");
    duk_push_string(ctx,"");          duk_put_prop_string(ctx,-2,"search");
    duk_push_string(ctx,"");          duk_put_prop_string(ctx,-2,"hash");
    duk_push_string(ctx,"3DS");       duk_put_prop_string(ctx,-2,"hostname");
    duk_put_prop_string(ctx,-2,"location");
    /* window dimensions */
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"innerWidth");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"innerHeight");
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"outerWidth");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"outerHeight");
    duk_push_int(ctx,0);             duk_put_prop_string(ctx,-2,"pageXOffset");
    duk_push_int(ctx,0);             duk_put_prop_string(ctx,-2,"pageYOffset");
    duk_push_int(ctx,0);             duk_put_prop_string(ctx,-2,"scrollX");
    duk_push_int(ctx,0);             duk_put_prop_string(ctx,-2,"scrollY");
    /* alert / confirm / prompt — map to log or safe stubs */
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"alert");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"confirm");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"print");
    duk_push_c_function(ctx,js_noop,          1); duk_put_prop_string(ctx,-2,"prompt");
    /* DOMContentLoaded helper */
    duk_eval_string_noresult(ctx,
        "var _we_dcl_fn=null;"
        "function _we_dcl(){ if(_we_dcl_fn) _we_dcl_fn(); }"
        "var document=window.document||document;"
    );
    (void)doc_id;
    duk_pop(ctx);
}

void wjs_install_navigator(duk_context *ctx){ (void)ctx; }

void wjs_install_fetch(duk_context *ctx, uint8_t doc_id){
    wf_install_fetch(ctx, doc_id);
    wf_install_xhr(ctx, doc_id);
}

void wjs_install_storage(duk_context *ctx, uint8_t doc_id){
    char origin[64];
    snprintf(origin,sizeof(origin),"doc%d",(int)doc_id);
    ws_install_local(ctx,origin);
    ws_install_session(ctx,origin);
    ws_install_idb(ctx,origin);
    ws_install_cookies(ctx);
}

void wjs_install_audio(duk_context *ctx, uint8_t doc_id){
    wa_install_bindings(ctx,doc_id);
}

/* ── Eval / call ─────────────────────────────────────────────────── */

/* Custom fatal handler — prevents abort()→svcBreak()→UDF-instruction crash.
 * Uses longjmp during context creation so wjs_create_context can return NULL
 * instead of crashing the 3DS on OOM or any other Duktape fatal error.
 * After creation succeeds, s_fatal_armed is cleared; any later fatal during
 * JS evaluation will log the message and spin (better than a silent crash). */
static jmp_buf s_fatal_env;
static bool    s_fatal_armed = false;

static void wjs_fatal_handler(void *udata, const char *msg){
    (void)udata;
    char buf[128];
    snprintf(buf,sizeof(buf),"JS fatal: %s",msg?msg:"unknown");
    wjs_log_push(buf);
    if(s_fatal_armed){
        s_fatal_armed=false;
        longjmp(s_fatal_env,1);
    }
    /* Outside creation window: spin to avoid UDF instruction.
     * User will see the error in the console overlay. */
    for(;;) svcSleepThread(1000000000LL);
}

duk_context *wjs_create_context(uint8_t doc_id){
    s_fatal_armed=true;
    if(setjmp(s_fatal_env)!=0){
        /* Duktape fatal during setup — context is invalid, return NULL */
        return NULL;
    }
    duk_context *ctx=duk_create_heap(NULL,NULL,NULL,NULL,wjs_fatal_handler);
    if(!ctx){ s_fatal_armed=false; return NULL; }
    duk_push_heap_stash(ctx);
    duk_push_int(ctx,(int)doc_id);
    duk_put_prop_string(ctx,-2,WJS_STASH_DOCID);
    duk_pop(ctx);
    wjs_install_console(ctx);
    wjs_install_window(ctx,doc_id);
    wjs_install_dom(ctx,doc_id);
    wjs_install_fetch(ctx,doc_id);
    wjs_install_storage(ctx,doc_id);
    wjs_install_audio(ctx,doc_id);
    s_fatal_armed=false;
    return ctx;
}

void wjs_destroy_context(duk_context *ctx){
    if(ctx) duk_destroy_heap(ctx);
}

bool wjs_eval(duk_context *ctx, const char *script){
    if(!ctx||!script) return false;
    if(duk_peval_string(ctx,script)!=0){
        wjs_log_push(duk_safe_to_string(ctx,-1));
        duk_pop(ctx); return false;
    }
    duk_pop(ctx); return true;
}

bool wjs_eval_file(duk_context *ctx, const char *path){
    if(!ctx||!path) return false;
    char resolved[256];
    if(strncmp(path,"sdmc:/",6)==0) strncpy(resolved,path,255);
    else snprintf(resolved,sizeof(resolved),"sdmc:/3ds/pocketcompiler/www/%s",path);
    resolved[255]='\0';
    FILE *f=fopen(resolved,"r");
    if(!f){
        char msg[128];
        snprintf(msg,sizeof(msg),"[JS] Cannot open: %s",resolved);
        wjs_log_push(msg);
        return false;
    }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    if(sz<=0||sz>65535){ fclose(f); return false; }
    char *buf=(char*)malloc(sz+1);
    if(!buf){ fclose(f); return false; }
    fread(buf,1,sz,f); fclose(f); buf[sz]='\0';
    bool ok=wjs_eval(ctx,buf);
    free(buf); return ok;
}

bool wjs_call(duk_context *ctx, const char *fn){
    if(!ctx||!fn) return false;
    duk_get_global_string(ctx,fn);
    if(!duk_is_function(ctx,-1)){ duk_pop(ctx); return false; }
    if(duk_pcall(ctx,0)!=0){
        wjs_log_push(duk_safe_to_string(ctx,-1));
        duk_pop(ctx); return false;
    }
    duk_pop(ctx); return true;
}
