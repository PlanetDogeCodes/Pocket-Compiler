# Pocket Compiler

**A homebrew HTML/CSS/JS editor and runtime for the Nintendo 3DS.**

Made by **PlanetDogeCodes**

---

## What is it?

Pocket Compiler lets you write, edit, and run basic HTML/CSS/JavaScript directly on your 3DS. The bottom screen is a full code editor; the top screen shows a live preview and feature summary.

---

## Features

- HTML/CSS/JS editor with syntax-aware detection  
- 5-slot SD card save/load system  
- D-Pad navigation, A to edit any line via 3DS keyboard  
- B to undo, START to compile, SELECT for help  
- Circle Pad cursor dot  
- Feature flag detection: DOM, fetch, images, canvas, WebGL, audio, IndexedDB, iframe  
- Dark, minimal dual-screen UI  
- No crashy 3D subsystem — safe libctru console rendering only  

---

## Limitations

- No real browser rendering engine (text preview only)  
- JavaScript execution via QuickJS (scaffold present, limited DOM)  
- HTTPS/network: mbedTLS scaffold present, limited on real hardware  
- WebGL: Citro3D scaffold only, not full GL  
- No pointer lock  
- CIA building requires external `bannertool`/`makerom`  

---

## Building

Requirements: devkitPro, devkitARM, `3ds-dev` package

```bash
export DEVKITPRO=/opt/devkitpro
export DEVKITARM=$DEVKITPRO/devkitARM
export PATH=$DEVKITARM/bin:$DEVKITPRO/tools/bin:$PATH

make
```

Copy `PocketCompiler.3dsx` to your SD card and launch via the Homebrew Launcher.

---

## SD Card Layout

```
sdmc:/3ds/PocketCompiler/projects/
    project1.html  …  project5.html
```

Create the `projects/` folder manually if save doesn't work on first launch.

---

## Controls (Edit Mode)

| Button | Action |
|--------|--------|
| D-Pad ↑↓ | Scroll lines |
| Circle Pad | Move cursor dot |
| A | Edit current line (keyboard) |
| B | Undo |
| X | Save project (slot menu) |
| Y | Load project (slot menu) |
| START | Compile / run |
| SELECT | Controls help |
