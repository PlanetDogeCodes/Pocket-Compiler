/*
 * web_events.h  —  Event system for Pocket Compiler Web Engine
 * Maps 3DS buttons/circle-pad/touch to DOM events.
 */
#pragma once
#include "web_dom.h"
#include <stdbool.h>
#include <stdint.h>
#ifdef __3DS__
#  include <3ds.h>
#endif

/* ── Event types ────────────────────────────────────────────────── */
typedef enum {
    WE_EV_NONE        = 0,
    /* Mouse / pointer */
    WE_EV_CLICK       = 1,
    WE_EV_DBLCLICK    = 2,
    WE_EV_MOUSEDOWN   = 3,
    WE_EV_MOUSEUP     = 4,
    WE_EV_MOUSEMOVE   = 5,
    WE_EV_MOUSEENTER  = 6,
    WE_EV_MOUSELEAVE  = 7,
    WE_EV_CONTEXTMENU = 8,
    /* Keyboard */
    WE_EV_KEYDOWN     = 9,
    WE_EV_KEYUP       = 10,
    WE_EV_KEYPRESS    = 11,
    /* Focus */
    WE_EV_FOCUS       = 12,
    WE_EV_BLUR        = 13,
    /* Input / form */
    WE_EV_INPUT       = 14,
    WE_EV_CHANGE      = 15,
    WE_EV_SUBMIT      = 16,
    /* Touch (3DS stylus) */
    WE_EV_TOUCHSTART  = 17,
    WE_EV_TOUCHEND    = 18,
    WE_EV_TOUCHMOVE   = 19,
    /* Scroll */
    WE_EV_SCROLL      = 20,
    /* Load / unload */
    WE_EV_LOAD        = 21,
    WE_EV_UNLOAD      = 22,
    WE_EV_RESIZE      = 23,
    /* Custom */
    WE_EV_CUSTOM      = 24,
    WE_EV_COUNT
} WEEventType;

/* ── Key codes (subset matching 3DS → DOM) ─────────────────────── */
typedef enum {
    WE_KEY_NONE      = 0,
    WE_KEY_LEFT      = 37,
    WE_KEY_UP        = 38,
    WE_KEY_RIGHT     = 39,
    WE_KEY_DOWN      = 40,
    WE_KEY_ENTER     = 13,
    WE_KEY_ESCAPE    = 27,
    WE_KEY_BACKSPACE = 8,
    WE_KEY_TAB       = 9,
    WE_KEY_SPACE     = 32,
    WE_KEY_A         = 65,  /* A button → 'a'  */
    WE_KEY_B         = 66,
    WE_KEY_X         = 88,
    WE_KEY_Y         = 89,
    WE_KEY_L         = 76,
    WE_KEY_R         = 82,
    WE_KEY_F1        = 112,  /* SELECT */
    WE_KEY_F2        = 113,  /* START  */
} WEKeyCode;

/* ── Event record ────────────────────────────────────────────────── */
typedef struct {
    WEEventType  type;
    uint8_t      doc_id;
    int16_t      target;      /* node index                    */
    float        client_x, client_y;   /* screen position      */
    float        offset_x, offset_y;   /* relative to target   */
    int16_t      key_code;
    uint8_t      button;      /* 0=left 1=mid 2=right          */
    uint8_t      buttons;     /* bitmask current held buttons  */
    bool         shift, ctrl, alt, meta;
    uint8_t      touch_id;
    char         key_str[8];  /* printable char if any         */
} WEEvent;

/* ── 3DS button state for event generation ──────────────────────── */
typedef struct {
    uint32_t   held;          /* hidKeysHeld()    */
    uint32_t   down;          /* hidKeysDown()    */
    uint32_t   up;            /* hidKeysUp()      */
    float      cursor_x, cursor_y;    /* top-screen pointer */
    float      prev_x, prev_y;
    bool       cursor_locked;
    touchPosition touch;
    touchPosition prev_touch;
    bool       touched;
    bool       was_touched;
} WEInputState;

/* ── API ────────────────────────────────────────────────────────── */

/* Call each frame with current 3DS input state */
void   we_events_update(uint8_t doc_id, const WEInputState *inp);

/* Dispatch a synthetic event to a node (bubble up tree) */
void   we_dispatch(uint8_t doc_id, int16_t target, WEEvent *ev);

/* Register a JS handler (called from Duktape bindings) */
void   we_add_listener(int16_t node, WEEventType t, int js_ref);
void   we_remove_listener(int16_t node, WEEventType t);

/* Fire all JS handlers matching node+type (called from dispatch) */
void   we_invoke_js(uint8_t doc_id, int16_t node, const WEEvent *ev);

/* Scroll a scrollable element */
void   we_scroll_by(int16_t node, int16_t dx, int16_t dy);
void   we_scroll_to(int16_t node, int16_t x, int16_t y);

/* Focus management */
void   we_focus(uint8_t doc_id, int16_t node);
void   we_blur (uint8_t doc_id);

/* Key string helper: 3DS KEY_* → DOM key string */
const char *we_key_string(uint32_t ds_key);
int16_t     we_key_code  (uint32_t ds_key);
