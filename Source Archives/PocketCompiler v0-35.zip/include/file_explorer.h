#pragma once
#include <stdbool.h>
#include "editor.h"

/* ---- SD card project directory ---- */
#define FE_DIR          "sdmc:/3ds/PocketCompiler/projects"
#define FE_MAX_FILES    64
#define FE_FILENAME_MAX 64
#define FE_VISIBLE_ROWS  8   /* files visible at once in the scroll window */

typedef struct {
    char names[FE_MAX_FILES][FE_FILENAME_MAX];
    long sizes[FE_MAX_FILES];   /* file size in bytes; -1 = unknown */
    int  count;                 /* number of .html files found */
    int  cursor;                /* current selection index */
    int  scroll;                /* first visible row (for scrolling) */
} FileExplorer;

/* Initialise to empty/zero state. */
void fe_init(FileExplorer *fe);

/* Scan FE_DIR and populate names[]/sizes[]/count.
 * Resets cursor and scroll to 0.
 * Attempts to create FE_DIR if it does not exist. */
void fe_scan(FileExplorer *fe);

/* Move cursor up/down.
 * total_rows: pass (count+1) for save mode, count for load mode.
 * Adjusts scroll so cursor is always in the visible window. */
void fe_move_up(FileExplorer *fe);
void fe_move_down(FileExplorer *fe, int total_rows);

/* Format file size into buf as human-readable string (e.g. "1.2 KB"). */
void fe_format_size(long bytes, char *buf, int buf_sz);

/* Save editor buffer to FE_DIR/<filename>.
 * Returns true on success. */
bool fe_save_named(const Editor *e, const char *filename);

/* Load FE_DIR/<filename> into editor.
 * Returns true on success. */
bool fe_load_named(Editor *e, const char *filename);

/* ---- Legacy slot API — kept for backwards compatibility ---- */
#define NUM_SLOTS 5
const char *fe_slot_name(int slot);
bool fe_save_slot(const Editor *e, int slot);
bool fe_load_slot(Editor *e, int slot);
