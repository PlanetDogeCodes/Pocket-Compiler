#pragma once
#include <stdbool.h>

#define EDITOR_MAX        65536
#define EDITOR_MAX_LINES    512
#define LINE_MAX            256

typedef struct {
    char  buf[EDITOR_MAX];
    int   cursor_line;
    int   scroll_offset;
    /* undo snapshot */
    char  undo_buf[EDITOR_MAX];
    int   undo_cursor_line;
    bool  undo_valid;   /* true only after at least one snapshot has been taken */
} Editor;

void editor_init(Editor *e);
void editor_snapshot(Editor *e);   /* save current state into undo_buf */
void editor_undo(Editor *e);       /* restore from undo_buf if undo_valid */
int  editor_line_count(const Editor *e);
void editor_get_line(const Editor *e, int line, char *out, int out_sz);
void editor_set_line(Editor *e, int line, const char *text);
void editor_insert_line(Editor *e, int line, const char *text);
void editor_delete_line(Editor *e, int line);
void editor_scroll_up(Editor *e);
void editor_scroll_down(Editor *e);
