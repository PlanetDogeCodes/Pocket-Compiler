/*
 * web_engine.h  —  Top-level Web Engine API for Pocket Compiler
 * Single include for main.c / ui.c integration.
 */
#pragma once
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "web_render.h"
#include "web_events.h"
#include "web_js.h"
#include "web_canvas.h"
#include "web_audio.h"
#include "web_storage.h"
#include "web_fetch.h"
#include "web_iframe.h"
#include "web_html_parser.h"
#include <3ds.h>

/* ── Web engine state ───────────────────────────────────────────── */
typedef struct {
    bool      initialized;
    uint8_t   main_doc;       /* main document id (0)          */
    bool      loaded;         /* a page is currently loaded    */

    /* scroll state (top-screen) */
    int16_t   scroll_x;
    int16_t   scroll_y;
    int16_t   max_scroll_x;
    int16_t   max_scroll_y;

    /* hover/focus */
    int16_t   hover_node;
    int16_t   focus_node;

    /* cursor lock (from run mode) */
    bool      cursor_locked;

    /* frame timer */
    double    time_ms;        /* milliseconds since init       */

    /* document title (for top-bar) */
    char      title[128];

    /* console log enabled */
    bool      show_console;
    int       console_scroll;
} WebEngine;

extern WebEngine g_web_engine;

/* ── Lifecycle ──────────────────────────────────────────────────── */

/* Initialize the web engine (call once at startup) */
void  we_init(void);

/* Destroy the web engine (call at shutdown) */
void  we_exit(void);

/* Load an HTML string as the main document */
void  we_load_html(const char *html);

/* Load an HTML file from SD card */
bool  we_load_file(const char *sd_path);

/* Unload current document */
void  we_unload(void);

/* ── Frame update ────────────────────────────────────────────────── */
/*
 * Call once per frame from ui.c draw_top() when in run_mode.
 *   inp         - current 3DS input state
 *   top_cursor  - cursor position on top screen
 *   dt_ms       - frame time delta in milliseconds
 */
void  we_update(const WEInputState *inp, float top_cx, float top_cy,
                bool cursor_locked, double dt_ms);

/* ── Rendering ───────────────────────────────────────────────────── */
/*
 * Render the full web page onto the top screen.
 * Must be called inside a Citro2D top-screen scene.
 */
void  we_render(void);

/* ── document.write() integration ──────────────────────────────── */
void  we_document_write(const char *html);
void  we_document_writeln(const char *html);
void  we_document_open(void);
void  we_document_close(void);

/* ── Scroll control ──────────────────────────────────────────────── */
void  we_page_scroll_by(int16_t dx, int16_t dy);
void  we_scroll_to_top(void);

/* ── Getters for main.c ──────────────────────────────────────────── */
const char *we_get_title(void);
bool        we_is_loaded(void);
int16_t     we_hit_test(float x, float y);  /* returns node id */
