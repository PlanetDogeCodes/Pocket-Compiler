#pragma once
#include "app.h"
#include "editor.h"
#include "runtime_features.h"

void ui_init(void);
void ui_draw(const AppState *app, const Editor *e, const FeatureRuntime *rt);

/* Called from main.c when START is pressed to commit the compiled HTML.
 * Passing NULL resets to the "not yet compiled" state.                  */
void ui_set_compiled(const char *html);

/* Returns the number of output lines produced by the last compile.
 * Used by main.c to clamp out_scroll correctly.                         */
int  ui_get_out_count(void);

void ui_exit(void);
