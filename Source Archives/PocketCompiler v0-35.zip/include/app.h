#pragma once
#include <stdbool.h>
#include "file_explorer.h"

/* CODE_AREA_H must match the number of lines the Citro2D editor actually
 * displays. The editor scroll logic uses this to advance the viewport. */
#define CODE_AREA_W   42
#define CODE_AREA_H   10    /* visible lines in the Citro2D editor panel */

typedef enum {
    MODE_EDIT = 0,
    MODE_SAVE,
    MODE_LOAD,
    MODE_CONTROLS,
    MODE_PREVIEW
} AppMode;

typedef struct {
    AppMode      mode;
    bool         running;
    int          slot_cursor;   /* legacy */
    FileExplorer fe;            /* proper file explorer state */

    /* Bottom-screen circle-pad cursor */
    float        cursor_x;
    float        cursor_y;

    /* Code view: horizontal scroll offset in characters */
    int          view_left;

    /* Which visual row (0..CODE_AREA_H-1) the cursor dot is hovering
     * in the code area.  Used by A-press to target the correct line. */
    int          code_cursor_line;

    /* Run mode: toggled by START.  While true, output is shown on the
     * top screen and the bottom screen is locked. */
    bool         run_mode;

    /* Top-screen cursor (only active in run_mode) */
    float        top_cursor_x;
    float        top_cursor_y;

    /* Cursor / pointer lock: constrains cursor to the output panel */
    bool         cursor_locked;

    /* Output scroll offset (DPad scrolls in run_mode) */
    int          out_scroll;

    /* Click feedback animation */
    int          click_flash;   /* frames remaining */
    int          click_line;    /* which s_out[] row was clicked */
} AppState;
