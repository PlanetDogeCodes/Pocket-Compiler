# Pocket Compiler

**A homebrew HTML/CSS/JS editor and runtime for the Nintendo 3DS.**

Made by **PlanetDogeCodes**

---

## What is it?

Pocket Compiler lets you write, edit, and run basic HTML/CSS/JavaScript directly on your 3DS. The bottom screen is a full code editor; the top screen shows a live preview and feature summary.

---

## Features

- HTML/CSS/JS editor with syntax-aware detection
- SD-card project browser (save / load / rename / delete / sort)
- D-Pad navigation, A to edit any line via 3DS keyboard
- Multi-level undo (5-step ring), B to step back
- Find / Replace, Go-to-line, Duplicate line, Comment toggle
- Auto-save draft (writes to SD on compile + 10 s of idle)
- Remembers the last-opened file across launches
- Touch support: tap tabs, code lines, and file rows
- Live JS console tab with timestamps and "export log to SD"
- START to compile, SELECT for help, R for the Actions menu
- Feature flag detection: DOM, fetch, images, canvas, WebGL, audio, IndexedDB, iframe
- Dark, minimal dual-screen UI
- No crashy 3D subsystem — safe libctru console rendering only

---

## Limitations

- No real browser rendering engine (text preview only)
- JavaScript execution via Duktape (ES5 + a subset of ES6)
- HTTPS/network: mbedTLS scaffold present, limited on real hardware
- WebGL: Citro3D scaffold only, not full GL
- No pointer lock
- CIA building requires external `bannertool`/`makerom`

---

## Building

Requirements: devkitPro, devkitARM, `3ds-dev` package

```bash
export DEVKITPRO=/opt/devkitpro
export DEVKITARM=$DEVKITPRO/devkitARM
export PATH=$DEVKITARM/bin:$DEVKITPRO/tools/bin:$PATH

make
```

Copy `PocketCompiler.3dsx` to your SD card and launch via the Homebrew Launcher.

---

## SD Card Layout

```
sdmc:/3ds/PocketCompiler/
    config.txt        ← last-opened file (auto-managed)
    autosave.html     ← crash-recovery draft (auto-managed)
    console_log.txt   ← exported JS console log (written on demand)
    projects/
        project1.html  …  project5.html  (+ anything you save)
```

The `projects/` and parent `PocketCompiler/` folders are created lazily
on first write; you no longer need to create them manually.

---

## Controls (Edit Mode — Editor tab)

| Button | Action |
|--------|--------|
| D-Pad ↑↓ | Scroll lines (vertical) |
| D-Pad ←→ | Scroll horizontally |
| Circle Pad | Move cursor dot |
| Touch | Snap cursor to tap; tap tabs / code lines / file rows |
| A | Edit current line (keyboard; auto-indent if empty) |
| B | Undo (5-step ring) |
| X | Save As… (file explorer) |
| Y | Load… (file explorer) |
| L | Toggle JS Console tab |
| R | Open Actions menu (Find, Go-to, Duplicate, Comment, Rename, Delete, Sort, Export log) |
| START | Compile + run |
| SELECT | Controls help (scrollable) |

## Controls (Edit Mode — Console tab)

| Button | Action |
|--------|--------|
| D-Pad ↑↓ | Scroll console log |
| A | Type & eval JS expression |
| B | Clear console log |
| L | Back to editor tab |

## Controls (Run Mode)

| Button | Action |
|--------|--------|
| START | Stop, return to editor |
| Circle Pad | Move top-screen cursor |
| D-Pad ↑↓ | Scroll output |
| A / L | Left-click |
| B / R | Right-click |
| X | Release cursor lock |

---

## Version

Current: **v0.42**. See `docs/CHANGELOG.md` for the full version history.

