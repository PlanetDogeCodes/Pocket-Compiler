/*
 * web_engine.c  —  Top-level Web Engine orchestration
 */
#include "web_engine.h"
#include "duktape.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "web_render.h"
#include "web_events.h"
#include "web_js.h"
#include "web_html_parser.h"
#include "web_fetch.h"
#include "web_storage.h"
#include "web_iframe.h"
#include "web_audio.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <3ds.h>

WebEngine g_web_engine;

/* document.write() accumulation buffer */
static char s_docwrite_buf[16384]; /* reduced: 64KB→16KB */
static int  s_docwrite_pos=0;
static bool s_docwrite_open=false;

/* ── Init / exit ─────────────────────────────────────────────────── */

void we_init(void){
    if(g_web_engine.initialized) return;
    memset(&g_web_engine,0,sizeof(g_web_engine));
    g_web_engine.initialized=true;
    g_web_engine.hover_node=-1;
    g_web_engine.focus_node=-1;

    /* init subsystems */
    dom_reset_all();
    css_reset();
    wrender_init();
    wif_init();
    ws_init();

    /* allocate main document slot */
    g_web_engine.main_doc=dom_new_doc();
    if(g_web_engine.main_doc==0xFF) g_web_engine.main_doc=0;
}

void we_exit(void){
    if(!g_web_engine.initialized) return;
    we_unload();
    wrender_exit();
    wa_exit();
    g_web_engine.initialized=false;
}

/* ── Load ────────────────────────────────────────────────────────── */

static void init_iframes(uint8_t doc_id){
    /* find all <iframe> elements and load them */
    int16_t node=dom_get_by_tag(doc_id,"iframe",-1);
    while(node>=0){
        const char *src=dom_get_attr(node,"src");
        if(src&&*src) wif_load(node,doc_id,src);
        node=dom_get_by_tag(doc_id,"iframe",node);
    }
}

static void load_images(uint8_t doc_id){
    /* find all <img> elements */
    int16_t node=dom_get_by_tag(doc_id,"img",-1);
    while(node>=0){
        const char *src=dom_get_attr(node,"src");
        if(src&&*src){
            uint16_t img_id=wrender_load_image(src);
            if(img_id>0) g_dom_nodes[node].image_id=img_id;
        }
        node=dom_get_by_tag(doc_id,"img",node);
    }
}

void we_load_html(const char *html){
    if(!g_web_engine.initialized||!html) return;
    /* reset previous */
    we_unload();

    /* reset CSS and DOM for main doc */
    css_reset();
    dom_reset(g_web_engine.main_doc);

    /* parse */
    WEParseOpts opts={
        .doc_id=g_web_engine.main_doc,
        .fragment_mode=false,
        .fragment_parent=-1
    };
    wep_parse(html,&opts);

    /* get title */
    DOMDocument *d=dom_doc(g_web_engine.main_doc);
    if(d&&d->title_node>=0){
        const char *t=dom_text_content(d->title_node);
        if(t&&*t) strncpy(g_web_engine.title,t,127);
        g_web_engine.title[127]='\0';
    }

    /* set background from body style */
    if(d&&d->body_node>=0){
        DOMNode *bn=dom_node(d->body_node);
        if(bn&&bn->style.background==0)
            bn->style.background=0x111111FF; /* default dark bg */
    }

    /* layout */
    layout_document(g_web_engine.main_doc);

    /* create JS context */
    duk_context *jsc=wjs_create_context(g_web_engine.main_doc);
    if(d){ d->js_ctx=jsc; d->js_ready=(jsc!=NULL); }

    /* install storage with doc-specific origin */
    if(jsc){
        char origin[64]; snprintf(origin,sizeof(origin),"doc%d",g_web_engine.main_doc);
        ws_install_local(jsc,origin);
        ws_install_session(jsc,origin);
        wf_install_xhr(jsc,g_web_engine.main_doc);
    }

    /* run style and script blocks */
    wep_run_styles(g_web_engine.main_doc);
    layout_document(g_web_engine.main_doc); /* re-layout after styles */
    if(jsc) wep_run_scripts(g_web_engine.main_doc);

    /* load images */
    load_images(g_web_engine.main_doc);

    /* init iframes */
    init_iframes(g_web_engine.main_doc);

    /* init audio */
    wa_init(g_web_engine.main_doc);

    g_web_engine.loaded=true;
    g_web_engine.scroll_x=0;
    g_web_engine.scroll_y=0;
    g_web_engine.hover_node=-1;
    g_web_engine.focus_node=-1;

    /* fire load event */
    if(jsc) wjs_call(jsc,"_we_dcl");
}

bool we_load_file(const char *sd_path){
    if(!sd_path) return false;
    WFResponse resp; memset(&resp,0,sizeof(resp));
    if(!wf_fetch_sync(sd_path,&resp)||!resp.ok) return false;
    we_load_html((const char*)resp.body);
    return true;
}

void we_unload(void){
    if(!g_web_engine.initialized) return;
    /* destroy iframes */
    for(int i=0;i<WE_MAX_IFRAMES;i++) if(g_iframes[i].used) wif_unload(i);
    /* destroy JS */
    DOMDocument *d=dom_doc(g_web_engine.main_doc);
    if(d&&d->js_ctx){ wjs_destroy_context((duk_context*)d->js_ctx); d->js_ctx=NULL; }
    /* free images */
    for(int i=1;i<=g_we_image_n;i++) wrender_free_image((uint16_t)i);
    g_we_image_n=0;
    /* reset audio */
    wa_exit();
    /* clear DOM */
    dom_reset(g_web_engine.main_doc);
    css_reset();
    g_web_engine.loaded=false;
    g_web_engine.title[0]='\0';
    g_web_engine.hover_node=-1;
    g_web_engine.focus_node=-1;
    /* clear JS log */
    wjs_log_clear();
}

/* ── Frame update ─────────────────────────────────────────────────── */

void we_update(const WEInputState *inp, float top_cx, float top_cy,
               bool cursor_locked, double dt_ms){
    if(!g_web_engine.initialized||!g_web_engine.loaded) return;

    g_web_engine.time_ms+=dt_ms;
    g_web_engine.cursor_locked=cursor_locked;

    /* feed events */
    WEInputState local_inp={0};
    if(inp) local_inp=*inp;
    local_inp.cursor_x=top_cx;
    local_inp.cursor_y=top_cy;
    we_events_update(g_web_engine.main_doc,&local_inp);

    /* tick JS */
    DOMDocument *d=dom_doc(g_web_engine.main_doc);
    if(d&&d->js_ctx&&d->js_ready){
        duk_context *ctx=(duk_context*)d->js_ctx;
        wjs_tick_timers(ctx);
        wjs_tick_raf(ctx,g_web_engine.time_ms);
        wf_tick(ctx);
    }

    /* tick iframes */
    wif_tick(inp);

    /* tick audio */
    wa_tick(dt_ms/1000.0);

    /* flush docwrite if pending */
    if(s_docwrite_pos>0){
        WEParseOpts opts={.doc_id=g_web_engine.main_doc,.fragment_mode=true};
        DOMDocument *dd=dom_doc(g_web_engine.main_doc);
        opts.fragment_parent=dd?dd->body_node:-1;
        s_docwrite_buf[s_docwrite_pos]='\0';
        wep_parse(s_docwrite_buf,&opts);
        css_cascade(g_web_engine.main_doc);
        layout_document(g_web_engine.main_doc);
        s_docwrite_pos=0;
        s_docwrite_open=false;
    }

    /* re-layout if dirty */
    bool any_dirty=false;
    for(int i=0;i<g_dom_node_n&&!any_dirty;i++)
        if(g_dom_nodes[i].doc_id==g_web_engine.main_doc&&g_dom_nodes[i].dirty)
            any_dirty=true;
    if(any_dirty) layout_document(g_web_engine.main_doc);

    /* scroll clamping */
    DOMDocument *dd=dom_doc(g_web_engine.main_doc);
    if(dd&&dd->body_node>=0){
        int16_t msx,msy;
        layout_scroll_extents(dd->body_node,&msx,&msy);
        g_web_engine.max_scroll_x=msx;
        g_web_engine.max_scroll_y=msy;
        if(g_web_engine.scroll_x<0) g_web_engine.scroll_x=0;
        if(g_web_engine.scroll_x>msx) g_web_engine.scroll_x=msx;
        if(g_web_engine.scroll_y<0) g_web_engine.scroll_y=0;
        if(g_web_engine.scroll_y>msy) g_web_engine.scroll_y=msy;
    }
}

/* ── Render ──────────────────────────────────────────────────────── */

void we_render(void){
    if(!g_web_engine.initialized) return;
    if(!g_web_engine.loaded){
        /* show splash */
        C2D_DrawRectSolid(0,0,0,WE_VIEWPORT_W,WE_VIEWPORT_H,
                          C2D_Color32(0x11,0x11,0x11,0xFF));
        extern void wrender_text(const char*,float,float,float,float,uint32_t,uint8_t,uint8_t,uint8_t);
        wrender_text("Pocket Compiler Web Engine",10,100,380,14,0xDDDDDDFF,1,0,0);
        wrender_text("Press START to run code",10,120,380,11,0x888888FF,1,0,0);
        return;
    }
    /* render document */
    wrender_document(g_web_engine.main_doc,
                     g_web_engine.scroll_x,
                     g_web_engine.scroll_y);
    /* render iframes */
    wif_render(g_web_engine.main_doc);
    /* title bar overlay if title exists */
    if(g_web_engine.title[0]){
        C2D_DrawRectSolid(0,0,0,WE_VIEWPORT_W,14,
                          C2D_Color32(0x22,0x22,0x33,0xCC));
        wrender_text(g_web_engine.title,4,1,WE_VIEWPORT_W-8,10,
                     0xAABBFFFF,0,0,0);
    }
    /* JS console overlay */
    if(g_web_engine.show_console&&g_wjs_log_n>0){
        float cy=WE_VIEWPORT_H-g_wjs_log_n*12-4;
        if(cy<0) cy=0;
        C2D_DrawRectSolid(0,cy,0,WE_VIEWPORT_W,(float)(g_wjs_log_n*12+4),
                          C2D_Color32(0,0,0,0xC0));
        for(int i=0;i<g_wjs_log_n;i++){
            wrender_text(g_wjs_log[i],2,cy+2+i*12,WE_VIEWPORT_W-4,10,
                         0x00FF44FF,0,0,0);
        }
    }
    /* vertical scrollbar if page is scrollable */
    if(g_web_engine.max_scroll_y>0){
        wrender_scrollbar_v(WE_VIEWPORT_W-5,14,WE_VIEWPORT_H-14,
                            g_web_engine.scroll_y,
                            g_web_engine.max_scroll_y+WE_VIEWPORT_H,
                            0x888888FF);
    }
}

/* ── document.write() ────────────────────────────────────────────── */

void we_document_write(const char *html){
    if(!html) return;
    int l=(int)strlen(html);
    if(s_docwrite_pos+l<65535){
        memcpy(s_docwrite_buf+s_docwrite_pos,html,l);
        s_docwrite_pos+=l;
        s_docwrite_open=true;
    }
}

void we_document_writeln(const char *html){
    we_document_write(html);
    we_document_write("<br>");
}

void we_document_open(void){
    s_docwrite_pos=0;
    s_docwrite_open=true;
    /* clear body */
    DOMDocument *d=dom_doc(g_web_engine.main_doc);
    if(d&&d->body_node>=0){
        DOMNode *bn=dom_node(d->body_node);
        if(bn){
            int16_t ch=bn->first_child;
            while(ch>=0){ int16_t nx=g_dom_nodes[ch].next_sib; dom_remove_child(d->body_node,ch); ch=nx; }
        }
    }
}

void we_document_close(void){
    /* flush will happen in we_update() */
}

/* ── Scroll control ──────────────────────────────────────────────── */

void  we_page_scroll_by(int16_t dx, int16_t dy){
    g_web_engine.scroll_x+=dx;
    g_web_engine.scroll_y+=dy;
}

void we_scroll_to_top(void){
    g_web_engine.scroll_x=0;
    g_web_engine.scroll_y=0;
}

/* ── Getters ─────────────────────────────────────────────────────── */

const char *we_get_title(void){ return g_web_engine.title; }
bool        we_is_loaded(void){ return g_web_engine.loaded; }

int16_t we_hit_test(float x, float y){
    return layout_hit(g_web_engine.main_doc,(int16_t)x,(int16_t)y);
}
