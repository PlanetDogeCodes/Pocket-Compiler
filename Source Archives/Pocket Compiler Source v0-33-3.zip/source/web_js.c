/*
 * web_js.c  —  Duktape JS runtime bindings
 *
 * fix6 changes:
 *  - Shared node prototype stored in heap stash (ensure_node_prototype).
 *    All 16 methods + 10 accessor pairs are created ONCE total instead of
 *    once per DOM node — eliminates OOM → Duktape fatal → abort() →
 *    "Exception: Undefined Instruction" on 3DS.
 *  - Fixed all 13 node methods that used get_node_from_obj(ctx,-1) to read
 *    arguments instead of 'this'.  Each now calls duk_push_this first.
 *  - Fixed childNodes/children put_prop_string to use explicit obj_idx.
 *  - Replaced void-cast (duk_push_undefined) with js_noop in wjs_fire_event.
 */
#include "web_js.h"
#include "duktape.h"
#include "web_render.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "web_events.h"
#include "web_html_parser.h"
#include "web_fetch.h"
#include "web_storage.h"
#include "web_audio.h"
#include "web_canvas.h"
#include "web_webgl.h"
#include "web_iframe.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <3ds.h>

/* ── Log buffer ─────────────────────────────────────────────────── */
char g_wjs_log[WJS_LOG_MAX_LINES][WJS_LOG_LINE_LEN];
int  g_wjs_log_n=0;

void wjs_log_push(const char *line){
    if(g_wjs_log_n<WJS_LOG_MAX_LINES){
        strncpy(g_wjs_log[g_wjs_log_n],line,WJS_LOG_LINE_LEN-1);
        g_wjs_log[g_wjs_log_n][WJS_LOG_LINE_LEN-1]='\0';
        g_wjs_log_n++;
    } else {
        /* scroll */
        for(int i=0;i<WJS_LOG_MAX_LINES-1;i++)
            memcpy(g_wjs_log[i],g_wjs_log[i+1],WJS_LOG_LINE_LEN);
        strncpy(g_wjs_log[WJS_LOG_MAX_LINES-1],line,WJS_LOG_LINE_LEN-1);
    }
}
void wjs_log_clear(void){ g_wjs_log_n=0; }

/* ── Timer system ────────────────────────────────────────────────── */
#define WJS_MAX_TIMERS 32
typedef struct {
    bool   used;
    bool   interval;
    double fire_at;    /* ms */
    double interval_ms;
    int    js_ref;     /* heapptr stash index */
    int    id;
} WJSTimer;

static WJSTimer s_timers[WJS_MAX_TIMERS];
static int      s_timer_next_id=1;
static double   s_time_ms=0;

/* ── RAF system ──────────────────────────────────────────────────── */
#define WJS_MAX_RAF 8
static int s_raf_n=0;

/* ── Shared node prototype key ───────────────────────────────────── */
#define WJS_STASH_NODE_PROTO "\xFF" "node_proto"

/* ── Duktape helpers ─────────────────────────────────────────────── */

static uint8_t get_doc_id(duk_context *ctx){
    duk_push_heap_stash(ctx);
    duk_get_prop_string(ctx,-1,WJS_STASH_DOCID);
    uint8_t id=(uint8_t)duk_to_int(ctx,-1);
    duk_pop_2(ctx);
    return id;
}

static int16_t get_node_from_obj(duk_context *ctx, duk_idx_t idx){
    duk_get_prop_string(ctx,idx,"__node_id");
    int16_t nid=(int16_t)duk_to_int(ctx,-1);
    duk_pop(ctx);
    return nid;
}

static void push_node_obj(duk_context *ctx, int16_t node_id);

/* ── console ─────────────────────────────────────────────────────── */

static duk_ret_t js_console_log(duk_context *ctx){
    int n=duk_get_top(ctx);
    char buf[WJS_LOG_LINE_LEN]; buf[0]='\0'; int pos=0;
    for(int i=0;i<n;i++){
        const char *s=duk_safe_to_string(ctx,i);
        if(s&&pos<WJS_LOG_LINE_LEN-2){
            int l=(int)strlen(s);
            if(pos+l>=WJS_LOG_LINE_LEN-1) l=WJS_LOG_LINE_LEN-1-pos;
            memcpy(buf+pos,s,l); pos+=l;
            if(i<n-1&&pos<WJS_LOG_LINE_LEN-1) buf[pos++]=' ';
        }
    }
    buf[pos]='\0';
    wjs_log_push(buf);
    return 0;
}

void wjs_install_console(duk_context *ctx){
    duk_push_global_object(ctx);
    duk_push_object(ctx);
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"log");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"warn");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"error");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"info");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"debug");
    duk_put_prop_string(ctx,-2,"console");
    duk_pop(ctx);
}

/* ── setTimeout / setInterval / clearTimeout / requestAnimationFrame */

static duk_ret_t js_setTimeout(duk_context *ctx){
    if(!duk_is_function(ctx,0)){ duk_push_int(ctx,0); return 1; }
    double ms=duk_get_number_default(ctx,1,0);
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(!s_timers[i].used){
            duk_dup(ctx,0);
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timer_next_id);
            duk_dup(ctx,-2); duk_put_prop_string(ctx,-2,key);
            duk_pop_2(ctx);
            s_timers[i].used=true;
            s_timers[i].interval=false;
            s_timers[i].fire_at=s_time_ms+ms;
            s_timers[i].interval_ms=ms;
            s_timers[i].js_ref=s_timer_next_id;
            s_timers[i].id=s_timer_next_id++;
            duk_push_int(ctx,s_timers[i].id);
            return 1;
        }
    }
    duk_push_int(ctx,0); return 1;
}

static duk_ret_t js_setInterval(duk_context *ctx){
    if(!duk_is_function(ctx,0)){ duk_push_int(ctx,0); return 1; }
    double ms=duk_get_number_default(ctx,1,16);
    if(ms<16) ms=16; /* 60fps cap */
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(!s_timers[i].used){
            duk_dup(ctx,0);
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timer_next_id);
            duk_dup(ctx,-2); duk_put_prop_string(ctx,-2,key);
            duk_pop_2(ctx);
            s_timers[i].used=true;
            s_timers[i].interval=true;
            s_timers[i].fire_at=s_time_ms+ms;
            s_timers[i].interval_ms=ms;
            s_timers[i].js_ref=s_timer_next_id;
            s_timers[i].id=s_timer_next_id++;
            duk_push_int(ctx,s_timers[i].id);
            return 1;
        }
    }
    duk_push_int(ctx,0); return 1;
}

static duk_ret_t js_clearTimeout(duk_context *ctx){
    int id=duk_to_int(ctx,0);
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(s_timers[i].used&&s_timers[i].id==id){
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timers[i].js_ref);
            duk_del_prop_string(ctx,-1,key);
            duk_pop(ctx);
            s_timers[i].used=false;
        }
    }
    return 0;
}

static duk_ret_t js_raf(duk_context *ctx){
    if(duk_is_function(ctx,0)&&s_raf_n<WJS_MAX_RAF){
        duk_push_heap_stash(ctx);
        char key[16]; snprintf(key,16,"raf%d",s_raf_n);
        duk_dup(ctx,0); duk_put_prop_string(ctx,-2,key);
        duk_pop(ctx);
        s_raf_n++;
    }
    duk_push_int(ctx,0); return 1;
}

void wjs_tick_timers(duk_context *ctx){
    for(int i=0;i<WJS_MAX_TIMERS;i++){
        if(!s_timers[i].used) continue;
        if(s_time_ms>=s_timers[i].fire_at){
            duk_push_heap_stash(ctx);
            char key[16]; snprintf(key,16,"t%d",s_timers[i].js_ref);
            duk_get_prop_string(ctx,-1,key);
            if(duk_is_function(ctx,-1)){
                if(duk_pcall(ctx,0)!=0){
                    wjs_log_push(duk_safe_to_string(ctx,-1));
                }
            }
            duk_pop(ctx); /* result/fn */
            if(s_timers[i].interval){
                s_timers[i].fire_at+=s_timers[i].interval_ms;
            } else {
                duk_del_prop_string(ctx,-1,key);
                s_timers[i].used=false;
            }
            duk_pop(ctx); /* stash */
        }
    }
}

void wjs_tick_raf(duk_context *ctx, double timestamp_ms){
    s_time_ms=timestamp_ms;
    int n=s_raf_n; s_raf_n=0;
    duk_push_heap_stash(ctx);
    for(int i=0;i<n;i++){
        char key[16]; snprintf(key,16,"raf%d",i);
        duk_get_prop_string(ctx,-1,key);
        if(duk_is_function(ctx,-1)){
            duk_push_number(ctx,timestamp_ms);
            if(duk_pcall(ctx,1)!=0){
                wjs_log_push(duk_safe_to_string(ctx,-1));
            }
            duk_pop(ctx);
        } else { duk_pop(ctx); }
        duk_del_prop_string(ctx,-1,key);
    }
    duk_pop(ctx);
}

/* ── no-op helper ────────────────────────────────────────────────── */
/* Used for preventDefault / stopPropagation instead of void-cast UB */
static duk_ret_t js_noop(duk_context *ctx){ (void)ctx; return 0; }

/* ── Event firing ────────────────────────────────────────────────── */

void wjs_fire_event(duk_context *ctx, int js_ref, const WEEvent *ev){
    duk_push_heap_stash(ctx);
    char key[16]; snprintf(key,16,"ev%d",js_ref);
    duk_get_prop_string(ctx,-1,key);
    if(!duk_is_function(ctx,-1)){ duk_pop_2(ctx); return; }
    /* build event object */
    duk_push_object(ctx);
    duk_push_int(ctx,ev->type);        duk_put_prop_string(ctx,-2,"type");
    duk_push_number(ctx,ev->client_x); duk_put_prop_string(ctx,-2,"clientX");
    duk_push_number(ctx,ev->client_y); duk_put_prop_string(ctx,-2,"clientY");
    duk_push_number(ctx,ev->offset_x); duk_put_prop_string(ctx,-2,"offsetX");
    duk_push_number(ctx,ev->offset_y); duk_put_prop_string(ctx,-2,"offsetY");
    duk_push_int(ctx,ev->key_code);    duk_put_prop_string(ctx,-2,"keyCode");
    duk_push_string(ctx,ev->key_str);  duk_put_prop_string(ctx,-2,"key");
    duk_push_int(ctx,ev->button);      duk_put_prop_string(ctx,-2,"button");
    duk_push_boolean(ctx,ev->shift);   duk_put_prop_string(ctx,-2,"shiftKey");
    duk_push_boolean(ctx,ev->ctrl);    duk_put_prop_string(ctx,-2,"ctrlKey");
    duk_push_boolean(ctx,ev->alt);     duk_put_prop_string(ctx,-2,"altKey");
    /* preventDefault / stopPropagation — safe no-op (fixes void-cast UB) */
    duk_push_c_function(ctx,js_noop,0);
    duk_put_prop_string(ctx,-2,"preventDefault");
    duk_push_c_function(ctx,js_noop,0);
    duk_put_prop_string(ctx,-2,"stopPropagation");
    if(duk_pcall(ctx,1)!=0){
        wjs_log_push(duk_safe_to_string(ctx,-1));
    }
    duk_pop_2(ctx); /* result, stash */
}

/* ── DOM Property Accessors (live getter/setter via duk_def_prop) ── */
/* All accessors already use duk_push_this — no changes needed here.  */

static duk_ret_t dom_get_innerHTML(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    duk_push_string(ctx,dom_text_content(nid)); return 1;
}
static duk_ret_t dom_set_innerHTML(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    DOMNode *n=dom_node(nid); if(!n) return 0;
    const char *html=duk_safe_to_string(ctx,0);
    uint8_t doc_id=n->doc_id;
    int16_t ch=n->first_child;
    while(ch>=0){ int16_t nx=g_dom_nodes[ch].next_sib; dom_remove_child(nid,ch); ch=nx; }
    WEParseOpts opts={.doc_id=doc_id,.fragment_mode=true,.fragment_parent=nid};
    wep_parse(html,&opts);
    css_cascade(doc_id); dom_mark_dirty(nid);
    return 0;
}

static duk_ret_t dom_get_textContent(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    duk_push_string(ctx,dom_text_content(nid)); return 1;
}
static duk_ret_t dom_set_textContent(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    DOMNode *n=dom_node(nid); if(!n) return 0;
    const char *txt=duk_safe_to_string(ctx,0);
    int16_t ch=n->first_child;
    while(ch>=0){ int16_t nx=g_dom_nodes[ch].next_sib; dom_remove_child(nid,ch); ch=nx; }
    int16_t tn=dom_new_text(n->doc_id,txt);
    if(tn>=0) dom_append_child(nid,tn);
    dom_mark_dirty(nid);
    return 0;
}

static duk_ret_t dom_get_value(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *v=dom_get_attr(nid,"value");
    duk_push_string(ctx,v?v:""); return 1;
}
static duk_ret_t dom_set_value(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    dom_set_attr(nid,"value",duk_safe_to_string(ctx,0));
    DOMNode *n=dom_node(nid);
    if(n){ WEEvent ev={0}; ev.type=WE_EV_INPUT; we_dispatch(n->doc_id,nid,&ev); }
    return 0;
}

static duk_ret_t dom_get_className(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *v=dom_get_attr(nid,"class");
    duk_push_string(ctx,v?v:""); return 1;
}
static duk_ret_t dom_set_className(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid<0) return 0;
    dom_set_attr(nid,"class",duk_safe_to_string(ctx,0));
    css_compute_node(nid);
    return 0;
}

static duk_ret_t dom_get_id(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    const char *v=dom_get_attr(nid,"id");
    duk_push_string(ctx,v?v:""); return 1;
}
static duk_ret_t dom_set_id(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    if(nid>=0) dom_set_attr(nid,"id",duk_safe_to_string(ctx,0));
    return 0;
}

static duk_ret_t dom_get_checked(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_boolean(ctx,n?n->checked:0); return 1;
}
static duk_ret_t dom_set_checked(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->checked=duk_to_boolean(ctx,0)?1:0;
    return 0;
}

static duk_ret_t dom_get_disabled(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_boolean(ctx,n?n->disabled:0); return 1;
}
static duk_ret_t dom_set_disabled(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->disabled=duk_to_boolean(ctx,0)?1:0;
    return 0;
}

static duk_ret_t dom_get_scrollLeft(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_int(ctx,n?n->scroll_x:0); return 1;
}
static duk_ret_t dom_set_scrollLeft(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->scroll_x=(int16_t)duk_to_int(ctx,0);
    return 0;
}

static duk_ret_t dom_get_scrollTop(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_int(ctx,n?n->scroll_y:0); return 1;
}
static duk_ret_t dom_set_scrollTop(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1); duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) n->scroll_y=(int16_t)duk_to_int(ctx,0);
    return 0;
}

/* ── DOM Node methods ────────────────────────────────────────────── */
/* FIX: all methods now call duk_push_this to get 'this', then pop it */

static duk_ret_t js_node_addEventListener(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx); /* pop this */
    const char *type=duk_get_string(ctx,0);
    if(!duk_is_function(ctx,1)||!type) return 0;
    WEEventType evt=WE_EV_NONE;
    if(strcmp(type,"click")==0)        evt=WE_EV_CLICK;
    else if(strcmp(type,"mousedown")==0)  evt=WE_EV_MOUSEDOWN;
    else if(strcmp(type,"mouseup")==0)    evt=WE_EV_MOUSEUP;
    else if(strcmp(type,"mousemove")==0)  evt=WE_EV_MOUSEMOVE;
    else if(strcmp(type,"mouseenter")==0) evt=WE_EV_MOUSEENTER;
    else if(strcmp(type,"mouseleave")==0) evt=WE_EV_MOUSELEAVE;
    else if(strcmp(type,"keydown")==0)    evt=WE_EV_KEYDOWN;
    else if(strcmp(type,"keyup")==0)      evt=WE_EV_KEYUP;
    else if(strcmp(type,"keypress")==0)   evt=WE_EV_KEYPRESS;
    else if(strcmp(type,"focus")==0)      evt=WE_EV_FOCUS;
    else if(strcmp(type,"blur")==0)       evt=WE_EV_BLUR;
    else if(strcmp(type,"input")==0)      evt=WE_EV_INPUT;
    else if(strcmp(type,"change")==0)     evt=WE_EV_CHANGE;
    else if(strcmp(type,"submit")==0)     evt=WE_EV_SUBMIT;
    else if(strcmp(type,"scroll")==0)     evt=WE_EV_SCROLL;
    else if(strcmp(type,"load")==0)       evt=WE_EV_LOAD;
    else if(strcmp(type,"touchstart")==0) evt=WE_EV_TOUCHSTART;
    else if(strcmp(type,"touchend")==0)   evt=WE_EV_TOUCHEND;
    else if(strcmp(type,"touchmove")==0)  evt=WE_EV_TOUCHMOVE;
    if(evt==WE_EV_NONE) return 0;
    static int s_ref=0;
    duk_push_heap_stash(ctx);
    char key[16]; snprintf(key,16,"ev%d",++s_ref);
    duk_dup(ctx,1); duk_put_prop_string(ctx,-2,key);
    duk_pop(ctx);
    we_add_listener(nid,evt,s_ref);
    return 0;
}

static duk_ret_t js_node_setAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    const char *val=duk_safe_to_string(ctx,1);
    if(name) dom_set_attr(nid,name,val);
    if(name&&strcmp(name,"style")==0) css_compute_node(nid);
    return 0;
}
static duk_ret_t js_node_getAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    const char *val=dom_get_attr(nid,name?name:"");
    if(val) duk_push_string(ctx,val); else duk_push_null(ctx);
    return 1;
}
static duk_ret_t js_node_removeAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    if(name) dom_remove_attr(nid,name);
    return 0;
}
static duk_ret_t js_node_hasAttribute(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    const char *name=duk_get_string(ctx,0);
    duk_push_boolean(ctx,dom_has_attr(nid,name?name:""));
    return 1;
}
static duk_ret_t js_node_appendChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t par=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    int16_t child=get_node_from_obj(ctx,0);
    dom_append_child(par,child);
    push_node_obj(ctx,child); return 1;
}
static duk_ret_t js_node_removeChild(duk_context *ctx){
    duk_push_this(ctx);
    int16_t par=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    int16_t child=get_node_from_obj(ctx,0);
    dom_remove_child(par,child);
    push_node_obj(ctx,child); return 1;
}
static duk_ret_t js_node_insertBefore(duk_context *ctx){
    /* this = parent (not needed — dom_insert_before finds parent from ref) */
    int16_t newnode=get_node_from_obj(ctx,0);
    int16_t ref=get_node_from_obj(ctx,1);
    dom_insert_before(ref,newnode);
    push_node_obj(ctx,newnode); return 1;
}
static duk_ret_t js_node_replaceChild(duk_context *ctx){
    /* this = parent (not needed — dom_replace_child finds parent from oldn) */
    int16_t newn=get_node_from_obj(ctx,0);
    int16_t oldn=get_node_from_obj(ctx,1);
    dom_replace_child(oldn,newn);
    push_node_obj(ctx,oldn); return 1;
}
static duk_ret_t js_node_cloneNode(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    DOMNode *n=dom_node(nid); if(!n){ duk_push_null(ctx); return 1; }
    int16_t clone=dom_new_element(n->doc_id,dom_tag(nid));
    push_node_obj(ctx,clone); return 1;
}
static duk_ret_t js_node_focus(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) we_focus(n->doc_id,nid);
    return 0;
}
static duk_ret_t js_node_blur(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    if(n) we_blur(n->doc_id);
    return 0;
}
static duk_ret_t js_node_click(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    DOMNode *n=dom_node(nid); if(!n) return 0;
    WEEvent ev={0}; ev.type=WE_EV_CLICK;
    we_dispatch(n->doc_id,nid,&ev);
    return 0;
}
static duk_ret_t js_node_scrollIntoView(duk_context *ctx){ (void)ctx; return 0; }
static duk_ret_t js_node_getBoundingClientRect(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    DOMNode *n=dom_node(nid);
    duk_push_object(ctx);
    if(n){
        duk_push_number(ctx,n->lay_x);         duk_put_prop_string(ctx,-2,"left");
        duk_push_number(ctx,n->lay_y);         duk_put_prop_string(ctx,-2,"top");
        duk_push_number(ctx,n->lay_x+n->lay_w);duk_put_prop_string(ctx,-2,"right");
        duk_push_number(ctx,n->lay_y+n->lay_h);duk_put_prop_string(ctx,-2,"bottom");
        duk_push_number(ctx,n->lay_w);         duk_put_prop_string(ctx,-2,"width");
        duk_push_number(ctx,n->lay_h);         duk_put_prop_string(ctx,-2,"height");
    }
    return 1;
}

/* getContext for canvas */
static duk_ret_t js_node_getContext(duk_context *ctx){
    duk_push_this(ctx);
    int16_t nid=get_node_from_obj(ctx,-1);
    duk_pop(ctx);
    const char *type=duk_get_string(ctx,0);
    DOMNode *n=dom_node(nid);
    if(!n||!type){ duk_push_null(ctx); return 1; }
    if(n->canvas_id==0){
        int16_t cw=n->lay_w>0?n->lay_w:300;
        int16_t ch=n->lay_h>0?n->lay_h:150;
        const char *ws=dom_get_attr(nid,"width");
        const char *hs=dom_get_attr(nid,"height");
        if(ws) cw=(int16_t)atoi(ws);
        if(hs) ch=(int16_t)atoi(hs);
        n->canvas_id=wrender_new_canvas((uint16_t)cw,(uint16_t)ch);
    }
    if(strcmp(type,"2d")==0){
        wc_install_bindings(ctx,(uint16_t)n->canvas_id);
        return 1;
    }
    if(strcmp(type,"webgl")==0||strcmp(type,"experimental-webgl")==0){
        wgl_install_bindings(ctx,(int)n->canvas_id,(int)n->doc_id);
        return 1;
    }
    duk_push_null(ctx); return 1;
}

/* ── Shared node prototype ───────────────────────────────────────── */
/*
 * ensure_node_prototype: creates the shared prototype object ONCE and
 * stores it in the heap stash under WJS_STASH_NODE_PROTO.  Subsequent
 * calls are O(1) (just a stash lookup).  All 16 methods + 20 accessor
 * functions (10 pairs) live on this one object instead of being
 * re-created for every DOM node.
 */
static void ensure_node_prototype(duk_context *ctx){
    duk_push_heap_stash(ctx);
    if(duk_has_prop_string(ctx,-1,WJS_STASH_NODE_PROTO)){
        duk_pop(ctx); return;
    }

    duk_push_object(ctx);
    duk_idx_t proto_idx=duk_get_top_index(ctx);

    /* ── Methods (16 function objects, created once) ── */
    #define METH(name,fn,nargs) \
        duk_push_c_function(ctx,fn,nargs); \
        duk_put_prop_string(ctx,proto_idx,name)
    METH("addEventListener",      js_node_addEventListener,     3);
    METH("setAttribute",          js_node_setAttribute,         2);
    METH("getAttribute",          js_node_getAttribute,         1);
    METH("removeAttribute",       js_node_removeAttribute,      1);
    METH("hasAttribute",          js_node_hasAttribute,         1);
    METH("appendChild",           js_node_appendChild,          1);
    METH("removeChild",           js_node_removeChild,          1);
    METH("insertBefore",          js_node_insertBefore,         2);
    METH("replaceChild",          js_node_replaceChild,         2);
    METH("cloneNode",             js_node_cloneNode,            1);
    METH("focus",                 js_node_focus,                0);
    METH("blur",                  js_node_blur,                 0);
    METH("click",                 js_node_click,                0);
    METH("scrollIntoView",        js_node_scrollIntoView,       0);
    METH("getBoundingClientRect", js_node_getBoundingClientRect,0);
    METH("getContext",            js_node_getContext,           1);
    #undef METH

    /* ── Accessor pairs (10 pairs = 20 function objects, created once) ── */
    #define ACCESSOR(prop,getter,setter) \
        duk_push_string(ctx,prop); \
        duk_push_c_function(ctx,getter,0); \
        duk_push_c_function(ctx,setter,1); \
        duk_def_prop(ctx,proto_idx, \
            DUK_DEFPROP_HAVE_GETTER|DUK_DEFPROP_HAVE_SETTER| \
            DUK_DEFPROP_HAVE_CONFIGURABLE|DUK_DEFPROP_CONFIGURABLE| \
            DUK_DEFPROP_HAVE_ENUMERABLE|DUK_DEFPROP_ENUMERABLE)
    ACCESSOR("innerHTML",   dom_get_innerHTML,   dom_set_innerHTML);
    ACCESSOR("textContent", dom_get_textContent, dom_set_textContent);
    ACCESSOR("innerText",   dom_get_textContent, dom_set_textContent);
    ACCESSOR("value",       dom_get_value,       dom_set_value);
    ACCESSOR("className",   dom_get_className,   dom_set_className);
    ACCESSOR("id",          dom_get_id,          dom_set_id);
    ACCESSOR("checked",     dom_get_checked,     dom_set_checked);
    ACCESSOR("disabled",    dom_get_disabled,    dom_set_disabled);
    ACCESSOR("scrollLeft",  dom_get_scrollLeft,  dom_set_scrollLeft);
    ACCESSOR("scrollTop",   dom_get_scrollTop,   dom_set_scrollTop);
    #undef ACCESSOR

    /* put proto into stash */
    duk_put_prop_string(ctx,-2,WJS_STASH_NODE_PROTO);
    duk_pop(ctx); /* pop stash */
}

/* ── push_node_obj: creates a thin JS element object ────────────── */
/*
 * Each node instance now holds only per-instance data (__node_id,
 * tagName, static layout snapshots, children array, style, etc.).
 * All 36 method/accessor functions are inherited from the shared
 * prototype via duk_set_prototype — reducing heap pressure from
 * O(36 * nodes) to O(36 + nodes).
 */
static void push_node_obj(duk_context *ctx, int16_t node_id){
    if(node_id<0){ duk_push_null(ctx); return; }

    /* guarantee shared prototype exists */
    ensure_node_prototype(ctx);

    duk_push_object(ctx);
    duk_idx_t obj_idx=duk_get_top_index(ctx);

    /* link instance to shared prototype */
    duk_push_heap_stash(ctx);
    duk_get_prop_string(ctx,-1,WJS_STASH_NODE_PROTO);
    /* stack: [..., obj, stash, proto]  duk_set_prototype pops proto */
    duk_set_prototype(ctx,obj_idx);
    duk_pop(ctx); /* pop stash */

    /* per-instance: __node_id */
    duk_push_int(ctx,(int)node_id);
    duk_put_prop_string(ctx,obj_idx,"__node_id");

    /* per-instance: static snapshot properties */
    DOMNode *n=dom_node(node_id);
    if(n){
        duk_push_string(ctx,dom_tag(node_id)); duk_put_prop_string(ctx,obj_idx,"tagName");
        duk_push_string(ctx,dom_tag(node_id)); duk_put_prop_string(ctx,obj_idx,"nodeName");
        duk_push_int(ctx,n->type);             duk_put_prop_string(ctx,obj_idx,"nodeType");
        duk_push_int(ctx,n->lay_x);            duk_put_prop_string(ctx,obj_idx,"offsetLeft");
        duk_push_int(ctx,n->lay_y);            duk_put_prop_string(ctx,obj_idx,"offsetTop");
        duk_push_int(ctx,n->lay_w);            duk_put_prop_string(ctx,obj_idx,"offsetWidth");
        duk_push_int(ctx,n->lay_h);            duk_put_prop_string(ctx,obj_idx,"offsetHeight");
        /* href / src */
        const char *href=dom_get_attr(node_id,"href");
        duk_push_string(ctx,href?href:""); duk_put_prop_string(ctx,obj_idx,"href");
        const char *src=dom_get_attr(node_id,"src");
        duk_push_string(ctx,src?src:"");   duk_put_prop_string(ctx,obj_idx,"src");
        /* style object */
        duk_push_object(ctx);
        duk_push_int(ctx,(int)node_id);
        duk_put_prop_string(ctx,-2,"__node_id");
        duk_put_prop_string(ctx,obj_idx,"style");
        /* children / childNodes — build array, dup before consuming */
        duk_push_array(ctx);
        int ci=0;
        for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            push_node_obj(ctx,ch);
            duk_put_prop_index(ctx,-2,(duk_uarridx_t)ci++);
        }
        duk_dup(ctx,-1);                              /* dup array  */
        duk_put_prop_string(ctx,obj_idx,"childNodes");/* consumes dup    */
        duk_put_prop_string(ctx,obj_idx,"children");  /* consumes original*/
        /* iframe contentWindow with postMessage */
        if(n->type==NT_ELEMENT && strcmp(dom_tag(node_id),"iframe")==0){
            int slot=wif_find(node_id);
            if(slot>=0){
                duk_push_object(ctx);
                duk_push_int(ctx,slot);
                duk_put_prop_string(ctx,-2,"__iframe_idx");
                duk_push_c_function(ctx,wif_js_postMessage,2);
                duk_put_prop_string(ctx,-2,"postMessage");
                duk_put_prop_string(ctx,obj_idx,"contentWindow");
            }
        }
    }
}

/* ── document object ─────────────────────────────────────────────── */

static duk_ret_t js_doc_getElementById(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *id=duk_get_string(ctx,0);
    int16_t node=dom_get_by_id(doc_id,id?id:"");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_getElementsByTagName(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *tag=duk_get_string(ctx,0);
    duk_push_array(ctx);
    int16_t n=dom_get_by_tag(doc_id,tag?tag:"",-1); int i=0;
    while(n>=0){ push_node_obj(ctx,n); duk_put_prop_index(ctx,-2,(duk_uarridx_t)i++); n=dom_get_by_tag(doc_id,tag,n); }
    return 1;
}
static duk_ret_t js_doc_getElementsByClassName(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *cls=duk_get_string(ctx,0);
    int16_t out[64]; int n=0;
    dom_get_by_class(doc_id,cls?cls:"",out,&n,64);
    duk_push_array(ctx);
    for(int i=0;i<n;i++){ push_node_obj(ctx,out[i]); duk_put_prop_index(ctx,-2,(duk_uarridx_t)i); }
    return 1;
}
static duk_ret_t js_doc_querySelector(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *sel=duk_get_string(ctx,0);
    int16_t node=dom_query_selector(doc_id,sel?sel:"");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_querySelectorAll(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *sel=duk_get_string(ctx,0);
    duk_push_array(ctx);
    if(!sel||!*sel) return 1;
    int i=0;
    if(sel[0]=='#'){ int16_t n=dom_get_by_id(doc_id,sel+1); if(n>=0){ push_node_obj(ctx,n); duk_put_prop_index(ctx,-2,0);} return 1; }
    if(sel[0]=='.'){
        int16_t out[64]; int n=0; dom_get_by_class(doc_id,sel+1,out,&n,64);
        for(int j=0;j<n;j++){ push_node_obj(ctx,out[j]); duk_put_prop_index(ctx,-2,(duk_uarridx_t)j); }
        return 1;
    }
    int16_t n=dom_get_by_tag(doc_id,sel,-1);
    while(n>=0){ push_node_obj(ctx,n); duk_put_prop_index(ctx,-2,(duk_uarridx_t)i++); n=dom_get_by_tag(doc_id,sel,n); }
    return 1;
}
static duk_ret_t js_doc_createElement(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *tag=duk_get_string(ctx,0);
    int16_t node=dom_new_element(doc_id,tag?tag:"div");
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_createTextNode(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *txt=duk_safe_to_string(ctx,0);
    int16_t node=dom_new_text(doc_id,txt);
    push_node_obj(ctx,node); return 1;
}
static duk_ret_t js_doc_write(duk_context *ctx){
    uint8_t doc_id=get_doc_id(ctx);
    const char *html=duk_safe_to_string(ctx,0);
    DOMDocument *d=dom_doc(doc_id);
    if(!d||d->body_node<0) return 0;
    WEParseOpts opts={.doc_id=doc_id,.fragment_mode=true,.fragment_parent=d->body_node};
    wep_parse(html,&opts);
    css_cascade(doc_id);
    return 0;
}
static duk_ret_t js_doc_writeln(duk_context *ctx){
    js_doc_write(ctx);
    uint8_t doc_id=get_doc_id(ctx);
    DOMDocument *d=dom_doc(doc_id);
    if(d&&d->body_node>=0){
        int16_t br=dom_new_element(doc_id,"br");
        if(br>=0) dom_append_child(d->body_node,br);
    }
    return 0;
}

void wjs_install_dom(duk_context *ctx, uint8_t doc_id){
    duk_push_global_object(ctx);

    /* document object */
    duk_push_object(ctx);
    duk_push_int(ctx,(int)doc_id); duk_put_prop_string(ctx,-2,"__doc_id");

    DOMDocument *d=dom_doc(doc_id);
    if(d){
        push_node_obj(ctx,d->body_node); duk_put_prop_string(ctx,-2,"body");
        push_node_obj(ctx,d->head_node); duk_put_prop_string(ctx,-2,"head");
        push_node_obj(ctx,d->root_node); duk_put_prop_string(ctx,-2,"documentElement");
    }
    duk_push_string(ctx,"complete"); duk_put_prop_string(ctx,-2,"readyState");
    duk_push_c_function(ctx,js_doc_getElementById,        1); duk_put_prop_string(ctx,-2,"getElementById");
    duk_push_c_function(ctx,js_doc_getElementsByTagName,  1); duk_put_prop_string(ctx,-2,"getElementsByTagName");
    duk_push_c_function(ctx,js_doc_getElementsByClassName,1); duk_put_prop_string(ctx,-2,"getElementsByClassName");
    duk_push_c_function(ctx,js_doc_querySelector,         1); duk_put_prop_string(ctx,-2,"querySelector");
    duk_push_c_function(ctx,js_doc_querySelectorAll,      1); duk_put_prop_string(ctx,-2,"querySelectorAll");
    duk_push_c_function(ctx,js_doc_createElement,         1); duk_put_prop_string(ctx,-2,"createElement");
    duk_push_c_function(ctx,js_doc_createTextNode,        1); duk_put_prop_string(ctx,-2,"createTextNode");
    duk_push_c_function(ctx,js_doc_write,                 1); duk_put_prop_string(ctx,-2,"write");
    duk_push_c_function(ctx,js_doc_writeln,               1); duk_put_prop_string(ctx,-2,"writeln");
    duk_push_c_function(ctx,js_node_addEventListener,     3); duk_put_prop_string(ctx,-2,"addEventListener");
    duk_put_prop_string(ctx,-2,"document");

    duk_pop(ctx);
}

/* ── window / navigator / screen / location ─────────────────────── */

void wjs_install_window(duk_context *ctx, uint8_t doc_id){
    duk_push_global_object(ctx);
    duk_dup(ctx,-1); duk_put_prop_string(ctx,-2,"window");
    duk_push_c_function(ctx,js_setTimeout,   -1); duk_put_prop_string(ctx,-2,"setTimeout");
    duk_push_c_function(ctx,js_setInterval,  -1); duk_put_prop_string(ctx,-2,"setInterval");
    duk_push_c_function(ctx,js_clearTimeout,  1); duk_put_prop_string(ctx,-2,"clearTimeout");
    duk_push_c_function(ctx,js_clearTimeout,  1); duk_put_prop_string(ctx,-2,"clearInterval");
    duk_push_c_function(ctx,js_raf,           1); duk_put_prop_string(ctx,-2,"requestAnimationFrame");
    /* screen */
    duk_push_object(ctx);
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"width");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"height");
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"availWidth");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"availHeight");
    duk_push_int(ctx,24);            duk_put_prop_string(ctx,-2,"colorDepth");
    duk_put_prop_string(ctx,-2,"screen");
    /* navigator */
    duk_push_object(ctx);
    duk_push_string(ctx,"Nintendo 3DS");                duk_put_prop_string(ctx,-2,"platform");
    duk_push_string(ctx,"Pocket Compiler/0.33 (3DS)"); duk_put_prop_string(ctx,-2,"userAgent");
    duk_push_string(ctx,"en-US");                       duk_put_prop_string(ctx,-2,"language");
    duk_push_boolean(ctx,1);                            duk_put_prop_string(ctx,-2,"onLine");
    duk_put_prop_string(ctx,-2,"navigator");
    /* location */
    duk_push_object(ctx);
    duk_push_string(ctx,"3ds://app"); duk_put_prop_string(ctx,-2,"href");
    duk_push_string(ctx,"3ds");       duk_put_prop_string(ctx,-2,"protocol");
    duk_push_string(ctx,"app");       duk_put_prop_string(ctx,-2,"pathname");
    duk_push_string(ctx,"");          duk_put_prop_string(ctx,-2,"search");
    duk_push_string(ctx,"");          duk_put_prop_string(ctx,-2,"hash");
    duk_put_prop_string(ctx,-2,"location");
    /* window dimensions */
    duk_push_int(ctx,WE_VIEWPORT_W); duk_put_prop_string(ctx,-2,"innerWidth");
    duk_push_int(ctx,WE_VIEWPORT_H); duk_put_prop_string(ctx,-2,"innerHeight");
    /* alert / confirm — mapped to log */
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"alert");
    duk_push_c_function(ctx,js_console_log,-1); duk_put_prop_string(ctx,-2,"confirm");
    /* DOMContentLoaded helper */
    duk_eval_string_noresult(ctx,
        "var _we_dcl_fn=null;"
        "function _we_dcl(){ if(_we_dcl_fn) _we_dcl_fn(); }"
        "var document=window.document||document;"
    );
    (void)doc_id;
    duk_pop(ctx);
}

void wjs_install_navigator(duk_context *ctx){ (void)ctx; }

void wjs_install_fetch(duk_context *ctx, uint8_t doc_id){
    wf_install_fetch(ctx, doc_id);
    wf_install_xhr(ctx, doc_id);
}

void wjs_install_storage(duk_context *ctx, uint8_t doc_id){
    char origin[64];
    snprintf(origin, sizeof(origin), "doc%d", (int)doc_id);
    ws_install_local(ctx, origin);
    ws_install_session(ctx, origin);
    ws_install_idb(ctx, origin);
    ws_install_cookies(ctx);
}

void wjs_install_audio(duk_context *ctx, uint8_t doc_id){
    wa_install_bindings(ctx, doc_id);
}

/* ── Eval / call ─────────────────────────────────────────────────── */

duk_context *wjs_create_context(uint8_t doc_id){
    duk_context *ctx=duk_create_heap_default();
    if(!ctx) return NULL;
    duk_push_heap_stash(ctx);
    duk_push_int(ctx,(int)doc_id);
    duk_put_prop_string(ctx,-2,WJS_STASH_DOCID);
    duk_pop(ctx);
    wjs_install_console(ctx);
    wjs_install_window(ctx,doc_id);
    wjs_install_dom(ctx,doc_id);
    wjs_install_fetch(ctx,doc_id);
    wjs_install_storage(ctx,doc_id);
    wjs_install_audio(ctx,doc_id);
    return ctx;
}

void wjs_destroy_context(duk_context *ctx){
    if(ctx) duk_destroy_heap(ctx);
}

bool wjs_eval(duk_context *ctx, const char *script){
    if(!ctx||!script) return false;
    if(duk_peval_string(ctx,script)!=0){
        wjs_log_push(duk_safe_to_string(ctx,-1));
        duk_pop(ctx); return false;
    }
    duk_pop(ctx); return true;
}

bool wjs_eval_file(duk_context *ctx, const char *path){
    if(!ctx||!path) return false;
    char resolved[256];
    if(strncmp(path,"sdmc:/",6)==0) strncpy(resolved,path,255);
    else snprintf(resolved,sizeof(resolved),"sdmc:/3ds/pocketcompiler/www/%s",path);
    resolved[255]='\0';
    FILE *f=fopen(resolved,"r");
    if(!f){ char msg[128]; snprintf(msg,sizeof(msg),"[JS] Cannot open: %s",resolved); wjs_log_push(msg); return false; }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    if(sz<=0||sz>65535){ fclose(f); return false; }
    char *buf=(char*)malloc(sz+1);
    if(!buf){ fclose(f); return false; }
    fread(buf,1,sz,f); fclose(f); buf[sz]='\0';
    bool ok=wjs_eval(ctx,buf);
    free(buf); return ok;
}

bool wjs_call(duk_context *ctx, const char *fn){
    if(!ctx||!fn) return false;
    duk_get_global_string(ctx,fn);
    if(!duk_is_function(ctx,-1)){ duk_pop(ctx); return false; }
    if(duk_pcall(ctx,0)!=0){
        wjs_log_push(duk_safe_to_string(ctx,-1));
        duk_pop(ctx); return false;
    }
    duk_pop(ctx); return true;
}
