/*
 * web_render.c  —  Citro2D renderer for the web engine
 */
#include "web_render.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "lodepng.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

WEImage g_we_images[WE_MAX_IMAGES];
int     g_we_image_n=0;

WECanvas g_we_canvas[WE_MAX_CANVAS];

/* ── Utility color conversion ────────────────────────────────────── */
/* RGBA8 (0xRRGGBBAA) → Citro2D u32 (ABGR) */
static u32 to_c2d(uint32_t rgba){
    uint8_t r=(rgba>>24)&0xFF;
    uint8_t g=(rgba>>16)&0xFF;
    uint8_t b=(rgba>>8)&0xFF;
    uint8_t a=rgba&0xFF;
    return C2D_Color32(r,g,b,a);
}

/* ── Init / exit ─────────────────────────────────────────────────── */

void wrender_init(void){
    memset(g_we_images,0,sizeof(g_we_images));
    memset(g_we_canvas,0,sizeof(g_we_canvas));
    g_we_image_n=0;
}

void wrender_exit(void){
    for(int i=0;i<WE_MAX_IMAGES;i++){
        if(g_we_images[i].loaded){
            C3D_TexDelete(&g_we_images[i].tex);
            g_we_images[i].loaded=false;
        }
    }
    for(int i=0;i<WE_MAX_CANVAS;i++){
        if(g_we_canvas[i].used) wrender_free_canvas((uint16_t)i);
    }
}

/* ── Rounded rectangle ───────────────────────────────────────────── */

void wrender_rounded_rect(float x, float y, float w, float h, float r, uint32_t col){
    u32 c=to_c2d(col);
    if(r<=0){
        C2D_DrawRectSolid(x,y,0,w,h,c);
        return;
    }
    if(r>w/2) r=w/2;
    if(r>h/2) r=h/2;
    /* center rect */
    C2D_DrawRectSolid(x+r,y,0,w-2*r,h,c);
    /* left/right strips */
    C2D_DrawRectSolid(x,y+r,0,r,h-2*r,c);
    C2D_DrawRectSolid(x+w-r,y+r,0,r,h-2*r,c);
    /* four corners */
    C2D_DrawCircleSolid(x+r,   y+r,   0,r,c);
    C2D_DrawCircleSolid(x+w-r, y+r,   0,r,c);
    C2D_DrawCircleSolid(x+r,   y+h-r, 0,r,c);
    C2D_DrawCircleSolid(x+w-r, y+h-r, 0,r,c);
}

/* ── Text rendering ──────────────────────────────────────────────── */

void wrender_text(const char *s, float x, float y, float w,
                  float size, uint32_t col, uint8_t align,
                  uint8_t weight, uint8_t decoration){
    if(!s||!*s) return;
    (void)weight; (void)decoration; (void)w;
    float scale=size/11.0f;
    if(scale<0.4f) scale=0.4f;
    if(scale>3.0f) scale=3.0f;
    u32 c=to_c2d(col);

    C2D_Text txt;
    static C2D_TextBuf s_tbuf=NULL;
    if(!s_tbuf) s_tbuf=C2D_TextBufNew(4096);

    /* truncate at 200 chars to avoid overflow */
    char buf[201]; strncpy(buf,s,200); buf[200]='\0';
    C2D_TextBufClear(s_tbuf);
    C2D_TextParse(&txt,s_tbuf,buf);
    C2D_TextOptimize(&txt);

    float tw,th;
    C2D_TextGetDimensions(&txt,scale,scale,&tw,&th);

    float tx=x;
    if(align==1&&w>0) tx=x+(w-tw)/2;
    else if(align==2&&w>0) tx=x+w-tw;

    C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx,y+th*0.85f,0,scale,scale,c);
}

/* ── Scrollbar ───────────────────────────────────────────────────── */

void wrender_scrollbar_v(float x, float y, float h,
                          int scroll, int total, uint32_t col){
    if(total<=0) return;
    float frac=(float)h/total;
    if(frac>1) frac=1;
    float bar_h=h*frac;
    float bar_y=y+(h-bar_h)*(float)scroll/(total-1);
    /* track */
    C2D_DrawRectSolid(x,y,0,4,h,to_c2d(0x333333FF));
    /* thumb */
    C2D_DrawRectSolid(x,bar_y,0,4,bar_h,to_c2d(col));
}

void wrender_scrollbar_h(float x, float y, float w,
                          int scroll, int total, uint32_t col){
    if(total<=0) return;
    float frac=(float)w/total;
    if(frac>1) frac=1;
    float bar_w=w*frac;
    float bar_x=x+(w-bar_w)*(float)scroll/(total-1);
    C2D_DrawRectSolid(x,y,0,w,4,to_c2d(0x333333FF));
    C2D_DrawRectSolid(bar_x,y,0,bar_w,4,to_c2d(col));
}

/* ── Image loading ───────────────────────────────────────────────── */

static bool load_png_to_tex(const char *path, WEImage *img){
    unsigned char *data=NULL;
    unsigned w=0,h=0;
    unsigned err=lodepng_decode32_file(&data,&w,&h,path);
    if(err||!data) return false;
    /* round up to power of 2 */
    unsigned tw=1,th=1;
    while(tw<w) tw<<=1; while(th<h) th<<=1;
    /* create texture */
    if(!C3D_TexInit(&img->tex,tw,th,GPU_RGBA8)){
        free(data); return false;
    }
    /* copy pixels (RGBA8) — need to tile for 3DS */
    /* Simple approach: copy raw, then convert */
    unsigned char *tex_data=img->tex.data;
    memset(tex_data,0,tw*th*4);
    for(unsigned y2=0;y2<h;y2++){
        for(unsigned x2=0;x2<w;x2++){
            /* 3DS expects Morton/tile order, but for simplicity
               use linear and hope citro2d handles it */
            unsigned src=(y2*w+x2)*4;
            unsigned dst=((th-1-y2)*tw+x2)*4; /* flip Y */
            tex_data[dst+0]=data[src+3]; /* A */
            tex_data[dst+1]=data[src+2]; /* B */
            tex_data[dst+2]=data[src+1]; /* G */
            tex_data[dst+3]=data[src+0]; /* R */
        }
    }
    C3D_TexSetFilter(&img->tex,GPU_LINEAR,GPU_LINEAR);
    img->img.tex=&img->tex;
    img->img.subtex=NULL;
    img->w=(uint16_t)w;
    img->h=(uint16_t)h;
    img->loaded=true;
    free(data);
    return true;
}

uint16_t wrender_load_image(const char *path_or_dataurl){
    if(!path_or_dataurl) return 0;
    /* check cache */
    for(int i=0;i<g_we_image_n;i++){
        if(g_we_images[i].loaded&&strcmp(g_we_images[i].path,path_or_dataurl)==0)
            return (uint16_t)(i+1);
    }
    if(g_we_image_n>=WE_MAX_IMAGES) return 0;
    WEImage *img=&g_we_images[g_we_image_n];
    strncpy(img->path,path_or_dataurl,127);
    img->path[127]='\0';
    /* resolve path */
    char resolved[256];
    if(strncmp(path_or_dataurl,"sdmc:/",6)==0||strncmp(path_or_dataurl,"/",1)==0){
        strncpy(resolved,path_or_dataurl,255);
    } else {
        snprintf(resolved,sizeof(resolved),"sdmc:/3ds/pocketcompiler/www/%s",path_or_dataurl);
    }
    if(!load_png_to_tex(resolved,img)) return 0;
    return (uint16_t)(++g_we_image_n);
}

void wrender_free_image(uint16_t id){
    if(id==0||id>WE_MAX_IMAGES) return;
    WEImage *img=&g_we_images[id-1];
    if(img->loaded){ C3D_TexDelete(&img->tex); img->loaded=false; }
}

/* ── Canvas management ───────────────────────────────────────────── */

uint16_t wrender_new_canvas(uint16_t w, uint16_t h){
    for(int i=0;i<WE_MAX_CANVAS;i++){
        if(!g_we_canvas[i].used){
            /* round up to power of 2 */
            uint16_t tw=1,th=1;
            while(tw<w) tw<<=1; while(th<h) th<<=1;
            if(!C3D_TexInitVRAM(&g_we_canvas[i].tex,tw,th,GPU_RGBA8)) return 0;
            g_we_canvas[i].fb=C3D_RenderTargetCreateFromTex(&g_we_canvas[i].tex,GPU_TEXFACE_2D,0,-1);
            if(!g_we_canvas[i].fb){
                C3D_TexDelete(&g_we_canvas[i].tex); return 0;
            }
            g_we_canvas[i].w=w;
            g_we_canvas[i].h=h;
            g_we_canvas[i].used=true;
            return (uint16_t)(i+1);
        }
    }
    return 0;
}

void wrender_free_canvas(uint16_t id){
    if(id==0||id>WE_MAX_CANVAS) return;
    WECanvas *c=&g_we_canvas[id-1];
    if(!c->used) return;
    if(c->fb) C3D_RenderTargetDelete(c->fb);
    C3D_TexDelete(&c->tex);
    c->used=false;
}

WECanvas *wrender_canvas(uint16_t id){
    if(id==0||id>WE_MAX_CANVAS) return NULL;
    return g_we_canvas[id-1].used?&g_we_canvas[id-1]:NULL;
}

/* ── Node rendering ──────────────────────────────────────────────── */

static void render_border(DOMNode *n){
    if(n->style.border_width<=0) return;
    float x=n->lay_x, y=n->lay_y;
    float w=n->lay_w, h=n->lay_h;
    float bw=n->style.border_width;
    u32 bc=to_c2d(n->style.border_color?n->style.border_color:0x444444FF);
    /* top/bottom/left/right as rects */
    C2D_DrawRectSolid(x,y,0,w,bw,bc);
    C2D_DrawRectSolid(x,y+h-bw,0,w,bw,bc);
    C2D_DrawRectSolid(x,y+bw,0,bw,h-2*bw,bc);
    C2D_DrawRectSolid(x+w-bw,y+bw,0,bw,h-2*bw,bc);
}

void wrender_node(int16_t node_id, int16_t clip_x, int16_t clip_y,
                  int16_t clip_w, int16_t clip_h, int16_t ox, int16_t oy){
    if(node_id<0) return;
    DOMNode *n=dom_node(node_id);
    if(!n||n->style.display==4||n->style.visibility==1) return;

    float x=n->lay_x-ox;
    float y=n->lay_y-oy;
    float w=n->lay_w;
    float h=n->lay_h;

    /* coarse clip — skip if entirely outside viewport */
    if(x+w<clip_x||y+h<clip_y||x>clip_x+clip_w||y>clip_y+clip_h) return;

    uint8_t alpha=n->style.opacity;
    (void)alpha; /* C2D doesn't have per-draw alpha easily; skip for now */

    /* text node */
    if(n->type==NT_TEXT){
        const char *t=dom_text(n->text_off);
        if(!t||!*t) return;
        /* get parent style for color/font */
        CSSStyle *pst=(n->parent>=0)?&g_dom_nodes[n->parent].style:&n->style;
        wrender_text(t,x,y,w,(float)(pst->font_size>0?pst->font_size:11),
                     pst->color?pst->color:CSS_DEFAULT_COLOR,
                     pst->text_align,pst->font_weight,pst->text_decoration);
        return;
    }

    if(n->type!=NT_ELEMENT) return;

    /* background */
    if(n->style.background&0xFF){  /* has alpha */
        wrender_rounded_rect(x,y,w,h,(float)n->style.border_radius,n->style.background);
    }
    /* border */
    render_border(n);

    /* hover highlight */
    if(n->hover&&n->style.cursor==1){
        /* subtle highlight */
        C2D_DrawRectSolid(x,y,0,w,h,C2D_Color32(255,255,255,20));
    }

    /* image element */
    if(n->image_id>0){
        WEImage *img=&g_we_images[n->image_id-1];
        if(img->loaded){
            C2D_DrawImageAt(img->img,x,y,0,NULL,w/img->w,h/img->h);
        }
    }

    /* canvas element */
    if(n->canvas_id>0){
        WECanvas *cv=wrender_canvas(n->canvas_id);
        if(cv&&cv->used){
            /* draw canvas texture */
            C2D_Image ci; ci.tex=&cv->tex; ci.subtex=NULL;
            C2D_DrawImageAt(ci,x,y,0,NULL,w/cv->w,h/cv->h);
        }
    }

    /* determine scroll offset for children */
    int16_t scroll_x=n->scroll_x;
    int16_t scroll_y=n->scroll_y;

    /* render children */
    for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
        wrender_node(ch,clip_x,clip_y,clip_w,clip_h,
                     ox+scroll_x,oy+scroll_y);
    }

    /* tag-specific rendering */
    const char *tag=dom_tag(node_id);
    if(strcmp(tag,"input")==0||strcmp(tag,"textarea")==0){
        /* draw input box */
        float bw=(n->style.border_width>0)?n->style.border_width:1;
        u32 bc=to_c2d(n->style.border_color?n->style.border_color:0x555555FF);
        u32 bg=to_c2d(n->style.background?n->style.background:0x222222FF);
        C2D_DrawRectSolid(x,y,0,w,h,bg);
        C2D_DrawRectSolid(x,y,0,w,bw,bc);
        C2D_DrawRectSolid(x,y+h-bw,0,w,bw,bc);
        C2D_DrawRectSolid(x,y+bw,0,bw,h-2*bw,bc);
        C2D_DrawRectSolid(x+w-bw,y+bw,0,bw,h-2*bw,bc);
        /* value text */
        const char *val=dom_get_attr(node_id,"value");
        if(!val) val=dom_get_attr(node_id,"placeholder");
        if(val){
            wrender_text(val,x+3,y+2,w-6,
                         (float)(n->style.font_size>0?n->style.font_size:11),
                         n->style.color?n->style.color:0xBBBBBBFF,
                         0,0,0);
        }
        /* cursor blink if focused */
        if(n->focused){
            C2D_DrawRectSolid(x+3,y+2,0,1,h-4,to_c2d(0xFFFFFFFF));
        }
    }

    /* scrollbars if overflow:scroll or auto */
    if(n->style.overflow_y==2||n->style.overflow_y==3){
        int16_t msx,msy;
        layout_scroll_extents(node_id,&msx,&msy);
        if(msy>0) wrender_scrollbar_v(x+w-5,y,h,scroll_y,msy,0xAAAAAAAA);
    }
    if(n->style.overflow_x==2||n->style.overflow_x==3){
        int16_t msx,msy;
        layout_scroll_extents(node_id,&msx,&msy);
        if(msx>0) wrender_scrollbar_h(x,y+h-5,w,scroll_x,msx,0xAAAAAAAA);
    }
}

/* ── Document render ─────────────────────────────────────────────── */

void wrender_document(uint8_t doc_id, int16_t scroll_x, int16_t scroll_y){
    DOMDocument *d=dom_doc(doc_id);
    if(!d) return;
    int16_t body=d->body_node>=0?d->body_node:d->root_node;
    if(body<0) return;

    /* draw body background */
    DOMNode *bn=dom_node(body);
    if(bn&&bn->style.background&0xFF)
        wrender_rounded_rect(0,0,WE_VIEWPORT_W,WE_VIEWPORT_H,0,bn->style.background);

    /* render all children of body */
    for(int16_t ch=g_dom_nodes[body].first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
        wrender_node(ch,0,0,WE_VIEWPORT_W,WE_VIEWPORT_H,scroll_x,scroll_y);
    }
}

/* ── Cursor ──────────────────────────────────────────────────────── */

void wrender_cursor(float cx, float cy, bool locked){
    /* arrow cursor */
    u32 col=locked?to_c2d(0xFF4444FF):to_c2d(0xFFFFFFFF);
    u32 outline=to_c2d(0x000000AA);
    /* pointer: small triangle approximated as rect */
    C2D_DrawRectSolid(cx,   cy,   0, 2,10,outline);
    C2D_DrawRectSolid(cx+1, cy,   0, 2,10,col);
    C2D_DrawRectSolid(cx,   cy,   0,10, 2,outline);
    C2D_DrawRectSolid(cx,   cy+1, 0,10, 2,col);
    C2D_DrawRectSolid(cx+2, cy+2, 0, 6, 6,outline);
    C2D_DrawRectSolid(cx+3, cy+3, 0, 4, 4,col);
    if(locked){
        /* ring around cursor when locked */
        C2D_DrawCircleSolid(cx,cy,0,8,to_c2d(0xFF444466));
    }
}
