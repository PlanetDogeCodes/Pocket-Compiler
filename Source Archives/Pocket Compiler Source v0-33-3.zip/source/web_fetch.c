/*
 * web_fetch.c  —  Fetch API (SD card backed)
 */
#include "web_fetch.h"
#include "duktape.h"
#include "web_js.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

WFRequest g_wf_requests[WF_MAX_REQUESTS];

/* ── URL resolution ──────────────────────────────────────────────── */

bool wf_resolve_url(const char *url, const char *base, char *out, int sz){
    if(!url||!out) return false;
    if(strncmp(url,"sdmc:/",6)==0||strncmp(url,"file://",7)==0){
        const char *p=(url[4]=='/')?url:(url+7);
        strncpy(out,p,sz-1); out[sz-1]='\0'; return true;
    }
    if(strncmp(url,"3ds://",6)==0){
        snprintf(out,sz,"%s/%s",WF_SD_ROOT,url+6); return true;
    }
    if(strncmp(url,"http://",7)==0||strncmp(url,"https://",8)==0){
        /* map to SD root: http://example.com/path → WF_SD_ROOT/example.com/path */
        const char *start=strchr(url+8,'/');
        if(!start) start=url+strlen(url);
        char host[128]; int hl=(int)(start-(url+(url[4]=='s'?8:7)));
        if(hl>=128) hl=127;
        memcpy(host,url+(url[4]=='s'?8:7),hl); host[hl]='\0';
        snprintf(out,sz,"%s/%s%s",WF_SD_ROOT,host,*start?start:"/");
        return true;
    }
    /* relative URL */
    if(base&&*base){
        /* find last '/' in base */
        const char *last=strrchr(base,'/');
        if(last){
            int blen=(int)(last-base+1);
            if(blen+strlen(url)>=sz) blen=sz-(int)strlen(url)-1;
            memcpy(out,base,blen); out[blen]='\0';
            strncat(out,url,sz-blen-1);
        } else {
            snprintf(out,sz,"%s/%s",WF_SD_ROOT,url);
        }
    } else {
        snprintf(out,sz,"%s/%s",WF_SD_ROOT,url);
    }
    return true;
}

bool wf_can_serve(const char *url){
    char path[WF_MAX_URL];
    if(!wf_resolve_url(url,NULL,path,sizeof(path))) return false;
    FILE *f=fopen(path,"r");
    if(!f) return false;
    fclose(f); return true;
}

/* ── Content type sniffing ────────────────────────────────────────── */

const char *wf_sniff_type(const char *path){
    if(!path) return "application/octet-stream";
    const char *ext=strrchr(path,'.');
    if(!ext) return "application/octet-stream";
    if(strcmp(ext,".html")==0||strcmp(ext,".htm")==0) return "text/html";
    if(strcmp(ext,".css")==0)  return "text/css";
    if(strcmp(ext,".js")==0)   return "application/javascript";
    if(strcmp(ext,".json")==0) return "application/json";
    if(strcmp(ext,".txt")==0)  return "text/plain";
    if(strcmp(ext,".png")==0)  return "image/png";
    if(strcmp(ext,".jpg")==0||strcmp(ext,".jpeg")==0) return "image/jpeg";
    if(strcmp(ext,".gif")==0)  return "image/gif";
    if(strcmp(ext,".wav")==0)  return "audio/wav";
    if(strcmp(ext,".mp3")==0)  return "audio/mpeg";
    if(strcmp(ext,".xml")==0)  return "text/xml";
    if(strcmp(ext,".svg")==0)  return "image/svg+xml";
    return "application/octet-stream";
}

/* ── Synchronous fetch ───────────────────────────────────────────── */

bool wf_fetch_sync(const char *url, WFResponse *out){
    if(!url||!out) return false;
    memset(out,0,sizeof(*out));
    char path[WF_MAX_URL];
    if(!wf_resolve_url(url,NULL,path,sizeof(path))){
        out->status=400; return false;
    }
    FILE *f=fopen(path,"rb");
    if(!f){
        out->status=404; out->ok=false; return false;
    }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    if(sz<=0){ fclose(f); out->status=204; out->ok=true; return true; }
    if(sz>WF_MAX_BODY) sz=WF_MAX_BODY;
    out->body_len=(int)fread(out->body,1,sz,f);
    fclose(f);
    out->body[out->body_len]='\0';
    out->status=200;
    out->ok=true;
    strncpy(out->content_type,wf_sniff_type(path),63);
    return true;
}

/* ── Async fetch (all synchronous in practice — 3DS has no network) */

int wf_fetch_async(uint8_t doc_id, const char *url, int resolve_ref, int reject_ref){
    for(int i=0;i<WF_MAX_REQUESTS;i++){
        if(!g_wf_requests[i].used){
            strncpy(g_wf_requests[i].url,url,WF_MAX_URL-1);
            g_wf_requests[i].doc_id=doc_id;
            g_wf_requests[i].js_resolve_ref=resolve_ref;
            g_wf_requests[i].js_reject_ref=reject_ref;
            g_wf_requests[i].used=true;
            g_wf_requests[i].done=false;
            return i;
        }
    }
    return -1;
}

void wf_tick(duk_context *ctx){
    for(int i=0;i<WF_MAX_REQUESTS;i++){
        if(!g_wf_requests[i].used||g_wf_requests[i].done) continue;
        /* "Fetch" synchronously now */
        bool ok=wf_fetch_sync(g_wf_requests[i].url,&g_wf_requests[i].resp);
        g_wf_requests[i].done=true;
        /* resolve or reject the promise */
        duk_push_heap_stash(ctx);
        if(ok&&g_wf_requests[i].resp.ok){
            char key[16]; snprintf(key,16,"fetch_r%d",g_wf_requests[i].js_resolve_ref);
            duk_get_prop_string(ctx,-1,key);
            if(duk_is_function(ctx,-1)){
                /* push response object */
                duk_push_object(ctx);
                duk_push_boolean(ctx,1);     duk_put_prop_string(ctx,-2,"ok");
                duk_push_int(ctx,200);       duk_put_prop_string(ctx,-2,"status");
                /* text() method */
                char *body_copy=malloc(g_wf_requests[i].resp.body_len+1);
                if(body_copy){
                    memcpy(body_copy,g_wf_requests[i].resp.body,g_wf_requests[i].resp.body_len);
                    body_copy[g_wf_requests[i].resp.body_len]='\0';
                    duk_push_string(ctx,body_copy);
                    free(body_copy);
                } else { duk_push_string(ctx,""); }
                duk_put_prop_string(ctx,-2,"__body");
                /* methods */
                duk_eval_string_noresult(ctx,
                    "__tmpResp={"
                    "  text:function(){return Promise.resolve(this.__body);},"
                    "  json:function(){return Promise.resolve(JSON.parse(this.__body));},"
                    "  ok:true,status:200"
                    "};");
                duk_get_global_string(ctx,"__tmpResp");
                if(duk_pcall(ctx,1)!=0) wjs_log_push(duk_safe_to_string(ctx,-1));
                duk_pop(ctx);
            } else { duk_pop(ctx); }
        } else {
            char key[16]; snprintf(key,16,"fetch_j%d",g_wf_requests[i].js_reject_ref);
            duk_get_prop_string(ctx,-1,key);
            if(duk_is_function(ctx,-1)){
                duk_push_string(ctx,"Network Error");
                if(duk_pcall(ctx,1)!=0) wjs_log_push(duk_safe_to_string(ctx,-1));
                else duk_pop(ctx);
            } else { duk_pop(ctx); }
        }
        duk_pop(ctx); /* stash */
        g_wf_requests[i].used=false;
    }
}

/* ── Duktape fetch binding ───────────────────────────────────────── */

static duk_ret_t js_fetch(duk_context *ctx){
    const char *url=duk_safe_to_string(ctx,0);
    /* Return a Promise-like object */
    /* Simplified: synchronous resolution via .then() trampoline */
    WFResponse resp; memset(&resp,0,sizeof(resp));
    bool ok=wf_fetch_sync(url,&resp);
    /* Build a thenable */
    duk_push_object(ctx); /* response object */
    duk_push_boolean(ctx,ok&&resp.ok); duk_put_prop_string(ctx,-2,"ok");
    duk_push_int(ctx,resp.status);     duk_put_prop_string(ctx,-2,"status");
    /* Store body */
    duk_push_lstring(ctx,(const char*)resp.body,resp.body_len);
    duk_put_prop_string(ctx,-2,"__body");
    duk_eval_string_noresult(ctx,
        "var __fr=__we_last_fetch_resp;"
        "if(__fr){"
        "  __fr.text=function(){return {then:function(fn){fn(this.__body);return this;}}.bind(__fr);};"
        "  __fr.json=function(){var b=this.__body;return {then:function(fn){try{fn(JSON.parse(b));}catch(e){fn({});}return this;}}};"
        "}");
    /* Return Promise-like */
    duk_push_object(ctx);
    duk_dup(ctx,-2); /* response */
    duk_put_prop_string(ctx,-2,"__resp");
    /* .then() implementation */
    duk_eval_string(ctx,
        "(function(resp){"
        "  return {"
        "    __resp:resp,"
        "    then:function(fn){"
        "      if(fn)fn(this.__resp);"
        "      return this;"
        "    },"
        "    catch:function(fn){ return this; }"
        "  };"
        "})");
    duk_dup(ctx,-3); /* response */
    if(duk_pcall(ctx,1)!=0){
        wjs_log_push(duk_safe_to_string(ctx,-1));
        duk_pop(ctx);
        duk_push_object(ctx); /* empty thenable */
    }
    duk_remove(ctx,-2); /* remove response obj */
    duk_remove(ctx,-2); /* remove old response */
    return 1;
}

static duk_ret_t js_xhr_open(duk_context *ctx){ return 0; }
static duk_ret_t js_xhr_send(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__url"); const char *url=duk_safe_to_string(ctx,-1); duk_pop(ctx);
    WFResponse resp; wf_fetch_sync(url,&resp);
    duk_push_int(ctx,resp.status); duk_put_prop_string(ctx,-2,"status");
    duk_push_lstring(ctx,(const char*)resp.body,resp.body_len);
    duk_put_prop_string(ctx,-2,"responseText");
    duk_put_prop_string(ctx,-2,"response");
    /* fire onload */
    duk_get_prop_string(ctx,-1,"onload");
    if(duk_is_function(ctx,-1)) duk_pcall(ctx,0);
    else duk_pop(ctx);
    duk_pop(ctx);
    return 0;
}
static duk_ret_t js_xhr_setRequestHeader(duk_context *ctx){ return 0; }

void wf_install_fetch(duk_context *ctx, uint8_t doc_id){
    (void)doc_id;
    duk_push_global_object(ctx);
    duk_push_c_function(ctx,js_fetch,DUK_VARARGS);
    duk_put_prop_string(ctx,-2,"fetch");
    duk_pop(ctx);
}

void wf_install_xhr(duk_context *ctx, uint8_t doc_id){
    (void)doc_id;
    /* XMLHttpRequest constructor */
    duk_eval_string_noresult(ctx,
        "function XMLHttpRequest(){"
        "  this.status=0; this.responseText=''; this.response=null;"
        "  this.onload=null; this.onerror=null; this.onreadystatechange=null;"
        "  this.readyState=0;"
        "}");
    duk_push_global_object(ctx);
    duk_get_prop_string(ctx,-1,"XMLHttpRequest");
    if(duk_is_function(ctx,-1)){
        duk_get_prop_string(ctx,-1,"prototype");
        duk_push_c_function(ctx,js_xhr_open,3);            duk_put_prop_string(ctx,-2,"open");
        duk_push_c_function(ctx,js_xhr_send,1);            duk_put_prop_string(ctx,-2,"send");
        duk_push_c_function(ctx,js_xhr_setRequestHeader,2);duk_put_prop_string(ctx,-2,"setRequestHeader");
        duk_pop(ctx);
    }
    duk_pop_2(ctx);
}
