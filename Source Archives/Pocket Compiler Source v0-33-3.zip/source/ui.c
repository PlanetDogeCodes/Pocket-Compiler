/*
 * ui.c — Citro2D UI for Pocket Compiler v0.33
 *
 * Changes vs previous revision:
 *  - Code area: horizontal scroll via app->view_left (no more lb[38] truncation).
 *  - Code area: cursor-dot hover highlight (code_cursor_line) separate from
 *    active-line highlight (cursor_line).
 *  - Top screen: output only updates when START compiles; stored in
 *    s_compiled_html (set by ui_set_compiled).
 *  - Run mode: full-screen interactive output panel, scrollable, with
 *    top-screen cursor, cursor-lock indicator, and click-flash highlights.
 *  - OutLine: added 'interactive' flag (set for <a> and <button> content).
 *  - Bottom screen shows locked message during run_mode.
 */
#include "ui.h"
#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <string.h>
#include "web_engine.h"

/* ═══════════════════════════════════════════════════════════
   COLOUR PALETTE
   ═══════════════════════════════════════════════════════════ */
#define C_BG      C2D_Color32(0x00,0x00,0x00,0xFF) /* pure black           */
#define C_PANEL   C2D_Color32(0x0C,0x0C,0x0C,0xFF) /* panel bg             */
#define C_PANEL2  C2D_Color32(0x18,0x18,0x18,0xFF) /* elevated panel       */
#define C_BORDER  C2D_Color32(0x2E,0x2E,0x2E,0xFF) /* borders              */
#define C_SEL     C2D_Color32(0x18,0x24,0x34,0xFF) /* selected row tint    */
#define C_CURLINE C2D_Color32(0x12,0x1C,0x28,0xFF) /* active-line tint     */
#define C_HOVER   C2D_Color32(0x18,0x18,0x18,0xFF) /* hover-row tint       */
#define C_ACCENT2 C2D_Color32(0x10,0x20,0x38,0xFF) /* dim blue bg          */
#define C_GREEN2  C2D_Color32(0x0A,0x20,0x10,0xFF) /* dim green bg         */
#define C_GREEN   C2D_Color32(0x3F,0xB9,0x50,0xFF) /* active / RUN colour  */
#define C_ORANGE  C2D_Color32(0xFF,0xA6,0x57,0xFF) /* cursor-lock colour   */

/* All non-syntax text: solid white */
#define C_WHITE   C2D_Color32(0xFF,0xFF,0xFF,0xFF)
#define C_TEXT    C_WHITE
#define C_DIM     C_WHITE
#define C_ACCENT  C_WHITE
#define C_LNUM    C_WHITE

/* Syntax colours — unchanged */
#define C_TAG     C2D_Color32(0x79,0xC0,0xFF,0xFF)
#define C_VAL     C2D_Color32(0xA3,0xD9,0x91,0xFF)
#define C_CMT     C2D_Color32(0x57,0x5F,0x68,0xFF)
#define C_DOCTYPE C2D_Color32(0xFF,0xA6,0x57,0xFF)

/* Cursor dots */
#define C_DOT_BOT C2D_Color32(0xFF,0xFF,0xFF,0xBB) /* bottom-screen dot    */
#define C_DOT_TOP C2D_Color32(0xFF,0xFF,0xFF,0xBB) /* top-screen dot       */
#define C_DOT_LCK C2D_Color32(0xFF,0x80,0x00,0xCC) /* locked cursor (orange)*/

/* ═══════════════════════════════════════════════════════════
   LAYOUT
   ═══════════════════════════════════════════════════════════ */
#define TOP_W  400.0f
#define TOP_H  240.0f
#define BOT_W  320.0f
#define BOT_H  240.0f
#define MAR    6.0f
#define PAD    5.0f
#define RAD    7.0f
#define RAD_S  4.0f
#define FS_ED  0.42f
#define FS_UI  0.50f
#define FS_H   0.58f
#define LH_ED  15.0f
#define LH_FE  21.0f
#define ED_X   (MAR)
#define ED_Y   (28.0f)
#define ED_W   (BOT_W - 2*MAR)
#define ED_H   (BOT_H - ED_Y - 32.0f)
#define LNUM_W 22.0f
#define CODE_X (ED_X + PAD + LNUM_W)
#define FE_X   (MAR)
#define FE_Y   (28.0f)
#define FE_W   (BOT_W - 2*MAR)
#define FE_H   (BOT_H - FE_Y - 32.0f)

/* ═══════════════════════════════════════════════════════════
   COMPILED HTML SNAPSHOT
   Filled by ui_set_compiled(); read by draw_top().
   Static so it doesn't hit the stack.
   ═══════════════════════════════════════════════════════════ */
static char s_compiled_html[EDITOR_MAX];
static bool s_has_compiled  = false;
static bool s_render_dirty  = false;  /* set true on every compile */
static int s_out_n;  /* forward declaration – defined at line ~233 */

int ui_get_out_count(void){ return s_out_n; }

void ui_set_compiled(const char *html){
    if(html){
        strncpy(s_compiled_html,html,EDITOR_MAX-1);
        s_compiled_html[EDITOR_MAX-1]='\0';
    } else {
        s_compiled_html[0]='\0';
    }
    s_has_compiled  = (html!=NULL);
    s_render_dirty  = true;   /* trigger one re-parse on next draw */
}

/* ═══════════════════════════════════════════════════════════
   STATIC RENDER STATE
   ═══════════════════════════════════════════════════════════ */
static C3D_RenderTarget *s_top;
static C3D_RenderTarget *s_bot;
static C2D_TextBuf       s_tb;

/* ═══════════════════════════════════════════════════════════
   DRAWING PRIMITIVES
   ═══════════════════════════════════════════════════════════ */

static void rr(float x,float y,float w,float h,float r,u32 c){
    if(r>w*.5f)r=w*.5f;
    if(r>h*.5f)r=h*.5f;
    if(r<1.f){C2D_DrawRectSolid(x,y,.5f,w,h,c);return;}
    C2D_DrawRectSolid(x+r,y,.5f,w-2*r,h,c);
    C2D_DrawRectSolid(x,y+r,.5f,r,h-2*r,c);
    C2D_DrawRectSolid(x+w-r,y+r,.5f,r,h-2*r,c);
    C2D_DrawCircleSolid(x+r,y+r,.5f,r,c);
    C2D_DrawCircleSolid(x+w-r,y+r,.5f,r,c);
    C2D_DrawCircleSolid(x+r,y+h-r,.5f,r,c);
    C2D_DrawCircleSolid(x+w-r,y+h-r,.5f,r,c);
}

static void rr_outline(float x,float y,float w,float h,
                        float r,u32 brd,u32 fill){
    rr(x,y,w,h,r,brd);
    float b=1.5f;
    rr(x+b,y+b,w-2*b,h-2*b,r>b?r-b:0.f,fill);
}

static void T(const char *s,float x,float y,float sc,u32 col){
    if(!s||!*s)return;
    C2D_Text t;
    C2D_TextParse(&t,s_tb,s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t,C2D_WithColor,x,y,.5f,sc,sc,col);
}

static float TW(const char *s,float sc){
    if(!s||!*s)return 0.f;
    C2D_Text t;
    C2D_TextParse(&t,s_tb,s);
    float w=0,h=0;
    C2D_TextGetDimensions(&t,sc,sc,&w,&h);
    return w;
}

static void TC(const char *s,float cx,float y,float sc,u32 col){
    T(s,cx-TW(s,sc)*.5f,y,sc,col);
}

/* ═══════════════════════════════════════════════════════════
   HTML SYNTAX HIGHLIGHTER  (editor display only)
   ═══════════════════════════════════════════════════════════ */
typedef struct { int start; int len; u32 color; } Span;
#define MAX_SPANS 40

static int tokenize(const char *line, Span *out, int max){
    int ns=0, len=(int)strlen(line);
    if(!len)return 0;
    if(strncmp(line,"<!--",4)==0){out[0]=(Span){0,len,C_CMT};return 1;}
    if(strncmp(line,"<!D",3)==0||strncmp(line,"<!d",3)==0){
        out[0]=(Span){0,len,C_DOCTYPE};return 1;}

    typedef enum{S_NORM,S_TAG,S_VAL}St;
    St st=S_NORM; u32 curc=C_TEXT; int cs=0;

#define FLUSH(end) if((end)>cs&&ns<max){out[ns++]=(Span){cs,(end)-cs,curc};cs=(end);}

    for(int i=0;i<=len;i++){
        char c=(i<len)?line[i]:'\0';
        if(st==S_NORM){
            if(c=='<'){FLUSH(i);st=S_TAG;curc=C_TAG;cs=i;}
        }else if(st==S_TAG){
            if(c=='>'){
                FLUSH(i+1);
                st=S_NORM;curc=C_TEXT;cs=i+1;
            }else if(c=='"'){
                FLUSH(i);st=S_VAL;curc=C_VAL;cs=i;
            }
        }else if(st==S_VAL){
            if(c=='"'){
                FLUSH(i+1);
                st=S_TAG;curc=C_TAG;cs=i+1;
            }
        }
        if(c=='\0')FLUSH(len);
    }
#undef FLUSH
    return ns;
}

static float draw_code_line(const char *line,float x,float y,float sc){
    Span spans[MAX_SPANS];
    char buf[LINE_MAX];
    int ns=tokenize(line,spans,MAX_SPANS);
    float cx=x;
    for(int i=0;i<ns;i++){
        int sl=spans[i].len;
        if(sl<=0)continue;
        if(sl>=LINE_MAX)sl=LINE_MAX-1;
        memcpy(buf,line+spans[i].start,sl);buf[sl]='\0';
        T(buf,cx,y,sc,spans[i].color);
        cx+=TW(buf,sc);
    }
    return cx;
}

/* ═══════════════════════════════════════════════════════════
   HTML OUTPUT RENDERER
   Parses compiled HTML and extracts visible text content,
   respecting headings, paragraphs, lists, and block elements.
   Marks lines from <a> and <button> content as interactive.
   ═══════════════════════════════════════════════════════════ */
#define OUT_MAX   22
#define OUT_LINE  64

typedef struct {
    char text[OUT_LINE];
    int  level;        /* 0=normal, 1=h1, 2=h2, 3=h3-h6, 4=li */
    bool interactive;  /* true when derived from <a> or <button> */
} OutLine;

static OutLine s_out[OUT_MAX];
static int     s_out_n;

/* Extract lowercase tag name (without attributes) into dst. */
static void get_tag_name(const char *raw, char *dst, int sz){
    int i=0;
    const char *p=raw;
    if(*p=='/'&&i<sz-1){dst[i++]='/';p++;}
    while(*p&&*p!=' '&&*p!='/'&&*p!='>'&&i<sz-1){
        char c=(*p>='A'&&*p<='Z')?*p+32:*p;
        dst[i++]=c; p++;
    }
    dst[i]='\0';
}

static void html_render(const char *html){
    s_out_n=0;
    if(!html||!*html)return;

    char  lbuf[OUT_LINE]; int lpos=0;
    int   level=0;
    bool  skip=false, in_body=false, in_tag=false, in_cmt=false;
    bool  in_interactive=false;
    char  tagbuf[128]; int tpos=0;
    bool  last_sp=false;

    /* If there is no <body> tag at all, render everything */
    if(!strstr(html,"<body")&&!strstr(html,"<BODY"))
        in_body=true;

    memset(lbuf,0,sizeof(lbuf));

#define COMMIT() do{ \
    lbuf[lpos]='\0'; \
    while(lpos>0&&lbuf[lpos-1]==' ')lbuf[--lpos]='\0'; \
    if(lpos>0&&s_out_n<OUT_MAX){ \
        strncpy(s_out[s_out_n].text,lbuf,OUT_LINE-1); \
        s_out[s_out_n].level=level; \
        s_out[s_out_n].interactive=in_interactive; \
        s_out_n++; \
    } \
    lpos=0;last_sp=false; \
    memset(lbuf,0,sizeof(lbuf)); \
}while(0)

#define APPEND(ch) do{ \
    char _c=(ch); \
    if(_c==' '||_c=='\t'){ \
        if(!last_sp&&lpos>0&&lpos<OUT_LINE-1){lbuf[lpos++]=' ';last_sp=true;} \
    }else if(lpos<OUT_LINE-1){lbuf[lpos++]=_c;last_sp=false;} \
}while(0)

    const char *p=html;
    while(*p){
        char c=*p;

        /* HTML comment */
        if(!in_tag&&!in_cmt&&c=='<'&&strncmp(p,"<!--",4)==0){
            in_cmt=true; p+=4; continue;
        }
        if(in_cmt){
            if(strncmp(p,"-->",3)==0){in_cmt=false;p+=3;}else p++;
            continue;
        }

        if(c=='<'){
            in_tag=true; tpos=0; memset(tagbuf,0,sizeof(tagbuf));
        } else if(in_tag){
            if(c=='>'){
                in_tag=false; tagbuf[tpos]='\0';
                char tn[32]; get_tag_name(tagbuf,tn,sizeof(tn));

                /* Opening skip-content tags */
                if(!strcmp(tn,"head")||!strcmp(tn,"script")||
                   !strcmp(tn,"style")||!strcmp(tn,"title")||
                   !strcmp(tn,"meta") ||!strcmp(tn,"link"))     skip=true;
                /* Closing skip-content tags */
                else if(!strcmp(tn,"/head")||!strcmp(tn,"/script")||
                        !strcmp(tn,"/style")||!strcmp(tn,"/title"))  skip=false;
                /* Body */
                else if(!strncmp(tn,"body",4)){in_body=true;skip=false;}
                /* Content tags */
                else if(in_body&&!skip){
                    if     (!strcmp(tn,"h1"))                         {COMMIT();level=1;}
                    else if(!strcmp(tn,"h2"))                         {COMMIT();level=2;}
                    else if(!strcmp(tn,"h3")||!strcmp(tn,"h4")||
                            !strcmp(tn,"h5")||!strcmp(tn,"h6"))       {COMMIT();level=3;}
                    else if(tn[0]=='/'&&tn[1]=='h'&&
                            tn[2]>='1'&&tn[2]<='6')                  {COMMIT();level=0;}
                    else if(!strcmp(tn,"p") ||!strcmp(tn,"/p")||
                            !strcmp(tn,"div")||!strcmp(tn,"/div")||
                            !strcmp(tn,"section")||!strcmp(tn,"/section")||
                            !strcmp(tn,"article")||!strcmp(tn,"/article")||
                            !strcmp(tn,"main")||!strcmp(tn,"/main")||
                            !strcmp(tn,"header")||!strcmp(tn,"/header")||
                            !strcmp(tn,"footer")||!strcmp(tn,"/footer"))  {COMMIT();}
                    else if(!strcmp(tn,"br")||!strcmp(tn,"br/"))      {COMMIT();}
                    else if(!strcmp(tn,"li")){
                        COMMIT(); level=4;
                        if(lpos+2<OUT_LINE-1){lbuf[lpos++]='-';lbuf[lpos++]=' ';last_sp=true;}
                    }
                    else if(!strcmp(tn,"/li"))  {COMMIT();level=0;}
                    else if(!strcmp(tn,"ul")||!strcmp(tn,"/ul")||
                            !strcmp(tn,"ol")||!strcmp(tn,"/ol"))  {COMMIT();}
                    else if(!strcmp(tn,"hr")){
                        COMMIT();
                        strncpy(s_out[s_out_n].text,"--------------------",OUT_LINE-1);
                        s_out[s_out_n].level=0;
                        s_out[s_out_n].interactive=false;
                        if(s_out_n<OUT_MAX)s_out_n++;
                    }
                    /* Interactive elements: <a> and <button> */
                    else if(!strcmp(tn,"a")||!strcmp(tn,"button")){
                        COMMIT();
                        in_interactive=true;
                    }
                    else if(!strcmp(tn,"/a")||!strcmp(tn,"/button")){
                        COMMIT();
                        in_interactive=false;
                    }
                    /* img: show alt text or "[image]" */
                    else if(!strcmp(tn,"img")){
                        COMMIT();
                        const char *alt=strstr(tagbuf,"alt=\"");
                        if(alt){
                            alt+=5;
                            const char *ae=strchr(alt,'"');
                            int alen=ae?(int)(ae-alt):0;
                            if(alen>0&&alen<OUT_LINE-12){
                                char ibuf[OUT_LINE]="[";
                                strncat(ibuf,alt,alen);
                                strcat(ibuf,"]");
                                strncpy(s_out[s_out_n].text,ibuf,OUT_LINE-1);
                            }else{
                                strncpy(s_out[s_out_n].text,"[image]",OUT_LINE-1);
                            }
                        }else{
                            strncpy(s_out[s_out_n].text,"[image]",OUT_LINE-1);
                        }
                        s_out[s_out_n].level=0;
                        s_out[s_out_n].interactive=false;
                        if(s_out_n<OUT_MAX)s_out_n++;
                    }
                }
            } else {
                if(tpos<126)tagbuf[tpos++]=c;
            }
        } else if(in_body&&!skip){
            /* Text content */
            if(c=='\n'||c=='\r'||c=='\t'){
                APPEND(' ');
            } else if(c=='&'){
                /* Basic HTML entity decoding */
                const char *e=p+1;
                char ent[12]={0}; int ei=0;
                while(*e&&*e!=';'&&*e!='<'&&*e!=' '&&ei<10)ent[ei++]=*e++;
                if(*e==';'){
                    char ec=0;
                    if(!strcmp(ent,"amp"))  ec='&';
                    else if(!strcmp(ent,"lt"))   ec='<';
                    else if(!strcmp(ent,"gt"))   ec='>';
                    else if(!strcmp(ent,"nbsp")) ec=' ';
                    else if(!strcmp(ent,"quot")) ec='"';
                    else if(!strcmp(ent,"apos")||!strcmp(ent,"#39")) ec='\'';
                    if(ec){APPEND(ec);p=e;}else APPEND(c);
                } else APPEND(c);
            } else {
                APPEND(c);
            }
        }
        p++;
    }
    COMMIT();

#undef COMMIT
#undef APPEND
}

/* ═══════════════════════════════════════════════════════════
   TOP SCREEN — feature pills (used in normal mode only)
   ═══════════════════════════════════════════════════════════ */

static void pill(const char *lbl,float x,float y,bool active){
    float pw=TW(lbl,0.38f)+8.f, ph=12.f;
    rr_outline(x,y,pw,ph,RAD_S,
               active?C_GREEN:C_BORDER,
               active?C_GREEN2:C_PANEL2);
    T(lbl,x+4.f,y+1.5f,0.38f,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   TOP SCREEN DRAW
   ═══════════════════════════════════════════════════════════ */

static void draw_top(const AppState *app, const Editor *e, const FeatureRuntime *rt){
    (void)e; /* compiled HTML is in s_compiled_html — e not needed */

    /* ── RUN MODE layout ────────────────────────────────────── */
    /* Re-parse only when new content has been compiled (dirty flag). */
    if(s_render_dirty){
        if(s_has_compiled)
            html_render(s_compiled_html);
        else
            s_out_n=0;
        s_render_dirty=false;
    }

    if(app->run_mode){

        /* ── Web Engine rendering ── */
        if(g_web_engine.loaded){
            /* Render the full web page */
            we_render();
            /* Draw cursor on top of page */
            wrender_cursor(app->top_cursor_x, app->top_cursor_y, app->cursor_locked);
            /* Show run-mode indicator bar */
            C2D_DrawRectSolid(0,0,0,TOP_W,14,C2D_Color32(0x06,0x14,0x06,0xDD));
            T("RUNNING",MAR,1.5f,0.40f,C_GREEN);
            if(app->cursor_locked){
                T("LOCKED",TOP_W-48.f,1.5f,0.38f,C_ORANGE);
            } else {
                T("ACTIVE",TOP_W-48.f,1.5f,0.38f,C_WHITE);
            }
            const char *pg_title=we_get_title();
            if(pg_title&&*pg_title){
                T(pg_title, 60.f, 1.5f, 0.38f, C2D_Color32(0xAA,0xBB,0xFF,0xFF));
            }
        } else {
            /* Fallback: text-based output (legacy mode) */
            rr(0,0,TOP_W,20,0,C2D_Color32(0x06,0x14,0x06,0xFF));
            T("RUNNING",MAR,3.f,FS_H,C_GREEN);
            if(app->cursor_locked){
                T("LOCKED",TOP_W-52.f,4.5f,FS_UI,C_ORANGE);
            } else {
                T("ACTIVE",TOP_W-52.f,4.5f,FS_UI,C_WHITE);
            }
            float py0=22.f, ph_out=TOP_H-py0-3.f;
            rr_outline(MAR,py0,TOP_W-2*MAR,ph_out,RAD,C_BORDER,C_PANEL);
            float ty=py0+4.f;
            float max_y=py0+ph_out-4.f;
            int scroll=app->out_scroll;
            if(scroll<0) scroll=0;
            if(scroll>=s_out_n&&s_out_n>0) scroll=s_out_n-1;
            if(s_out_n==0){
                TC("(no output — edit code and run START)",
                   (MAR+TOP_W-MAR)*.5f, py0+ph_out*.5f-6.f, FS_UI, C_WHITE);
            } else {
                for(int i=scroll; i<s_out_n&&ty<max_y; i++){
                    float sc,lh;
                    switch(s_out[i].level){
                        case 1: sc=FS_H;  lh=19.f; break;
                        case 2: sc=FS_UI; lh=17.f; break;
                        case 3: sc=0.46f; lh=16.f; break;
                        default:sc=FS_ED; lh=14.f; break;
                    }
                    bool is_flash=(app->click_flash>0&&app->click_line==i);
                    bool is_hover=(!is_flash&&app->top_cursor_y>=ty&&app->top_cursor_y<ty+lh);
                    if(is_flash){ rr(MAR+2,ty-1,TOP_W-2*MAR-4,lh+1,RAD_S,C2D_Color32(0x1A,0x36,0x1A,0xFF)); }
                    else if(is_hover){ rr(MAR+2,ty-1,TOP_W-2*MAR-4,lh+1,RAD_S,C2D_Color32(0x18,0x18,0x30,0xFF)); }
                    char tb[OUT_LINE];
                    strncpy(tb,s_out[i].text,OUT_LINE-1); tb[OUT_LINE-1]='\0';
                    u32 col=s_out[i].interactive ? C_TAG : C_WHITE;
                    if(is_flash) col=C_GREEN;
                    T(tb,MAR+PAD+2.f,ty,sc,col);
                    ty+=lh;
                }
            }
            if(s_out_n>14){
                float sx=MAR+TOP_W-2*MAR-8,sy=py0+4,sh=ph_out-8;
                float frac=(s_out_n>1)?(float)scroll/(float)(s_out_n-1):0.f;
                C2D_DrawRectSolid(sx,sy,.5f,3,sh,C_PANEL2);
                rr(sx,sy+frac*(sh-10),3,10,1.5f,C_WHITE);
            }
            u32 cdot=app->cursor_locked ? C_DOT_LCK : C_DOT_TOP;
            C2D_DrawCircleSolid(app->top_cursor_x,app->top_cursor_y,.6f,4.f,cdot);
        }
        return;
    }

    /* ── NORMAL MODE layout ─────────────────────────────────── */
    /* Header bar */
    rr(0,0,TOP_W,20,0,C_PANEL);
    T("Pocket Compiler",MAR,3.f,FS_H,C_WHITE);
    T("v0.33",TOP_W-36.f,4.5f,FS_UI,C_WHITE);

    /* Feature pills row 1 */
    float px=MAR,py=25.f;
    pill("DOM",   px,py,rt->dom);      px+=TW("DOM",   .38f)+14;
    pill("Fetch", px,py,rt->fetch);    px+=TW("Fetch", .38f)+14;
    pill("Img",   px,py,rt->images);   px+=TW("Img",   .38f)+14;
    pill("Canvas",px,py,rt->canvas);   px+=TW("Canvas",.38f)+14;
    pill("WebGL", px,py,rt->webgl);

    /* Feature pills row 2 */
    px=MAR; py=41.f;
    pill("Audio",  px,py,rt->audio);    px+=TW("Audio",  .38f)+14;
    pill("Storage",px,py,rt->storage);  px+=TW("Storage",.38f)+14;
    pill("IDB",    px,py,rt->indexeddb);px+=TW("IDB",    .38f)+14;
    pill("iframe", px,py,rt->iframe);

    /* Status strip */
    rr(MAR,57.f,TOP_W-2*MAR,14.f,RAD_S,C_PANEL2);
    char sm[60]; strncpy(sm,rt->status_msg,59); sm[59]='\0';
    T(sm,MAR+PAD,59.f,.40f,C_WHITE);

    /* Output panel */
    float py0=75.f, ph=TOP_H-py0-MAR;
    rr_outline(MAR,py0,TOP_W-2*MAR,ph,RAD,C_BORDER,C_PANEL);

    T("OUTPUT",MAR+PAD,py0+2.f,0.38f,C_WHITE);
    C2D_DrawRectSolid(MAR+2,py0+13.f,.5f,TOP_W-2*MAR-4.f,1.f,C_BORDER);

    float ty=py0+17.f;
    float max_y=py0+ph-4.f;

    if(s_out_n==0){
        TC("(press START to compile)",
           (MAR+TOP_W-MAR)*.5f, py0+ph*.5f-6.f, FS_UI, C_WHITE);
    } else {
        for(int i=0;i<s_out_n&&ty<max_y;i++){
            float sc,lh;
            switch(s_out[i].level){
                case 1:  sc=FS_H;  lh=19.f; break;
                case 2:  sc=FS_UI; lh=17.f; break;
                case 3:  sc=0.46f; lh=16.f; break;
                default: sc=FS_ED; lh=14.f; break;
            }
            char tb[OUT_LINE];
            strncpy(tb,s_out[i].text,OUT_LINE-1); tb[OUT_LINE-1]='\0';
            u32 col=s_out[i].interactive ? C_TAG : C_WHITE;
            T(tb,MAR+PAD+2.f,ty,sc,col);
            ty+=lh;
        }
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — EDIT MODE
   Fixes vs old version:
   - view_left applied for horizontal scroll (no lb[38] truncation).
   - code_cursor_line row highlighted in hover colour.
   - Line counter shows hovered line, not just cursor_line.
   ═══════════════════════════════════════════════════════════ */

static void draw_edit(const AppState *app, const Editor *e){
    rr(0,0,BOT_W,22,0,C_PANEL);
    T("EDIT",MAR,4.f,FS_H,C_WHITE);

    /* Show the line the cursor dot is hovering */
    int total=editor_line_count(e);
    int hover_line=e->scroll_offset+app->code_cursor_line;
    if(hover_line>=total) hover_line=total-1;
    char lc[32];
    snprintf(lc,sizeof(lc),"ln %d/%d",hover_line+1,total);
    T(lc,BOT_W-TW(lc,.40f)-MAR,5.5f,.40f,C_WHITE);

    rr_outline(ED_X,ED_Y,ED_W,ED_H,RAD,C_BORDER,C_PANEL);

    char lb[LINE_MAX];
    char nb[8];
    int  start=e->scroll_offset;
    int  end_l=start+CODE_AREA_H; if(end_l>total)end_l=total;
    int  vl=app->view_left; /* horizontal scroll in chars */

    /* Bug fix: only show hover highlight when cursor is inside the
     * code panel.  When cursor is in the toolbar or status bar the
     * stored code_cursor_line retains its last valid value, which
     * would incorrectly highlight a line even though the cursor is
     * not there.                                                    */
    bool cursor_in_code = (
        app->cursor_x >= ED_X          && app->cursor_x < ED_X+ED_W &&
        app->cursor_y >= ED_Y+PAD      && app->cursor_y < ED_Y+ED_H);

    for(int i=start;i<end_l;i++){
        float ry=ED_Y+PAD+(i-start)*LH_ED;
        bool is_active=( i==e->cursor_line );
        bool is_hover =(cursor_in_code && (i-start)==app->code_cursor_line);

        /* Active line (last edited) */
        if(is_active)
            rr(ED_X+2,ry-1,ED_W-4,LH_ED+1,RAD_S,C_CURLINE);
        /* Hover line (cursor dot is over it) */
        else if(is_hover)
            rr(ED_X+2,ry-1,ED_W-4,LH_ED+1,RAD_S,C_HOVER);

        snprintf(nb,sizeof(nb),"%3d",i+1);
        T(nb,ED_X+PAD,ry,FS_ED,C_WHITE);
        C2D_DrawRectSolid(ED_X+PAD+LNUM_W-3,ry,.5f,1.5f,LH_ED-2,C_BORDER);

        editor_get_line(e,i,lb,sizeof(lb));
        int llen=(int)strlen(lb);

        /* Apply horizontal scroll: skip vl chars from the left */
        char disp[CODE_AREA_W+2];
        if(vl>=llen){
            disp[0]='\0';
        } else {
            strncpy(disp,lb+vl,CODE_AREA_W);
            disp[CODE_AREA_W]='\0';
        }
        draw_code_line(disp,CODE_X,ry,FS_ED);
    }

    /* Vertical scrollbar */
    if(total>CODE_AREA_H){
        float sx=ED_X+ED_W-5,sh=ED_H-2*PAD;
        float th=sh*CODE_AREA_H/(float)total; if(th<10)th=10;
        float ty2=ED_Y+PAD+sh*e->scroll_offset/(float)total;
        C2D_DrawRectSolid(sx,ED_Y+PAD,.5f,3,sh,C_PANEL2);
        rr(sx,ty2,3,th,1.5f,C_WHITE);
    }

    /* Horizontal scroll indicator (shown inside bottom-right of panel) */
    if(vl>0){
        char hsi[14]; snprintf(hsi,sizeof(hsi),"<col %d",vl+1);
        float hx=ED_X+ED_W-TW(hsi,.34f)-PAD;
        float hy=ED_Y+ED_H-12.f;
        rr(hx-2,hy-1,TW(hsi,.34f)+4,11,RAD_S,C_PANEL2);
        T(hsi,hx,hy,.34f,C_WHITE);
    }

    /* Status / hint bar */
    float fy=BOT_H-18;
    rr(0,fy,BOT_W,18,0,C_PANEL);
    T("DPAD:scroll  A:edit  X:save  Y:load  B:undo",MAR,fy+2.5f,.34f,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — RUN MODE  (screen locked; status shown)
   ═══════════════════════════════════════════════════════════ */

static void draw_running_bot(const AppState *app){
    /* Full black with centred status */
    rr(0,0,BOT_W,BOT_H,0,C_BG);

    /* Indicator */
    rr(MAR,BOT_H*.35f-10,BOT_W-2*MAR,20,RAD,C2D_Color32(0x06,0x14,0x06,0xFF));
    TC("OUTPUT RUNNING",BOT_W*.5f,BOT_H*.35f-7.f,FS_H,C_GREEN);

    if(app->cursor_locked){
        TC("Cursor LOCKED to output",BOT_W*.5f,BOT_H*.52f,FS_UI,C_ORANGE);
        TC("Press X to release",     BOT_W*.5f,BOT_H*.62f,.40f,C_WHITE);
    } else {
        TC("Click output to lock cursor",BOT_W*.5f,BOT_H*.52f,FS_UI,C_WHITE);
    }

    /* Hint bar */
    rr(0,BOT_H-18,BOT_W,18,0,C_PANEL);
    T("START:stop  DPAD:scroll  A/L:click  B/R:rclick  X:unlock",
      MAR,BOT_H-14.f,.30f,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — SAVE FILE EXPLORER
   ═══════════════════════════════════════════════════════════ */

static void draw_save(const AppState *app){
    const FileExplorer *fe=&app->fe;
    rr(0,0,BOT_W,22,0,C_PANEL);
    T("SAVE PROJECT",MAR,4.f,FS_H,C_WHITE);
    T("A/X:save  B:back",BOT_W-TW("A/X:save  B:back",.38f)-MAR,5.5f,.38f,C_WHITE);
    rr_outline(FE_X,FE_Y,FE_W,FE_H,RAD,C_BORDER,C_PANEL);

    float ry=FE_Y+PAD;
    int total=fe->count+1;
    int ve=fe->scroll+FE_VISIBLE_ROWS; if(ve>total)ve=total;

    for(int row=fe->scroll;row<ve;row++){
        bool sel=(row==fe->cursor);
        if(sel)rr(FE_X+3,ry-1,FE_W-6,LH_FE,RAD_S,C_SEL);
        if(row==0){
            rr_outline(FE_X+PAD,ry+1,FE_W-2*PAD-2,LH_FE-4,RAD_S,
                       sel?C_WHITE:C_BORDER, sel?C_ACCENT2:C_PANEL);
            T("+ New File",FE_X+2*PAD,ry+3.5f,FS_UI,C_WHITE);
        }else{
            int fi=row-1;
            char fn[30]; strncpy(fn,fe->names[fi],29); fn[29]='\0';
            char sz[10]; fe_format_size(fe->sizes[fi],sz,sizeof(sz));
            T(fn,FE_X+2*PAD,ry+3.5f,FS_UI,C_WHITE);
            T(sz,FE_X+FE_W-TW(sz,.40f)-2*PAD,ry+4.5f,.40f,C_WHITE);
        }
        ry+=LH_FE;
    }
    if(fe->count>FE_VISIBLE_ROWS-1){
        char ind[24]; snprintf(ind,sizeof(ind),"%d files",fe->count);
        T(ind,FE_X+FE_W-TW(ind,.38f)-PAD,FE_Y+FE_H-14.f,.38f,C_WHITE);
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — LOAD FILE EXPLORER
   ═══════════════════════════════════════════════════════════ */

static void draw_load(const AppState *app){
    const FileExplorer *fe=&app->fe;
    rr(0,0,BOT_W,22,0,C_PANEL);
    T("LOAD PROJECT",MAR,4.f,FS_H,C_WHITE);
    T("Y/A:load  B:back",BOT_W-TW("Y/A:load  B:back",.38f)-MAR,5.5f,.38f,C_WHITE);
    rr_outline(FE_X,FE_Y,FE_W,FE_H,RAD,C_BORDER,C_PANEL);

    if(fe->count==0){
        TC("No .html files on SD card",BOT_W*.5f,FE_Y+FE_H*.4f,FS_UI,C_WHITE);
        TC("Save a project first!",BOT_W*.5f,FE_Y+FE_H*.55f,.40f,C_WHITE);
        return;
    }

    float ry=FE_Y+PAD;
    int er=fe->scroll+FE_VISIBLE_ROWS; if(er>fe->count)er=fe->count;
    for(int row=fe->scroll;row<er;row++){
        bool sel=(row==fe->cursor);
        if(sel)rr(FE_X+3,ry-1,FE_W-6,LH_FE,RAD_S,C_SEL);
        char fn[30]; strncpy(fn,fe->names[row],29); fn[29]='\0';
        char sz[10]; fe_format_size(fe->sizes[row],sz,sizeof(sz));
        T(fn,FE_X+2*PAD,ry+3.5f,FS_UI,C_WHITE);
        T(sz,FE_X+FE_W-TW(sz,.40f)-2*PAD,ry+4.5f,.40f,C_WHITE);
        ry+=LH_FE;
    }
    if(fe->count>FE_VISIBLE_ROWS){
        float sx=FE_X+FE_W-5,sy=FE_Y+PAD,sh=FE_H-2*PAD;
        float th=sh*FE_VISIBLE_ROWS/(float)fe->count; if(th<10)th=10;
        float ty=sy+sh*fe->scroll/(float)fe->count;
        C2D_DrawRectSolid(sx,sy,.5f,3,sh,C_PANEL2);
        rr(sx,ty,3,th,1.5f,C_WHITE);
    }
}

/* ═══════════════════════════════════════════════════════════
   BOTTOM — CONTROLS REFERENCE
   ═══════════════════════════════════════════════════════════ */

static void draw_controls(void){
    rr(0,0,BOT_W,22,0,C_PANEL);
    TC("CONTROLS",BOT_W*.5f,4.f,FS_H,C_WHITE);
    rr_outline(MAR,26,BOT_W-2*MAR,BOT_H-44,RAD,C_BORDER,C_PANEL);
    static const char*lbl[]={
        "D-Pad(edit)", "Scroll code (U/D=lines L/R=cols)",
        "D-Pad(run)",  "Scroll output up/down",
        "Circle",      "Move cursor (bottom/top screen)",
        "A",           "Edit hovered line / Left-click",
        "B",           "Undo / Right-click (run)",
        "L / R",       "Left / Right click (run mode)",
        "X",           "Save project / Release lock (run)",
        "Y",           "Load project / Space (run)",
        "START",       "Compile + Run / Stop output",
        "SELECT",      "This screen",
        NULL,NULL
    };
    float ry=30;
    for(int i=0;lbl[i];i+=2){
        T(lbl[i],  MAR+PAD,       ry,0.38f,C_WHITE);
        T(lbl[i+1],MAR+PAD+68.f,  ry,0.36f,C_WHITE);
        ry+=17;
    }
    rr(0,BOT_H-18,BOT_W,18,0,C_PANEL);
    TC("SELECT or B to close",BOT_W*.5f,BOT_H-14.f,.38f,C_WHITE);
}

/* ═══════════════════════════════════════════════════════════
   PUBLIC API
   ═══════════════════════════════════════════════════════════ */

void ui_init(void){
    gfxInitDefault();
    gfxSet3D(false);
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    s_top=C2D_CreateScreenTarget(GFX_TOP,   GFX_LEFT);
    s_bot=C2D_CreateScreenTarget(GFX_BOTTOM,GFX_LEFT);
    s_tb =C2D_TextBufNew(16384);
}

void ui_draw(const AppState *app,const Editor *e,const FeatureRuntime *rt){
    if(!app||!e||!rt)return;
    C2D_TextBufClear(s_tb);
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

    /* TOP SCREEN */
    C2D_TargetClear(s_top,C_BG); C2D_SceneBegin(s_top);
    draw_top(app,e,rt);

    /* BOTTOM SCREEN */
    C2D_TargetClear(s_bot,C_BG); C2D_SceneBegin(s_bot);
    if(app->run_mode){
        /* Bottom is locked during run mode */
        draw_running_bot(app);
    } else {
        switch(app->mode){
            case MODE_EDIT:     draw_edit(app,e);  break;
            case MODE_SAVE:     draw_save(app);    break;
            case MODE_LOAD:     draw_load(app);    break;
            case MODE_CONTROLS: draw_controls();   break;
            case MODE_PREVIEW:
                rr(0,0,BOT_W,22,0,C_PANEL);
                TC("PREVIEW",BOT_W*.5f,4.f,FS_H,C_WHITE);
                TC("Press B or START to return",BOT_W*.5f,BOT_H*.5f,FS_UI,C_WHITE);
                break;
            default: draw_edit(app,e); break;
        }
        /* Bottom-screen cursor dot (only in non-run mode) */
        C2D_DrawCircleSolid(app->cursor_x,app->cursor_y,.6f,3.5f,C_DOT_BOT);
    }

    C3D_FrameEnd(0);
}

void ui_exit(void){
    C2D_TextBufDelete(s_tb);
    C2D_Fini(); C3D_Fini(); gfxExit();
}
