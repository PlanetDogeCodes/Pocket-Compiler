/*
 * web_render.h  —  Citro2D renderer for Pocket Compiler Web Engine
 */
#pragma once
#include "web_dom.h"
#include <3ds.h>
#include <citro2d.h>

/* ── Image cache ─────────────────────────────────────────────────
   Loaded PNG/BMP textures (C3D_Tex backed)                       */
#define WE_MAX_IMAGES  32

typedef struct {
    char        path[128];       /* SD card path or data-URL     */
    C3D_Tex     tex;
    C2D_Image   img;
    uint16_t    w, h;
    bool        loaded;
} WEImage;

extern WEImage g_we_images[WE_MAX_IMAGES];
extern int     g_we_image_n;

/* ── Canvas framebuffers ─────────────────────────────────────────
   Each <canvas> element owns a C3D_RenderTarget                  */
#define WE_MAX_CANVAS  8

typedef struct {
    C3D_RenderTarget *fb;
    C3D_Tex           tex;
    uint16_t          w, h;
    bool              used;
} WECanvas;

extern WECanvas g_we_canvas[WE_MAX_CANVAS];

/* ── API ────────────────────────────────────────────────────────── */

/* Init/cleanup */
void  wrender_init(void);
void  wrender_exit(void);

/* Full document render (call inside Citro2D top-screen scene) */
void  wrender_document(uint8_t doc_id, int16_t scroll_x, int16_t scroll_y);

/* Render a single node and its children */
void  wrender_node(int16_t node_id, int16_t clip_x, int16_t clip_y,
                   int16_t clip_w, int16_t clip_h, int16_t ox, int16_t oy);

/* Draw cursor (pointer) on top screen */
void  wrender_cursor(float cx, float cy, bool locked);

/* Image loading */
uint16_t wrender_load_image(const char *path_or_dataurl);
void     wrender_free_image(uint16_t id);

/* Canvas management */
uint16_t wrender_new_canvas(uint16_t w, uint16_t h);
void     wrender_free_canvas(uint16_t id);
WECanvas *wrender_canvas(uint16_t id);

/* Utility: draw rounded rect in current scene */
void  wrender_rounded_rect(float x, float y, float w, float h,
                            float r, uint32_t col);

/* Utility: draw text with word-wrap */
void  wrender_text(const char *s, float x, float y, float w,
                   float size, uint32_t col, uint8_t align,
                   uint8_t weight, uint8_t decoration);

/* Scrollbar rendering */
void  wrender_scrollbar_v(float x, float y, float h,
                           int scroll, int total, uint32_t col);
void  wrender_scrollbar_h(float x, float y, float w,
                           int scroll, int total, uint32_t col);
