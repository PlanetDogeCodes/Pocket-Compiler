/*
 * web_css.h  —  CSS parser & cascade for Pocket Compiler Web Engine
 */
#pragma once
#include "web_dom.h"

/* ── Default style values ───────────────────────────────────────── */
#define CSS_DEFAULT_COLOR        0xDDDDDDFF  /* near-white text     */
#define CSS_DEFAULT_BG           0x111111FF  /* near-black bg       */
#define CSS_DEFAULT_FONT_SIZE    11          /* px                  */
#define CSS_DEFAULT_LINE_HEIGHT  14          /* px                  */

/* ── Stylesheet: up to 256 rules ───────────────────────────────── */
#define CSS_MAX_RULES   256
#define CSS_SEL_LEN      64

typedef struct {
    char      selector[CSS_SEL_LEN];
    CSSStyle  style;
    uint8_t   used;
    uint8_t   specificity;   /* 0-255 approximation */
} CSSRule;

extern CSSRule g_css_rules[CSS_MAX_RULES];
extern int     g_css_rule_n;

/* ── Parse functions ────────────────────────────────────────────── */

/* Parse inline style="..." string into a CSSStyle */
void  css_parse_inline(const char *inline_css, CSSStyle *out);

/* Parse a <style> block text, append to g_css_rules */
void  css_parse_stylesheet(const char *css_text);

/* Apply cascade to all nodes of doc_id (call after parse) */
void  css_cascade(uint8_t doc_id);

/* Apply computed style to a single node (uses parent inheritance) */
void  css_compute_node(int16_t node_id);

/* Color parsing: "#RGB" "#RRGGBB" "rgb()" named colors → RGBA8 */
uint32_t css_parse_color(const char *s);

/* CSS length: "10px" "1em" "50%" "auto" → px (em=font_size, %=parent) */
int16_t  css_parse_length(const char *s, int parent_px, int font_px);

/* Reset stylesheet (drop all rules) */
void  css_reset(void);

/* Get default (initial) style */
CSSStyle css_default_style(void);

/* Inherit style from parent node */
void  css_inherit(CSSStyle *child, const CSSStyle *parent);

/* Named CSS colors lookup table */
uint32_t css_named_color(const char *name);
