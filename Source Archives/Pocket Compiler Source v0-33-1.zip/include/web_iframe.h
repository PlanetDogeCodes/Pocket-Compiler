/*
 * web_iframe.h  —  iframe support for Pocket Compiler Web Engine
 * Each iframe is a full sub-document with its own JS context.
 */
#pragma once
#include "web_dom.h"
#include "duktape.h"

/* ── iframe node extension ──────────────────────────────────────── */
/* When an element with tag=="iframe" is encountered, this struct
   tracks the sub-document it hosts.                               */

typedef struct {
    bool       used;
    int16_t    host_node;     /* node id of the <iframe> element   */
    uint8_t    parent_doc;    /* doc_id of the parent document     */
    uint8_t    child_doc;     /* doc_id of the sub-document        */
    char       src[256];      /* resolved SD path of the src       */
    bool       loaded;
    bool       sandbox;       /* sandbox attribute present         */
    bool       allow_scripts; /* allow scripts even in sandbox     */
} WEIFrame;

#define WE_MAX_IFRAMES  3   /* limited by WE_MAX_DOCUMENTS - 1    */

extern WEIFrame g_iframes[WE_MAX_IFRAMES];

/* ── API ────────────────────────────────────────────────────────── */

/* Initialize iframe system */
void   wif_init(void);

/* Load an iframe: allocate sub-doc, parse src HTML, run scripts */
int    wif_load(int16_t host_node, uint8_t parent_doc, const char *src);

/* Destroy an iframe sub-doc */
void   wif_unload(int iframe_idx);

/* Get iframe index for a host node (-1 if none) */
int    wif_find(int16_t host_node);

/* Update all iframe JS timers + events (call once per frame) */
void   wif_tick(const void *inp_state);  /* WEInputState* */

/* Render all iframes into their host element rects */
void   wif_render(uint8_t parent_doc);

/* postMessage API */
void   wif_post_message(int iframe_idx, const char *json_msg);

/* Install iframe JS bindings on a parent context */
void   wif_install_bindings(duk_context *ctx, uint8_t doc_id);
