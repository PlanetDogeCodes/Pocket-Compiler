/*  web_webgl.c  — limited WebGL 1.0-like API over Citro3D
 *  PocketCompiler v0.33
 *
 *  Implementation notes:
 *  ─────────────────────
 *  Full GPU shader compilation (PICA200 DVLB) is not exposed here because
 *  homebrew shaders must be pre-compiled with picasso and baked into the
 *  binary.  The JS-facing API accepts shader source strings for compatibility
 *  but silently discards them.  To use real 3D rendering, embed a compiled
 *  .shbin via $(ROMFS) and load it in C before handing the context to JS.
 *
 *  Draw calls fall back to solid-color Citro2D rectangles / triangles when
 *  no linked shader program is present, allowing simple demos to work.
 *
 *  Texture uploads: raw RGBA8 pixel data is copied into a C3D_Tex.
 *
 *  All JS bindings are in wgl_install_bindings().
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "duktape.h"
#include "web_webgl.h"
#include "web_render.h"   /* WECanvas, g_we_canvas */
#include "web_dom.h"

#ifdef __3DS__
#  include <3ds.h>
#  include <citro3d.h>
#  include <citro2d.h>
#endif

/* ─── Global context pool ────────────────────────────────────────────────── */
WGLContext g_wgl_ctx[WGL_MAX_CTX];

/* ─── Helpers ────────────────────────────────────────────────────────────── */
static WGLContext *ctx_from_duk(duk_context *J)
{
    duk_push_global_stash(J);
    duk_get_prop_string(J, -1, "\xFF" "wgl_ctx_ptr");
    WGLContext *c = (WGLContext *)duk_get_pointer(J, -1);
    duk_pop_2(J);
    return c;
}

/* Check buffer index validity */
static bool buf_valid(WGLContext *c, WGLuint id)
{
    return id > 0 && id <= WGL_MAX_BUFFERS && c->buffers[id-1].used;
}
static WGLBuffer *get_buf(WGLContext *c, WGLuint id)
{
    if (!buf_valid(c, id)) return NULL;
    return &c->buffers[id-1];
}
static WGLBuffer *bound_buf(WGLContext *c, WGLenum target)
{
    WGLuint id = (target == WGL_ELEMENT_ARRAY_BUFFER) ? c->bound_ibo : c->bound_vbo;
    return get_buf(c, id);
}

/* Texture helpers */
static bool tex_valid(WGLContext *c, WGLuint id)
{
    return id > 0 && id <= WGL_MAX_TEXTURES && c->textures[id-1].used;
}
static WGLTexture *get_tex(WGLContext *c, WGLuint id)
{
    if (!tex_valid(c, id)) return NULL;
    return &c->textures[id-1];
}

/* Program helpers */
static bool prog_valid(WGLContext *c, WGLuint id)
{
    return id > 0 && id <= WGL_MAX_PROGRAMS && c->programs[id-1].used;
}
static WGLProgram *get_prog(WGLContext *c, WGLuint id)
{
    if (!prog_valid(c, id)) return NULL;
    return &c->programs[id-1];
}

/* ─── Context management ─────────────────────────────────────────────────── */
WGLContext *wgl_new_context(int doc_id, int canvas_id)
{
    for (int i = 0; i < WGL_MAX_CTX; i++) {
        if (!g_wgl_ctx[i].used) {
            WGLContext *c = &g_wgl_ctx[i];
            memset(c, 0, sizeof(*c));
            c->used       = true;
            c->doc_id     = doc_id;
            c->canvas_id  = canvas_id;
            c->clear_a    = 1.0f;
            c->vp_w       = 400;
            c->vp_h       = 240;
            c->blend_src  = WGL_ONE;
            c->blend_dst  = WGL_ZERO;
            c->depth_func = WGL_LESS;
            c->cull_mode  = WGL_BACK;
            return c;
        }
    }
    return NULL;
}

void wgl_free_context(WGLContext *c)
{
    if (!c || !c->used) return;
#ifdef __3DS__
    for (int i = 0; i < WGL_MAX_TEXTURES; i++) {
        if (c->textures[i].used && c->textures[i].loaded)
            C3D_TexDelete(&c->textures[i].tex);
    }
    for (int i = 0; i < WGL_MAX_PROGRAMS; i++) {
        if (c->programs[i].used && c->programs[i].linked) {
            shaderProgramFree(&c->programs[i].sh);
            if (c->programs[i].dvlb)
                DVLB_Free(c->programs[i].dvlb);
        }
    }
#endif
    memset(c, 0, sizeof(*c));
}

/* ─── Error ──────────────────────────────────────────────────────────────── */
WGLenum wgl_getError(WGLContext *c)
{
    if (!c) return WGL_NO_ERROR;
    WGLenum e = c->last_error;
    c->last_error = WGL_NO_ERROR;
    return e;
}

/* ─── Clear ──────────────────────────────────────────────────────────────── */
void wgl_clearColor(WGLContext *c, float r, float g, float b, float a)
{
    if (!c) return;
    c->clear_r = r; c->clear_g = g; c->clear_b = b; c->clear_a = a;
}

void wgl_clear(WGLContext *c, WGLuint mask)
{
    if (!c) return;
#ifdef __3DS__
    extern WECanvas g_we_canvas[];
    if (c->canvas_id >= 0 && g_we_canvas[c->canvas_id].used) {
        WECanvas *cv = &g_we_canvas[c->canvas_id];
        if (mask & WGL_COLOR_BUFFER_BIT) {
            uint8_t r = (uint8_t)(c->clear_r * 255);
            uint8_t g2 = (uint8_t)(c->clear_g * 255);
            uint8_t b2 = (uint8_t)(c->clear_b * 255);
            uint8_t a2 = (uint8_t)(c->clear_a * 255);
            C3D_RenderTargetClear(cv->fb,
                C3D_CLEAR_COLOR,
                C2D_Color32(r, g2, b2, a2), 0);
        }
    }
#endif
}

/* ─── Viewport ───────────────────────────────────────────────────────────── */
void wgl_viewport(WGLContext *c, int x, int y, int w, int h)
{
    if (!c) return;
    c->vp_x = x; c->vp_y = y;
    c->vp_w = w; c->vp_h = h;
}

/* ─── Buffers ────────────────────────────────────────────────────────────── */
WGLuint wgl_createBuffer(WGLContext *c)
{
    if (!c) return 0;
    for (int i = 0; i < WGL_MAX_BUFFERS; i++) {
        if (!c->buffers[i].used) {
            c->buffers[i].used = true;
            c->buffers[i].size = 0;
            return (WGLuint)(i + 1);
        }
    }
    c->last_error = WGL_OUT_OF_MEMORY;
    return 0;
}

void wgl_bindBuffer(WGLContext *c, WGLenum target, WGLuint buf)
{
    if (!c) return;
    if (target == WGL_ELEMENT_ARRAY_BUFFER) c->bound_ibo = buf;
    else                                    c->bound_vbo = buf;
}

void wgl_bufferData(WGLContext *c, WGLenum target, const void *data,
                    uint32_t size, WGLenum usage)
{
    if (!c || !data) return;
    WGLBuffer *b = bound_buf(c, target);
    if (!b) { c->last_error = WGL_INVALID_OPERATION; return; }
    if (size > WGL_BUF_CAP) size = WGL_BUF_CAP;
    memcpy(b->data, data, size);
    b->size   = size;
    b->target = target;
    b->usage  = usage;
}

void wgl_deleteBuffer(WGLContext *c, WGLuint buf)
{
    WGLBuffer *b = get_buf(c, buf);
    if (b) memset(b, 0, sizeof(*b));
}

/* ─── Programs / Shaders (stubs — source discarded) ─────────────────────── */
WGLuint wgl_createProgram(WGLContext *c)
{
    if (!c) return 0;
    for (int i = 0; i < WGL_MAX_PROGRAMS; i++) {
        if (!c->programs[i].used) {
            memset(&c->programs[i], 0, sizeof(c->programs[i]));
            c->programs[i].used = true;
            return (WGLuint)(i + 1);
        }
    }
    c->last_error = WGL_OUT_OF_MEMORY;
    return 0;
}

WGLuint wgl_createShader(WGLContext *c, WGLenum type)
{
    (void)c; (void)type;
    /* Return a non-zero dummy; shader objects are not pooled separately */
    return 1;
}
void wgl_shaderSource(WGLContext *c, WGLuint shader, const char *src)
    { (void)c; (void)shader; (void)src; }
void wgl_compileShader(WGLContext *c, WGLuint shader)
    { (void)c; (void)shader; }
void wgl_attachShader(WGLContext *c, WGLuint prog, WGLuint shader)
    { (void)c; (void)prog; (void)shader; }

void wgl_linkProgram(WGLContext *c, WGLuint prog)
{
    WGLProgram *p = get_prog(c, prog);
    if (p) p->linked = true;
}

void wgl_useProgram(WGLContext *c, WGLuint prog)
{
    if (c) c->active_program = prog;
}

void wgl_deleteProgram(WGLContext *c, WGLuint prog)
{
    WGLProgram *p = get_prog(c, prog);
    if (!p) return;
#ifdef __3DS__
    if (p->linked) {
        shaderProgramFree(&p->sh);
        if (p->dvlb) DVLB_Free(p->dvlb);
    }
#endif
    memset(p, 0, sizeof(*p));
}

void wgl_deleteShader(WGLContext *c, WGLuint shader)
    { (void)c; (void)shader; }

/* ─── Uniforms ───────────────────────────────────────────────────────────── */
WGLint wgl_getUniformLocation(WGLContext *c, WGLuint prog, const char *name)
{
    WGLProgram *p = get_prog(c, prog);
    if (!p || !name) return -1;
    /* Search existing */
    for (int i = 0; i < p->uniform_n; i++)
        if (strcmp(p->uniforms[i].name, name) == 0)
            return (WGLint)i;
    /* Create new */
    if (p->uniform_n >= WGL_MAX_UNIFORMS) return -1;
    int idx = p->uniform_n++;
    strncpy(p->uniforms[idx].name, name, 31);
    p->uniforms[idx].location = idx;
    return (WGLint)idx;
}

static WGLUniform *get_uniform(WGLContext *c, WGLint loc)
{
    WGLProgram *p = get_prog(c, c->active_program);
    if (!p || loc < 0 || loc >= p->uniform_n) return NULL;
    return &p->uniforms[loc];
}

void wgl_uniform1i(WGLContext *c, WGLint loc, int v)
    { WGLUniform *u = get_uniform(c, loc); if (u) { u->ival = v; u->type = WGL_INT; } }
void wgl_uniform1f(WGLContext *c, WGLint loc, float v)
    { WGLUniform *u = get_uniform(c, loc); if (u) { u->fval[0] = v; u->type = WGL_FLOAT; } }
void wgl_uniform2f(WGLContext *c, WGLint loc, float x, float y)
    { WGLUniform *u = get_uniform(c, loc); if (u) { u->fval[0]=x; u->fval[1]=y; u->type = WGL_FLOAT_VEC2; } }
void wgl_uniform3f(WGLContext *c, WGLint loc, float x, float y, float z)
    { WGLUniform *u = get_uniform(c, loc); if (u) { u->fval[0]=x; u->fval[1]=y; u->fval[2]=z; u->type = WGL_FLOAT_VEC3; } }
void wgl_uniform4f(WGLContext *c, WGLint loc, float x, float y, float z, float w)
    { WGLUniform *u = get_uniform(c, loc); if (u) { u->fval[0]=x; u->fval[1]=y; u->fval[2]=z; u->fval[3]=w; u->type = WGL_FLOAT_VEC4; } }
void wgl_uniformMatrix4fv(WGLContext *c, WGLint loc, bool transpose, const float *m)
{
    WGLUniform *u = get_uniform(c, loc);
    if (u && m) { memcpy(u->fval, m, 16*sizeof(float)); u->type = WGL_FLOAT_MAT4; (void)transpose; }
}

/* ─── Attributes (stubs — layout is fixed in fallback renderer) ──────────── */
WGLint wgl_getAttribLocation(WGLContext *c, WGLuint prog, const char *name)
    { (void)c; (void)prog; (void)name; return 0; }
void wgl_enableVertexAttribArray(WGLContext *c, WGLuint idx)
    { (void)c; (void)idx; }
void wgl_disableVertexAttribArray(WGLContext *c, WGLuint idx)
    { (void)c; (void)idx; }
void wgl_vertexAttribPointer(WGLContext *c, WGLuint idx, int size,
    WGLenum type, bool normalized, int stride, int offset)
    { (void)c; (void)idx; (void)size; (void)type;
      (void)normalized; (void)stride; (void)offset; }

/* ─── Draw calls (fallback: solid 2D rects / triangles via Citro2D) ──────── */
/*
 * We interpret float[3] (x,y,z) stride in the bound VBO as x,y screen coords
 * (normalised -1..1 → pixel coords).  Colors are taken from the first
 * uniform4f bound to the active program (or white as default).
 */
static void draw_triangles_fallback(WGLContext *c, int first, int count)
{
#ifdef __3DS__
    extern WECanvas g_we_canvas[];
    if (c->canvas_id < 0 || !g_we_canvas[c->canvas_id].used) return;
    WECanvas *cv = &g_we_canvas[c->canvas_id];

    WGLBuffer *vbo = get_buf(c, c->bound_vbo);
    if (!vbo || vbo->size == 0) return;

    /* Determine color from first vec4 uniform */
    float cr=1,cg=1,cb=1,ca=1;
    WGLProgram *p = get_prog(c, c->active_program);
    if (p) {
        for (int i = 0; i < p->uniform_n; i++) {
            if (p->uniforms[i].type == WGL_FLOAT_VEC4) {
                cr = p->uniforms[i].fval[0];
                cg = p->uniforms[i].fval[1];
                cb = p->uniforms[i].fval[2];
                ca = p->uniforms[i].fval[3];
                break;
            }
        }
    }
    uint32_t col = C2D_Color32(
        (uint8_t)(cr*255), (uint8_t)(cg*255),
        (uint8_t)(cb*255), (uint8_t)(ca*255));

    /* stride: assume 3 floats per vertex (x,y,z) */
    const float *verts = (const float *)vbo->data;
    int stride = 3;
    float ox = (float)c->vp_x;
    float oy = (float)c->vp_y;
    float sw = (float)(c->vp_w > 0 ? c->vp_w : cv->w);
    float sh = (float)(c->vp_h > 0 ? c->vp_h : cv->h);

    C2D_SceneBegin(cv->fb);

    for (int i = first; i + 2 < first + count; i += 3) {
        float x0 = ox + (verts[(i+0)*stride+0]*0.5f+0.5f)*sw;
        float y0 = oy + (1.0f-(verts[(i+0)*stride+1]*0.5f+0.5f))*sh;
        float x1 = ox + (verts[(i+1)*stride+0]*0.5f+0.5f)*sw;
        float y1 = oy + (1.0f-(verts[(i+1)*stride+1]*0.5f+0.5f))*sh;
        float x2 = ox + (verts[(i+2)*stride+0]*0.5f+0.5f)*sw;
        float y2 = oy + (1.0f-(verts[(i+2)*stride+1]*0.5f+0.5f))*sh;

        /* Draw as thin bounding-box rect (Citro2D has no triangle prim) */
        float mnx = fminf(x0, fminf(x1, x2));
        float mny = fminf(y0, fminf(y1, y2));
        float mxx = fmaxf(x0, fmaxf(x1, x2));
        float mxy = fmaxf(y0, fmaxf(y1, y2));
        C2D_DrawRectSolid(mnx, mny, 0.5f, mxx-mnx, mxy-mny, col);
    }
#else
    (void)c; (void)first; (void)count;
#endif
}

void wgl_drawArrays(WGLContext *c, WGLenum mode, int first, int count)
{
    if (!c || count <= 0) return;
    /* Only TRIANGLES supported in fallback */
    if (mode == WGL_TRIANGLES || mode == WGL_TRIANGLE_STRIP ||
        mode == WGL_TRIANGLE_FAN) {
        draw_triangles_fallback(c, first, count);
    }
    /* LINES / POINTS: silently ignored in fallback */
}

void wgl_drawElements(WGLContext *c, WGLenum mode, int count,
                      WGLenum type, int offset)
{
    (void)c; (void)mode; (void)count; (void)type; (void)offset;
    /* Index-based draw not implemented in fallback */
}

/* ─── Textures ───────────────────────────────────────────────────────────── */
WGLuint wgl_createTexture(WGLContext *c)
{
    if (!c) return 0;
    for (int i = 0; i < WGL_MAX_TEXTURES; i++) {
        if (!c->textures[i].used) {
            memset(&c->textures[i], 0, sizeof(c->textures[i]));
            c->textures[i].used       = true;
            c->textures[i].min_filter = WGL_LINEAR;
            c->textures[i].mag_filter = WGL_LINEAR;
            c->textures[i].wrap_s     = WGL_CLAMP_TO_EDGE;
            c->textures[i].wrap_t     = WGL_CLAMP_TO_EDGE;
            return (WGLuint)(i + 1);
        }
    }
    c->last_error = WGL_OUT_OF_MEMORY;
    return 0;
}

void wgl_activeTexture(WGLContext *c, WGLenum unit)
{
    if (c) c->active_texture_unit = unit - WGL_TEXTURE0;
}

void wgl_bindTexture(WGLContext *c, WGLenum target, WGLuint tex)
{
    if (!c || target != WGL_TEXTURE_2D) return;
    if (c->active_texture_unit < 8)
        c->bound_textures[c->active_texture_unit] = tex;
}

void wgl_texImage2D(WGLContext *c, WGLenum target, int level,
                    WGLenum internalfmt, int w, int h, int border,
                    WGLenum format, WGLenum type, const void *pixels)
{
    (void)internalfmt; (void)border; (void)level;
    if (!c || target != WGL_TEXTURE_2D || !pixels) return;
    WGLuint id = (c->active_texture_unit < 8)
                 ? c->bound_textures[c->active_texture_unit] : 0;
    WGLTexture *t = get_tex(c, id);
    if (!t) return;

#ifdef __3DS__
    /* Delete old texture if present */
    if (t->loaded) { C3D_TexDelete(&t->tex); t->loaded = false; }

    /* Round up to power-of-2 for PICA200 */
    int tw = 8, th = 8;
    while (tw < w) tw <<= 1;
    while (th < h) th <<= 1;

    GPU_TEXCOLOR fmt = (format == WGL_RGBA) ? GPU_RGBA8 : GPU_RGB8;
    if (!C3D_TexInit(&t->tex, tw, th, fmt)) return;

    /* Copy pixels (RGBA8 assumed) */
    int cpp = (format == WGL_RGBA) ? 4 : 3;
    uint8_t *dst = (uint8_t *)t->tex.data;
    const uint8_t *src = (const uint8_t *)pixels;
    for (int py = 0; py < h; py++) {
        for (int px = 0; px < w; px++) {
            int di = (py * tw + px) * 4;
            int si = (py * w  + px) * cpp;
            dst[di+0] = src[si+0];
            dst[di+1] = src[si+1];
            dst[di+2] = src[si+2];
            dst[di+3] = (cpp == 4) ? src[si+3] : 0xFF;
        }
    }
    C3D_TexFlush(&t->tex);
    t->loaded = true;
#endif
    t->w      = w;
    t->h      = h;
    t->format = format;
    (void)type;
}

void wgl_texParameteri(WGLContext *c, WGLenum target, WGLenum pname, WGLint param)
{
    if (!c || target != WGL_TEXTURE_2D) return;
    WGLuint id = (c->active_texture_unit < 8)
                 ? c->bound_textures[c->active_texture_unit] : 0;
    WGLTexture *t = get_tex(c, id);
    if (!t) return;
    if (pname == WGL_TEXTURE_MIN_FILTER) t->min_filter = (WGLenum)param;
    if (pname == WGL_TEXTURE_MAG_FILTER) t->mag_filter = (WGLenum)param;
    if (pname == WGL_TEXTURE_WRAP_S)     t->wrap_s     = (WGLenum)param;
    if (pname == WGL_TEXTURE_WRAP_T)     t->wrap_t     = (WGLenum)param;
}

void wgl_generateMipmap(WGLContext *c, WGLenum target)
    { (void)c; (void)target; /* Not supported — silently ignored */ }

void wgl_deleteTexture(WGLContext *c, WGLuint tex)
{
    WGLTexture *t = get_tex(c, tex);
    if (!t) return;
#ifdef __3DS__
    if (t->loaded) C3D_TexDelete(&t->tex);
#endif
    memset(t, 0, sizeof(*t));
}

/* ─── Caps ───────────────────────────────────────────────────────────────── */
void wgl_enable(WGLContext *c, WGLenum cap)
{
    if (!c) return;
    if (cap == WGL_BLEND)      c->blend_enabled = true;
    if (cap == WGL_DEPTH_TEST) c->depth_test    = true;
    if (cap == WGL_CULL_FACE)  c->cull_face     = true;
}
void wgl_disable(WGLContext *c, WGLenum cap)
{
    if (!c) return;
    if (cap == WGL_BLEND)      c->blend_enabled = false;
    if (cap == WGL_DEPTH_TEST) c->depth_test    = false;
    if (cap == WGL_CULL_FACE)  c->cull_face     = false;
}
void wgl_blendFunc(WGLContext *c, WGLenum sfactor, WGLenum dfactor)
    { if (c) { c->blend_src = sfactor; c->blend_dst = dfactor; } }
void wgl_depthFunc(WGLContext *c, WGLenum fn)
    { if (c) c->depth_func = fn; }
void wgl_cullFace(WGLContext *c, WGLenum mode)
    { if (c) c->cull_mode = mode; }

void wgl_flush(WGLContext *c)   { (void)c; }
void wgl_finish(WGLContext *c)  { (void)c; }

/* ══════════════════════════════════════════════════════════════════════════
   Duktape JS Bindings
   ══════════════════════════════════════════════════════════════════════════ */

/* Helper: get WGLContext* from 'this' object's __wgl_ptr property */
static WGLContext *ctx_from_this(duk_context *J)
{
    duk_push_this(J);
    duk_get_prop_string(J, -1, "__wgl_ptr");
    WGLContext *c = (WGLContext *)duk_get_pointer(J, -1);
    duk_pop_2(J);
    return c;
}

/* ── JS method implementations ── */
#define JS_WGL_HEADER \
    WGLContext *c = ctx_from_this(J); \
    if (!c) return 0;

static duk_ret_t js_getError(duk_context *J)
    { JS_WGL_HEADER; duk_push_int(J, (int)wgl_getError(c)); return 1; }

static duk_ret_t js_clearColor(duk_context *J)
{
    JS_WGL_HEADER;
    float r = (float)duk_opt_number(J, 0, 0);
    float g = (float)duk_opt_number(J, 1, 0);
    float b2 = (float)duk_opt_number(J, 2, 0);
    float a = (float)duk_opt_number(J, 3, 1);
    wgl_clearColor(c, r, g, b2, a); return 0;
}

static duk_ret_t js_clear(duk_context *J)
{
    JS_WGL_HEADER;
    WGLuint mask = (WGLuint)duk_opt_int(J, 0, WGL_COLOR_BUFFER_BIT);
    wgl_clear(c, mask); return 0;
}

static duk_ret_t js_viewport(duk_context *J)
{
    JS_WGL_HEADER;
    int x=(int)duk_opt_int(J,0,0), y=(int)duk_opt_int(J,1,0);
    int w=(int)duk_opt_int(J,2,400), h=(int)duk_opt_int(J,3,240);
    wgl_viewport(c, x, y, w, h); return 0;
}

static duk_ret_t js_createBuffer(duk_context *J)
    { JS_WGL_HEADER; duk_push_int(J, (int)wgl_createBuffer(c)); return 1; }
static duk_ret_t js_bindBuffer(duk_context *J)
{
    JS_WGL_HEADER;
    WGLenum tgt = (WGLenum)duk_opt_int(J, 0, 0);
    WGLuint buf = (WGLuint)duk_opt_int(J, 1, 0);
    wgl_bindBuffer(c, tgt, buf); return 0;
}
static duk_ret_t js_bufferData(duk_context *J)
{
    JS_WGL_HEADER;
    WGLenum tgt  = (WGLenum)duk_opt_int(J, 0, WGL_ARRAY_BUFFER);
    WGLenum usage = (WGLenum)duk_opt_int(J, 2, WGL_STATIC_DRAW);
    if (duk_is_buffer_data(J, 1)) {
        duk_size_t sz;
        void *ptr = duk_get_buffer_data(J, 1, &sz);
        wgl_bufferData(c, tgt, ptr, (uint32_t)sz, usage);
    } else if (duk_is_array(J, 1)) {
        /* Float32Array / plain array */
        duk_size_t len = (duk_size_t)duk_get_length(J, 1);
        float *tmp = (float *)malloc(len * sizeof(float));
        if (tmp) {
            for (duk_size_t i = 0; i < len; i++) {
                duk_get_prop_index(J, 1, (duk_uarridx_t)i);
                tmp[i] = (float)duk_get_number(J, -1);
                duk_pop(J);
            }
            wgl_bufferData(c, tgt, tmp, (uint32_t)(len*sizeof(float)), usage);
            free(tmp);
        }
    }
    return 0;
}
static duk_ret_t js_deleteBuffer(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_deleteBuffer(c, (WGLuint)duk_opt_int(J, 0, 0)); return 0;
}

static duk_ret_t js_createProgram(duk_context *J)
    { JS_WGL_HEADER; duk_push_int(J, (int)wgl_createProgram(c)); return 1; }
static duk_ret_t js_createShader(duk_context *J)
{
    JS_WGL_HEADER;
    WGLenum t = (WGLenum)duk_opt_int(J, 0, WGL_VERTEX_SHADER);
    duk_push_int(J, (int)wgl_createShader(c, t)); return 1;
}
static duk_ret_t js_shaderSource(duk_context *J)
{
    JS_WGL_HEADER;
    WGLuint sh = (WGLuint)duk_opt_int(J, 0, 0);
    const char *src = duk_opt_string(J, 1, "");
    wgl_shaderSource(c, sh, src); return 0;
}
static duk_ret_t js_compileShader(duk_context *J)
    { JS_WGL_HEADER; wgl_compileShader(c, (WGLuint)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_attachShader(duk_context *J)
    { JS_WGL_HEADER; wgl_attachShader(c,(WGLuint)duk_opt_int(J,0,0),(WGLuint)duk_opt_int(J,1,0)); return 0; }
static duk_ret_t js_linkProgram(duk_context *J)
    { JS_WGL_HEADER; wgl_linkProgram(c, (WGLuint)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_useProgram(duk_context *J)
    { JS_WGL_HEADER; wgl_useProgram(c, (WGLuint)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_deleteProgram(duk_context *J)
    { JS_WGL_HEADER; wgl_deleteProgram(c, (WGLuint)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_deleteShader(duk_context *J)
    { JS_WGL_HEADER; wgl_deleteShader(c, (WGLuint)duk_opt_int(J,0,0)); return 0; }

/* Shader info log — always returns empty (no real compiler) */
static duk_ret_t js_getShaderInfoLog(duk_context *J)
    { (void)J; duk_push_string(J, ""); return 1; }
static duk_ret_t js_getProgramInfoLog(duk_context *J)
    { (void)J; duk_push_string(J, ""); return 1; }
static duk_ret_t js_getShaderParameter(duk_context *J)
    { (void)J; duk_push_boolean(J, 1); return 1; }
static duk_ret_t js_getProgramParameter(duk_context *J)
    { (void)J; duk_push_boolean(J, 1); return 1; }

static duk_ret_t js_getUniformLocation(duk_context *J)
{
    JS_WGL_HEADER;
    WGLuint prog = (WGLuint)duk_opt_int(J, 0, 0);
    const char *nm = duk_opt_string(J, 1, "");
    duk_push_int(J, (int)wgl_getUniformLocation(c, prog, nm)); return 1;
}
static duk_ret_t js_uniform1i(duk_context *J)
    { JS_WGL_HEADER; wgl_uniform1i(c,(WGLint)duk_opt_int(J,0,-1),duk_opt_int(J,1,0)); return 0; }
static duk_ret_t js_uniform1f(duk_context *J)
    { JS_WGL_HEADER; wgl_uniform1f(c,(WGLint)duk_opt_int(J,0,-1),(float)duk_opt_number(J,1,0)); return 0; }
static duk_ret_t js_uniform2f(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_uniform2f(c,(WGLint)duk_opt_int(J,0,-1),
        (float)duk_opt_number(J,1,0),(float)duk_opt_number(J,2,0)); return 0;
}
static duk_ret_t js_uniform3f(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_uniform3f(c,(WGLint)duk_opt_int(J,0,-1),
        (float)duk_opt_number(J,1,0),(float)duk_opt_number(J,2,0),
        (float)duk_opt_number(J,3,0)); return 0;
}
static duk_ret_t js_uniform4f(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_uniform4f(c,(WGLint)duk_opt_int(J,0,-1),
        (float)duk_opt_number(J,1,0),(float)duk_opt_number(J,2,0),
        (float)duk_opt_number(J,3,0),(float)duk_opt_number(J,4,0)); return 0;
}
static duk_ret_t js_uniformMatrix4fv(duk_context *J)
{
    JS_WGL_HEADER;
    WGLint loc    = (WGLint)duk_opt_int(J, 0, -1);
    bool transp   = duk_opt_boolean(J, 1, false);
    /* Arg 2: Float32Array or plain Array of 16 floats */
    float mat[16] = {0};
    if (duk_is_buffer_data(J, 2)) {
        duk_size_t sz;
        float *p = (float *)duk_get_buffer_data(J, 2, &sz);
        if (p && sz >= 64) memcpy(mat, p, 64);
    } else if (duk_is_array(J, 2)) {
        for (int i = 0; i < 16; i++) {
            duk_get_prop_index(J, 2, (duk_uarridx_t)i);
            mat[i] = (float)duk_get_number(J, -1);
            duk_pop(J);
        }
    }
    wgl_uniformMatrix4fv(c, loc, transp, mat); return 0;
}

static duk_ret_t js_getAttribLocation(duk_context *J)
{
    JS_WGL_HEADER;
    const char *nm = duk_opt_string(J, 1, "");
    duk_push_int(J, wgl_getAttribLocation(c, (WGLuint)duk_opt_int(J,0,0), nm));
    return 1;
}
static duk_ret_t js_enableVertexAttribArray(duk_context *J)
    { JS_WGL_HEADER; wgl_enableVertexAttribArray(c,(WGLuint)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_disableVertexAttribArray(duk_context *J)
    { JS_WGL_HEADER; wgl_disableVertexAttribArray(c,(WGLuint)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_vertexAttribPointer(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_vertexAttribPointer(c,
        (WGLuint)duk_opt_int(J,0,0), duk_opt_int(J,1,4),
        (WGLenum)duk_opt_int(J,2,WGL_FLOAT),
        duk_opt_boolean(J,3,false),
        duk_opt_int(J,4,0), duk_opt_int(J,5,0));
    return 0;
}
static duk_ret_t js_drawArrays(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_drawArrays(c,(WGLenum)duk_opt_int(J,0,WGL_TRIANGLES),
        duk_opt_int(J,1,0), duk_opt_int(J,2,0)); return 0;
}
static duk_ret_t js_drawElements(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_drawElements(c,(WGLenum)duk_opt_int(J,0,WGL_TRIANGLES),
        duk_opt_int(J,1,0),(WGLenum)duk_opt_int(J,2,0x1403),
        duk_opt_int(J,3,0)); return 0;
}

static duk_ret_t js_createTexture(duk_context *J)
    { JS_WGL_HEADER; duk_push_int(J,(int)wgl_createTexture(c)); return 1; }
static duk_ret_t js_bindTexture(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_bindTexture(c,(WGLenum)duk_opt_int(J,0,WGL_TEXTURE_2D),
        (WGLuint)duk_opt_int(J,1,0)); return 0;
}
static duk_ret_t js_activeTexture(duk_context *J)
    { JS_WGL_HEADER; wgl_activeTexture(c,(WGLenum)duk_opt_int(J,0,WGL_TEXTURE0)); return 0; }
static duk_ret_t js_texImage2D(duk_context *J)
{
    JS_WGL_HEADER;
    WGLenum tgt  = (WGLenum)duk_opt_int(J,0,WGL_TEXTURE_2D);
    int     lev  = duk_opt_int(J,1,0);
    WGLenum ifmt = (WGLenum)duk_opt_int(J,2,WGL_RGBA);
    int     w    = duk_opt_int(J,3,0);
    int     h    = duk_opt_int(J,4,0);
    int     brd  = duk_opt_int(J,5,0);
    WGLenum fmt  = (WGLenum)duk_opt_int(J,6,WGL_RGBA);
    WGLenum tp   = (WGLenum)duk_opt_int(J,7,WGL_UNSIGNED_BYTE);
    const void *px = NULL;
    duk_size_t sz;
    if (duk_is_buffer_data(J,8)) px = duk_get_buffer_data(J,8,&sz);
    wgl_texImage2D(c,tgt,lev,ifmt,w,h,brd,fmt,tp,px); return 0;
}
static duk_ret_t js_texParameteri(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_texParameteri(c,(WGLenum)duk_opt_int(J,0,WGL_TEXTURE_2D),
        (WGLenum)duk_opt_int(J,1,0),(WGLint)duk_opt_int(J,2,0)); return 0;
}
static duk_ret_t js_generateMipmap(duk_context *J)
    { JS_WGL_HEADER; wgl_generateMipmap(c,(WGLenum)duk_opt_int(J,0,WGL_TEXTURE_2D)); return 0; }
static duk_ret_t js_deleteTexture(duk_context *J)
    { JS_WGL_HEADER; wgl_deleteTexture(c,(WGLuint)duk_opt_int(J,0,0)); return 0; }

static duk_ret_t js_enable(duk_context *J)
    { JS_WGL_HEADER; wgl_enable(c,(WGLenum)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_disable(duk_context *J)
    { JS_WGL_HEADER; wgl_disable(c,(WGLenum)duk_opt_int(J,0,0)); return 0; }
static duk_ret_t js_blendFunc(duk_context *J)
{
    JS_WGL_HEADER;
    wgl_blendFunc(c,(WGLenum)duk_opt_int(J,0,WGL_ONE),
        (WGLenum)duk_opt_int(J,1,WGL_ZERO)); return 0;
}
static duk_ret_t js_depthFunc(duk_context *J)
    { JS_WGL_HEADER; wgl_depthFunc(c,(WGLenum)duk_opt_int(J,0,WGL_LESS)); return 0; }
static duk_ret_t js_cullFace(duk_context *J)
    { JS_WGL_HEADER; wgl_cullFace(c,(WGLenum)duk_opt_int(J,0,WGL_BACK)); return 0; }
static duk_ret_t js_flush(duk_context *J)
    { JS_WGL_HEADER; wgl_flush(c); return 0; }
static duk_ret_t js_finish(duk_context *J)
    { JS_WGL_HEADER; wgl_finish(c); return 0; }

/* ── Constant getter helper ── */
static duk_ret_t js_wgl_get_const(duk_context *J)
{
    /* The constant value is stored in the function's 'magic' */
    duk_push_int(J, (int)(duk_uint_t)duk_get_current_magic(J));
    return 1;
}

/* ── Install all bindings on a new WebGL context object ── */
void wgl_install_bindings(duk_context *J, int canvas_id, int doc_id)
{
    WGLContext *c = wgl_new_context(doc_id, canvas_id);
    if (!c) { duk_push_null(J); return; }

    duk_push_object(J);   /* The WebGLRenderingContext object */

    /* Store C pointer */
    duk_push_pointer(J, (void *)c);
    duk_put_prop_string(J, -2, "__wgl_ptr");

    /* Store in global stash for ctx_from_duk() */
    duk_push_global_stash(J);
    duk_push_pointer(J, (void *)c);
    duk_put_prop_string(J, -2, "\xFF" "wgl_ctx_ptr");
    duk_pop(J);

    /* Helper macro: register a method */
#define WGL_METHOD(name, fn, nargs) \
    duk_push_c_function(J, fn, nargs); \
    duk_put_prop_string(J, -2, name);

    /* Attach all methods */
    WGL_METHOD("getError",                js_getError, 0)
    WGL_METHOD("clearColor",              js_clearColor, 4)
    WGL_METHOD("clear",                   js_clear, 1)
    WGL_METHOD("viewport",                js_viewport, 4)
    WGL_METHOD("createBuffer",            js_createBuffer, 0)
    WGL_METHOD("bindBuffer",              js_bindBuffer, 2)
    WGL_METHOD("bufferData",              js_bufferData, 3)
    WGL_METHOD("deleteBuffer",            js_deleteBuffer, 1)
    WGL_METHOD("createProgram",           js_createProgram, 0)
    WGL_METHOD("createShader",            js_createShader, 1)
    WGL_METHOD("shaderSource",            js_shaderSource, 2)
    WGL_METHOD("compileShader",           js_compileShader, 1)
    WGL_METHOD("attachShader",            js_attachShader, 2)
    WGL_METHOD("linkProgram",             js_linkProgram, 1)
    WGL_METHOD("useProgram",              js_useProgram, 1)
    WGL_METHOD("deleteProgram",           js_deleteProgram, 1)
    WGL_METHOD("deleteShader",            js_deleteShader, 1)
    WGL_METHOD("getShaderInfoLog",        js_getShaderInfoLog, 1)
    WGL_METHOD("getProgramInfoLog",       js_getProgramInfoLog, 1)
    WGL_METHOD("getShaderParameter",      js_getShaderParameter, 2)
    WGL_METHOD("getProgramParameter",     js_getProgramParameter, 2)
    WGL_METHOD("getUniformLocation",      js_getUniformLocation, 2)
    WGL_METHOD("uniform1i",               js_uniform1i, 2)
    WGL_METHOD("uniform1f",               js_uniform1f, 2)
    WGL_METHOD("uniform2f",               js_uniform2f, 3)
    WGL_METHOD("uniform3f",               js_uniform3f, 4)
    WGL_METHOD("uniform4f",               js_uniform4f, 5)
    WGL_METHOD("uniformMatrix4fv",        js_uniformMatrix4fv, 3)
    WGL_METHOD("getAttribLocation",       js_getAttribLocation, 2)
    WGL_METHOD("enableVertexAttribArray", js_enableVertexAttribArray, 1)
    WGL_METHOD("disableVertexAttribArray",js_disableVertexAttribArray, 1)
    WGL_METHOD("vertexAttribPointer",     js_vertexAttribPointer, 6)
    WGL_METHOD("drawArrays",              js_drawArrays, 3)
    WGL_METHOD("drawElements",            js_drawElements, 4)
    WGL_METHOD("createTexture",           js_createTexture, 0)
    WGL_METHOD("bindTexture",             js_bindTexture, 2)
    WGL_METHOD("activeTexture",           js_activeTexture, 1)
    WGL_METHOD("texImage2D",              js_texImage2D, 9)
    WGL_METHOD("texParameteri",           js_texParameteri, 3)
    WGL_METHOD("generateMipmap",          js_generateMipmap, 1)
    WGL_METHOD("deleteTexture",           js_deleteTexture, 1)
    WGL_METHOD("enable",                  js_enable, 1)
    WGL_METHOD("disable",                 js_disable, 1)
    WGL_METHOD("blendFunc",               js_blendFunc, 2)
    WGL_METHOD("depthFunc",               js_depthFunc, 1)
    WGL_METHOD("cullFace",                js_cullFace, 1)
    WGL_METHOD("flush",                   js_flush, 0)
    WGL_METHOD("finish",                  js_finish, 0)
#undef WGL_METHOD

    /* Expose WebGL constants as integer properties */
#define WGL_CONST(name, val) \
    duk_push_int(J, val); \
    duk_put_prop_string(J, -2, #name);

    WGL_CONST(ARRAY_BUFFER,          0x8892)
    WGL_CONST(ELEMENT_ARRAY_BUFFER,  0x8893)
    WGL_CONST(STATIC_DRAW,           0x88B4)
    WGL_CONST(DYNAMIC_DRAW,          0x88E8)
    WGL_CONST(STREAM_DRAW,           0x88E0)
    WGL_CONST(TEXTURE_2D,            0x0DE1)
    WGL_CONST(TEXTURE0,              0x84C0)
    WGL_CONST(NEAREST,               0x2600)
    WGL_CONST(LINEAR,                0x2601)
    WGL_CONST(CLAMP_TO_EDGE,         0x812F)
    WGL_CONST(REPEAT,                0x2901)
    WGL_CONST(TEXTURE_MIN_FILTER,    0x2801)
    WGL_CONST(TEXTURE_MAG_FILTER,    0x2800)
    WGL_CONST(TEXTURE_WRAP_S,        0x2802)
    WGL_CONST(TEXTURE_WRAP_T,        0x2803)
    WGL_CONST(RGBA,                  0x1908)
    WGL_CONST(RGB,                   0x1907)
    WGL_CONST(UNSIGNED_BYTE,         0x1401)
    WGL_CONST(FLOAT,                 0x1406)
    WGL_CONST(UNSIGNED_SHORT,        0x1403)
    WGL_CONST(COLOR_BUFFER_BIT,      0x4000)
    WGL_CONST(DEPTH_BUFFER_BIT,      0x0100)
    WGL_CONST(TRIANGLES,             0x0004)
    WGL_CONST(TRIANGLE_STRIP,        0x0005)
    WGL_CONST(TRIANGLE_FAN,          0x0006)
    WGL_CONST(LINES,                 0x0001)
    WGL_CONST(LINE_STRIP,            0x0003)
    WGL_CONST(POINTS,                0x0000)
    WGL_CONST(BLEND,                 0x0BE2)
    WGL_CONST(ONE,                   1)
    WGL_CONST(ZERO,                  0)
    WGL_CONST(SRC_ALPHA,             0x0302)
    WGL_CONST(ONE_MINUS_SRC_ALPHA,   0x0303)
    WGL_CONST(DEPTH_TEST,            0x0B71)
    WGL_CONST(LESS,                  0x0201)
    WGL_CONST(LEQUAL,                0x0203)
    WGL_CONST(CULL_FACE,             0x0B44)
    WGL_CONST(BACK,                  0x0405)
    WGL_CONST(FRONT,                 0x0404)
    WGL_CONST(VERTEX_SHADER,         0x8B31)
    WGL_CONST(FRAGMENT_SHADER,       0x8B30)
    WGL_CONST(NO_ERROR,              0)
    WGL_CONST(INVALID_ENUM,          0x0500)
    WGL_CONST(INVALID_VALUE,         0x0501)
    WGL_CONST(INVALID_OPERATION,     0x0502)
    WGL_CONST(OUT_OF_MEMORY,         0x0505)
    WGL_CONST(FRAMEBUFFER_COMPLETE,  0x8CD5)
    WGL_CONST(COMPILE_STATUS,        0x8B81)
    WGL_CONST(LINK_STATUS,           0x8B82)
#undef WGL_CONST

    /* Leave the context object on top of the Duktape stack for the caller */
    /* caller (wjs_install_canvas) sets it as a property of the canvas element */
}
