/*
 * web_storage.c  —  localStorage / IndexedDB over SD card JSON
 */
#include "web_storage.h"
#include "duktape.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>

WSStore g_ws_local  [WS_MAX_STORES];
WSStore g_ws_session[WS_MAX_STORES];
WSIDBDatabase g_ws_idb[WS_IDB_MAX_STORES];

/* ── Init ────────────────────────────────────────────────────────── */

bool ws_init(void){
    /* Ensure directory hierarchy exists */
    mkdir("sdmc:/3ds",0777);
    mkdir("sdmc:/3ds/pocketcompiler",0777);
    mkdir("sdmc:/3ds/pocketcompiler/storage",0777);
    mkdir("sdmc:/3ds/pocketcompiler/storage/idb",0777);
    mkdir("sdmc:/3ds/pocketcompiler/www",0777);
    return true;
}

/* ── Simple JSON KV serialization ──────────────────────────────── */
/* Format: { "key1":"val1", "key2":"val2", ... }                   */

static WSStore *get_local_store(const char *origin, bool create){
    for(int i=0;i<WS_MAX_STORES;i++){
        if(g_ws_local[i].origin[0]&&strcmp(g_ws_local[i].origin,origin)==0)
            return &g_ws_local[i];
    }
    if(!create) return NULL;
    for(int i=0;i<WS_MAX_STORES;i++){
        if(!g_ws_local[i].origin[0]){
            strncpy(g_ws_local[i].origin,origin,63);
            g_ws_local[i].origin[63]='\0';
            ws_local_load(origin);
            return &g_ws_local[i];
        }
    }
    return NULL;
}

static WSStore *get_session_store(const char *origin, bool create){
    for(int i=0;i<WS_MAX_STORES;i++){
        if(g_ws_session[i].origin[0]&&strcmp(g_ws_session[i].origin,origin)==0)
            return &g_ws_session[i];
    }
    if(!create) return NULL;
    for(int i=0;i<WS_MAX_STORES;i++){
        if(!g_ws_session[i].origin[0]){
            strncpy(g_ws_session[i].origin,origin,63);
            g_ws_session[i].origin[63]='\0';
            return &g_ws_session[i];
        }
    }
    return NULL;
}

/* ── JSON escape/unescape (minimal) ────────────────────────────── */
static void json_escape(const char *in, char *out, int sz){
    int o=0;
    for(const char *p=in;*p&&o<sz-2;p++){
        if(*p=='"'||*p=='\\'){ if(o<sz-2) out[o++]='\\'; }
        if(o<sz-1) out[o++]=*p;
    }
    out[o]='\0';
}
static void json_unescape(const char *in, char *out, int sz){
    int o=0; bool esc=false;
    for(const char *p=in;*p&&o<sz-1;p++){
        if(esc){ out[o++]=*p; esc=false; }
        else if(*p=='\\') esc=true;
        else out[o++]=*p;
    }
    out[o]='\0';
}

/* ── Flush to SD ─────────────────────────────────────────────────── */

bool ws_local_flush(const char *origin){
    WSStore *st=get_local_store(origin,false);
    if(!st) return false;
    char path[256]; snprintf(path,sizeof(path),WS_LOCAL_FILE,origin);
    FILE *f=fopen(path,"w");
    if(!f) return false;
    fprintf(f,"{\n");
    bool first=true;
    for(int i=0;i<WS_MAX_ENTRIES;i++){
        if(!st->entries[i].used) continue;
        char ek[WS_MAX_KEY*2], ev[WS_MAX_VAL*2];
        json_escape(st->entries[i].key,ek,sizeof(ek));
        json_escape(st->entries[i].val,ev,sizeof(ev));
        fprintf(f,"%s\"%s\":\"%s\"\n",first?"":",",ek,ev);
        first=false;
    }
    fprintf(f,"}\n");
    fclose(f);
    st->dirty=false;
    return true;
}

bool ws_local_load(const char *origin){
    char path[256]; snprintf(path,sizeof(path),WS_LOCAL_FILE,origin);
    FILE *f=fopen(path,"r");
    if(!f) return false;
    WSStore *st=get_local_store(origin,true);
    if(!st){ fclose(f); return false; }
    /* simple JSON parser for flat KV */
    char buf[WS_MAX_VAL*4]; int n=(int)fread(buf,1,sizeof(buf)-1,f); fclose(f); buf[n]='\0';
    const char *p=buf;
    while(*p){
        /* find '"key"' */
        while(*p&&*p!='"') p++;
        if(!*p) break; p++;
        char key[WS_MAX_KEY]; int ki=0;
        while(*p&&*p!='"'&&ki<WS_MAX_KEY-1) key[ki++]=*p++;
        key[ki]='\0'; if(*p=='"') p++;
        /* find ':' */
        while(*p&&*p!=':') p++; if(*p==':') p++;
        /* find '"val"' */
        while(*p&&*p!='"') p++; if(*p=='"') p++;
        char val[WS_MAX_VAL]; int vi=0;
        bool esc2=false;
        while(*p&&vi<WS_MAX_VAL-1){
            if(esc2){ val[vi++]=*p++; esc2=false; }
            else if(*p=='\\'){esc2=true;p++;}
            else if(*p=='"'){ p++; break; }
            else val[vi++]=*p++;
        }
        val[vi]='\0';
        (void)esc2;
        if(*key) ws_local_set(origin,key,val);
    }
    return true;
}

/* ── localStorage API ────────────────────────────────────────────── */

bool ws_local_set(const char *origin, const char *key, const char *val){
    WSStore *st=get_local_store(origin,true);
    if(!st) return false;
    /* find existing */
    for(int i=0;i<WS_MAX_ENTRIES;i++){
        if(st->entries[i].used&&strcmp(st->entries[i].key,key)==0){
            strncpy(st->entries[i].val,val,WS_MAX_VAL-1);
            st->entries[i].val[WS_MAX_VAL-1]='\0';
            st->dirty=true; return true;
        }
    }
    /* add new */
    for(int i=0;i<WS_MAX_ENTRIES;i++){
        if(!st->entries[i].used){
            strncpy(st->entries[i].key,key,WS_MAX_KEY-1);
            st->entries[i].key[WS_MAX_KEY-1]='\0';
            strncpy(st->entries[i].val,val,WS_MAX_VAL-1);
            st->entries[i].val[WS_MAX_VAL-1]='\0';
            st->entries[i].used=true;
            st->count++;
            st->dirty=true;
            ws_local_flush(origin);
            return true;
        }
    }
    return false;
}

bool ws_local_get(const char *origin, const char *key, char *out, int sz){
    WSStore *st=get_local_store(origin,false);
    if(!st) return false;
    for(int i=0;i<WS_MAX_ENTRIES;i++){
        if(st->entries[i].used&&strcmp(st->entries[i].key,key)==0){
            strncpy(out,st->entries[i].val,sz-1); out[sz-1]='\0'; return true;
        }
    }
    return false;
}

bool ws_local_del(const char *origin, const char *key){
    WSStore *st=get_local_store(origin,false);
    if(!st) return false;
    for(int i=0;i<WS_MAX_ENTRIES;i++){
        if(st->entries[i].used&&strcmp(st->entries[i].key,key)==0){
            st->entries[i].used=false; st->count--;
            st->dirty=true;
            ws_local_flush(origin);
            return true;
        }
    }
    return false;
}

void ws_local_clear(const char *origin){
    WSStore *st=get_local_store(origin,false);
    if(!st) return;
    for(int i=0;i<WS_MAX_ENTRIES;i++) st->entries[i].used=false;
    st->count=0; st->dirty=true;
    ws_local_flush(origin);
}

int ws_local_count(const char *origin){
    WSStore *st=get_local_store(origin,false);
    return st?st->count:0;
}

bool ws_local_key(const char *origin, int idx, char *out, int sz){
    WSStore *st=get_local_store(origin,false);
    if(!st) return false;
    int n=0;
    for(int i=0;i<WS_MAX_ENTRIES;i++){
        if(st->entries[i].used){ if(n==idx){ strncpy(out,st->entries[i].key,sz-1); out[sz-1]='\0'; return true; } n++; }
    }
    return false;
}

/* sessionStorage is in-memory only */
bool ws_session_set(const char *origin, const char *key, const char *val){ WSStore *st=get_session_store(origin,true); if(!st) return false; for(int i=0;i<WS_MAX_ENTRIES;i++){ if(st->entries[i].used&&strcmp(st->entries[i].key,key)==0){ strncpy(st->entries[i].val,val,WS_MAX_VAL-1); return true; } } for(int i=0;i<WS_MAX_ENTRIES;i++){ if(!st->entries[i].used){ strncpy(st->entries[i].key,key,WS_MAX_KEY-1); strncpy(st->entries[i].val,val,WS_MAX_VAL-1); st->entries[i].used=true; st->count++; return true; } } return false; }
bool ws_session_get(const char *origin, const char *key, char *out, int sz){ WSStore *st=get_session_store(origin,false); if(!st) return false; for(int i=0;i<WS_MAX_ENTRIES;i++){ if(st->entries[i].used&&strcmp(st->entries[i].key,key)==0){ strncpy(out,st->entries[i].val,sz-1); out[sz-1]='\0'; return true; } } return false; }
bool ws_session_del(const char *origin, const char *key){ WSStore *st=get_session_store(origin,false); if(!st) return false; for(int i=0;i<WS_MAX_ENTRIES;i++){ if(st->entries[i].used&&strcmp(st->entries[i].key,key)==0){ st->entries[i].used=false; st->count--; return true; } } return false; }
void ws_session_clear(const char *origin){ WSStore *st=get_session_store(origin,false); if(!st) return; for(int i=0;i<WS_MAX_ENTRIES;i++) st->entries[i].used=false; st->count=0; }

/* ── Cookie (simplified) ─────────────────────────────────────────── */
bool ws_cookie_set(const char *name, const char *val, int max_age_s){ (void)max_age_s; return ws_local_set("__cookies__",name,val); }
bool ws_cookie_get(const char *name, char *out, int sz){ return ws_local_get("__cookies__",name,out,sz); }
void ws_cookie_clear(void){ ws_local_clear("__cookies__"); }

/* ── IndexedDB (simplified KV over files) ────────────────────────── */
int ws_idb_open(const char *origin, const char *name){
    for(int i=0;i<WS_IDB_MAX_STORES;i++){
        if(!g_ws_idb[i].used){
            strncpy(g_ws_idb[i].origin,origin,63); strncpy(g_ws_idb[i].name,name,63);
            g_ws_idb[i].used=true;
            char dir[256]; snprintf(dir,sizeof(dir),"sdmc:/3ds/pocketcompiler/storage/idb/%s/",name);
            mkdir(dir,0777);
            return i;
        }
    }
    return -1;
}
bool ws_idb_put(int db, const char *store, const char *key, const char *json){
    if(db<0||db>=WS_IDB_MAX_STORES) return false;
    char path[256]; snprintf(path,sizeof(path),"sdmc:/3ds/pocketcompiler/storage/idb/%s/%s_%s.json",g_ws_idb[db].name,store,key);
    FILE *f=fopen(path,"w"); if(!f) return false;
    fputs(json,f); fclose(f); return true;
}
bool ws_idb_get(int db, const char *store, const char *key, char *out, int sz){
    if(db<0||db>=WS_IDB_MAX_STORES) return false;
    char path[256]; snprintf(path,sizeof(path),"sdmc:/3ds/pocketcompiler/storage/idb/%s/%s_%s.json",g_ws_idb[db].name,store,key);
    FILE *f=fopen(path,"r"); if(!f) return false;
    int n=(int)fread(out,1,sz-1,f); fclose(f); out[n]='\0'; return true;
}
bool ws_idb_delete(int db, const char *store, const char *key){
    if(db<0||db>=WS_IDB_MAX_STORES) return false;
    char path[256]; snprintf(path,sizeof(path),"sdmc:/3ds/pocketcompiler/storage/idb/%s/%s_%s.json",g_ws_idb[db].name,store,key);
    return remove(path)==0;
}
bool ws_idb_clear(int db, const char *store){ (void)db;(void)store; return true; }
void ws_idb_close(int db){ if(db>=0&&db<WS_IDB_MAX_STORES) g_ws_idb[db].used=false; }

/* ── Duktape bindings ────────────────────────────────────────────── */

static duk_ret_t ws_js_setItem(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__origin"); const char *origin=duk_safe_to_string(ctx,-1); duk_pop(ctx);
    duk_get_prop_string(ctx,-1,"__session"); bool sess=duk_to_boolean(ctx,-1); duk_pop(ctx);
    duk_pop(ctx);
    const char *key=duk_safe_to_string(ctx,0);
    const char *val=duk_safe_to_string(ctx,1);
    if(sess) ws_session_set(origin,key,val);
    else ws_local_set(origin,key,val);
    return 0;
}

static duk_ret_t ws_js_getItem(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__origin"); const char *origin=duk_safe_to_string(ctx,-1); duk_pop(ctx);
    duk_get_prop_string(ctx,-1,"__session"); bool sess=duk_to_boolean(ctx,-1); duk_pop(ctx);
    duk_pop(ctx);
    const char *key=duk_safe_to_string(ctx,0);
    char val[WS_MAX_VAL];
    bool ok=sess?ws_session_get(origin,key,val,sizeof(val)):ws_local_get(origin,key,val,sizeof(val));
    if(ok) duk_push_string(ctx,val); else duk_push_null(ctx);
    return 1;
}

static duk_ret_t ws_js_removeItem(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__origin"); const char *origin=duk_safe_to_string(ctx,-1); duk_pop(ctx);
    duk_get_prop_string(ctx,-1,"__session"); bool sess=duk_to_boolean(ctx,-1); duk_pop(ctx);
    duk_pop(ctx);
    const char *key=duk_safe_to_string(ctx,0);
    if(sess) ws_session_del(origin,key); else ws_local_del(origin,key);
    return 0;
}

static duk_ret_t ws_js_clear(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__origin"); const char *origin=duk_safe_to_string(ctx,-1); duk_pop(ctx);
    duk_get_prop_string(ctx,-1,"__session"); bool sess=duk_to_boolean(ctx,-1); duk_pop(ctx);
    duk_pop(ctx);
    if(sess) ws_session_clear(origin); else ws_local_clear(origin);
    return 0;
}

static duk_ret_t ws_js_key(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__origin"); const char *origin=duk_safe_to_string(ctx,-1); duk_pop(ctx);
    duk_pop(ctx);
    int idx=duk_to_int(ctx,0);
    char key[WS_MAX_KEY];
    if(ws_local_key(origin,idx,key,sizeof(key))) duk_push_string(ctx,key);
    else duk_push_null(ctx);
    return 1;
}

static void push_storage_obj(duk_context *ctx, const char *origin, bool session){
    duk_push_object(ctx);
    duk_push_string(ctx,origin); duk_put_prop_string(ctx,-2,"__origin");
    duk_push_boolean(ctx,session); duk_put_prop_string(ctx,-2,"__session");
    duk_push_c_function(ctx,ws_js_setItem,2);    duk_put_prop_string(ctx,-2,"setItem");
    duk_push_c_function(ctx,ws_js_getItem,1);    duk_put_prop_string(ctx,-2,"getItem");
    duk_push_c_function(ctx,ws_js_removeItem,1); duk_put_prop_string(ctx,-2,"removeItem");
    duk_push_c_function(ctx,ws_js_clear,0);      duk_put_prop_string(ctx,-2,"clear");
    duk_push_c_function(ctx,ws_js_key,1);        duk_put_prop_string(ctx,-2,"key");
    duk_push_int(ctx,ws_local_count(origin));    duk_put_prop_string(ctx,-2,"length");
}

void ws_install_local(duk_context *ctx, const char *origin){
    duk_push_global_object(ctx);
    push_storage_obj(ctx,origin,false); duk_put_prop_string(ctx,-2,"localStorage");
    duk_pop(ctx);
}

void ws_install_session(duk_context *ctx, const char *origin){
    duk_push_global_object(ctx);
    push_storage_obj(ctx,origin,true); duk_put_prop_string(ctx,-2,"sessionStorage");
    duk_pop(ctx);
}

void ws_install_idb(duk_context *ctx, const char *origin){
    /* Minimal IndexedDB stub */
    (void)ctx; (void)origin;
}

void ws_install_cookies(duk_context *ctx){
    (void)ctx;
}
