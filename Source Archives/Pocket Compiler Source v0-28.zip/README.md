# Pocket Compiler v0.26 Crash-Hardened Full Source

This build is designed to fix persistent Nintendo 3DS runtime crashes such as:

```text
Exception type: data abort
Fault status: Translation - Section
```

That crash usually means the app touched invalid/unmapped memory. In earlier builds, the most likely causes were graphics/audio initialization paths, split render-frame lifecycles, invalid render targets, or risky startup allocations.

## What changed

This version keeps the existing feature direction but uses a much safer default runtime:

- libctru console rendering by default
- no forced Citro2D/Citro3D frame lifecycle
- no forced NDSP/audio startup
- no large startup heap/linear allocations
- static global runtime objects
- bounded editor buffer
- safe no-op feature modules
- save/load support retained
- controls retained
- feature counters/status retained

## Preserved feature areas

The project still keeps modules/scaffolding for:

- HTML/CSS/JS editing
- project save/load
- DOM events
- iframe support
- IndexedDB-style storage
- API/fetch layer
- canvas/WebGL-like runtime
- image/asset pipeline
- Web Audio subset

But risky systems are disabled/lazy by default so the app can boot reliably first.

## Build

```bash
make clean
make
```

Output:

```text
PocketCompiler.3dsx
```

## If this build still crashes

Please record these crash-screen fields:

```text
PC
LR
FAR
R0
R1
SP
```

Especially:

- `PC`
- `FAR`

If `FAR` is near `00000000`, it is almost certainly a null pointer.
