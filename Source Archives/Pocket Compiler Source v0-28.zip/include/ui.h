#pragma once
#include "app.h"
#include "editor.h"
#include "runtime_features.h"

void ui_init(void);
void ui_shutdown(void);
void ui_draw(const AppState* app, const Editor* editor, const FeatureRuntime* rt);
bool ui_edit_line(Editor* editor, int line, AppState* app);
