#pragma once
#include "app.h"
#include <stdbool.h>

typedef struct {
    bool dom_events;
    bool iframe;
    bool indexeddb;
    bool api_fetch;
    bool canvas;
    bool webgl;
    bool images;
    bool web_audio;
    bool local_storage;
    bool cache_api;

    int compile_count;
    int event_count;
    int storage_count;
    int draw_count;

    char last_message[256];
} FeatureRuntime;

void runtime_init(FeatureRuntime* rt);
void runtime_scan_html(FeatureRuntime* rt, const char* html);
void runtime_tick(FeatureRuntime* rt);
void runtime_mark_event(FeatureRuntime* rt, const char* event_name);
