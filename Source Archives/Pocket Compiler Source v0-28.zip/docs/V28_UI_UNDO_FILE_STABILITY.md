# v0.28 UI / Undo / Save-Load Stability Fix

## Fixed visual artifact

The previous raw-framebuffer clearing approach could itself cause subtle artifacts or instability.

This patch removes:

- raw framebuffer writes
- forced double-buffer disabling
- one-column left margin

It returns to normal console rendering with `consoleClear()`.

## Fixed undo crash

Undo is now hardened:

- checks for valid undo buffer
- always null-terminates
- clamps cursor
- does not snapshot uninitialized memory during first editor set

## Fixed save/load crash

The likely crash cause was a large function-local buffer:

```c
char buffer[EDITOR_MAX];
```

That is about 64 KB on the stack, which can be dangerous on 3DS.

This patch uses a static file load buffer instead.

## Other safety improvements

- project names are sanitized
- `.html` is added automatically
- `.html.html` is avoided
- save/load directories are created before use
