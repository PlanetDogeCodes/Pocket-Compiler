# v0.27b Visual Fix Compile Fix

## Fixed

The previous v0.27 patch changed:

```c
void ui_init(void)
```

to:

```c
bool ui_init(void)
```

but your current `include/ui.h` still declares:

```c
void ui_init(void);
```

This caused a compile error.

## This patch

- keeps `ui_init()` as `void`
- preserves the framebuffer clearing fix
- does not require editing `include/ui.h`
- does not require editing `main.c`
- does not remove any features
