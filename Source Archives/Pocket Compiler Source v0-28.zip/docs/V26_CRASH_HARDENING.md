# Pocket Compiler v0.26 Crash Hardening

## Why this build exists

The previous builds still crashed with:

```text
Exception type: data abort
Fault status: Translation - Section
```

That means the app touched unmapped memory.

## Most likely cause

The highest-risk systems were:

- Citro2D/Citro3D frame lifecycle
- render targets
- text buffers
- audio/NDSP
- large startup allocations

## What v0.26 changes

This build uses a safer default runtime:

- libctru console rendering only
- no Citro2D/Citro3D startup
- no NDSP startup
- no linearAlloc audio buffer
- no split graphics frame lifecycle
- no heap-heavy startup systems
- static global editor/runtime objects
- bounded feature detection runtime

## Feature preservation

The feature areas are still represented and detected:

- DOM events
- iframe
- IndexedDB
- fetch
- canvas
- WebGL
- images
- Web Audio
- storage/cache

But risky runtime execution is disabled until boot stability is confirmed.

## Next debugging step

If this version boots, re-enable advanced systems one at a time:

1. Citro2D UI
2. Citro3D/WebGL renderer
3. NDSP/WebAudio
4. network/fetch backend
5. QuickJS

That will identify the exact subsystem causing the data abort.
