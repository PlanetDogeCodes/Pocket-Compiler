# v0.28b File Explorer Header Fix

## Fixed

Missing header:

```text
include/file_explorer.h
```

## Why it happened

The stability patch included `source/file_explorer.c`, but your current project did not have the matching declaration header.

## No features removed

This only adds declarations for the existing save/load mini file explorer.
