# Homebrew Metadata

Pocket Compiler should use the following Makefile metadata:

```make
APP_TITLE := Pocket Compiler
APP_DESCRIPTION := Compile, Edit, and Run HTML/JS/CSS on your 3DS
APP_AUTHOR := PlanetDogeCodes
```

These values are used by devkitPro's 3DS build rules to generate Homebrew Launcher metadata.

After changing metadata, rebuild:

```bash
make clean
make
```
