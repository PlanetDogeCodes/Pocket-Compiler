# v0.27 Left-Side Visual Fix

## Symptom

A strange black visual line or stripe appears on the left side of the top screen. Sometimes it appears as one line, sometimes two.

## Likely reason

The framebuffer contains stale pixels that are not fully cleared by the console renderer.

## Fix strategy

- disable double buffering in console safe mode
- manually clear full raw framebuffer memory
- clear top left/right framebuffers
- clear bottom framebuffer
- draw console UI after full clear
- avoid writing at the absolute left edge where possible

## If the issue remains

If this patch does not fix it, the next thing to try is moving away from libctru console rendering entirely and drawing text with Citro2D using explicit full-screen clear rectangles.
