#!/usr/bin/env python3
from pathlib import Path
import re
import sys

MAKEFILE = Path("Makefile")

APP_TITLE = "Pocket Compiler"
APP_DESCRIPTION = "Compile, Edit, and Run HTML/JS/CSS on your 3DS"
APP_AUTHOR = "PlanetDogeCodes"

def set_make_var(text: str, name: str, value: str) -> str:
    # Replace active or commented assignment.
    pattern = rf"(?m)^\s*#?\s*{re.escape(name)}\s*:=\s*.*$"
    replacement = f"{name} := {value}"

    if re.search(pattern, text):
        return re.sub(pattern, replacement, text, count=1)

    # Insert after INCLUDES if possible, else after TARGET, else at top.
    insert_after_patterns = [
        r"(?m)^INCLUDES\s*:=\s*.*$",
        r"(?m)^SOURCES\s*:=\s*.*$",
        r"(?m)^TARGET\s*:=\s*.*$",
    ]

    for pat in insert_after_patterns:
        m = re.search(pat, text)
        if m:
            pos = m.end()
            return text[:pos] + f"\n{replacement}" + text[pos:]

    return replacement + "\n" + text

def main() -> int:
    if not MAKEFILE.exists():
        print("ERROR: Makefile not found. Run this from the Pocket Compiler project root.")
        return 1

    text = MAKEFILE.read_text(encoding="utf-8")
    original = text

    text = set_make_var(text, "APP_TITLE", APP_TITLE)
    text = set_make_var(text, "APP_DESCRIPTION", APP_DESCRIPTION)
    text = set_make_var(text, "APP_AUTHOR", APP_AUTHOR)

    if text != original:
        MAKEFILE.write_text(text, encoding="utf-8")
        print("Updated Makefile metadata:")
    else:
        print("Makefile metadata was already up to date:")

    print(f"APP_TITLE := {APP_TITLE}")
    print(f"APP_DESCRIPTION := {APP_DESCRIPTION}")
    print(f"APP_AUTHOR := {APP_AUTHOR}")

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
