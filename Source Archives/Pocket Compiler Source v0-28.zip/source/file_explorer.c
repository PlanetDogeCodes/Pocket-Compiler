#include "file_explorer.h"
#include "fs_io.h"

#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>

static char s_load_buffer[EDITOR_MAX];

static void sanitize_filename(const char* in, char* out, size_t out_size) {
    if (!out || out_size == 0) return;
    if (!in) in = "";

    size_t j = 0;
    for (size_t i = 0; in[i] && j + 1 < out_size; i++) {
        unsigned char c = (unsigned char)in[i];

        if (isalnum(c) || c == '_' || c == '-' || c == '.') {
            out[j++] = (char)c;
        } else {
            out[j++] = '_';
        }
    }

    out[j] = 0;

    if (!out[0]) snprintf(out, out_size, "project");
}

static void ensure_html_extension(char* name, size_t size) {
    size_t len = strlen(name);
    if (len >= 5 && strcmp(name + len - 5, ".html") == 0) return;
    if (len + 5 < size) strcat(name, ".html");
}

void file_explorer_init(FileExplorer* fx) {
    if (!fx) return;
    memset(fx, 0, sizeof(*fx));
}

bool file_explorer_refresh(FileExplorer* fx) {
    if (!fx) return false;

    fs_make_app_dirs();

    fx->count = 0;
    fx->selected = 0;

    DIR* d = opendir(APP_PROJECT_DIR);
    if (!d) return false;

    struct dirent* de;
    while ((de = readdir(d)) && fx->count < FILE_EXPLORER_MAX_FILES) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;

        snprintf(fx->names[fx->count], FILE_EXPLORER_NAME_MAX, "%s", de->d_name);
        fx->count++;
    }

    closedir(d);
    return true;
}

static bool ask_filename(char* out, size_t out_size, const char* hint) {
    if (!out || out_size == 0) return false;
    out[0] = 0;

    SwkbdState kbd;
    swkbdInit(&kbd, SWKBD_TYPE_NORMAL, 2, out_size - 1);
    swkbdSetHintText(&kbd, hint ? hint : "Project name");
    swkbdSetButton(&kbd, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&kbd, SWKBD_BUTTON_RIGHT, "OK", true);

    return swkbdInputText(&kbd, out, out_size) == SWKBD_BUTTON_RIGHT && out[0];
}

bool file_explorer_save_dialog(FileExplorer* fx, Editor* editor, AppState* app) {
    if (!fx || !editor) return false;

    fs_make_app_dirs();

    char input[FILE_EXPLORER_NAME_MAX];
    char safe[FILE_EXPLORER_NAME_MAX];

    if (!ask_filename(input, sizeof(input), "Save project name")) {
        if (app) app_status(app, "Save cancelled.");
        return false;
    }

    sanitize_filename(input, safe, sizeof(safe));
    ensure_html_extension(safe, sizeof(safe));

    char path[256];
    snprintf(path, sizeof(path), "%s/%s", APP_PROJECT_DIR, safe);

    if (fs_save_text(path, editor_text(editor))) {
        snprintf(fx->last_path, sizeof(fx->last_path), "%s", path);
        file_explorer_refresh(fx);
        if (app) app_status(app, "Saved: %s", safe);
        return true;
    }

    if (app) app_status(app, "Save failed.");
    return false;
}

bool file_explorer_load_dialog(FileExplorer* fx, Editor* editor, AppState* app) {
    if (!fx || !editor) return false;

    fs_make_app_dirs();
    file_explorer_refresh(fx);

    char input[FILE_EXPLORER_NAME_MAX];
    char safe[FILE_EXPLORER_NAME_MAX];

    if (!ask_filename(input, sizeof(input), "Load project name")) {
        if (app) app_status(app, "Load cancelled.");
        return false;
    }

    sanitize_filename(input, safe, sizeof(safe));
    ensure_html_extension(safe, sizeof(safe));

    char path[256];
    snprintf(path, sizeof(path), "%s/%s", APP_PROJECT_DIR, safe);

    memset(s_load_buffer, 0, sizeof(s_load_buffer));

    if (fs_load_text(path, s_load_buffer, sizeof(s_load_buffer))) {
        editor_set(editor, s_load_buffer);
        snprintf(fx->last_path, sizeof(fx->last_path), "%s", path);
        if (app) app_status(app, "Loaded: %s", safe);
        return true;
    }

    if (app) app_status(app, "Load failed.");
    return false;
}
