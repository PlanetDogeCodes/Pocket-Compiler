#include "runtime_features.h"
#include <string.h>
#include <stdio.h>

static bool has(const char* text, const char* needle) {
    return text && needle && strstr(text, needle) != NULL;
}

void runtime_init(FeatureRuntime* rt) {
    if (!rt) return;
    memset(rt, 0, sizeof(*rt));
    snprintf(rt->last_message, sizeof(rt->last_message), "Runtime ready (safe mode)");
}

void runtime_scan_html(FeatureRuntime* rt, const char* html) {
    if (!rt) return;

    rt->dom_events = has(html, "addEventListener") || has(html, "onclick");
    rt->iframe = has(html, "<iframe");
    rt->indexeddb = has(html, "indexedDB");
    rt->api_fetch = has(html, "fetch(");
    rt->canvas = has(html, "<canvas");
    rt->webgl = has(html, "webgl") || has(html, "getContext");
    rt->images = has(html, "<img");
    rt->web_audio = has(html, "AudioContext") || has(html, "new Audio") || has(html, "<audio");
    rt->local_storage = has(html, "localStorage") || has(html, "sessionStorage");
    rt->cache_api = has(html, "caches.");

    rt->compile_count++;

    if (rt->canvas || rt->webgl) rt->draw_count++;
    if (rt->indexeddb || rt->local_storage || rt->cache_api) rt->storage_count++;

    snprintf(rt->last_message, sizeof(rt->last_message), "Compiled in crash-hardened safe mode");
}

void runtime_tick(FeatureRuntime* rt) {
    if (!rt) return;
}

void runtime_mark_event(FeatureRuntime* rt, const char* event_name) {
    if (!rt) return;
    rt->event_count++;
    snprintf(rt->last_message, sizeof(rt->last_message), "Event: %s", event_name ? event_name : "unknown");
}
