#include <3ds.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "app.h"
#include "editor.h"
#include "fs_io.h"
#include "runtime_features.h"
#include "ui.h"

static const char* sample =
"<!doctype html>\n"
"<html>\n"
"<head><title>Pocket Compiler Safe</title></head>\n"
"<body>\n"
"<h1>Crash Hardened Build</h1>\n"
"<canvas id='game'></canvas>\n"
"<iframe id='fr'></iframe>\n"
"<script>\n"
"console.log('safe mode');\n"
"fetch('https://example.com');\n"
"indexedDB.open('cache',1);\n"
"</script>\n"
"</body>\n"
"</html>\n";

static Editor ed;
static FeatureRuntime runtime;

void app_status(AppState* app, const char* fmt, ...) {
    if (!app) return;
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(app->status, sizeof(app->status), fmt, ap);
    va_end(ap);
}

static void save_project(AppState* app) {
    fs_make_app_dirs();
    if (fs_save_text(APP_FILE, editor_text(&ed))) app_status(app, "Saved: %s", APP_FILE);
    else app_status(app, "Save failed.");
}

static void load_project(AppState* app) {
    char buf[EDITOR_MAX];
    if (fs_load_text(APP_FILE, buf, sizeof(buf))) {
        editor_set(&ed, buf);
        app_status(app, "Loaded: %s", APP_FILE);
    } else {
        app_status(app, "Load failed.");
    }
}

static void run_compile(AppState* app) {
    runtime_scan_html(&runtime, editor_text(&ed));
    app_status(app, "Compiled safely.");
}

int main(int argc, char** argv) {
    (void)argc;
    (void)argv;

    gfxInitDefault();

    AppState app;
    memset(&app, 0, sizeof(app));
    app.running = true;
    app_status(&app, "Boot OK.");

    editor_init(&ed);
    editor_set(&ed, sample);
    runtime_init(&runtime);
    fs_make_app_dirs();
    ui_init();

    run_compile(&app);

    while (aptMainLoop() && app.running) {
        hidScanInput();
        u32 down = hidKeysDown();

        if (down & KEY_START) run_compile(&app);
        if (down & KEY_SELECT) app.show_controls = !app.show_controls;

        if (down & KEY_B) {
            if (editor_undo(&ed)) app_status(&app, "Undo.");
            else app_status(&app, "Nothing to undo.");
        }

        if (down & KEY_X) save_project(&app);
        if (down & KEY_Y) load_project(&app);

        if (down & KEY_UP) editor_move_up(&ed);
        if (down & KEY_DOWN) editor_move_down(&ed);
        if (down & KEY_LEFT) editor_move_left(&ed);
        if (down & KEY_RIGHT) editor_move_right(&ed);

        if (down & KEY_A) {
            int line = ed.scroll_line;
            if (ui_edit_line(&ed, line, &app)) {
                app.dirty = true;
                runtime_mark_event(&runtime, "edit");
            }
        }

        runtime_tick(&runtime);
        ui_draw(&app, &ed, &runtime);

        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }

    ui_shutdown();
    gfxExit();
    return 0;
}
