#include "ui.h"

#include <3ds.h>
#include <stdio.h>
#include <string.h>

static PrintConsole s_top;
static PrintConsole s_bottom;
static bool s_ready = false;

static void print_limited(const char* s, int max_chars) {
    if (!s) return;
    for (int i = 0; s[i] && i < max_chars; i++) {
        putchar(s[i]);
    }
}

/*
 * Keep signature as void to match existing include/ui.h.
 *
 * Important:
 * - Do not manually clear raw framebuffers.
 * - Do not disable double buffering here.
 * - Let libctru console/gfx lifecycle behave normally.
 *
 * This avoids both compile mismatch issues and possible framebuffer-related
 * visual artifacts/crashes.
 */
void ui_init(void) {
    consoleInit(GFX_TOP, &s_top);
    consoleInit(GFX_BOTTOM, &s_bottom);
    s_ready = true;
}

void ui_shutdown(void) {
    s_ready = false;
}

bool ui_edit_line(Editor* editor, int line, AppState* app) {
    if (!editor || line < 0) return false;

    char current[512];
    current[0] = 0;

    editor_get_line(editor, line, current, sizeof(current));

    SwkbdState kbd;
    char input[512];
    snprintf(input, sizeof(input), "%s", current);

    swkbdInit(&kbd, SWKBD_TYPE_NORMAL, 2, sizeof(input) - 1);
    swkbdSetInitialText(&kbd, input);
    swkbdSetHintText(&kbd, "Edit line");
    swkbdSetButton(&kbd, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&kbd, SWKBD_BUTTON_RIGHT, "Apply", true);

    if (swkbdInputText(&kbd, input, sizeof(input)) == SWKBD_BUTTON_RIGHT) {
        if (editor_replace_line(editor, line, input)) {
            if (app) app_status(app, "Edited line %d.", line + 1);
            return true;
        }
        if (app) app_status(app, "Line edit failed.");
    }

    return false;
}

void ui_draw(const AppState* app, const Editor* editor, const FeatureRuntime* rt) {
    if (!s_ready) return;

    consoleSelect(&s_top);
    consoleClear();

    /*
     * Draw at column 0 again. The previous margin could itself appear as a
     * persistent black line depending on the screen/background.
     */
    printf("\x1b[0;0HPocket Compiler v0.28 Safe Mode");
    printf("\x1b[1;0H----------------------------------------");

    if (rt) {
        printf("\x1b[3;0HCompile count: %d", rt->compile_count);
        printf("\x1b[4;0HEvents: %d  Draws: %d  Storage: %d",
               rt->event_count,
               rt->draw_count,
               rt->storage_count);

        printf("\x1b[6;0HDetected features:");
        printf("\x1b[7;0HDOM:%d iframe:%d IDB:%d fetch:%d",
               rt->dom_events,
               rt->iframe,
               rt->indexeddb,
               rt->api_fetch);

        printf("\x1b[8;0Hcanvas:%d webgl:%d img:%d audio:%d",
               rt->canvas,
               rt->webgl,
               rt->images,
               rt->web_audio);

        printf("\x1b[10;0H");
        print_limited(rt->last_message, 48);
    }

    if (app) {
        printf("\x1b[28;0H");
        print_limited(app->status, 48);
    }

    consoleSelect(&s_bottom);
    consoleClear();

    printf("\x1b[0;0HSTART Run  SELECT Help  A Edit  B Undo");
    printf("\x1b[1;0HX Save  Y Load  DPad Scroll/Move");
    printf("\x1b[2;0H----------------------------------------");

    if (editor) {
        const char* p = editor->text;
        int line_no = 0;
        int row = 3;

        while (*p && row < 28) {
            const char* start = p;
            int len = 0;

            while (p[len] && p[len] != '\n') len++;

            if (line_no >= editor->scroll_line) {
                printf("\x1b[%d;0H%02d ", row, line_no + 1);

                char line[64];
                int n = len < 34 ? len : 34;
                memcpy(line, start, (size_t)n);
                line[n] = 0;

                print_limited(line, 34);
                row++;
            }

            p += len;
            if (*p == '\n') p++;
            line_no++;
        }
    }

    if (app && app->show_controls) {
        consoleSelect(&s_bottom);
        consoleClear();

        printf("\x1b[0;0HControls");
        printf("\x1b[2;0HDPad: Scroll/move");
        printf("\x1b[3;0HA: Edit current visible line");
        printf("\x1b[4;0HB: Undo");
        printf("\x1b[5;0HX: Save to SD");
        printf("\x1b[6;0HY: Load from SD");
        printf("\x1b[7;0HSTART: Run/compile");
        printf("\x1b[8;0HSELECT: Close menu");
    }
}
