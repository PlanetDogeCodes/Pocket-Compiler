/*
 * web_render.c  —  Citro2D renderer for the web engine
 */
#include "web_render.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "lodepng.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

WEImage g_we_images[WE_MAX_IMAGES];
int     g_we_image_n=0;

WECanvas g_we_canvas[WE_MAX_CANVAS];

/* ── Utility color conversion ────────────────────────────────────── */
/* RGBA8 (0xRRGGBBAA) → Citro2D u32 (ABGR) */
static u32 to_c2d(uint32_t rgba){
    uint8_t r=(rgba>>24)&0xFF;
    uint8_t g=(rgba>>16)&0xFF;
    uint8_t b=(rgba>>8)&0xFF;
    uint8_t a=rgba&0xFF;
    return C2D_Color32(r,g,b,a);
}

/* ── Init / exit ─────────────────────────────────────────────────── */

void wrender_init(void){
    memset(g_we_images,0,sizeof(g_we_images));
    memset(g_we_canvas,0,sizeof(g_we_canvas));
    g_we_image_n=0;
}

void wrender_exit(void){
    for(int i=0;i<WE_MAX_IMAGES;i++){
        if(g_we_images[i].loaded){
            C3D_TexDelete(&g_we_images[i].tex);
            g_we_images[i].loaded=false;
        }
    }
    for(int i=0;i<WE_MAX_CANVAS;i++){
        if(g_we_canvas[i].used) wrender_free_canvas((uint16_t)i);
    }
}

/* ── Rounded rectangle ───────────────────────────────────────────── */

void wrender_rounded_rect(float x, float y, float w, float h, float r, uint32_t col){
    u32 c=to_c2d(col);
    if(r<=0){
        C2D_DrawRectSolid(x,y,0,w,h,c);
        return;
    }
    if(r>w/2) r=w/2;
    if(r>h/2) r=h/2;
    /* center rect */
    C2D_DrawRectSolid(x+r,y,0,w-2*r,h,c);
    /* left/right strips */
    C2D_DrawRectSolid(x,y+r,0,r,h-2*r,c);
    C2D_DrawRectSolid(x+w-r,y+r,0,r,h-2*r,c);
    /* four corners */
    C2D_DrawCircleSolid(x+r,   y+r,   0,r,c);
    C2D_DrawCircleSolid(x+w-r, y+r,   0,r,c);
    C2D_DrawCircleSolid(x+r,   y+h-r, 0,r,c);
    C2D_DrawCircleSolid(x+w-r, y+h-r, 0,r,c);
}

/* ── Text rendering ──────────────────────────────────────────────── */
/*
 * Scale mapping: citro2d system font at scale=1.0 renders ~30px tall.
 * Therefore: scale = size_px / 30.0f gives correctly-sized text.
 *   14px (UA body default) → 0.467  (readable body text)
 *   22px (UA h1)           → 0.733  (clearly larger heading)
 *   18px (UA h2)           → 0.600  (sub-heading)
 *   11px (CSS_DEFAULT)     → 0.367  (small fallback)
 *
 * v0.40 audit fix: this function now actually applies font-weight
 * (bold), font-style (italic), and text-decoration (underline /
 * line-through). The old code accepted these as parameters but
 * immediately cast them to (void), so none of them had any visible
 * effect — bold/italic/underlined text rendered identically to
 * plain text. The citro2d system font doesn't have true bold/italic
 * variants, so bold is faked by drawing the text twice with a 1px
 * horizontal offset (a common technique for bitmap font "boldening"),
 * and italic is faked by drawing twice with a 1px vertical shear
 * offset on the second pass (approximates an oblique slant).
 * Underline and strikethrough are drawn as solid rectangles below
 * or through the text baseline. */
void wrender_text(const char *s, float x, float y, float w,
                  float size, uint32_t col, uint8_t align,
                  uint8_t weight, uint8_t decoration, uint8_t style){
    if(!s||!*s) return;
    if(size<=0) size=(float)CSS_DEFAULT_FONT_SIZE;
    float scale=size/30.0f;
    if(scale<0.30f) scale=0.30f;
    if(scale>2.00f) scale=2.00f;
    u32 c=to_c2d(col);

    C2D_Text txt;
    static C2D_TextBuf s_tbuf=NULL;
    if(!s_tbuf) s_tbuf=C2D_TextBufNew(4096);

    /* truncate at 200 chars to avoid overflow */
    char buf[201]; strncpy(buf,s,200); buf[200]='\0';
    C2D_TextBufClear(s_tbuf);
    C2D_TextParse(&txt,s_tbuf,buf);
    C2D_TextOptimize(&txt);

    float tw,th;
    C2D_TextGetDimensions(&txt,scale,scale,&tw,&th);

    float tx=x;
    if(align==1&&w>0) tx=x+(w-tw)/2.0f;
    else if(align==2&&w>0) tx=x+w-tw;

    float baseline=y+th*0.85f;

    /* v0.40: fake italic by drawing twice with a small horizontal
     * offset that grows with height — approximates an oblique shear
     * without needing a separate italic font. The offset is applied
     * to the second pass only, so the first pass establishes the
     * baseline position. */
    if(style){
        float shear=th*0.12f;
        C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx,baseline,0,scale,scale,c);
        C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx+shear,baseline,0,scale,scale,c);
        /* bold on top of italic: third pass at tx+shear+1 */
        if(weight){
            float off=scale*1.5f; if(off<1.f) off=1.f;
            C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx+shear+off,baseline,0,scale,scale,c);
        }
    } else if(weight){
        /* v0.40: fake bold by drawing twice with a 1px horizontal offset.
         * The citro2d system font has no bold variant, so this is the
         * standard bitmap-font boldening technique. The offset scales
         * with font size so it looks right at all sizes. */
        float off=scale*1.5f; if(off<1.f) off=1.f;
        C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx,baseline,0,scale,scale,c);
        C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx+off,baseline,0,scale,scale,c);
    } else {
        C2D_DrawText(&txt,C2D_WithColor|C2D_AtBaseline,tx,baseline,0,scale,scale,c);
    }

    /* v0.40: text-decoration. Underline = solid rect below baseline;
     * line-through = solid rect through the vertical middle of the
     * text. Both span the text width (tw). */
    if(decoration==1){
        /* underline: 1-2px tall rect at baseline+1 */
        float uh=scale*2.f; if(uh<1.f) uh=1.f;
        C2D_DrawRectSolid(tx,baseline+1.f,0,tw,uh,c);
    } else if(decoration==2){
        /* line-through: rect through vertical middle of text */
        float mh=scale*2.f; if(mh<1.f) mh=1.f;
        float my=y+th*0.5f;
        C2D_DrawRectSolid(tx,my,0,tw,mh,c);
    }
}

/* ── Scrollbar ───────────────────────────────────────────────────── */

void wrender_scrollbar_v(float x, float y, float h,
                          int scroll, int total, uint32_t col){
    if(total<=0) return;
    float frac=(float)h/total;
    if(frac>1) frac=1;
    float bar_h=h*frac;
    float bar_y=y+(h-bar_h)*(float)scroll/(total-1);
    /* track */
    C2D_DrawRectSolid(x,y,0,4,h,to_c2d(0x333333FF));
    /* thumb */
    C2D_DrawRectSolid(x,bar_y,0,4,bar_h,to_c2d(col));
}

void wrender_scrollbar_h(float x, float y, float w,
                          int scroll, int total, uint32_t col){
    if(total<=0) return;
    float frac=(float)w/total;
    if(frac>1) frac=1;
    float bar_w=w*frac;
    float bar_x=x+(w-bar_w)*(float)scroll/(total-1);
    C2D_DrawRectSolid(x,y,0,w,4,to_c2d(0x333333FF));
    C2D_DrawRectSolid(bar_x,y,0,bar_w,4,to_c2d(col));
}

/* ── Image loading ───────────────────────────────────────────────── */

static bool load_png_to_tex(const char *path, WEImage *img){
    unsigned char *data=NULL;
    unsigned w=0,h=0;
    unsigned err=lodepng_decode32_file(&data,&w,&h,path);
    if(err||!data) return false;
    /* round up to power of 2 */
    unsigned tw=1,th=1;
    while(tw<w) tw<<=1; while(th<h) th<<=1;
    /* create texture */
    if(!C3D_TexInit(&img->tex,(int)tw,(int)th,GPU_RGBA8)){
        free(data); return false;
    }
    /* copy pixels (RGBA8) — Y-flip for 3DS texture convention */
    unsigned char *tex_data=(unsigned char*)img->tex.data;
    memset(tex_data,0,tw*th*4);
    for(unsigned y2=0;y2<h;y2++){
        for(unsigned x2=0;x2<w;x2++){
            unsigned src=(y2*w+x2)*4;
            unsigned dst=((th-1-y2)*tw+x2)*4; /* flip Y */
            tex_data[dst+0]=data[src+3]; /* A */
            tex_data[dst+1]=data[src+2]; /* B */
            tex_data[dst+2]=data[src+1]; /* G */
            tex_data[dst+3]=data[src+0]; /* R */
        }
    }
    C3D_TexSetFilter(&img->tex,GPU_LINEAR,GPU_LINEAR);

    /* Initialise Tex3DS_SubTexture so C2D_DrawImageAt does not deref NULL.
     * 3DS Y-flip convention: top=1.0 is the top of the image.            */
    img->subtex.width  = (u16)w;
    img->subtex.height = (u16)h;
    img->subtex.left   = 0.0f;
    img->subtex.top    = 1.0f;
    img->subtex.right  = (float)w / (float)tw;
    img->subtex.bottom = 1.0f - (float)h / (float)th;

    img->img.tex    = &img->tex;
    img->img.subtex = &img->subtex;   /* non-NULL: crash fix */

    img->w=(uint16_t)w;
    img->h=(uint16_t)h;
    img->loaded=true;
    free(data);
    return true;
}

uint16_t wrender_load_image(const char *path_or_dataurl){
    if(!path_or_dataurl) return 0;
    /* check cache */
    for(int i=0;i<g_we_image_n;i++){
        if(g_we_images[i].loaded&&strcmp(g_we_images[i].path,path_or_dataurl)==0)
            return (uint16_t)(i+1);
    }
    if(g_we_image_n>=WE_MAX_IMAGES) return 0;
    WEImage *img=&g_we_images[g_we_image_n];
    strncpy(img->path,path_or_dataurl,127);
    img->path[127]='\0';
    /* resolve path */
    char resolved[256];
    if(strncmp(path_or_dataurl,"sdmc:/",6)==0||strncmp(path_or_dataurl,"/",1)==0){
        strncpy(resolved,path_or_dataurl,255);
    } else {
        snprintf(resolved,sizeof(resolved),"sdmc:/3ds/pocketcompiler/www/%s",path_or_dataurl);
    }
    if(!load_png_to_tex(resolved,img)) return 0;
    return (uint16_t)(++g_we_image_n);
}

void wrender_free_image(uint16_t id){
    if(id==0||id>WE_MAX_IMAGES) return;
    WEImage *img=&g_we_images[id-1];
    if(img->loaded){ C3D_TexDelete(&img->tex); img->loaded=false; }
}

/* ── Canvas management ───────────────────────────────────────────── */

uint16_t wrender_new_canvas(uint16_t w, uint16_t h){
    for(int i=0;i<WE_MAX_CANVAS;i++){
        if(!g_we_canvas[i].used){
            /* round up to power of 2 */
            uint16_t tw=1,th=1;
            while(tw<w) tw<<=1; while(th<h) th<<=1;
            if(!C3D_TexInitVRAM(&g_we_canvas[i].tex,tw,th,GPU_RGBA8)) return 0;
            g_we_canvas[i].fb=C3D_RenderTargetCreateFromTex(
                &g_we_canvas[i].tex,GPU_TEXFACE_2D,0,-1);
            if(!g_we_canvas[i].fb){
                C3D_TexDelete(&g_we_canvas[i].tex); return 0;
            }
            g_we_canvas[i].w=w;
            g_we_canvas[i].h=h;

            /* Initialise Tex3DS_SubTexture for canvas draw calls */
            g_we_canvas[i].subtex.width  = w;
            g_we_canvas[i].subtex.height = h;
            g_we_canvas[i].subtex.left   = 0.0f;
            g_we_canvas[i].subtex.top    = 1.0f;
            g_we_canvas[i].subtex.right  = (float)w / (float)tw;
            g_we_canvas[i].subtex.bottom = 1.0f - (float)h / (float)th;

            g_we_canvas[i].used=true;
            return (uint16_t)(i+1);
        }
    }
    return 0;
}

void wrender_free_canvas(uint16_t id){
    if(id==0||id>WE_MAX_CANVAS) return;
    WECanvas *c=&g_we_canvas[id-1];
    if(!c->used) return;
    if(c->fb) C3D_RenderTargetDelete(c->fb);
    C3D_TexDelete(&c->tex);
    c->used=false;
}

WECanvas *wrender_canvas(uint16_t id){
    if(id==0||id>WE_MAX_CANVAS) return NULL;
    return g_we_canvas[id-1].used?&g_we_canvas[id-1]:NULL;
}

/* ── Node rendering ──────────────────────────────────────────────── */

/* v0.38 final audit: render recursion depth guard. wrender_node
 * recurses into children with no depth limit, but the DOM pool allows
 * up to 1024 nodes — a deeply nested chain could recurse ~1024 levels
 * deep and overflow the 3DS's 256KB main-thread stack (each frame is
 * ~100-200 bytes, so 1024 levels = ~100-200KB on top of whatever the
 * rest of the call chain is using). Cap at 80 levels (matching
 * web_layout.c's MAX_LAYOUT_DEPTH) — beyond that, children simply
 * aren't rendered (they'd be invisibly small anyway at that depth). */
#define MAX_RENDER_DEPTH 80
static int s_render_depth=0;

static void render_border(DOMNode *n){
    if(n->style.border_width<=0) return;
    float x=n->lay_x, y=n->lay_y;
    float w=n->lay_w, h=n->lay_h;
    float bw=n->style.border_width;
    u32 bc=to_c2d(n->style.border_color?n->style.border_color:0x444444FF);
    /* top/bottom/left/right as rects */
    C2D_DrawRectSolid(x,y,0,w,bw,bc);
    C2D_DrawRectSolid(x,y+h-bw,0,w,bw,bc);
    C2D_DrawRectSolid(x,y+bw,0,bw,h-2*bw,bc);
    C2D_DrawRectSolid(x+w-bw,y+bw,0,bw,h-2*bw,bc);
}

void wrender_node(int16_t node_id, int16_t clip_x, int16_t clip_y,
                  int16_t clip_w, int16_t clip_h, int16_t ox, int16_t oy){
    if(node_id<0) return;
    /* v0.38: depth guard — prevents stack overflow on deeply nested DOM */
    if(s_render_depth>=MAX_RENDER_DEPTH) return;
    DOMNode *n=dom_node(node_id);
    if(!n||n->style.display==4||n->style.visibility==1) return;

    float x=n->lay_x-ox;
    float y=n->lay_y-oy;
    float w=n->lay_w;
    float h=n->lay_h;

    /* v0.41: apply CSS transform: translate(). translate_x/translate_y
     * have been parsed and stored since v0.39 but the renderer ignored
     * them. Now the element (and all its children, since they're
     * rendered relative to this node's position via ox/oy) shifts by
     * the translate offset. This covers the most common transform use
     * case (UI animations, tooltips, dropdowns). Rotate/scale still
     * need matrix math and aren't applied yet. */
    x += n->style.translate_x;
    y += n->style.translate_y;

    /* coarse clip — skip if entirely outside viewport */
    if(x+w<clip_x||y+h<clip_y||x>clip_x+clip_w||y>clip_y+clip_h) return;

    /* v0.40: opacity is now actually applied. The old code read
     * n->style.opacity into a local `alpha` and immediately cast it
     * to (void), so opacity had zero visual effect. Now we scale the
     * alpha byte of every color we draw by (opacity/255). This is
     * done per-node by premultiplying into a local style copy.
     * Citro2D's C2D_DrawRectSolid / C2D_DrawText both honour the
     * alpha byte of the color they're given, so this "just works". */
    uint8_t opacity=n->style.opacity;
    if(opacity==0) opacity=255;   /* 0 means "unset", treat as fully opaque */

    /* text node */
    if(n->type==NT_TEXT){
        const char *t=dom_text(n->text_off);
        if(!t||!*t) return;
        /* get parent style for color/font */
        CSSStyle *pst=(n->parent>=0)?&g_dom_nodes[n->parent].style:&n->style;
        /* Use parent container width for proper text alignment.
         * lay_w of text node is avail_w (set in layout), which equals parent
         * content content — so alignment (center/right) computes correctly. */
        float container_w = w;
        if(n->parent>=0){
            DOMNode *par=dom_node(n->parent);
            if(par){
                float pw=(float)par->lay_w
                         -(float)pst->padding_left
                         -(float)pst->padding_right;
                if(pw>container_w) container_w=pw;
            }
        }
        /* v0.40: apply opacity to the text color's alpha channel. */
        uint32_t tcol=pst->color?pst->color:CSS_DEFAULT_COLOR;
        uint8_t ta=(uint8_t)(tcol&0xFF);
        ta=(uint8_t)((ta*opacity)/255);
        tcol=(tcol&0xFFFFFF00u)|ta;
        wrender_text(t,x,y,container_w,
                     (float)(pst->font_size>0?pst->font_size:CSS_DEFAULT_FONT_SIZE),
                     tcol,
                     pst->text_align,pst->font_weight,pst->text_decoration,
                     pst->font_style);
        return;
    }

    if(n->type!=NT_ELEMENT) return;

    /* v0.40: helper to apply opacity to a color's alpha byte. */
    #define APPLY_OPACITY(col) \
        do { \
            uint8_t _a=(uint8_t)((col)&0xFF); \
            _a=(uint8_t)((_a*opacity)/255); \
            (col)=((col)&0xFFFFFF00u)|_a; \
        } while(0)

    /* v0.42: box-shadow. Draw a semi-transparent rect behind the
     * element, offset by shadow_x/shadow_y, expanded by shadow_blur.
     * Drawn BEFORE the background so the element appears on top.
     * Simplified: no real gaussian blur, just a spread rect. */
    if(n->style.shadow_color){
        uint32_t sc=n->style.shadow_color;
        APPLY_OPACITY(sc);
        float sx=x+(float)n->style.shadow_x - (float)n->style.shadow_blur;
        float sy=y+(float)n->style.shadow_y - (float)n->style.shadow_blur;
        float sw=w + 2.f*(float)n->style.shadow_blur;
        float sh=h + 2.f*(float)n->style.shadow_blur;
        C2D_DrawRectSolid(sx,sy,0,sw,sh,to_c2d(sc));
    }

    /* background — v0.40: apply opacity. */
    uint32_t bg=n->style.background;

    /* v0.42: linear-gradient background. If gradient_active, draw
     * color bands instead of a solid fill. The gradient is drawn as
     * N horizontal or vertical strips, each a slightly different
     * color interpolated from start to end. N=16 gives smooth-enough
     * gradients without too many draw calls. */
    if(n->style.gradient_active && (n->style.gradient_start_set||n->style.gradient_end_set)){
        uint32_t gs=n->style.gradient_start;
        uint32_t ge=n->style.gradient_end;
        APPLY_OPACITY(gs);
        APPLY_OPACITY(ge);
        #define GRAD_STEPS 16
        for(int i=0;i<GRAD_STEPS;i++){
            float t0=(float)i/GRAD_STEPS;
            float t1=(float)(i+1)/GRAD_STEPS;
            /* Interpolate RGBA channels */
            uint8_t r0=(gs>>24)&0xFF, g0=(gs>>16)&0xFF, b0=(gs>>8)&0xFF, a0=gs&0xFF;
            uint8_t r1=(ge>>24)&0xFF, g1=(ge>>16)&0xFF, b1=(ge>>8)&0xFF, a1=ge&0xFF;
            uint8_t r=(uint8_t)(r0+(int)((r1-r0)*t0));
            uint8_t g=(uint8_t)(g0+(int)((g1-g0)*t0));
            uint8_t b=(uint8_t)(b0+(int)((b1-b0)*t0));
            uint8_t a=(uint8_t)(a0+(int)((a1-a0)*t0));
            uint32_t col=C2D_Color32(r,g,b,a);
            if(n->style.gradient_dir==0){        /* to right */
                C2D_DrawRectSolid(x+t0*w,y,0,(t1-t0)*w+1,h,col);
            } else if(n->style.gradient_dir==1){ /* to bottom */
                C2D_DrawRectSolid(x,y+t0*h,0,w,(t1-t0)*h+1,col);
            } else if(n->style.gradient_dir==2){ /* to left */
                C2D_DrawRectSolid(x+(1-t1)*w,y,0,(t1-t0)*w+1,h,col);
            } else {                             /* to top */
                C2D_DrawRectSolid(x,y+(1-t1)*h,0,w,(t1-t0)*h+1,col);
            }
        }
        #undef GRAD_STEPS
    } else if(bg&0xFF){
        APPLY_OPACITY(bg);
        wrender_rounded_rect(x,y,w,h,(float)n->style.border_radius,bg);
    }
    /* border — v0.40: apply opacity by temporarily patching the node's
     * border_color. render_border reads n->style.border_color directly
     * so we patch and restore. */
    if(n->style.border_width>0){
        uint32_t saved_bc=n->style.border_color;
        uint32_t bc=saved_bc?saved_bc:0x444444FF;
        APPLY_OPACITY(bc);
        n->style.border_color=bc;
        render_border(n);
        n->style.border_color=saved_bc;
    }

    #undef APPLY_OPACITY

    /* hover highlight */
    if(n->hover&&n->style.cursor==1){
        C2D_DrawRectSolid(x,y,0,w,h,C2D_Color32(255,255,255,20));
    }

    /* image element */
    if(n->image_id>0){
        WEImage *img=&g_we_images[n->image_id-1];
        if(img->loaded){
            /* img.subtex is guaranteed non-NULL (set in load_png_to_tex) */
            C2D_DrawImageAt(img->img,x,y,0,NULL,
                            w/(float)img->w, h/(float)img->h);
        }
    }

    /* canvas element */
    if(n->canvas_id>0){
        WECanvas *cv=wrender_canvas(n->canvas_id);
        if(cv&&cv->used){
            /* Use &cv->subtex — never NULL */
            C2D_Image ci;
            ci.tex    = &cv->tex;
            ci.subtex = &cv->subtex;
            C2D_DrawImageAt(ci,x,y,0,NULL,
                            w/(float)cv->w, h/(float)cv->h);
        }
    }

    /* scroll offsets for children.
     * v0.41: also fold in the translate() offset so children move
     * with the translated parent. The translate was applied to the
     * local draw position (x, y) above; here we subtract it from ox/oy
     * so children's (lay_x - ox) also picks up the shift. */
    int16_t scroll_x=n->scroll_x - (int16_t)n->style.translate_x;
    int16_t scroll_y=n->scroll_y - (int16_t)n->style.translate_y;

    /* render children */
    s_render_depth++;
    for(int16_t ch=n->first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
        wrender_node(ch,clip_x,clip_y,clip_w,clip_h,
                     ox+scroll_x,oy+scroll_y);
    }
    s_render_depth--;

    /* tag-specific rendering */
    const char *tag=dom_tag(node_id);
    if(strcmp(tag,"input")==0||strcmp(tag,"textarea")==0){
        float bw=(n->style.border_width>0)?n->style.border_width:1;
        u32 bc=to_c2d(n->style.border_color?n->style.border_color:0x555555FF);
        u32 bg=to_c2d(n->style.background?n->style.background:0x222222FF);
        C2D_DrawRectSolid(x,y,0,w,h,bg);
        C2D_DrawRectSolid(x,y,0,w,bw,bc);
        C2D_DrawRectSolid(x,y+h-bw,0,w,bw,bc);
        C2D_DrawRectSolid(x,y+bw,0,bw,h-2*bw,bc);
        C2D_DrawRectSolid(x+w-bw,y+bw,0,bw,h-2*bw,bc);
        const char *val=dom_get_attr(node_id,"value");
        if(!val) val=dom_get_attr(node_id,"placeholder");
        if(val){
            wrender_text(val,x+3,y+2,w-6,
                         (float)(n->style.font_size>0?n->style.font_size:CSS_DEFAULT_FONT_SIZE),
                         n->style.color?n->style.color:0xBBBBBBFF,
                         0,0,0,0);
        }
        if(n->focused){
            C2D_DrawRectSolid(x+3,y+2,0,1,h-4,to_c2d(0xFFFFFFFF));
        }
    }

    /* scrollbars if overflow:scroll or auto */
    if(n->style.overflow_y==2||n->style.overflow_y==3){
        int16_t msx,msy;
        layout_scroll_extents(node_id,&msx,&msy);
        if(msy>0) wrender_scrollbar_v(x+w-5,y,h,scroll_y,msy,0xAAAAAAAA);
    }
    if(n->style.overflow_x==2||n->style.overflow_x==3){
        int16_t msx,msy;
        layout_scroll_extents(node_id,&msx,&msy);
        if(msx>0) wrender_scrollbar_h(x,y+h-5,w,scroll_x,msx,0xAAAAAAAA);
    }
}

/* ── Document render ─────────────────────────────────────────────── */

void wrender_document(uint8_t doc_id, int16_t scroll_x, int16_t scroll_y){
    DOMDocument *d=dom_doc(doc_id);
    if(!d) return;
    int16_t body=d->body_node>=0?d->body_node:d->root_node;
    if(body<0) return;

    /* v0.38: reset render depth at each top-level render pass so a
     * previous aborted-deep render can't poison the counter. */
    s_render_depth=0;

    /* draw body background filling the full viewport */
    DOMNode *bn=dom_node(body);
    if(bn&&(bn->style.background&0xFF))
        wrender_rounded_rect(0,0,WE_VIEWPORT_W,WE_VIEWPORT_H,0,bn->style.background);

    /* render all children of body */
    for(int16_t ch=g_dom_nodes[body].first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
        wrender_node(ch,0,0,WE_VIEWPORT_W,WE_VIEWPORT_H,scroll_x,scroll_y);
    }
}

/* ── Cursor ──────────────────────────────────────────────────────── */

void wrender_cursor(float cx, float cy, bool locked){
    /* BW theme: white cursor always; dim slightly when locked */
    u32 col=locked?to_c2d(0xCCCCCCFF):to_c2d(0xFFFFFFFF);
    u32 outline=to_c2d(0x000000AA);
    C2D_DrawRectSolid(cx,   cy,   0, 2,10,outline);
    C2D_DrawRectSolid(cx+1, cy,   0, 2,10,col);
    C2D_DrawRectSolid(cx,   cy,   0,10, 2,outline);
    C2D_DrawRectSolid(cx,   cy+1, 0,10, 2,col);
    C2D_DrawRectSolid(cx+2, cy+2, 0, 6, 6,outline);
    C2D_DrawRectSolid(cx+3, cy+3, 0, 4, 4,col);
    if(locked){
        /* subtle white glow instead of red ring */
        C2D_DrawCircleSolid(cx,cy,0,8,to_c2d(0xFFFFFF22));
    }
}
