/*
 * web_css.c  —  CSS parser & cascade
 *
 * v0.39 additions (additive; no existing parse case touched):
 *  - apply_property() now recognises three more declarations, all
 *    using fields already present in CSSStyle:
 *      • align-self   — was in the struct but had no parser case.
 *      • flex-flow    — shorthand setting flex-direction + flex-wrap.
 *      • inset        — shorthand setting top/right/bottom/left,
 *                       mirroring the existing margin/padding shorthand.
 *
 * v0.38 BUG FIX: css_parse_inline's 2048-byte buffer and
 * css_parse_stylesheet's 1024-byte decl_buf were both non-static
 * stack buffers, and the former is called from inside the latter
 * while its locals are still live — over 3KB combined in one call
 * chain. Both made static (parsing is strictly sequential, never
 * reentrant, so this is safe) to reduce 3DS stack pressure.
 */
#include "web_css.h"
#include "web_dom.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>

CSSRule g_css_rules[CSS_MAX_RULES];
int     g_css_rule_n=0;

/* v0.44: CSS custom properties (variables). Stored as a flat array
 * of name→value pairs. var(--name) is resolved by looking up this
 * table. Set via :root { --name: value; } or any other selector. */
#define CSS_MAX_VARS 64
#define CSS_VAR_NAME_MAX 64
#define CSS_VAR_VAL_MAX 256
static struct {
    char name[CSS_VAR_NAME_MAX];
    char value[CSS_VAR_VAL_MAX];
    bool used;
} g_css_vars[CSS_MAX_VARS];

/* Resolve a var(--name) reference. Returns the value or NULL if not
 * found. `expr` points to "var(--name)" or "var(--name, fallback)".
 * Writes the resolved value into `out` (buf_sz bytes). */
static bool css_resolve_var(const char *expr, char *out, int out_sz){
    if(!expr||!out||out_sz<=0) return false;
    /* Find "--" after "var(" */
    const char *p=strstr(expr,"--");
    if(!p) return false;
    p+=2; /* skip "--" */
    /* Read var name up to ',' or ')' */
    char name[CSS_VAR_NAME_MAX]; int nl=0;
    while(*p && *p!=',' && *p!=')' && nl<CSS_VAR_NAME_MAX-1){
        name[nl++]=*p++;
    }
    name[nl]='\0';
    /* Look up in g_css_vars */
    for(int i=0;i<CSS_MAX_VARS;i++){
        if(g_css_vars[i].used && strcmp(g_css_vars[i].name,name)==0){
            strncpy(out,g_css_vars[i].value,out_sz-1);
            out[out_sz-1]='\0';
            return true;
        }
    }
    /* Check for fallback: var(--name, fallback) */
    if(*p==','){
        p++; /* skip comma */
        while(*p==' ') p++;
        int ol=0;
        while(*p && *p!=')' && ol<out_sz-1){
            out[ol++]=*p++;
        }
        out[ol]='\0';
        return ol>0;
    }
    return false;
}

/* Check if a value string contains var() and resolve it.
 * `val` is the original value, `out` is the resolved value.
 * v0.44 audit fix: added depth limit to prevent infinite recursion
 * on self-referencing variables (e.g. --x: var(--x)). */
static bool css_resolve_vars_impl(const char *val, char *out, int out_sz, int depth){
    if(!val||!out||out_sz<=0) return false;
    if(depth>8){
        /* Too many nested var() references — give up and return
         * the value as-is to prevent stack overflow / infinite loop. */
        strncpy(out,val,out_sz-1);
        out[out_sz-1]='\0';
        return true;
    }
    const char *var_pos=strstr(val,"var(");
    if(!var_pos){
        strncpy(out,val,out_sz-1);
        out[out_sz-1]='\0';
        return true;
    }
    /* Find matching ) */
    const char *close=strchr(var_pos,')');
    if(!close){
        strncpy(out,val,out_sz-1);
        out[out_sz-1]='\0';
        return true;
    }
    /* Resolve the var() */
    char resolved[CSS_VAR_VAL_MAX];
    if(!css_resolve_var(var_pos,resolved,sizeof(resolved))){
        resolved[0]='\0';
    }
    /* Build the output: prefix + resolved + suffix */
    int prefix_len=(int)(var_pos-val);
    int resolved_len=(int)strlen(resolved);
    int suffix_start=(int)(close-val)+1;
    int suffix_len=(int)strlen(val)-suffix_start;
    if(prefix_len+resolved_len+suffix_len>=out_sz){
        strncpy(out,val,out_sz-1);
        out[out_sz-1]='\0';
        return true;
    }
    memcpy(out,val,(size_t)prefix_len);
    memcpy(out+prefix_len,resolved,(size_t)resolved_len);
    memcpy(out+prefix_len+resolved_len,val+suffix_start,(size_t)suffix_len);
    out[prefix_len+resolved_len+suffix_len]='\0';
    /* Recursively resolve any remaining var() in the suffix */
    if(strstr(out,"var(")){
        char tmp[CSS_VAR_VAL_MAX];
        strncpy(tmp,out,CSS_VAR_VAL_MAX-1);
        tmp[CSS_VAR_VAL_MAX-1]='\0';
        css_resolve_vars_impl(tmp,out,out_sz,depth+1);
    }
    return true;
}

static bool css_resolve_vars(const char *val, char *out, int out_sz){
    return css_resolve_vars_impl(val, out, out_sz, 0);
}

/* Set a CSS custom property. Called from the stylesheet parser when
 * it encounters a "--name: value;" declaration. */
static void css_set_var(const char *name, const char *value){
    if(!name||!*name||!value) return;
    /* Check if var already exists */
    for(int i=0;i<CSS_MAX_VARS;i++){
        if(g_css_vars[i].used && strcmp(g_css_vars[i].name,name)==0){
            strncpy(g_css_vars[i].value,value,CSS_VAR_VAL_MAX-1);
            g_css_vars[i].value[CSS_VAR_VAL_MAX-1]='\0';
            return;
        }
    }
    /* Find free slot */
    for(int i=0;i<CSS_MAX_VARS;i++){
        if(!g_css_vars[i].used){
            strncpy(g_css_vars[i].name,name,CSS_VAR_NAME_MAX-1);
            g_css_vars[i].name[CSS_VAR_NAME_MAX-1]='\0';
            strncpy(g_css_vars[i].value,value,CSS_VAR_VAL_MAX-1);
            g_css_vars[i].value[CSS_VAR_VAL_MAX-1]='\0';
            g_css_vars[i].used=true;
            return;
        }
    }
}

/* ── Color parsing ──────────────────────────────────────────────── */

/* Named color table */
static const struct { const char *name; uint32_t rgba; } s_named[]={
    {"black",      0x000000FF},{"white",      0xFFFFFFFF},
    {"red",        0xFF0000FF},{"green",      0x008000FF},
    {"blue",       0x0000FFFF},{"yellow",     0xFFFF00FF},
    {"cyan",       0x00FFFFFF},{"magenta",    0xFF00FFFF},
    {"orange",     0xFF8000FF},{"purple",     0x800080FF},
    {"pink",       0xFFC0CBFF},{"lime",       0x00FF00FF},
    {"teal",       0x008080FF},{"navy",       0x000080FF},
    {"maroon",     0x800000FF},{"olive",      0x808000FF},
    {"silver",     0xC0C0C0FF},{"gray",       0x808080FF},
    {"grey",       0x808080FF},{"darkgray",   0xA9A9A9FF},
    {"darkgrey",   0xA9A9A9FF},{"lightgray",  0xD3D3D3FF},
    {"lightgrey",  0xD3D3D3FF},{"whitesmoke", 0xF5F5F5FF},
    {"crimson",    0xDC143CFF},{"coral",      0xFF7F50FF},
    {"salmon",     0xFA8072FF},{"gold",       0xFFD700FF},
    {"khaki",      0xF0E68CFF},{"violet",     0xEE82EEFF},
    {"indigo",     0x4B0082FF},{"turquoise",  0x40E0D0FF},
    {"chocolate",  0xD2691EFF},{"tomato",     0xFF6347FF},
    {"dodgerblue", 0x1E90FFFF},{"skyblue",    0x87CEEBFF},
    {"steelblue",  0x4682B4FF},{"slateblue",  0x6A5ACDFF},
    {"sienna",     0xA0522DFF},{"tan",        0xD2B48CFF},
    {"beige",      0xF5F5DCFF},{"ivory",      0xFFFFF0FF},
    {"lavender",   0xE6E6FAFF},{"linen",      0xFAF0E6FF},
    {"transparent",0x00000000},
    {NULL,0}
};

uint32_t css_named_color(const char *name){
    char buf[32]; int i=0;
    while(name[i]&&i<31){ buf[i]=tolower((unsigned char)name[i]); i++; }
    buf[i]='\0';
    for(int j=0;s_named[j].name;j++)
        if(strcmp(s_named[j].name,buf)==0) return s_named[j].rgba;
    return 0x888888FF;
}

uint32_t css_parse_color(const char *s){
    if(!s||!*s) return 0x888888FF;
    while(*s==' ')s++;
    if(s[0]=='#'){
        s++;
        int len=(int)strlen(s);
        unsigned r=0,g=0,b=0,a=255;
        if(len>=6){
            sscanf(s,"%02x%02x%02x",&r,&g,&b);
            if(len>=8) sscanf(s+6,"%02x",&a);
        } else if(len>=3){
            /* shorthand #RGB */
            sscanf(s,"%1x%1x%1x",&r,&g,&b);
            r|=r<<4; g|=g<<4; b|=b<<4;
        }
        return ((r&0xFF)<<24)|((g&0xFF)<<16)|((b&0xFF)<<8)|(a&0xFF);
    }
    if(strncmp(s,"rgb(",4)==0||strncmp(s,"rgba(",5)==0){
        int r=0,g=0,b=0; float a=1.0f;
        sscanf(s+(s[3]=='('?4:5),"%d,%d,%d,%f",&r,&g,&b,&a);
        int ai=(int)(a*255.f); if(ai<0)ai=0; if(ai>255)ai=255;
        return ((r&0xFF)<<24)|((g&0xFF)<<16)|((b&0xFF)<<8)|(ai);
    }
    if(strncmp(s,"hsl(",4)==0){
        float h=0,sv=0,lv=0; float a=1.0f;
        sscanf(s+4,"%f,%f%%,%f%%",&h,&sv,&lv);
        sv/=100.f; lv/=100.f;
        float c=(1-fabsf(2*lv-1))*sv;
        float x=c*(1-fabsf(fmodf(h/60.f,2)-1));
        float m=lv-c/2;
        float rf=0,gf=0,bf=0;
        if(h<60){rf=c;gf=x;}
        else if(h<120){rf=x;gf=c;}
        else if(h<180){gf=c;bf=x;}
        else if(h<240){gf=x;bf=c;}
        else if(h<300){rf=x;bf=c;}
        else{rf=c;bf=x;}
        int r=(int)((rf+m)*255),g=(int)((gf+m)*255),b=(int)((bf+m)*255);
        int ai=(int)(a*255.f);
        return ((r&0xFF)<<24)|((g&0xFF)<<16)|((b&0xFF)<<8)|(ai);
    }
    return css_named_color(s);
}

/* ── Length parsing ─────────────────────────────────────────────── */

/* v0.42: Parse a single calc() term (a number + unit). Used by
 * css_parse_length when it encounters "calc(...)". Returns the px
 * value of the term. `parent_px` and `font_px` are the context for
 * % and em resolution. */
static float calc_parse_term(const char *s, int parent_px, int font_px){
    if(!s||!*s) return 0;
    while(*s==' ') s++;
    char *end;
    float v=(float)strtod(s,&end);
    while(*end==' ') end++;
    int fp = (font_px > 0) ? font_px : CSS_DEFAULT_FONT_SIZE;
    if(strncmp(end,"px",2)==0)  return v;
    if(strncmp(end,"rem",3)==0) return v*CSS_DEFAULT_FONT_SIZE;
    if(strncmp(end,"em",2)==0)  return v*fp;
    if(strncmp(end,"vw",2)==0)  return v*4.0f;
    if(strncmp(end,"vh",2)==0)  return v*2.4f;
    if(strncmp(end,"%",1)==0)   return v*parent_px/100.f;
    if(*end=='\0')              return v;  /* assume px */
    return v;
}

/* v0.42: Evaluate a calc() expression. Supports +, -, *, / with
 * the standard precedence (* and / before + and -). Parentheses
 * inside calc() are not supported (rare in practice). The input
 * is the expression INSIDE calc( ) — e.g. "100% - 20px" or
 * "50px * 2 + 10%". Returns the result in px. */
static float calc_eval(const char *expr, int parent_px, int font_px){
    if(!expr||!*expr) return 0;
    /* Tokenise into terms and operators. Each term is a value with
     * a unit; operators are +, -, *, /. We do two passes: first
     * handle * and /, then + and -. */
    /* Copy to a mutable buffer */
    static char buf[256];
    strncpy(buf,expr,255); buf[255]='\0';
    /* Parse into up to 16 terms and 15 operators */
    float terms[16]; char ops[16]; int nt=0;
    /* Split on +, -, *, / while preserving the operators.
     * v0.42 audit: removed unused `first_term` variable. */
    char *p=buf;
    while(*p && nt<16){
        /* Skip spaces */
        while(*p==' ') p++;
        if(!*p) break;
        /* Find the end of this term (next operator that's not a
         * leading sign) */
        char *term_start=p;
        if(*p=='-'||*p=='+') p++; /* skip leading sign */
        while(*p && *p!='+' && *p!='-' && *p!='*' && *p!='/') p++;
        /* Null-terminate the term and parse it */
        char saved=*p;
        *p='\0';
        terms[nt]=calc_parse_term(term_start,parent_px,font_px);
        *p=saved;
        nt++;
        /* Skip spaces before operator */
        while(*p==' ') p++;
        /* Read the operator */
        if(*p=='+'||*p=='-'||*p=='*'||*p=='/'){
            ops[nt-1]=*p;
            p++;
        }
    }
    /* First pass: handle * and / */
    for(int i=0;i<nt-1;){
        if(ops[i]=='*'){
            terms[i]=terms[i]*terms[i+1];
            /* Shift everything down */
            for(int j=i+1;j<nt-1;j++){
                terms[j]=terms[j+1];
                ops[j-1]=ops[j];
            }
            nt--;
        } else if(ops[i]=='/'){
            if(terms[i+1]!=0) terms[i]=terms[i]/terms[i+1];
            else terms[i]=0;
            for(int j=i+1;j<nt-1;j++){
                terms[j]=terms[j+1];
                ops[j-1]=ops[j];
            }
            nt--;
        } else {
            i++;
        }
    }
    /* Second pass: handle + and - */
    float result=terms[0];
    for(int i=0;i<nt-1;i++){
        if(ops[i]=='+') result+=terms[i+1];
        else if(ops[i]=='-') result-=terms[i+1];
    }
    return result;
}

int16_t css_parse_length(const char *s, int parent_px, int font_px){
    if(!s||!*s) return 0;
    while(*s==' ')s++;
    if(strcmp(s,"auto")==0) return -1;
    /* v0.42: calc() support. If the value starts with "calc(", extract
     * the expression inside the parentheses and evaluate it. */
    if(strncmp(s,"calc(",5)==0){
        const char *inner=s+5;
        const char *close=strchr(inner,')');
        if(close){
            char expr[256];
            int el=(int)(close-inner);
            if(el>=256) el=255;
            memcpy(expr,inner,el); expr[el]='\0';
            return (int16_t)calc_eval(expr,parent_px,font_px);
        }
    }
    char *end;
    float v=(float)strtod(s,&end);
    while(*end==' ')end++;
    /* Use CSS_DEFAULT_FONT_SIZE as em fallback when font_px is 0 */
    int fp = (font_px > 0) ? font_px : CSS_DEFAULT_FONT_SIZE;
    if(strncmp(end,"px",2)==0) return (int16_t)(v);
    if(strncmp(end,"rem",3)==0)return (int16_t)(v*CSS_DEFAULT_FONT_SIZE);
    if(strncmp(end,"em",2)==0) return (int16_t)(v*fp);
    if(strncmp(end,"vw",2)==0) return (int16_t)(v*4.0f);/* 1vw=4px (400/100) */
    if(strncmp(end,"vh",2)==0) return (int16_t)(v*2.4f);/* 1vh=2.4px (240/100) */
    if(strncmp(end,"%",1)==0)  return (int16_t)(v*parent_px/100.f);
    if(*end=='\0') return (int16_t)(v);  /* assume px */
    return 0;
}

/* ── Inline CSS parser ──────────────────────────────────────────── */

static void trim(char *s){
    /* ltrim */
    char *p=s; while(*p==' '||*p=='\t'||*p=='\n'||*p=='\r') p++;
    if(p!=s) memmove(s,p,strlen(p)+1);
    /* rtrim */
    int l=(int)strlen(s);
    while(l>0&&(s[l-1]==' '||s[l-1]=='\t'||s[l-1]=='\n'||s[l-1]=='\r'))
        s[--l]='\0';
}

static void apply_property(CSSStyle *st, const char *prop, const char *val){
    if(!prop||!val||!*prop) return;
    char p[64]; strncpy(p,prop,63); p[63]=0; trim(p);

    /* v0.44: CSS custom property declaration (--name: value).
     * Store in the global var table and return — custom properties
     * don't affect the style struct directly. */
    if(p[0]=='-' && p[1]=='-'){
        css_set_var(p, val);
        return;
    }

    /* v0.44: Resolve var() references in the value before parsing.
     * If the value contains "var(", resolve all references first. */
    char v[256];
    if(strstr(val,"var(")){
        char resolved[256];
        if(css_resolve_vars(val,resolved,sizeof(resolved))){
            strncpy(v,resolved,255); v[255]=0;
        } else {
            strncpy(v,val,255); v[255]=0;
        }
    } else {
        strncpy(v,val,255); v[255]=0;
    }
    trim(v);

    /* v0.44: Strip !important suffix — we treat all declarations as
     * having the same specificity (later wins), so !important is
     * accepted but doesn't change cascade behavior. */
    {
        char *imp=strstr(v,"!important");
        if(imp){
            /* Trim trailing space before !important */
            while(imp>v && (imp[-1]==' '||imp[-1]=='\t')) imp--;
            *imp='\0';
        }
    }

    /* Color properties.
     * v0.40 audit fix: `background` is a shorthand that can contain
     * a color, an image url(), or both. The old code routed every
     * `background:` value to css_parse_color(), which would try to
     * parse "url(foo.png)" as a color and silently fall back to the
     * named-color lookup (returning 0 = transparent black). Now:
     *   - background-color: always a color
     *   - background: if it contains "url(", treat as image (no-op
     *     for now — image loading is handled at render time via the
     *     <img>/<canvas> paths, not CSS background-image); otherwise
     *     parse the last token as a color (handles "red", "#f00",
     *     "no-repeat center" etc. by extracting the color-looking token). */
    if(strcmp(p,"color")==0){ st->color=css_parse_color(v); return; }
    if(strcmp(p,"background-color")==0){
        st->background=css_parse_color(v); return;
    }
    if(strcmp(p,"background")==0){
        if(strstr(v,"url(")){
            /* background-image — not yet supported in the renderer.
             * Silently ignore the url() so any color in the same
             * shorthand still gets applied. */
            /* Try to extract a color token from the rest of the value
             * (e.g. "url(bg.png) red" → red). Strip the url(...) part. */
            char tmp[256]; strncpy(tmp,v,255); tmp[255]=0;
            char *url_start=strstr(tmp,"url(");
            if(url_start){
                char *url_end=strchr(url_start,')');
                if(url_end){
                    memmove(url_start,url_end+1,strlen(url_end+1)+1);
                    char *t=tmp; while(*t==' ')t++;
                    if(*t) st->background=css_parse_color(t);
                }
            }
        } else {
            st->background=css_parse_color(v);
        }
        return;
    }
    if(strcmp(p,"border-color")==0){ st->border_color=css_parse_color(v); return; }

    /* Display */
    if(strcmp(p,"display")==0){
        if(strcmp(v,"none")==0)         st->display=4;
        else if(strcmp(v,"flex")==0)    st->display=3;
        else if(strcmp(v,"inline-block")==0) st->display=2;
        else if(strcmp(v,"inline")==0)  st->display=1;
        else if(strcmp(v,"grid")==0)    st->display=5;
        else                            st->display=0; /* block */
        return;
    }

    /* Flex */
    if(strcmp(p,"flex-direction")==0){
        if(strcmp(v,"column")==0)         st->flex_direction=1;
        else if(strcmp(v,"row-reverse")==0)st->flex_direction=2;
        else if(strcmp(v,"column-reverse")==0)st->flex_direction=3;
        else st->flex_direction=0;
        return;
    }
    if(strcmp(p,"justify-content")==0){
        if(strcmp(v,"flex-end")==0||strcmp(v,"end")==0)    st->justify_content=1;
        else if(strcmp(v,"center")==0)                     st->justify_content=2;
        else if(strcmp(v,"space-between")==0)              st->justify_content=3;
        else if(strcmp(v,"space-around")==0)               st->justify_content=4;
        else st->justify_content=0;
        return;
    }
    if(strcmp(p,"align-items")==0){
        if(strcmp(v,"flex-end")==0||strcmp(v,"end")==0)    st->align_items=1;
        else if(strcmp(v,"center")==0)                     st->align_items=2;
        else if(strcmp(v,"stretch")==0)                    st->align_items=3;
        else st->align_items=0;
        return;
    }
    if(strcmp(p,"flex-wrap")==0){
        st->flex_wrap=(strcmp(v,"wrap")==0)?1:(strcmp(v,"wrap-reverse")==0)?2:0;
        return;
    }
    if(strcmp(p,"flex-grow")==0){ st->flex_grow=(int16_t)atoi(v); return; }
    if(strcmp(p,"gap")==0){ st->gap=(int16_t)css_parse_length(v,400,CSS_DEFAULT_FONT_SIZE); return; }

    /* v0.39: align-self (was in CSSStyle but never parsed). Mirrors
     * the align-items value mapping — auto/flex-start map to 0 (the
     * struct's "follow align-items" sentinel), flex-end→1, center→2,
     * stretch→3. Pure addition; no existing case touched. */
    if(strcmp(p,"align-self")==0){
        if(strcmp(v,"flex-end")==0||strcmp(v,"end")==0)    st->align_self=1;
        else if(strcmp(v,"center")==0)                     st->align_self=2;
        else if(strcmp(v,"stretch")==0)                    st->align_self=3;
        else st->align_self=0;   /* auto / flex-start / start */
        return;
    }

    /* v0.39: flex-flow shorthand — sets BOTH flex-direction and
     * flex-wrap from a single "row wrap" / "column nowrap" / etc.
     * declaration. Tokenises on whitespace; each token is matched
     * against the direction and wrap value sets. Tokens that match
     * neither are silently ignored (matching browser leniency for
     * unknown shorthand components). */
    if(strcmp(p,"flex-flow")==0){
        char tmp[64]; strncpy(tmp,v,63); tmp[63]=0;
        char *tok = strtok(tmp, " ");
        while(tok){
            if     (strcmp(tok,"row")==0)            st->flex_direction=0;
            else if(strcmp(tok,"column")==0)         st->flex_direction=1;
            else if(strcmp(tok,"row-reverse")==0)    st->flex_direction=2;
            else if(strcmp(tok,"column-reverse")==0) st->flex_direction=3;
            else if(strcmp(tok,"wrap")==0)           st->flex_wrap=1;
            else if(strcmp(tok,"wrap-reverse")==0)   st->flex_wrap=2;
            else if(strcmp(tok,"nowrap")==0)         st->flex_wrap=0;
            tok = strtok(NULL, " ");
        }
        return;
    }

    /* Position */
    if(strcmp(p,"position")==0){
        if(strcmp(v,"relative")==0)  st->position=1;
        else if(strcmp(v,"absolute")==0) st->position=2;
        else if(strcmp(v,"fixed")==0)    st->position=3;
        else st->position=0;
        return;
    }
    int fpos=st->font_size?st->font_size:CSS_DEFAULT_FONT_SIZE;
    if(strcmp(p,"left")==0)  { st->left  =css_parse_length(v,400,fpos); return;}
    if(strcmp(p,"top")==0)   { st->top   =css_parse_length(v,240,fpos); return;}
    if(strcmp(p,"right")==0) { st->right =css_parse_length(v,400,fpos); return;}
    if(strcmp(p,"bottom")==0){ st->bottom=css_parse_length(v,240,fpos); return;}
    if(strcmp(p,"z-index")==0){ st->z_index=(int16_t)atoi(v); return; }

    /* v0.39: inset shorthand — sets top/right/bottom/left in one
     * declaration, mirroring the margin/padding shorthand pattern
     * already in this file. 1 value = all four; 2 values = T/B + L/R;
     * 3 values = T + L/R + B; 4 values = T R B L. Uses the same
     * font-size-relative length parsing as the individual sides. */
    if(strcmp(p,"inset")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t vals[4]={0,0,0,0}; int vc=0;
        char *tok=strtok(tmp," ");
        while(tok&&vc<4){
            /* top/bottom use the 240 parent (screen height); left/right
             * use 400 (screen width). We approximate by using 240 for
             * all four, which is what the existing individual-property
             * path does for any of top/bottom — and the 3DS screen is
             * near-square anyway, so the relative difference is small. */
            vals[vc++]=(int16_t)css_parse_length(tok,240,fpos);
            tok=strtok(NULL," ");
        }
        if(vc==1){ st->top=st->right=st->bottom=st->left=vals[0]; }
        else if(vc==2){ st->top=st->bottom=vals[0]; st->left=st->right=vals[1]; }
        else if(vc==3){ st->top=vals[0]; st->left=st->right=vals[1]; st->bottom=vals[2]; }
        else if(vc==4){ st->top=vals[0]; st->right=vals[1]; st->bottom=vals[2]; st->left=vals[3]; }
        return;
    }

    /* Box model */
    int fp=st->font_size?st->font_size:CSS_DEFAULT_FONT_SIZE;
    if(strcmp(p,"width")==0)     { st->width      =css_parse_length(v,400,fp); return; }
    if(strcmp(p,"height")==0)    { st->height     =css_parse_length(v,240,fp); return; }
    if(strcmp(p,"min-width")==0) { st->min_width  =css_parse_length(v,400,fp); return; }
    if(strcmp(p,"min-height")==0){ st->min_height =css_parse_length(v,240,fp); return; }
    if(strcmp(p,"max-width")==0) { st->max_width  =css_parse_length(v,400,fp); return; }
    if(strcmp(p,"max-height")==0){ st->max_height =css_parse_length(v,240,fp); return; }

    /* v0.40 audit fix: border shorthand now properly tokenises.
     * The old code only checked for "solid" and used strrchr(v,' ')
     * to find the color, which broke on "1px solid #ccc" if the
     * color had a leading space variant, and completely ignored
     * border-style. Now tokenises on whitespace and classifies
     * each token: width (has "px"/"em"/number), style (solid/dashed/
     * dotted/double/none/hidden), color (everything else).
     * Also handles the per-side variants (border-top, border-right,
     * border-bottom, border-left) which the old code silently dropped. */
    if(strcmp(p,"border")==0||strcmp(p,"border-top")==0||
       strcmp(p,"border-right")==0||strcmp(p,"border-bottom")==0||
       strcmp(p,"border-left")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t bw=0; uint32_t bc=0; bool bc_set=false;
        char *tok=strtok(tmp," ");
        while(tok){
            if(strstr(tok,"px")||strstr(tok,"em")||strstr(tok,"rem")||
               (tok[0]>='0'&&tok[0]<='9')){
                bw=(int16_t)css_parse_length(tok,0,fp);
            } else if(strcmp(tok,"solid")==0||strcmp(tok,"dashed")==0||
                      strcmp(tok,"dotted")==0||strcmp(tok,"double")==0||
                      strcmp(tok,"none")==0||strcmp(tok,"hidden")==0||
                      strcmp(tok,"groove")==0||strcmp(tok,"ridge")==0||
                      strcmp(tok,"inset")==0||strcmp(tok,"outset")==0){
                /* style — accepted but not stored (renderer only
                 * draws solid borders). */
            } else {
                bc=css_parse_color(tok); bc_set=true;
            }
            tok=strtok(NULL," ");
        }
        /* Apply to all four sides for "border", or the specific side
         * for the per-side variants. Since CSSStyle only has a single
         * border_width/border_color (no per-side fields), we apply
         * to the unified field for all variants — this matches the
         * renderer's render_border() which draws all four sides. */
        st->border_width=bw;
        if(bc_set) st->border_color=bc;
        return;
    }
    if(strcmp(p,"border-width")==0){
        st->border_width=(int16_t)css_parse_length(v,0,fp); return;
    }
    if(strcmp(p,"border-radius")==0){ st->border_radius=(int16_t)css_parse_length(v,0,fp); return; }

    /* Margin shorthand.
     * v0.40 audit fix: added the 3-value form (T L/R B) which was
     * missing — "margin: 10px 20px 5px" used to fall through to the
     * vc==2 branch and silently drop the third value. */
    if(strcmp(p,"margin")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t vals[4]={0,0,0,0}; int vc=0;
        char *tok=strtok(tmp," ");
        while(tok&&vc<4){ vals[vc++]=(int16_t)css_parse_length(tok,0,fp); tok=strtok(NULL," "); }
        if(vc==1){ st->margin_top=st->margin_right=st->margin_bottom=st->margin_left=vals[0]; }
        else if(vc==2){ st->margin_top=st->margin_bottom=vals[0]; st->margin_left=st->margin_right=vals[1]; }
        else if(vc==3){ st->margin_top=vals[0]; st->margin_left=st->margin_right=vals[1]; st->margin_bottom=vals[2]; }
        else if(vc==4){ st->margin_top=vals[0];st->margin_right=vals[1];st->margin_bottom=vals[2];st->margin_left=vals[3];}
        return;
    }
    if(strcmp(p,"margin-top")==0)   { st->margin_top   =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"margin-right")==0) { st->margin_right =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"margin-bottom")==0){ st->margin_bottom=css_parse_length(v,0,fp); return; }
    if(strcmp(p,"margin-left")==0)  { st->margin_left  =css_parse_length(v,0,fp); return; }

    /* Padding shorthand.
     * v0.40 audit fix: same 3-value fix as margin. */
    if(strcmp(p,"padding")==0){
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        int16_t vals[4]={0,0,0,0}; int vc=0;
        char *tok=strtok(tmp," ");
        while(tok&&vc<4){ vals[vc++]=(int16_t)css_parse_length(tok,0,fp); tok=strtok(NULL," "); }
        if(vc==1){ st->padding_top=st->padding_right=st->padding_bottom=st->padding_left=vals[0]; }
        else if(vc==2){ st->padding_top=st->padding_bottom=vals[0]; st->padding_left=st->padding_right=vals[1]; }
        else if(vc==3){ st->padding_top=vals[0]; st->padding_left=st->padding_right=vals[1]; st->padding_bottom=vals[2]; }
        else if(vc==4){ st->padding_top=vals[0];st->padding_right=vals[1];st->padding_bottom=vals[2];st->padding_left=vals[3];}
        return;
    }
    if(strcmp(p,"padding-top")==0)   { st->padding_top   =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"padding-right")==0) { st->padding_right =css_parse_length(v,0,fp); return; }
    if(strcmp(p,"padding-bottom")==0){ st->padding_bottom=css_parse_length(v,0,fp); return; }
    if(strcmp(p,"padding-left")==0)  { st->padding_left  =css_parse_length(v,0,fp); return; }

    /* Text */
    /* v0.40: font shorthand — "italic bold 14px/16px Arial, sans-serif".
     * Tokenises on whitespace. Recognises: font-style (italic/oblique),
     * font-weight (bold/bolder/number), font-size (has px/em/rem/% or
     * is a named size), line-height (after the size, separated by '/'),
     * font-family (everything else, ignored — renderer uses system font).
     * This is additive to the individual property handlers below. */
    if(strcmp(p,"font")==0){
        char tmp[256]; strncpy(tmp,v,255); tmp[255]=0;
        char *tok=strtok(tmp," ");
        while(tok){
            if(strcmp(tok,"italic")==0||strcmp(tok,"oblique")==0){
                st->font_style=1;
            } else if(strcmp(tok,"bold")==0||strcmp(tok,"bolder")==0||
                      (tok[0]>='0'&&tok[0]<='9'&&atoi(tok)>=700)){
                st->font_weight=1;
            } else if(strcmp(tok,"normal")==0||strcmp(tok,"lighter")==0){
                /* "normal" resets both style and weight to default;
                 * "lighter" just unsets bold */
                if(strcmp(tok,"normal")==0) st->font_style=0;
                st->font_weight=0;
            } else if(strcmp(tok,"small")==0){ st->font_size=9; }
            else if(strcmp(tok,"medium")==0){ st->font_size=14; }
            else if(strcmp(tok,"large")==0){ st->font_size=18; }
            else if(strcmp(tok,"x-large")==0){ st->font_size=22; }
            else if(strcmp(tok,"xx-large")==0){ st->font_size=26; }
            else if(strstr(tok,"px")||strstr(tok,"em")||strstr(tok,"rem")){
                /* Could be "14px" or "14px/16px" (size/line-height) */
                st->font_size=(int16_t)css_parse_length(tok,0,fp);
            } else if(tok[0]>='0'&&tok[0]<='9'&&strchr(tok,'/')){
                /* "14/16" size/line-height with no unit */
                char *slash=strchr(tok,'/');
                if(slash) *slash='\0';
                st->font_size=(int16_t)atoi(tok);
            }
            /* font-family tokens (Arial, sans-serif, etc.) are
             * silently ignored — renderer uses the citro2d system font. */
            tok=strtok(NULL," ");
        }
        return;
    }
    if(strcmp(p,"font-size")==0){
        /* handle named sizes */
        if(strcmp(v,"small")==0)  { st->font_size=9;  return; }
        if(strcmp(v,"medium")==0) { st->font_size=14; return; }
        if(strcmp(v,"large")==0)  { st->font_size=18; return; }
        if(strcmp(v,"x-large")==0){ st->font_size=22; return; }
        st->font_size=(int16_t)css_parse_length(v,CSS_DEFAULT_FONT_SIZE,fp); return;
    }
    if(strcmp(p,"font-weight")==0){
        if(strcmp(v,"bold")==0||strcmp(v,"bolder")==0||atoi(v)>=700)
            st->font_weight=1;
        else st->font_weight=0;
        return;
    }
    if(strcmp(p,"font-style")==0){
        st->font_style=(strcmp(v,"italic")==0||strcmp(v,"oblique")==0)?1:0; return; }
    if(strcmp(p,"text-align")==0){
        if(strcmp(v,"center")==0)        st->text_align=1;
        else if(strcmp(v,"right")==0)    st->text_align=2;
        else if(strcmp(v,"justify")==0)  st->text_align=3;
        else st->text_align=0;
        return;
    }
    if(strcmp(p,"text-decoration")==0){
        if(strstr(v,"underline"))     st->text_decoration=1;
        else if(strstr(v,"line-through")) st->text_decoration=2;
        else st->text_decoration=0;
        return;
    }
    if(strcmp(p,"white-space")==0){
        if(strcmp(v,"nowrap")==0)  st->white_space=1;
        else if(strcmp(v,"pre")==0||strcmp(v,"pre-wrap")==0) st->white_space=2;
        else st->white_space=0;
        return;
    }

    /* Overflow */
    if(strcmp(p,"overflow")==0||strcmp(p,"overflow-y")==0||strcmp(p,"overflow-x")==0){
        uint8_t ov=0;
        if(strcmp(v,"hidden")==0) ov=1;
        else if(strcmp(v,"scroll")==0) ov=2;
        else if(strcmp(v,"auto")==0) ov=3;
        if(strcmp(p,"overflow")==0||strcmp(p,"overflow-y")==0) st->overflow_y=ov;
        if(strcmp(p,"overflow")==0||strcmp(p,"overflow-x")==0) st->overflow_x=ov;
        st->overflow=ov;
        return;
    }

    /* Opacity / visibility */
    if(strcmp(p,"opacity")==0){
        float f=(float)atof(v);
        if(f<0)f=0; if(f>1)f=1;
        st->opacity=(uint8_t)(f*255);
        return;
    }
    if(strcmp(p,"visibility")==0){
        st->visibility=(strcmp(v,"hidden")==0)?1:(strcmp(v,"collapse")==0)?2:0; return; }

    /* Cursor */
    if(strcmp(p,"cursor")==0){
        if(strcmp(v,"pointer")==0)  st->cursor=1;
        else if(strcmp(v,"text")==0)st->cursor=2;
        else if(strcmp(v,"none")==0)st->cursor=3;
        else st->cursor=0;
        return;
    }

    /* v0.44: box-sizing. border-box includes padding+border in the
     * declared width; content-box (default) does not. */
    if(strcmp(p,"box-sizing")==0){
        st->box_sizing=(strcmp(v,"border-box")==0)?1:0;
        st->box_sizing_set=1;
        return;
    }

    /* v0.44: flex-shrink (default 1). */
    if(strcmp(p,"flex-shrink")==0){
        st->flex_shrink=(int16_t)atoi(v);
        return;
    }
    /* v0.44: flex-basis. */
    if(strcmp(p,"flex-basis")==0){
        if(strcmp(v,"auto")==0) st->flex_basis=-1;
        else st->flex_basis=css_parse_length(v,0,fp);
        return;
    }
    /* v0.44: flex shorthand: "grow shrink basis" or "none".
     * e.g. "flex: 1" → grow=1, "flex: 1 0 auto" → grow=1 shrink=0. */
    if(strcmp(p,"flex")==0){
        if(strcmp(v,"none")==0){
            st->flex_grow=0; st->flex_shrink=0; st->flex_basis=-1;
        } else if(strcmp(v,"auto")==0){
            st->flex_grow=1; st->flex_shrink=1; st->flex_basis=-1;
        } else {
            char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
            char *tok=strtok(tmp," ");
            int vals[3]={1,1,-1}; int vc=0;
            while(tok&&vc<3){
                if(strstr(tok,"px")||strstr(tok,"em")||strstr(tok,"%")||
                   strcmp(tok,"auto")==0){
                    vals[2]=strcmp(tok,"auto")==0?-1:(int16_t)css_parse_length(tok,0,fp);
                } else {
                    vals[vc<2?vc:2]=(int16_t)atoi(tok);
                }
                vc++; tok=strtok(NULL," ");
            }
            st->flex_grow=(int16_t)vals[0];
            st->flex_shrink=(int16_t)vals[1];
            st->flex_basis=(int16_t)vals[2];
        }
        return;
    }

    /* v0.44: pointer-events. */
    if(strcmp(p,"pointer-events")==0){
        st->pointer_events=(strcmp(v,"none")==0)?1:0;
        return;
    }
    /* v0.44: user-select. */
    if(strcmp(p,"user-select")==0){
        st->user_select=(strcmp(v,"none")==0)?1:0;
        return;
    }
    /* v0.44: outline (simplified — treated like border but without
     * affecting layout). */
    if(strcmp(p,"outline")==0){
        st->outline_width=0; st->outline_color=0;
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        char *tok=strtok(tmp," ");
        while(tok){
            if(strcmp(tok,"none")==0||strcmp(tok,"0")==0){
                st->outline_width=0;
            } else if((tok[0]>='0'&&tok[0]<='9')||strstr(tok,"px")){
                st->outline_width=(uint8_t)css_parse_length(tok,0,fp);
            } else {
                st->outline_color=css_parse_color(tok);
            }
            tok=strtok(NULL," ");
        }
        return;
    }
    if(strcmp(p,"outline-width")==0){
        st->outline_width=(uint8_t)css_parse_length(v,0,fp);
        return;
    }
    if(strcmp(p,"outline-color")==0){
        st->outline_color=css_parse_color(v);
        return;
    }
    if(strcmp(p,"outline-style")==0){
        /* accepted but not stored — only solid is drawn */
        return;
    }

    /* v0.44: text-transform. */
    if(strcmp(p,"text-transform")==0){
        if(strcmp(v,"uppercase")==0)       st->text_transform=1;
        else if(strcmp(v,"lowercase")==0)  st->text_transform=2;
        else if(strcmp(v,"capitalize")==0) st->text_transform=3;
        else st->text_transform=0;
        return;
    }

    /* v0.44: letter-spacing. */
    if(strcmp(p,"letter-spacing")==0){
        if(strcmp(v,"normal")==0) st->letter_spacing=0;
        else st->letter_spacing=css_parse_length(v,0,fp);
        return;
    }

    /* v0.44: line-height. Accepts px, unitless (multiplier), or
     * "normal". Stored as px (0 = normal = use font_size * 1.2). */
    if(strcmp(p,"line-height")==0){
        if(strcmp(v,"normal")==0) st->line_height=0;
        else {
            /* Check if it's a unitless multiplier (e.g. "1.5") */
            char *end;
            float f=(float)strtod(v,&end);
            if(*end=='\0'){
                /* Unitless multiplier — multiply by font size */
                st->line_height=(int16_t)(f*(float)fp);
            } else {
                st->line_height=css_parse_length(v,0,fp);
            }
        }
        return;
    }

    /* v0.44: list-style. */
    if(strcmp(p,"list-style")==0||strcmp(p,"list-style-type")==0){
        if(strcmp(v,"none")==0)          st->list_style=1;
        else if(strcmp(v,"circle")==0)   st->list_style=2;
        else if(strcmp(v,"square")==0)   st->list_style=3;
        else if(strcmp(v,"decimal")==0)  st->list_style=4;
        else st->list_style=0; /* disc */
        return;
    }

    /* v0.44: object-fit. */
    if(strcmp(p,"object-fit")==0){
        if(strcmp(v,"contain")==0)       st->object_fit=1;
        else if(strcmp(v,"cover")==0)    st->object_fit=2;
        else st->object_fit=0; /* fill */
        return;
    }

    /* v0.44: min-width / min-height / max-width / max-height with
     * "none" support. These were already parsed but didn't handle
     * "none" (which should set them to -1 = auto). */
    if(strcmp(p,"min-width")==0){
        if(strcmp(v,"none")==0||strcmp(v,"auto")==0) st->min_width=-1;
        else st->min_width=css_parse_length(v,400,fp);
        return;
    }
    if(strcmp(p,"min-height")==0){
        if(strcmp(v,"none")==0||strcmp(v,"auto")==0) st->min_height=-1;
        else st->min_height=css_parse_length(v,240,fp);
        return;
    }
    if(strcmp(p,"max-width")==0){
        if(strcmp(v,"none")==0||strcmp(v,"auto")==0) st->max_width=-1;
        else st->max_width=css_parse_length(v,400,fp);
        return;
    }
    if(strcmp(p,"max-height")==0){
        if(strcmp(v,"none")==0||strcmp(v,"auto")==0) st->max_height=-1;
        else st->max_height=css_parse_length(v,240,fp);
        return;
    }

    /* Transform (simple) */
    if(strcmp(p,"transform")==0){
        if(strncmp(v,"rotate(",7)==0){
            float deg=(float)atof(v+7);
            st->rotate_deg=deg;
        } else if(strncmp(v,"scale(",6)==0){
            float sx=1,sy=1;
            sscanf(v+6,"%f,%f",&sx,&sy);
            st->scale_x=sx; st->scale_y=sy;
        } else if(strncmp(v,"translate(",10)==0){
            float tx=0,ty=0;
            sscanf(v+10,"%f,%f",&tx,&ty);
            st->translate_x=tx; st->translate_y=ty;
        }
        return;
    }

    /* v0.42: box-shadow. Parses "offset-x offset-y blur color".
     * Simplified: blur is drawn as a spread (no real gaussian blur
     * on 3DS hardware). Color 0 = no shadow (default). */
    if(strcmp(p,"box-shadow")==0){
        /* Default: no shadow */
        st->shadow_color=0;
        st->shadow_x=0; st->shadow_y=0; st->shadow_blur=0;
        /* Parse tokens: numbers (with optional px) = offsets/blur,
         * color tokens = everything else. */
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        char *tok=strtok(tmp," ");
        int nums[3]={0,0,0}; int nc=0;
        uint32_t sc=0;
        while(tok){
            if((tok[0]>='0'&&tok[0]<='9')||tok[0]=='-'||tok[0]=='+'){
                if(nc<3){
                    nums[nc++]=(int16_t)css_parse_length(tok,0,fp);
                }
            } else if(strcmp(tok,"none")!=0){
                sc=css_parse_color(tok);
            }
            tok=strtok(NULL," ");
        }
        if(sc){
            st->shadow_x=(int16_t)nums[0];
            st->shadow_y=(int16_t)(nc>1?nums[1]:nums[0]);
            st->shadow_blur=(int16_t)(nc>2?nums[2]:0);
            st->shadow_color=sc;
        }
        return;
    }

    /* v0.42: linear-gradient. Parses:
     *   linear-gradient(to right, red, blue)
     *   linear-gradient(to bottom, #f00, #00f)
     *   linear-gradient(45deg, red, blue)   (45deg = to bottom-right)
     * Stores gradient_start/end/direction. gradient_active=1 tells
     * the renderer to draw bands instead of a solid fill. */
    if(strcmp(p,"background")==0 && strstr(v,"linear-gradient(")){
        /* Extract the content inside linear-gradient(...) */
        const char *gp=strstr(v,"linear-gradient(");
        if(gp){
            gp+=16; /* skip "linear-gradient(" */
            const char *end=strchr(gp,')');
            if(end){
                char gbuf[256];
                int gl=(int)(end-gp);
                if(gl>=255) gl=255;
                memcpy(gbuf,gp,gl); gbuf[gl]='\0';
                /* Parse direction and colors */
                st->gradient_dir=0; /* default: to right */
                st->gradient_start=0; st->gradient_end=0;
                st->gradient_start_set=0; st->gradient_end_set=0;
                st->gradient_active=1;
                /* Split on commas */
                char *save=NULL;
                char *part=strtok_r(gbuf,",",&save);
                int part_idx=0;
                while(part){
                    /* Trim leading spaces */
                    while(*part==' ') part++;
                    if(part_idx==0 && strncmp(part,"to ",3)==0){
                        if(strstr(part,"right"))     st->gradient_dir=0;
                        else if(strstr(part,"bottom")) st->gradient_dir=1;
                        else if(strstr(part,"left"))   st->gradient_dir=2;
                        else if(strstr(part,"top"))    st->gradient_dir=3;
                    } else if(part_idx==0 && strstr(part,"deg")){
                        /* Angle: 0=to top, 90=to right, 180=to bottom, 270=to left */
                        float deg=(float)atof(part);
                        int di=(int)((deg+45.0f)/90.0f)&3;
                        st->gradient_dir=(uint8_t)di;
                        part_idx=-1; /* colors start at next index 0 */
                    } else {
                        /* v0.42 audit: use _set flags instead of checking
                         * for 0, since 0x00000000 is a valid color (transparent). */
                        uint32_t col=css_parse_color(part);
                        if(!st->gradient_start_set){
                            st->gradient_start=col;
                            st->gradient_start_set=1;
                        } else if(!st->gradient_end_set){
                            st->gradient_end=col;
                            st->gradient_end_set=1;
                        }
                    }
                    part_idx++;
                    part=strtok_r(NULL,",",&save);
                }
                /* If only one color was given, gradient is solid */
                if(!st->gradient_end_set) st->gradient_end=st->gradient_start;
                return;
            }
        }
    }

    /* v0.42: transition. Parses "property duration timing-function".
     * We only care about duration; property is "all" by default,
     * timing-function is always ease-in-out (simplified). */
    if(strcmp(p,"transition")==0){
        st->transition_duration=0;
        /* Find a number followed by 's' or 'ms' */
        char tmp[128]; strncpy(tmp,v,127); tmp[127]=0;
        char *tok=strtok(tmp," ");
        while(tok){
            /* Check for "0.3s" or "300ms" */
            char *s_end;
            float val=strtof(tok,&s_end);
            if(s_end>tok){
                if(strcmp(s_end,"ms")==0){
                    st->transition_duration=(uint16_t)val;
                } else if(strcmp(s_end,"s")==0){
                    st->transition_duration=(uint16_t)(val*1000.0f);
                }
            }
            tok=strtok(NULL," ");
        }
        return;
    }

    /* v0.42: grid-template-columns. Parses:
     *   grid-template-columns: 100px 100px 100px   (3 fixed cols)
     *   grid-template-columns: repeat(3, 1fr)        (3 equal cols)
     *   grid-template-columns: 1fr 2fr 1fr           (3 proportional cols)
     *   grid-template-columns: auto auto             (2 equal cols)
     * Stores the column count in grid_cols and individual widths in
     * grid_template_cols (-1 = auto/equal, >0 = fixed px). */
    if(strcmp(p,"grid-template-columns")==0){
        st->grid_cols=0;
        for(int i=0;i<8;i++) st->grid_template_cols[i]=-1;
        char tmp[256]; strncpy(tmp,v,255); tmp[255]=0;
        /* Handle repeat(N, X) syntax first */
        char *rep=strstr(tmp,"repeat(");
        if(rep){
            int n=atoi(rep+7);
            if(n<1) n=1; if(n>8) n=8;
            /* Find the comma and the unit */
            char *comma=strchr(rep+7,',');
            if(comma){
                comma++;
                while(*comma==' ') comma++;
                int16_t col_w=-1; /* default: equal */
                if(strstr(comma,"fr")||strstr(comma,"auto")){
                    col_w=-1;
                } else {
                    col_w=(int16_t)css_parse_length(comma,0,fp);
                }
                for(int i=0;i<n;i++) st->grid_template_cols[i]=col_w;
                st->grid_cols=(uint8_t)n;
            }
        } else {
            /* Space-separated list of column widths */
            char *tok=strtok(tmp," ");
            while(tok && st->grid_cols<8){
                if(strstr(tok,"fr")){
                    /* Fractional unit — treat as auto (equal split) */
                    st->grid_template_cols[st->grid_cols]=-1;
                } else if(strcmp(tok,"auto")==0){
                    st->grid_template_cols[st->grid_cols]=-1;
                } else {
                    st->grid_template_cols[st->grid_cols]=
                        (int16_t)css_parse_length(tok,0,fp);
                }
                st->grid_cols++;
                tok=strtok(NULL," ");
            }
        }
        return;
    }
}

/* Expanded inline CSS buffer to handle longer style attributes.
 * v0.38 BUG FIX: buf[] was a non-static 2048-byte stack buffer, and
 * this function is called from inside css_parse_stylesheet() while
 * that function's own ~1KB+ of locals are still live on the stack —
 * over 3KB combined in a single call chain. Made static, matching the
 * pattern already used for large buffers elsewhere in this codebase
 * (see editor.c, file_explorer.c) to keep 3DS stack usage minimal.
 * Safe: CSS parsing is strictly sequential/non-reentrant — no call
 * site invokes this function while another call is already in
 * progress. */
void css_parse_inline(const char *inline_css, CSSStyle *out){
    if(!inline_css||!out) return;
    static char buf[2048];
    strncpy(buf,inline_css,2047); buf[2047]=0;
    char *p=buf;
    while(*p){
        /* find ':' */
        char *colon=strchr(p,':');
        if(!colon) break;
        *colon='\0';
        char *prop=p;
        char *val=colon+1;
        /* find ';' */
        char *semi=strchr(val,';');
        if(semi) *semi='\0';
        trim(prop); trim(val);
        apply_property(out,prop,val);
        if(!semi) break;
        p=semi+1;
    }
}

/* ── Stylesheet parser ──────────────────────────────────────────── */

void css_parse_stylesheet(const char *css_text){
    if(!css_text) return;
    const char *p=css_text;
    while(*p){
        /* skip whitespace/comments */
        while(*p&&isspace((unsigned char)*p)) p++;
        if(!*p) break;
        /* skip block comment */
        if(p[0]=='/'&&p[1]=='*'){
            const char *end=strstr(p+2,"*/");
            if(!end) break;
            p=end+2; continue;
        }
        /* v0.44: @media queries — skip the entire block gracefully.
         * We don't support responsive breakpoints, but we must parse
         * past the @media block without choking on it. Find the
         * matching closing brace (accounting for nested braces). */
        if(strncmp(p,"@media",6)==0){
            /* Skip to the opening brace */
            while(*p && *p!='{') p++;
            if(!*p) break;
            p++; /* skip '{' */
            /* Skip to matching '}' (track nesting) */
            int depth=1;
            while(*p && depth>0){
                if(*p=='{') depth++;
                else if(*p=='}') depth--;
                p++;
            }
            continue;
        }
        /* v0.44: @keyframes — skip the entire block (transitions
         * don't use @keyframes in our simplified engine). */
        if(strncmp(p,"@keyframes",10)==0||strncmp(p,"@-webkit-keyframes",18)==0){
            while(*p && *p!='{') p++;
            if(!*p) break;
            p++;
            int depth=1;
            while(*p && depth>0){
                if(*p=='{') depth++;
                else if(*p=='}') depth--;
                p++;
            }
            continue;
        }
        /* v0.44: @import / @font-face / @charset — skip to ';' or '}' */
        if(p[0]=='@'){
            while(*p && *p!=';' && *p!='}') p++;
            if(*p==';') p++;
            else if(*p=='}') p++;
            continue;
        }
        /* read selector up to '{' */
        const char *sel_start=p;
        while(*p&&*p!='{') p++;
        if(!*p) break;
        char sel[CSS_SEL_LEN]; int sl=(int)(p-sel_start);
        if(sl>=CSS_SEL_LEN) sl=CSS_SEL_LEN-1;
        memcpy(sel,sel_start,sl); sel[sl]='\0'; trim(sel);
        p++; /* skip '{' */
        /* read declarations up to '}' */
        const char *decl_start=p;
        while(*p&&*p!='}') p++;
        static char decl_buf[1024];
        int dl=(int)(p-decl_start);
        if(dl>=1024) dl=1023;
        memcpy(decl_buf,decl_start,dl); decl_buf[dl]='\0';
        if(*p=='}') p++;
        /* v0.44: :root selector — apply declarations as CSS custom
         * properties (they're usually --variable definitions). The
         * css_parse_inline call will route --name:value to css_set_var
         * via apply_property. Also match :root as a universal selector
         * so regular properties (like font-size on :root) apply to
         * all elements via inheritance. */
        if(strcmp(sel,":root")==0 || strcmp(sel,"html")==0){
            /* v0.44: :root selector. Parse declarations into a *
             * rule so properties cascade to all elements. The
             * css_parse_inline call also routes --name:value to
             * css_set_var via apply_property, so custom properties
             * are stored in the global variable table.
             * v0.44 audit fix: removed the write to g_css_rules[0]
             * which was corrupting the first existing rule (the UA
             * stylesheet). Only create the * rule. */
            if(g_css_rule_n<CSS_MAX_RULES){
                CSSRule *r=&g_css_rules[g_css_rule_n];
                strncpy(r->selector,"*",CSS_SEL_LEN-1);
                r->selector[CSS_SEL_LEN-1]='\0';
                r->style=css_default_style();
                r->used=1;
                r->specificity=0; /* lowest specificity */
                css_parse_inline(decl_buf,&r->style);
                g_css_rule_n++;
            }
            continue;
        }
        /* v0.44: comma-separated selectors — split and create a
         * separate rule for each. e.g. "h1, h2, h3 { ... }"
         * v0.44 audit fix: use strtok_r instead of strtok so the
         * css_parse_inline call (which uses strtok internally for
         * shorthand properties) doesn't corrupt the selector split. */
        if(strchr(sel,',')){
            static char sel_copy[CSS_SEL_LEN];
            strncpy(sel_copy,sel,CSS_SEL_LEN-1);
            sel_copy[CSS_SEL_LEN-1]='\0';
            char *saveptr=NULL;
            char *tok=strtok_r(sel_copy,",",&saveptr);
            while(tok){
                /* trim the sub-selector */
                while(*tok==' ') tok++;
                char *end_tok=tok+strlen(tok)-1;
                while(end_tok>tok && (*end_tok==' '||*end_tok=='\t')) *end_tok--='\0';
                if(*tok && g_css_rule_n<CSS_MAX_RULES){
                    CSSRule *r=&g_css_rules[g_css_rule_n];
                    strncpy(r->selector,tok,CSS_SEL_LEN-1);
                    r->selector[CSS_SEL_LEN-1]='\0';
                    r->style=css_default_style();
                    r->used=1;
                    if(strchr(tok,'#')) r->specificity=100;
                    else if(strchr(tok,'.')) r->specificity=10;
                    else r->specificity=1;
                    css_parse_inline(decl_buf,&r->style);
                    g_css_rule_n++;
                }
                tok=strtok_r(NULL,",",&saveptr);
            }
            continue;
        }
        /* create rule */
        if(g_css_rule_n<CSS_MAX_RULES&&*sel){
            CSSRule *r=&g_css_rules[g_css_rule_n];
            strncpy(r->selector,sel,CSS_SEL_LEN-1);
            r->selector[CSS_SEL_LEN-1]='\0';
            r->style=css_default_style();
            r->used=1;
            /* compute rough specificity */
            if(strchr(sel,'#')) r->specificity=100;
            else if(strchr(sel,'.')) r->specificity=10;
            else r->specificity=1;
            css_parse_inline(decl_buf,&r->style);
            g_css_rule_n++;
        }
    }
}

/* ── Default style ──────────────────────────────────────────────── */

CSSStyle css_default_style(void){
    CSSStyle s; memset(&s,0,sizeof(s));
    s.color      = CSS_DEFAULT_COLOR;
    s.background = 0x00000000; /* transparent */
    /* font_size = 0 means "unset / inherit".
     * css_compute_node resolves this to CSS_DEFAULT_FONT_SIZE
     * at the end of the cascade if still 0.                  */
    s.font_size  = 0;
    s.opacity    = 255;
    s.display    = 0; /* block */
    s.width      = -1; s.height=-1;
    s.max_width  = -1; s.max_height=-1;
    s.scale_x    = 1.f; s.scale_y=1.f;
    /* v0.44: new property defaults */
    s.flex_shrink = 1;  /* default flex-shrink is 1 */
    s.flex_basis  = -1; /* default flex-basis is auto */
    return s;
}

/* ── Style inheritance ──────────────────────────────────────────── */

void css_inherit(CSSStyle *child, const CSSStyle *parent){
    /* inherited properties */
    if(child->color==CSS_DEFAULT_COLOR)  child->color=parent->color;
    if(child->font_size==0)              child->font_size=parent->font_size;
    if(child->font_weight==0)            child->font_weight=parent->font_weight;
    if(child->font_style==0)             child->font_style=parent->font_style;
    if(child->text_align==0)             child->text_align=parent->text_align;
    if(child->white_space==0)            child->white_space=parent->white_space;
    if(child->cursor==0)                 child->cursor=parent->cursor;
}

/* ── Cascade for a document ─────────────────────────────────────── */

/* v0.41: Check if a pseudo-class matches a node.
 * Supports: :hover, :focus, :active, :checked, :disabled,
 *           :first-child, :last-child, :nth-child(n), :nth-child(odd/even).
 * Returns true if the pseudo-class matches, false otherwise.
 * `pseudo` points just past the ':' character. */
/* v0.44: forward declarations for :not() support (mutual recursion). */
static bool selector_matches(const char *sel, int16_t node_id);
static bool pseudo_not_matches(const char *arg, int16_t node_id);

static bool pseudo_matches(const char *pseudo, int16_t node_id){
    DOMNode *n=dom_node(node_id);
    if(!n) return false;

    if(strcmp(pseudo,"hover")==0)   return n->hover!=0;
    if(strcmp(pseudo,"focus")==0)   return n->focused!=0;
    if(strcmp(pseudo,"active")==0)  return n->active!=0;
    if(strcmp(pseudo,"checked")==0) return n->checked!=0;
    if(strcmp(pseudo,"disabled")==0)return n->disabled!=0;

    /* Structural pseudo-classes — require walking the sibling chain */
    if(strcmp(pseudo,"first-child")==0){
        return n->prev_sib<0;
    }
    if(strcmp(pseudo,"last-child")==0){
        return n->next_sib<0;
    }
    if(strncmp(pseudo,"nth-child(",10)==0){
        /* Parse the argument inside nth-child(...) */
        const char *arg=pseudo+10;
        const char *close=strchr(arg,')');
        if(!close) return false;
        char abuf[16]; int al=(int)(close-arg);
        if(al>=16) al=15;
        memcpy(abuf,arg,al); abuf[al]='\0';
        /* Count this node's position among siblings (1-based) */
        int pos=1;
        int16_t ps=n->prev_sib;
        int guard=0;
        while(ps>=0 && guard<g_dom_node_n){
            guard++;
            pos++;
            ps=g_dom_nodes[ps].prev_sib;
        }
        if(strcmp(abuf,"odd")==0)  return (pos%2)==1;
        if(strcmp(abuf,"even")==0) return (pos%2)==0;
        /* Plain integer */
        int n_val=atoi(abuf);
        if(n_val>0) return pos==n_val;
        return false;
    }
    /* v0.44: :not(selector) — negate the inner selector match. */
    if(strncmp(pseudo,"not(",4)==0){
        const char *arg=pseudo+4;
        const char *close=strrchr(arg,')');
        if(!close) return true; /* malformed :not() — treat as match */
        char inner[CSS_SEL_LEN]; int il=(int)(close-arg);
        if(il>=CSS_SEL_LEN) il=CSS_SEL_LEN-1;
        memcpy(inner,arg,il); inner[il]='\0';
        return pseudo_not_matches(inner, node_id);
    }
    return false; /* unknown pseudo-class */
}

/* v0.44: :not() selector support. Parses the argument inside
 * :not(selector) and returns true if the node does NOT match. */
static bool pseudo_not_matches(const char *arg, int16_t node_id){
    if(!arg||!*arg) return true;
    /* The arg is a simple selector (tag, .class, #id). We recursively
     * call selector_matches with it. If it matches, :not() returns
     * false (and vice versa). */
    return !selector_matches(arg, node_id);
}

/* Check if selector matches node.
 * v0.41: now supports pseudo-classes: :hover, :focus, :active, :checked,
 * :disabled, :first-child, :last-child, :nth-child(n/odd/even).
 * A selector like "div.foo:hover" is split at the ':' — the base
 * selector ("div.foo") is matched first, then the pseudo ("hover").
 * Multiple pseudo-classes can be chained (e.g. "a:focus:hover"). */
static bool selector_matches(const char *sel, int16_t node_id){
    if(!sel||!*sel) return false;
    DOMNode *n=dom_node(node_id);
    if(!n||n->type!=NT_ELEMENT) return false;
    const char *tag=dom_str(n->tag_off);

    /* v0.41: Split off pseudo-class part(s) at the first ':'. The base
     * selector is everything before it; the pseudo(s) are after. */
    char base[CSS_SEL_LEN];
    const char *pseudos = strchr(sel, ':');
    if(pseudos){
        int bl=(int)(pseudos-sel);
        if(bl>=CSS_SEL_LEN) bl=CSS_SEL_LEN-1;
        memcpy(base,sel,bl); base[bl]='\0';
        sel=base;
        /* Skip the ':' */
        pseudos++;
    }

    /* #id */
    if(sel[0]=='#'){
        const char *id=dom_get_attr(node_id,"id");
        if(!id || strcmp(id,sel+1)!=0) return false;
        /* fall through to pseudo check */
    }
    /* .class */
    else if(sel[0]=='.'){
        const char *cls=dom_get_attr(node_id,"class");
        if(!cls) return false;
        char buf[256]; strncpy(buf,cls,255); buf[255]=0;
        char *tok=strtok(buf," ");
        bool found=false;
        while(tok){ if(strcmp(tok,sel+1)==0){ found=true; break; } tok=strtok(NULL," "); }
        if(!found) return false;
    }
    /* tag.class */
    else if(strchr(sel,'.')){
        const char *dot=strchr(sel,'.');
        char tbuf[32]; int tl=(int)(dot-sel); if(tl>=32)tl=31;
        memcpy(tbuf,sel,tl); tbuf[tl]=0;
        if(strcmp(tag,tbuf)!=0) return false;
        const char *cls=dom_get_attr(node_id,"class");
        if(!cls) return false;
        char cbuf[256]; strncpy(cbuf,cls,255); cbuf[255]=0;
        char *tok=strtok(cbuf," ");
        bool found=false;
        while(tok){ if(strcmp(tok,dot+1)==0){ found=true; break; } tok=strtok(NULL," "); }
        if(!found) return false;
    }
    /* tag or * */
    else {
        if(strcmp(sel,"*")!=0 && strcmp(sel,tag)!=0) return false;
    }

    /* If there was a pseudo-class, check it now (after the base matched). */
    if(pseudos){
        /* Handle chained pseudos: "hover:focus" — split on ':' */
        char pbuf[CSS_SEL_LEN];
        strncpy(pbuf, pseudos, CSS_SEL_LEN-1);
        pbuf[CSS_SEL_LEN-1]='\0';
        char *p = pbuf;
        while(*p){
            /* Find the next ':' delimiter */
            char *next_colon = strchr(p, ':');
            if(next_colon) *next_colon = '\0';
            if(!pseudo_matches(p, node_id)) return false;
            if(next_colon) p = next_colon + 1;
            else break;
        }
    }
    return true;
}

void css_compute_node(int16_t node_id){
    DOMNode *n=dom_node(node_id);
    if(!n) return;
    /* start with defaults (font_size=0 = unset) */
    CSSStyle st=css_default_style();
    /* inherit from parent (font_size propagates if parent has it set) */
    if(n->parent>=0) css_inherit(&st,&g_dom_nodes[n->parent].style);
    /* apply stylesheet rules (in order, for simple cascade) */
    for(int i=0;i<g_css_rule_n;i++){
        if(!g_css_rules[i].used) continue;
        if(selector_matches(g_css_rules[i].selector,node_id)){
            /* merge: non-default wins.
             * v0.40 audit fix: the previous MERGE block was missing
             * several fields that apply_property() actually parses,
             * so stylesheet rules setting those properties were
             * silently dropped during cascade. Added: align_self,
             * overflow_x, overflow_y, min_width, min_height,
             * max_width, max_height, z_index, translate_x,
             * translate_y. Each uses a default-sentinel guard so a
             * legitimately-set 0 still wins over the default. */
            CSSStyle *rs=&g_css_rules[i].style;
            #define MERGE_U32(f) if(rs->f) st.f=rs->f
            #define MERGE_I16(f) if(rs->f) st.f=rs->f
            #define MERGE_I16_NEG(f) if(rs->f!=-1) st.f=rs->f
            #define MERGE_U8(f)  if(rs->f) st.f=rs->f
            MERGE_U32(color); MERGE_U32(background); MERGE_U32(border_color);
            MERGE_I16(margin_top);MERGE_I16(margin_right);
            MERGE_I16(margin_bottom);MERGE_I16(margin_left);
            MERGE_I16(padding_top);MERGE_I16(padding_right);
            MERGE_I16(padding_bottom);MERGE_I16(padding_left);
            MERGE_I16(border_width); MERGE_I16(border_radius);
            MERGE_I16_NEG(width); MERGE_I16_NEG(height);
            MERGE_I16_NEG(min_width); MERGE_I16_NEG(min_height);
            MERGE_I16_NEG(max_width); MERGE_I16_NEG(max_height);
            MERGE_U8(position); MERGE_U8(display);
            MERGE_U8(flex_direction); MERGE_U8(justify_content);
            MERGE_U8(align_items); MERGE_U8(align_self);
            MERGE_U8(flex_wrap);
            MERGE_I16(flex_grow); MERGE_I16(gap);
            MERGE_U8(font_weight); MERGE_U8(font_style);
            if(rs->font_size) st.font_size=rs->font_size;
            MERGE_U8(text_align); MERGE_U8(text_decoration);
            MERGE_U8(white_space);
            MERGE_U8(overflow); MERGE_U8(overflow_x); MERGE_U8(overflow_y);
            if(rs->opacity!=255&&rs->opacity!=0) st.opacity=rs->opacity;
            MERGE_U8(visibility); MERGE_U8(cursor);
            MERGE_I16(left); MERGE_I16(top);
            MERGE_I16(right); MERGE_I16(bottom);
            MERGE_I16(z_index);
            if(rs->rotate_deg) st.rotate_deg=rs->rotate_deg;
            if(rs->scale_x!=1.f) st.scale_x=rs->scale_x;
            if(rs->scale_y!=1.f) st.scale_y=rs->scale_y;
            if(rs->translate_x) st.translate_x=rs->translate_x;
            if(rs->translate_y) st.translate_y=rs->translate_y;
            /* v0.42: box-shadow, gradient, transition */
            if(rs->shadow_color) st.shadow_color=rs->shadow_color;
            if(rs->shadow_x)     st.shadow_x=rs->shadow_x;
            if(rs->shadow_y)     st.shadow_y=rs->shadow_y;
            if(rs->shadow_blur)  st.shadow_blur=rs->shadow_blur;
            if(rs->gradient_active) st.gradient_active=rs->gradient_active;
            if(rs->gradient_dir)    st.gradient_dir=rs->gradient_dir;
            if(rs->gradient_start_set){ st.gradient_start=rs->gradient_start; st.gradient_start_set=1; }
            if(rs->gradient_end_set){   st.gradient_end=rs->gradient_end;     st.gradient_end_set=1; }
            if(rs->transition_duration) st.transition_duration=rs->transition_duration;
            /* v0.42: grid */
            if(rs->grid_cols){
                st.grid_cols=rs->grid_cols;
                for(int gi=0;gi<8;gi++)
                    st.grid_template_cols[gi]=rs->grid_template_cols[gi];
            }
            /* v0.44: new properties */
            if(rs->box_sizing_set) st.box_sizing=rs->box_sizing, st.box_sizing_set=1;
            if(rs->flex_shrink!=1) st.flex_shrink=rs->flex_shrink;
            if(rs->flex_basis!=-1) st.flex_basis=rs->flex_basis;
            if(rs->pointer_events) st.pointer_events=rs->pointer_events;
            if(rs->user_select)    st.user_select=rs->user_select;
            if(rs->outline_width)  st.outline_width=rs->outline_width;
            if(rs->outline_color)  st.outline_color=rs->outline_color;
            if(rs->text_transform) st.text_transform=rs->text_transform;
            if(rs->letter_spacing) st.letter_spacing=rs->letter_spacing;
            if(rs->line_height)    st.line_height=rs->line_height;
            if(rs->list_style)     st.list_style=rs->list_style;
            if(rs->object_fit)     st.object_fit=rs->object_fit;
        }
    }
    /* apply inline style (highest priority) */
    const char *inl=dom_get_attr(node_id,"style");
    if(inl) css_parse_inline(inl,&st);
    /* resolve unset font_size to fallback */
    if(!st.font_size) st.font_size=CSS_DEFAULT_FONT_SIZE;

    /* v0.42: Transition detection. If the new computed style has
     * transition_duration > 0, compare against the OLD computed style
     * (still in n->style) and record transitions for changed numeric
     * properties. The transition engine will interpolate the values
     * each frame and write them to n->style, overriding the computed
     * value until the transition completes. */
    if(st.transition_duration > 0){
        /* Get current time from the web engine (osGetTime). We use
         * a simple extern to avoid a circular include. */
        extern uint64_t we_get_time_ms(void);
        double now_ms = (double)we_get_time_ms();
        css_transitions_detect((uint16_t)node_id, &n->style, &st, now_ms);
    }

    n->style=st;
}

void css_cascade(uint8_t doc_id){
    for(int i=0;i<g_dom_node_n;i++){
        if(g_dom_nodes[i].doc_id==doc_id&&
           g_dom_nodes[i].type==NT_ELEMENT)
            css_compute_node((int16_t)i);
    }
}

void css_reset(void){
    g_css_rule_n=0;
    memset(g_css_rules,0,sizeof(g_css_rules));
    /* v0.44: reset custom properties too */
    memset(g_css_vars,0,sizeof(g_css_vars));
}

/* ── Browser default (UA) stylesheet ───────────────────────────── */
/*
 * Injected before user stylesheets so user rules always win.
 * Sizes are calibrated for the 3DS top screen (400x240 px):
 *   - body margin-top:16px keeps content below the 14px RUNNING bar
 *   - font sizes chosen so scale = size/30.0f gives readable results
 */
void css_apply_ua_defaults(void){
    static const char s_ua_css[] =
        "html{font-size:14px;}"
        "body{margin-top:16px;margin-right:3px;"
              "margin-bottom:3px;margin-left:3px;}"
        "h1{font-size:22px;font-weight:bold;}"
        "h2{font-size:18px;font-weight:bold;}"
        "h3{font-size:15px;font-weight:bold;}"
        "h4{font-size:14px;font-weight:bold;}"
        "h5{font-size:13px;font-weight:bold;}"
        "h6{font-size:12px;font-weight:bold;}"
        "b{font-weight:bold;}"
        "strong{font-weight:bold;}"
        "i{font-style:italic;}"
        "em{font-style:italic;}"
        "a{color:#79c0ff;}"
        "pre{white-space:pre;}"
        "code{white-space:pre;}";
    css_parse_stylesheet(s_ua_css);
}

/* ═══════════════════════════════════════════════════════════════
   v0.42: CSS Transitions engine
   ═══════════════════════════════════════════════════════════════ */

CSSTransition g_transitions[CSS_MAX_TRANSITIONS];
int           g_transition_n=0;

/* Helper: get a float value for a transitionable property from a
 * CSSStyle. Colors are packed RGBA8; we interpolate each channel
 * separately but store as a single float (re-packing). For colors,
 * old_val/new_val store the full uint32 as a float. */
static float style_get_float(const CSSStyle *s, TransitionProp p){
    switch(p){
        case TR_OPACITY:    return (float)s->opacity;
        case TR_WIDTH:      return (float)s->width;
        case TR_HEIGHT:     return (float)s->height;
        case TR_MARGIN_TOP:    return (float)s->margin_top;
        case TR_MARGIN_RIGHT:  return (float)s->margin_right;
        case TR_MARGIN_BOTTOM: return (float)s->margin_bottom;
        case TR_MARGIN_LEFT:   return (float)s->margin_left;
        case TR_PADDING_TOP:    return (float)s->padding_top;
        case TR_PADDING_RIGHT:  return (float)s->padding_right;
        case TR_PADDING_BOTTOM: return (float)s->padding_bottom;
        case TR_PADDING_LEFT:   return (float)s->padding_left;
        case TR_TRANSLATE_X: return s->translate_x;
        case TR_TRANSLATE_Y: return s->translate_y;
        case TR_LEFT:   return (float)s->left;
        case TR_TOP:    return (float)s->top;
        case TR_RIGHT:  return (float)s->right;
        case TR_BOTTOM: return (float)s->bottom;
        case TR_FONT_SIZE:     return (float)s->font_size;
        case TR_BORDER_WIDTH:  return (float)s->border_width;
        case TR_BORDER_RADIUS: return (float)s->border_radius;
        case TR_ROTATE:   return s->rotate_deg;
        case TR_SCALE_X:  return s->scale_x;
        case TR_SCALE_Y:  return s->scale_y;
        /* Colors: pack RGBA8 into a float (lossy but reversible for
         * the interpolation — we unpack in the setter). */
        case TR_COLOR:       return (float)(uint32_t)s->color;
        case TR_BACKGROUND:  return (float)(uint32_t)s->background;
        default: return 0;
    }
}

/* Helper: write an interpolated float value back to a CSSStyle. */
static void style_set_float(CSSStyle *s, TransitionProp p, float v){
    switch(p){
        case TR_OPACITY:    s->opacity=(uint8_t)v; break;
        case TR_WIDTH:      s->width=(int16_t)v; break;
        case TR_HEIGHT:     s->height=(int16_t)v; break;
        case TR_MARGIN_TOP:    s->margin_top=(int16_t)v; break;
        case TR_MARGIN_RIGHT:  s->margin_right=(int16_t)v; break;
        case TR_MARGIN_BOTTOM: s->margin_bottom=(int16_t)v; break;
        case TR_MARGIN_LEFT:   s->margin_left=(int16_t)v; break;
        case TR_PADDING_TOP:    s->padding_top=(int16_t)v; break;
        case TR_PADDING_RIGHT:  s->padding_right=(int16_t)v; break;
        case TR_PADDING_BOTTOM: s->padding_bottom=(int16_t)v; break;
        case TR_PADDING_LEFT:   s->padding_left=(int16_t)v; break;
        case TR_TRANSLATE_X: s->translate_x=v; break;
        case TR_TRANSLATE_Y: s->translate_y=v; break;
        case TR_LEFT:   s->left=(int16_t)v; break;
        case TR_TOP:    s->top=(int16_t)v; break;
        case TR_RIGHT:  s->right=(int16_t)v; break;
        case TR_BOTTOM: s->bottom=(int16_t)v; break;
        case TR_FONT_SIZE:     s->font_size=(int16_t)v; break;
        case TR_BORDER_WIDTH:  s->border_width=(int16_t)v; break;
        case TR_BORDER_RADIUS: s->border_radius=(int16_t)v; break;
        case TR_ROTATE:   s->rotate_deg=v; break;
        case TR_SCALE_X:  s->scale_x=v; break;
        case TR_SCALE_Y:  s->scale_y=v; break;
        case TR_COLOR:       s->color=(uint32_t)v; break;
        case TR_BACKGROUND:  s->background=(uint32_t)v; break;
        default: break;
    }
}

/* v0.42 audit: interpolate a color (RGBA8) channel-by-channel.
 * Takes uint32_t inputs directly (not floats) to avoid precision loss. */
static uint32_t interp_color_u32(uint32_t oc, uint32_t nc, float t){
    uint8_t or_=(oc>>24)&0xFF, og=(oc>>16)&0xFF, ob=(oc>>8)&0xFF, oa=oc&0xFF;
    uint8_t nr=(nc>>24)&0xFF, ng=(nc>>16)&0xFF, nb=(nc>>8)&0xFF, na=nc&0xFF;
    uint8_t r=(uint8_t)(or_+(int)((nr-or_)*t));
    uint8_t g=(uint8_t)(og+(int)((ng-og)*t));
    uint8_t b=(uint8_t)(ob+(int)((nb-ob)*t));
    uint8_t a=(uint8_t)(oa+(int)((na-oa)*t));
    return ((uint32_t)r<<24)|((uint32_t)g<<16)|((uint32_t)b<<8)|(uint32_t)a;
}

/* Ease-in-out timing function: 3t² - 2t³ (smoothstep). */
static float ease_in_out(float t){
    return t*t*(3.f-2.f*t);
}

void css_transitions_detect(uint16_t node_id, const CSSStyle *old_st,
                            const CSSStyle *new_st, double now_ms){
    if(!old_st||!new_st) return;
    if(new_st->transition_duration==0) return;

    /* Check each transitionable property. If old != new, record a
     * transition. We check a fixed list of the most common ones. */
    static const TransitionProp check[]={
        TR_OPACITY, TR_WIDTH, TR_HEIGHT,
        TR_MARGIN_TOP, TR_MARGIN_RIGHT, TR_MARGIN_BOTTOM, TR_MARGIN_LEFT,
        TR_PADDING_TOP, TR_PADDING_RIGHT, TR_PADDING_BOTTOM, TR_PADDING_LEFT,
        TR_TRANSLATE_X, TR_TRANSLATE_Y,
        TR_LEFT, TR_TOP, TR_RIGHT, TR_BOTTOM,
        TR_FONT_SIZE, TR_BORDER_WIDTH, TR_BORDER_RADIUS,
        TR_ROTATE, TR_SCALE_X, TR_SCALE_Y,
        TR_COLOR, TR_BACKGROUND,
        TR_NONE
    };

    for(int i=0; check[i]!=TR_NONE; i++){
        TransitionProp p=check[i];

        /* v0.42 audit: handle colors separately to avoid float
         * precision loss. uint32 RGBA8 can't be stored in a float
         * without losing bits past 2^24. */
        bool is_color = (p==TR_COLOR || p==TR_BACKGROUND);
        bool changed;
        if(is_color){
            uint32_t oc = (p==TR_COLOR) ? old_st->color : old_st->background;
            uint32_t nc = (p==TR_COLOR) ? new_st->color : new_st->background;
            changed = (oc != nc);
        } else {
            float ov=style_get_float(old_st,p);
            float nv=style_get_float(new_st,p);
            float diff=nv-ov;
            if(diff<0) diff=-diff;
            changed = (diff>=0.5f);
        }
        if(!changed) continue;

        /* Find an existing transition for this node+prop and update it,
         * or allocate a new slot. */
        int slot=-1;
        for(int j=0;j<g_transition_n;j++){
            if(g_transitions[j].active &&
               g_transitions[j].node_id==node_id &&
               g_transitions[j].prop==p){
                slot=j;
                break;
            }
        }
        if(slot<0){
            if(g_transition_n>=CSS_MAX_TRANSITIONS){
                /* Find a finished slot to reuse */
                for(int j=0;j<CSS_MAX_TRANSITIONS;j++){
                    if(!g_transitions[j].active){ slot=j; break; }
                }
                if(slot<0) continue;  /* all slots busy; skip */
                if(slot>=g_transition_n) g_transition_n=slot+1;
            } else {
                slot=g_transition_n++;
            }
        }

        g_transitions[slot].active=true;
        g_transitions[slot].node_id=node_id;
        g_transitions[slot].prop=p;
        /* v0.42 audit: store colors in old_color/new_color (not
         * old_val/new_val) to avoid float precision loss. */
        if(is_color){
            g_transitions[slot].old_color = (p==TR_COLOR) ? old_st->color : old_st->background;
            g_transitions[slot].new_color = (p==TR_COLOR) ? new_st->color : new_st->background;
        } else {
            g_transitions[slot].old_val=style_get_float(old_st,p);
            g_transitions[slot].new_val=style_get_float(new_st,p);
        }
        g_transitions[slot].start_time=now_ms;
        g_transitions[slot].duration=new_st->transition_duration;
    }
}

void css_tick_transitions(double now_ms){
    for(int i=0;i<g_transition_n;i++){
        if(!g_transitions[i].active) continue;
        CSSTransition *tr=&g_transitions[i];
        DOMNode *n=dom_node((int16_t)tr->node_id);
        if(!n){ tr->active=false; continue; }

        double elapsed=now_ms - tr->start_time;
        bool is_color = (tr->prop==TR_COLOR || tr->prop==TR_BACKGROUND);

        if(elapsed>=(double)tr->duration){
            /* Transition complete — snap to target value */
            if(is_color){
                style_set_float(&n->style, tr->prop, (float)tr->new_color);
            } else {
                style_set_float(&n->style, tr->prop, tr->new_val);
            }
            tr->active=false;
        } else if(elapsed<=0){
            /* Not started yet — hold at old value */
            if(is_color){
                style_set_float(&n->style, tr->prop, (float)tr->old_color);
            } else {
                style_set_float(&n->style, tr->prop, tr->old_val);
            }
        } else {
            /* Interpolate */
            float t=(float)(elapsed/(double)tr->duration);
            t=ease_in_out(t);
            if(is_color){
                /* v0.42 audit: interpolate using old_color/new_color
                 * (uint32) to avoid float precision loss */
                uint32_t v=interp_color_u32(tr->old_color, tr->new_color, t);
                style_set_float(&n->style, tr->prop, (float)v);
            } else {
                float v=tr->old_val + (tr->new_val-tr->old_val)*t;
                style_set_float(&n->style, tr->prop, v);
            }
        }
    }
}

void css_transitions_reset(void){
    for(int i=0;i<CSS_MAX_TRANSITIONS;i++) g_transitions[i].active=false;
    g_transition_n=0;
}
