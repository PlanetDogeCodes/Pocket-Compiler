/*
 * web_iframe.c  —  iframe sub-document support
 */
#include "web_iframe.h"
#include "duktape.h"
#include "web_dom.h"
#include "web_css.h"
#include "web_layout.h"
#include "web_render.h"
#include "web_js.h"
#include "web_html_parser.h"
#include "web_fetch.h"
#include "web_events.h"
#include <string.h>
#include <stdio.h>

WEIFrame g_iframes[WE_MAX_IFRAMES];

void wif_init(void){
    memset(g_iframes,0,sizeof(g_iframes));
}

int wif_load(int16_t host_node, uint8_t parent_doc, const char *src){
    /* find free slot */
    int slot=-1;
    for(int i=0;i<WE_MAX_IFRAMES;i++){
        if(!g_iframes[i].used){ slot=i; break; }
    }
    if(slot<0) return -1;
    /* allocate sub-document */
    uint8_t child_doc=dom_new_doc();
    if(child_doc==0xFF) return -1;
    g_iframes[slot].used=true;
    g_iframes[slot].host_node=host_node;
    g_iframes[slot].parent_doc=parent_doc;
    g_iframes[slot].child_doc=child_doc;
    strncpy(g_iframes[slot].src,src?src:"",255);
    g_iframes[slot].loaded=false;
    /* check sandbox attr */
    const char *sb=dom_get_attr(host_node,"sandbox");
    g_iframes[slot].sandbox=(sb!=NULL);
    g_iframes[slot].allow_scripts=(sb&&strstr(sb,"allow-scripts")!=NULL)||!sb;
    /* set iframe geometry from host node layout */
    DOMNode *hn=dom_node(host_node);
    if(hn){
        DOMDocument *cd=dom_doc(child_doc);
        if(cd){
            cd->frame_x=hn->lay_x; cd->frame_y=hn->lay_y;
            cd->frame_w=hn->lay_w>0?hn->lay_w:320;
            cd->frame_h=hn->lay_h>0?hn->lay_h:240;
            cd->parent_doc=parent_doc;
        }
    }
    /* fetch and parse src */
    if(src&&*src){
        static WFResponse resp; memset(&resp,0,sizeof(resp));
        if(wf_fetch_sync(src,&resp)&&resp.ok){
            WEParseOpts opts={.doc_id=child_doc,.fragment_mode=false,.fragment_parent=-1};
            wep_parse((const char*)resp.body,&opts);
            /* create JS context if scripts allowed */
            if(g_iframes[slot].allow_scripts){
                duk_context *jsc=wjs_create_context(child_doc);
                DOMDocument *cd=dom_doc(child_doc);
                if(cd){ cd->js_ctx=jsc; cd->js_ready=(jsc!=NULL); }
                if(jsc) wep_run_scripts(child_doc);
            }
            layout_document(child_doc);
            g_iframes[slot].loaded=true;
        }
    }
    /* Mark host node with iframe ref */
    if(hn) hn->canvas_id=0; /* canvas_id not used here */
    return slot;
}

void wif_unload(int i){
    if(i<0||i>=WE_MAX_IFRAMES||!g_iframes[i].used) return;
    uint8_t cid=g_iframes[i].child_doc;
    DOMDocument *cd=dom_doc(cid);
    if(cd&&cd->js_ctx){
        wjs_destroy_context((duk_context*)cd->js_ctx);
        cd->js_ctx=NULL;
    }
    dom_free_doc(cid);
    g_iframes[i].used=false;
}

int wif_find(int16_t host_node){
    for(int i=0;i<WE_MAX_IFRAMES;i++)
        if(g_iframes[i].used&&g_iframes[i].host_node==host_node) return i;
    return -1;
}

void wif_tick(const void *inp_state){
    const WEInputState *inp=(const WEInputState*)inp_state;
    for(int i=0;i<WE_MAX_IFRAMES;i++){
        if(!g_iframes[i].used||!g_iframes[i].loaded) continue;
        uint8_t cid=g_iframes[i].child_doc;
        DOMDocument *cd=dom_doc(cid);
        if(!cd) continue;
        /* tick JS */
        if(cd->js_ctx&&cd->js_ready){
            duk_context *ctx=(duk_context*)cd->js_ctx;
            wjs_tick_timers(ctx);
            /* todo: compute dt */
            wjs_tick_raf(ctx,0);
            wf_tick(ctx);
        }
        /* tick events */
        if(inp){
            /* adjust cursor position relative to iframe rect */
            WEInputState local=*inp;
            DOMNode *hn=dom_node(g_iframes[i].host_node);
            if(hn){
                local.cursor_x-=hn->lay_x;
                local.cursor_y-=hn->lay_y;
                local.prev_x-=hn->lay_x;
                local.prev_y-=hn->lay_y;
            }
            we_events_update(cid,&local);
        }
    }
}

void wif_render(uint8_t parent_doc){
    for(int i=0;i<WE_MAX_IFRAMES;i++){
        if(!g_iframes[i].used||!g_iframes[i].loaded) continue;
        if(g_iframes[i].parent_doc!=parent_doc) continue;
        uint8_t cid=g_iframes[i].child_doc;
        DOMNode *hn=dom_node(g_iframes[i].host_node);
        if(!hn) continue;
        /* render sub-document within host bounds */
        /* clip to host rect by adjusting render offset */
        DOMDocument *cd=dom_doc(cid);
        if(!cd) continue;
        int16_t body=cd->body_node>=0?cd->body_node:cd->root_node;
        if(body<0) continue;  /* v0.38: was `return` — skipped remaining iframes */
        /* draw background */
        DOMNode *bn=dom_node(body);
        if(bn&&bn->style.background&0xFF){
            extern void wrender_rounded_rect(float x,float y,float w,float h,float r,uint32_t col);
            wrender_rounded_rect(hn->lay_x,hn->lay_y,hn->lay_w,hn->lay_h,0,bn->style.background);
        }
        /* render children with offset */
        for(int16_t ch=g_dom_nodes[body].first_child;ch>=0;ch=g_dom_nodes[ch].next_sib){
            extern void wrender_node(int16_t node_id, int16_t clip_x, int16_t clip_y, int16_t clip_w, int16_t clip_h, int16_t ox, int16_t oy);
            wrender_node(ch,hn->lay_x,hn->lay_y,hn->lay_w,hn->lay_h,
                         (int16_t)(-hn->lay_x),(int16_t)(-hn->lay_y));
        }
    }
}

void wif_post_message(int i, const char *json_msg){
    if(i<0||i>=WE_MAX_IFRAMES||!g_iframes[i].used) return;
    uint8_t cid=g_iframes[i].child_doc;
    DOMDocument *cd=dom_doc(cid);
    if(!cd||!cd->js_ctx||!cd->js_ready) return;
    duk_context *ctx=(duk_context*)cd->js_ctx;
    /* fire message event on window */
    char script[512]; snprintf(script,sizeof(script),
        "if(typeof onmessage==='function')onmessage({data:%s,origin:'3ds://parent'});",
        json_msg?json_msg:"null");
    wjs_eval(ctx,script);
}

duk_ret_t wif_js_postMessage(duk_context *ctx){
    /* postMessage(data, origin) */
    const char *data=duk_json_encode(ctx,0);
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__iframe_idx");
    int idx=duk_to_int(ctx,-1); duk_pop_2(ctx);
    wif_post_message(idx,data);
    return 0;
}

void wif_install_bindings(duk_context *ctx, uint8_t doc_id){
    /* Install window.postMessage receiver in the child document context.
       The C-level wif_post_message() already fires onmessage; this just
       ensures window.postMessage is a no-op stub so code that calls
       window.postMessage() inside an iframe doesn't throw. */
    (void)doc_id;
    duk_push_global_object(ctx);
    /* Stub: postMessage sent from inside the iframe does nothing */
    duk_eval_string_noresult(ctx,
        "if(typeof postMessage==='undefined')"
        "  window.postMessage=function(){};"
    );
    duk_pop(ctx);
}
