/*
 * web_dom.h  —  Pocket Compiler Web Engine: DOM Tree
 * Fixed-pool allocator, no heap fragmentation, 3DS-safe.
 *
 * v0.38 BUG FIX: DOMEvent.js_ref widened from uint8_t to uint16_t.
 * The old uint8_t silently truncated event-listener refs past the
 * 255th addEventListener() call in a session, causing the wrong JS
 * callback to fire with no visible error.
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>

/* ── Pool sizes ─────────────────────────────────────────────────── */
#define WE_MAX_NODES      1024
#define WE_MAX_ATTRS       512
#define WE_MAX_STR        32768   /* string pool bytes (int16_t offset max) */
#define WE_MAX_TEXT       65536   /* text-content pool bytes (int32_t offset) */
#define WE_MAX_CHILDREN    8192   /* child-index list entries     */
#define WE_MAX_EVENTS       256   /* per-node event handlers      */
#define WE_MAX_DOCUMENTS      4   /* root + iframes               */

/* ── Node types (mirrors W3C) ───────────────────────────────────── */
typedef enum {
    NT_ELEMENT   = 1,
    NT_TEXT      = 3,
    NT_DOCUMENT  = 9,
    NT_DOCTYPE   = 10,
    NT_COMMENT   = 8,
    NT_CDATA     = 4,
} NodeType;

/* ── CSS style struct (inline & computed) ───────────────────────── */
typedef struct {
    /* colors: RGBA8 packed  0xRRGGBBAA */
    uint32_t color;           /* text color        */
    uint32_t background;      /* bg color          */
    uint32_t border_color;    /* border            */

    /* box model (in logical units = screen pixels) */
    int16_t  margin_top, margin_right, margin_bottom, margin_left;
    int16_t  padding_top, padding_right, padding_bottom, padding_left;
    int16_t  border_width;
    int16_t  border_radius;
    int16_t  width, height;   /* -1 = auto         */
    int16_t  min_width, min_height;
    int16_t  max_width, max_height;

    /* positioning */
    uint8_t  position;        /* 0=static 1=rel 2=abs 3=fixed */
    int16_t  left, top, right, bottom;  /* used when position!=static */
    int16_t  z_index;

    /* display / layout */
    uint8_t  display;         /* 0=block 1=inline 2=inline-block 3=flex 4=none 5=grid */
    uint8_t  flex_direction;  /* 0=row 1=col 2=row-rev 3=col-rev */
    uint8_t  flex_wrap;
    uint8_t  justify_content; /* 0=start 1=end 2=center 3=between 4=around */
    uint8_t  align_items;
    uint8_t  align_self;
    int16_t  flex_grow;
    int16_t  gap;

    /* text */
    uint8_t  font_weight;     /* 0=normal 1=bold                */
    uint8_t  font_style;      /* 0=normal 1=italic              */
    int16_t  font_size;       /* px, 0=inherit                  */
    uint8_t  text_align;      /* 0=left 1=center 2=right 3=justify */
    uint8_t  text_decoration; /* 0=none 1=underline 2=line-through */
    uint8_t  white_space;     /* 0=normal 1=nowrap 2=pre        */
    uint8_t  overflow;        /* 0=visible 1=hidden 2=scroll 3=auto */
    uint8_t  overflow_x, overflow_y;

    /* opacity & visibility */
    uint8_t  opacity;         /* 0–255                          */
    uint8_t  visibility;      /* 0=visible 1=hidden 2=collapse  */

    /* cursor */
    uint8_t  cursor;          /* 0=auto 1=pointer 2=text 3=none */

    /* transform (simple) */
    float    rotate_deg;
    float    scale_x, scale_y;
    float    translate_x, translate_y;

    /* v0.42: box-shadow (parsed but rendered as offset semi-transparent rect) */
    int16_t  shadow_x, shadow_y;   /* offset in px (can be negative) */
    int16_t  shadow_blur;          /* blur radius (simplified: drawn as spread) */
    uint32_t shadow_color;         /* RGBA8, 0 = no shadow */

    /* v0.42: linear-gradient background.
     * When gradient_active is true, the renderer draws a gradient
     * instead of a solid background color. direction: 0=to right,
     * 1=to bottom, 2=to left, 3=to top.
     * gradient_start_set / gradient_end_set track whether each color
     * was explicitly given (since 0x00000000 is a valid color). */
    uint8_t  gradient_active;
    uint8_t  gradient_dir;
    uint8_t  gradient_start_set;
    uint8_t  gradient_end_set;
    uint32_t gradient_start;       /* RGBA8 */
    uint32_t gradient_end;         /* RGBA8 */

    /* v0.42: transition (duration in ms; 0 = no transition).
     * When >0, style property changes on this node animate over
     * transition_duration ms with ease-in-out timing. */
    uint16_t transition_duration;

    /* v0.42: grid layout. grid_cols = number of columns (0 = not grid).
     * grid_template_cols stores up to 8 column widths in px (-1 = auto,
     * equal distribution). Used by layout_grid when display==5. */
    uint8_t  grid_cols;
    int16_t  grid_template_cols[8];

    /* v0.44: additional CSS properties for broader compatibility. */
    uint8_t  box_sizing;       /* 0=content-box, 1=border-box */
    int16_t  flex_shrink;      /* default 1 (shrink allowed) */
    int16_t  flex_basis;       /* -1 = auto */
    uint8_t  pointer_events;   /* 0=auto, 1=none */
    uint8_t  user_select;      /* 0=auto, 1=none */
    uint8_t  outline_width;    /* 0 = none */
    uint32_t outline_color;    /* RGBA8 */
    uint8_t  text_transform;   /* 0=none, 1=uppercase, 2=lowercase, 3=capitalize */
    int16_t  letter_spacing;   /* px, 0=normal */
    int16_t  line_height;      /* px, 0=normal (computed from font_size) */
    uint8_t  list_style;       /* 0=disc, 1=none, 2=circle, 3=square, 4=decimal */
    uint8_t  object_fit;       /* 0=fill, 1=contain, 2=cover */
    uint8_t  box_sizing_set;   /* whether box-sizing was explicitly set */
} CSSStyle;

/* ── Attribute ──────────────────────────────────────────────────── */
typedef struct {
    int16_t  name_off;    /* offset into string pool  */
    int16_t  val_off;     /* offset into string pool  */
    uint16_t node_id;     /* owning node              */
} DOMAttr;

/* ── Event handler entry ────────────────────────────────────────── */
typedef struct {
    uint16_t node_id;
    uint8_t  event_type;  /* WE_EV_* enum                            */
    uint8_t  _pad;        /* alignment padding                       */
    uint16_t js_ref;      /* v0.38 BUG FIX: widened uint8_t→uint16_t.
                           * The old uint8_t silently truncated refs
                           * past the 255th addEventListener() call,
                           * firing the wrong JS callback.           */
} DOMEvent;

/* ── DOM Node ───────────────────────────────────────────────────── */
typedef struct {
    uint8_t   type;         /* NodeType                             */
    uint8_t   doc_id;       /* which document (0=main)              */
    uint8_t   visible;      /* computed visibility                  */
    uint8_t   dirty;        /* layout/render dirty                  */

    /* tag name (for ELEMENT) — index into string pool */
    int16_t   tag_off;      /* -1 = none                            */
    int16_t   id_attr;      /* index of 'id' attr, -1=none          */
    int16_t   class_attr;   /* index of 'class' attr, -1=none       */
    int16_t   style_attr;   /* index of 'style' attr, -1=none       */
    int16_t   href_attr;    /* index of 'href', -1=none             */
    int16_t   src_attr;     /* index of 'src', -1=none              */

    /* text content (for TEXT) — index into text pool */
    int32_t   text_off;     /* -1 = none                            */

    /* tree links */
    int16_t   parent;       /* node index, -1 = root                */
    int16_t   first_child;  /* node index, -1 = leaf                */
    int16_t   last_child;
    int16_t   next_sib;
    int16_t   prev_sib;

    /* attrs: first attr index in attr pool */
    int16_t   attr_start;   /* -1=none                              */
    uint8_t   attr_count;

    /* computed style */
    CSSStyle  style;

    /* layout result (set by layout engine) */
    int16_t   lay_x, lay_y;         /* absolute pixel pos (top screen) */
    int16_t   lay_w, lay_h;         /* pixel size                       */
    int16_t   scroll_x, scroll_y;   /* internal scroll state            */

    /* canvas element data (if tag==canvas) */
    uint16_t  canvas_id;    /* 0=none, index into canvas pool       */

    /* img element data */
    uint16_t  image_id;     /* 0=none, index into image pool        */

    /* interactive state */
    uint8_t   hover   : 1;
    uint8_t   active  : 1;
    uint8_t   focused : 1;
    uint8_t   checked : 1;
    uint8_t   disabled: 1;
    uint8_t   _pad    : 3;
} DOMNode;

/* ── Document ───────────────────────────────────────────────────── */
typedef struct {
    uint8_t   used;
    int16_t   root_node;       /* index of document root node     */
    int16_t   head_node;
    int16_t   body_node;
    int16_t   title_node;      /* <title> text node               */
    int16_t   focused_node;    /* currently focused element       */

    /* JS context */
    void     *js_ctx;          /* duk_context* (opaque here)      */
    bool      js_ready;

    /* iframe geometry on parent document */
    int16_t   frame_x, frame_y, frame_w, frame_h;
    uint8_t   parent_doc;      /* parent document id              */
} DOMDocument;

/* ── Global DOM pool (extern, defined in web_dom.c) ────────────── */
extern DOMNode      g_dom_nodes [WE_MAX_NODES];
extern DOMAttr      g_dom_attrs [WE_MAX_ATTRS];
extern DOMEvent     g_dom_events[WE_MAX_EVENTS];
extern DOMDocument  g_dom_docs  [WE_MAX_DOCUMENTS];

extern char         g_dom_strs  [WE_MAX_STR];   /* tag/attr names  */
extern char         g_dom_texts [WE_MAX_TEXT];  /* text content    */

extern int          g_dom_node_n;
extern int          g_dom_attr_n;
extern int          g_dom_event_n;
extern int          g_dom_str_top;
extern int          g_dom_text_top;

/* ── API ────────────────────────────────────────────────────────── */

/* pool management */
void    dom_reset(uint8_t doc_id);           /* free all nodes of doc */
void    dom_reset_all(void);                 /* wipe entire pool      */

/* string pool */
int16_t dom_str_intern(const char *s);       /* deduplicated          */
int16_t dom_text_intern(const char *s);      /* text pool (no dedup)  */
const char *dom_str(int16_t off);
const char *dom_text(int32_t off);

/* node creation */
int16_t dom_new_node(uint8_t doc_id, NodeType t);
int16_t dom_new_element(uint8_t doc_id, const char *tag);
int16_t dom_new_text(uint8_t doc_id, const char *content);

/* tree manipulation */
void    dom_append_child(int16_t parent, int16_t child);
void    dom_remove_child(int16_t parent, int16_t child);
void    dom_insert_before(int16_t ref, int16_t newnode);
void    dom_replace_child(int16_t old_child, int16_t new_child);

/* attributes */
int16_t dom_set_attr(int16_t node, const char *name, const char *val);
const char *dom_get_attr(int16_t node, const char *name);
bool    dom_has_attr(int16_t node, const char *name);
void    dom_remove_attr(int16_t node, const char *name);

/* query */
int16_t dom_get_by_id   (uint8_t doc_id, const char *id);
int16_t dom_get_by_tag  (uint8_t doc_id, const char *tag, int16_t start);
void    dom_get_by_class(uint8_t doc_id, const char *cls,
                         int16_t *out, int *out_n, int max);
int16_t dom_query_selector(uint8_t doc_id, const char *sel);

/* convenience */
DOMNode *dom_node(int16_t idx);
const char *dom_tag(int16_t idx);       /* tag name of element    */
const char *dom_text_content(int16_t idx); /* full text content   */
bool    dom_is_block(int16_t idx);
bool    dom_is_inline(int16_t idx);

/* document helpers */
DOMDocument *dom_doc(uint8_t id);
uint8_t dom_new_doc(void);
void    dom_free_doc(uint8_t id);

/* block tag helper (used by DOM and CSS) */
bool wep_is_block_tag(const char *tag);

/* dirty propagation */
void    dom_mark_dirty(int16_t node);
void    dom_clear_dirty(uint8_t doc_id);
