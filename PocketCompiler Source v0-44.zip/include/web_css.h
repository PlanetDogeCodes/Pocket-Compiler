/*
 * web_css.h  —  CSS parser & cascade for Pocket Compiler Web Engine
 */
#pragma once
#include "web_dom.h"

/* ── Default style values ───────────────────────────────────────── */
#define CSS_DEFAULT_COLOR        0xDDDDDDFF  /* near-white text     */
#define CSS_DEFAULT_BG           0x111111FF  /* near-black bg       */
#define CSS_DEFAULT_FONT_SIZE    11          /* px (fallback only)  */
#define CSS_DEFAULT_LINE_HEIGHT  14          /* px                  */

/* ── Stylesheet: up to 256 rules ───────────────────────────────── */
#define CSS_MAX_RULES   256
#define CSS_SEL_LEN      64

typedef struct {
    char      selector[CSS_SEL_LEN];
    CSSStyle  style;
    uint8_t   used;
    uint8_t   specificity;   /* 0-255 approximation */
} CSSRule;

extern CSSRule g_css_rules[CSS_MAX_RULES];
extern int     g_css_rule_n;

/* ── Parse functions ────────────────────────────────────────────── */

/* Parse inline style="..." string into a CSSStyle */
void  css_parse_inline(const char *inline_css, CSSStyle *out);

/* Parse a <style> block text, append to g_css_rules */
void  css_parse_stylesheet(const char *css_text);

/* Apply cascade to all nodes of doc_id (call after parse) */
void  css_cascade(uint8_t doc_id);

/* Apply computed style to a single node (uses parent inheritance) */
void  css_compute_node(int16_t node_id);

/* Color parsing: "#RGB" "#RRGGBB" "rgb()" named colors → RGBA8 */
uint32_t css_parse_color(const char *s);

/* CSS length: "10px" "1em" "50%" "auto" → px (em=font_size, %=parent) */
int16_t  css_parse_length(const char *s, int parent_px, int font_px);

/* Reset stylesheet (drop all rules) */
void  css_reset(void);

/* Inject browser default (UA) stylesheet rules.
 * Call once after css_reset() and before parsing user styles. */
void  css_apply_ua_defaults(void);

/* Get default (initial) style */
CSSStyle css_default_style(void);

/* Inherit style from parent node */
void  css_inherit(CSSStyle *child, const CSSStyle *parent);

/* Named CSS colors lookup table */
uint32_t css_named_color(const char *name);

/* ── v0.42: CSS Transitions ─────────────────────────────────────── */

#define CSS_MAX_TRANSITIONS 64

typedef enum {
    TR_OPACITY = 0,
    TR_COLOR, TR_BACKGROUND,
    TR_WIDTH, TR_HEIGHT,
    TR_MARGIN_TOP, TR_MARGIN_RIGHT, TR_MARGIN_BOTTOM, TR_MARGIN_LEFT,
    TR_PADDING_TOP, TR_PADDING_RIGHT, TR_PADDING_BOTTOM, TR_PADDING_LEFT,
    TR_TRANSLATE_X, TR_TRANSLATE_Y,
    TR_LEFT, TR_TOP, TR_RIGHT, TR_BOTTOM,
    TR_FONT_SIZE,
    TR_BORDER_WIDTH, TR_BORDER_RADIUS,
    TR_ROTATE,
    TR_SCALE_X, TR_SCALE_Y,
    TR_NONE = 99
} TransitionProp;

typedef struct {
    bool          active;
    uint16_t      node_id;
    TransitionProp prop;
    /* v0.42 audit: for numeric properties, old_val/new_val hold the
     * float value. For color properties (TR_COLOR, TR_BACKGROUND),
     * old_val/new_val are UNUSED and old_color/new_color hold the
     * full RGBA8 value (float can't represent uint32 > 2^24 without
     * precision loss). */
    float         old_val;
    float         new_val;
    uint32_t      old_color;
    uint32_t      new_color;
    double        start_time;
    uint16_t      duration;
} CSSTransition;

extern CSSTransition g_transitions[CSS_MAX_TRANSITIONS];
extern int           g_transition_n;

void css_transitions_detect(uint16_t node_id, const CSSStyle *old_st,
                            const CSSStyle *new_st, double now_ms);
void css_tick_transitions(double now_ms);
void css_transitions_reset(void);
