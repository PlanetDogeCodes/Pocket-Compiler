/*
 * file_explorer.c — Proper file explorer for Pocket Compiler v0.39
 *
 * Uses POSIX opendir/readdir (devkitPro newlib) to list .html files on
 * the SD card under FE_DIR, with file-size display via stat().
 *
 * Large buffers are static to avoid 3DS stack overflow.
 *
 * v0.39 changes:
 *  - fe_scan() now SORTS results (alphabetical by default; size/date
 *    selectable via fe->sort_mode). Previously results came back in
 *    arbitrary FAT directory order.
 *  - fe_load_named() now resets the v0.39 undo RING (undo_head/undo_count)
 *    instead of the old single undo_valid flag, so a freshly-loaded file
 *    can't inherit a stale ring pointing at the pre-load buffer.
 *  - New: fe_delete_named, fe_rename_named (file management).
 *  - New: fe_save_last/fe_load_last (last-opened file persistence).
 *  - New: fe_save_autosave (crash-recovery draft write).
 */
#include "file_explorer.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>   /* v0.39: qsort() — used by fe_scan's sort step */
#include <dirent.h>
#include <sys/stat.h>

/* ----------------------------------------------------------------- init */

void fe_init(FileExplorer *fe) {
    if (!fe) return;
    memset(fe, 0, sizeof(*fe));
    fe->sort_mode = FE_SORT_NAME; /* v0.39 default: alphabetical */
}

/* ----------------------------------------------------------------- scan */

/* Try to create the project directory (silently ignores EEXIST). */
static void ensure_dir(void) {
    mkdir(FE_DIR, 0777);
}

/* v0.39: ensure the app-level dir (FE_APP_DIR) exists. Needed before
 * writing config.txt / autosave.html, which live one level above the
 * projects dir. Silently ignores EEXIST. */
static void ensure_app_dir(void) {
    mkdir(FE_APP_DIR, 0777);
}

/* Returns 1 if 'name' ends with ".html" (case-sensitive). */
static int is_html(const char *name) {
    if (!name) return 0;
    size_t len = strlen(name);
    return len > 5 && strcmp(name + len - 5, ".html") == 0;
}

/* v0.39: sort support. qsort comparator over parallel names[]/sizes[].
 * We sort a temporary index array via a small static context so the
 * comparator can see both arrays without global state. Re-entrant-safe:
 * the context is set immediately before qsort and not touched again
 * until the next fe_scan, and fe_scan is never called re-entrantly
 * (only from main.c input handlers). */
static const FileExplorer *s_sort_ctx = NULL;
static int fe_cmp(const void *pa, const void *pb) {
    int a = *(const int *)pa, b = *(const int *)pb;
    const FileExplorer *fe = s_sort_ctx;
    if (!fe) return 0;
    if (fe->sort_mode == FE_SORT_SIZE) {
        /* ascending by size; equal sizes fall back to name for stability */
        if (fe->sizes[a] < fe->sizes[b]) return -1;
        if (fe->sizes[a] > fe->sizes[b]) return  1;
        return strcmp(fe->names[a], fe->names[b]);
    }
    if (fe->sort_mode == FE_SORT_DATE) {
        /* readdir already filled in directory order; the index array is
         * initialized 0..n-1 in that order, so "date" sort = leave as
         * is. We still fall back to name for a deterministic tie-break. */
        return strcmp(fe->names[a], fe->names[b]) < 0 ? -1 :
               strcmp(fe->names[a], fe->names[b]) > 0 ?  1 :
               (a < b ? -1 : (a > b ? 1 : 0));
    }
    /* FE_SORT_NAME (default): ascending alphabetical, case-sensitive to
     * match the rest of the codebase's filename handling. */
    int c = strcmp(fe->names[a], fe->names[b]);
    if (c != 0) return c;
    return (a < b) ? -1 : (a > b ? 1 : 0); /* stable tie-break */
}

void fe_scan(FileExplorer *fe) {
    if (!fe) return;
    int saved_sort = fe->sort_mode;
    fe->count  = 0;
    fe->cursor = 0;
    fe->scroll = 0;

    ensure_dir();

    DIR *d = opendir(FE_DIR);
    if (!d) return;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && fe->count < FE_MAX_FILES) {
        if (!is_html(ent->d_name)) continue;

        strncpy(fe->names[fe->count], ent->d_name, FE_FILENAME_MAX - 1);
        fe->names[fe->count][FE_FILENAME_MAX - 1] = '\0';

        /* Get file size via stat */
        char path[128];
        snprintf(path, sizeof(path), "%s/%s", FE_DIR, ent->d_name);
        struct stat st;
        fe->sizes[fe->count] = (stat(path, &st) == 0) ? (long)st.st_size : -1L;

        fe->count++;
    }
    closedir(d);

    /* v0.39: sort results. Build an index array, qsort it, then compact
     * names[]/sizes[] into sorted order via static scratch buffers
     * (kept off the stack — these arrays total ~4 KB which is fine on
     * the 3DS heap/BSS but we avoid stack as everywhere else here). */
    if (fe->count > 1) {
        static int  idx[FE_MAX_FILES];
        static char nsorted[FE_MAX_FILES][FE_FILENAME_MAX];
        static long ssorted[FE_MAX_FILES];
        for (int i = 0; i < fe->count; i++) idx[i] = i;
        s_sort_ctx = fe;
        qsort(idx, (size_t)fe->count, sizeof(int), fe_cmp);
        s_sort_ctx = NULL;
        for (int i = 0; i < fe->count; i++) {
            strncpy(nsorted[i], fe->names[idx[i]], FE_FILENAME_MAX - 1);
            nsorted[i][FE_FILENAME_MAX - 1] = '\0';
            ssorted[i] = fe->sizes[idx[i]];
        }
        for (int i = 0; i < fe->count; i++) {
            strncpy(fe->names[i], nsorted[i], FE_FILENAME_MAX - 1);
            fe->names[i][FE_FILENAME_MAX - 1] = '\0';
            fe->sizes[i] = ssorted[i];
        }
    }
    fe->sort_mode = saved_sort;
}

/* --------------------------------------------------------------- cursor */

void fe_move_up(FileExplorer *fe) {
    if (!fe || fe->cursor <= 0) return;
    fe->cursor--;
    if (fe->cursor < fe->scroll)
        fe->scroll = fe->cursor;
}

void fe_move_down(FileExplorer *fe, int total_rows) {
    if (!fe || fe->cursor >= total_rows - 1) return;
    fe->cursor++;
    if (fe->cursor >= fe->scroll + FE_VISIBLE_ROWS)
        fe->scroll = fe->cursor - FE_VISIBLE_ROWS + 1;
}

/* ---------------------------------------------------------- size format */

void fe_format_size(long bytes, char *buf, int buf_sz) {
    if (!buf || buf_sz <= 0) return;
    if (bytes < 0) {
        snprintf(buf, buf_sz, "  ?.?  ");
    } else if (bytes < 1024L) {
        snprintf(buf, buf_sz, "%4ld B ", bytes);
    } else if (bytes < 1024L * 1024L) {
        snprintf(buf, buf_sz, "%4.1f KB", (double)bytes / 1024.0);
    } else {
        snprintf(buf, buf_sz, "%4.1f MB", (double)bytes / (1024.0 * 1024.0));
    }
}

/* ----------------------------------------------------------------- I/O */

bool fe_save_named(const Editor *e, const char *filename) {
    if (!e || !filename || filename[0] == '\0') return false;
    ensure_dir();

    char path[128];
    snprintf(path, sizeof(path), "%s/%s", FE_DIR, filename);

    FILE *f = fopen(path, "wb");
    if (!f) return false;

    size_t len     = strlen(e->buf);
    size_t written = fwrite(e->buf, 1, len, f);
    fclose(f);
    return written == len;
}

bool fe_load_named(Editor *e, const char *filename) {
    if (!e || !filename || filename[0] == '\0') return false;

    char path[128];
    snprintf(path, sizeof(path), "%s/%s", FE_DIR, filename);

    FILE *f = fopen(path, "rb");
    if (!f) return false;

    /* Static buffer avoids large stack allocation that crashes the 3DS */
    static char load_buf[EDITOR_MAX];

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (sz <= 0 || sz >= EDITOR_MAX) { fclose(f); return false; }

    size_t rd = fread(load_buf, 1, (size_t)sz, f);
    fclose(f);
    if ((long)rd != sz) return false;

    load_buf[sz] = '\0';
    memcpy(e->buf, load_buf, sz + 1);
    e->cursor_line   = 0;
    e->scroll_offset = 0;
    /* v0.39: reset the undo RING (was: undo_valid=false on the old
     * single-buffer model). A freshly-loaded file must not inherit a
     * ring whose slots still point at the pre-load buffer contents. */
    e->undo_head  = 0;
    e->undo_count = 0;
    return true;
}

/* ------------------------------------------------------- v0.39: delete */

bool fe_delete_named(const char *filename) {
    if (!filename || filename[0] == '\0') return false;
    char path[128];
    snprintf(path, sizeof(path), "%s/%s", FE_DIR, filename);
    return remove(path) == 0;
}

/* ------------------------------------------------------- v0.39: rename */

bool fe_rename_named(const char *oldname, const char *newname) {
    if (!oldname || !*oldname || !newname || !*newname) return false;

    /* Build the new name into a local buffer and ensure a .html suffix,
     * mirroring main.c's ensure_html_ext so save and rename agree. */
    char nn[FE_FILENAME_MAX];
    strncpy(nn, newname, FE_FILENAME_MAX - 1);
    nn[FE_FILENAME_MAX - 1] = '\0';
    size_t nl = strlen(nn);
    if (nl < 5 || strcmp(nn + nl - 5, ".html") != 0) {
        if (nl + 5 < FE_FILENAME_MAX) {
            strncat(nn, ".html", FE_FILENAME_MAX - nl - 1);
        } else {
            /* Name too long to append .html — reject rather than truncate. */
            return false;
        }
    }

    char opath[128], npath[128];
    snprintf(opath, sizeof(opath), "%s/%s", FE_DIR, oldname);
    snprintf(npath, sizeof(npath), "%s/%s", FE_DIR, nn);
    return rename(opath, npath) == 0;
}

/* ------------------------------------------------ v0.39: last-file memory */

void fe_save_last(const char *filename) {
    if (!filename || !*filename) return;
    ensure_app_dir();
    FILE *f = fopen(FE_CONFIG_FILE, "w");
    if (!f) return;
    fprintf(f, "%s\n", filename);
    fclose(f);
}

bool fe_load_last(char *out, int out_sz) {
    if (!out || out_sz <= 0) return false;
    FILE *f = fopen(FE_CONFIG_FILE, "r");
    if (!f) return false;
    /* Read one line, strip trailing newline, bounds-check. */
    if (!fgets(out, out_sz, f)) { fclose(f); return false; }
    fclose(f);
    size_t n = strlen(out);
    while (n > 0 && (out[n-1] == '\n' || out[n-1] == '\r')) out[--n] = '\0';
    return n > 0;
}

/* v0.39: remove FE_CONFIG_FILE. Silent no-op if the file doesn't exist
 * (remove() returns nonzero for missing files, which we ignore). */
void fe_clear_last(void) {
    remove(FE_CONFIG_FILE);
}

/* --------------------------------------------------- v0.39: autosave draft */

bool fe_save_autosave(const Editor *e) {
    if (!e) return false;
    ensure_app_dir();
    FILE *f = fopen(FE_AUTOSAVE, "wb");
    if (!f) return false;
    size_t len = strlen(e->buf);
    size_t written = fwrite(e->buf, 1, len, f);
    fclose(f);
    return written == len;
}

/* v0.39: load the crash-recovery draft. Mirrors fe_load_named's
 * buffer-loading + undo-ring-reset logic, just from FE_AUTOSAVE
 * instead of FE_DIR/<name>. Used by the Actions menu "Recover auto…"
 * row so the user can pull back unsaved work after a crash or power
 * loss. The caller should snapshot first if undo of the recovery
 * itself is wanted (we don't, matching fe_load_named's behaviour —
 * a loaded file is the new baseline). */
bool fe_load_autosave(Editor *e) {
    if (!e) return false;
    FILE *f = fopen(FE_AUTOSAVE, "rb");
    if (!f) return false;

    static char load_buf[EDITOR_MAX];

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (sz <= 0 || sz >= EDITOR_MAX) { fclose(f); return false; }

    size_t rd = fread(load_buf, 1, (size_t)sz, f);
    fclose(f);
    if ((long)rd != sz) return false;

    load_buf[sz] = '\0';
    memcpy(e->buf, load_buf, sz + 1);
    e->cursor_line   = 0;
    e->scroll_offset = 0;
    e->undo_head     = 0;
    e->undo_count    = 0;
    return true;
}

/* --------------------------------------------------------- legacy slots */

static const char *slot_names[NUM_SLOTS] = {
    "project1.html", "project2.html", "project3.html",
    "project4.html", "project5.html"
};

const char *fe_slot_name(int slot) {
    if (slot < 0 || slot >= NUM_SLOTS) return "unknown.html";
    return slot_names[slot];
}

bool fe_save_slot(const Editor *e, int slot) {
    if (slot < 0 || slot >= NUM_SLOTS) return false;
    return fe_save_named(e, slot_names[slot]);
}

bool fe_load_slot(Editor *e, int slot) {
    if (slot < 0 || slot >= NUM_SLOTS) return false;
    return fe_load_named(e, slot_names[slot]);
}
