/*
 * web_dom.c  —  DOM tree implementation for Pocket Compiler Web Engine
 */
#include "web_dom.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ── Pool storage ───────────────────────────────────────────────── */
DOMNode      g_dom_nodes [WE_MAX_NODES];
DOMAttr      g_dom_attrs [WE_MAX_ATTRS];
DOMEvent     g_dom_events[WE_MAX_EVENTS];
DOMDocument  g_dom_docs  [WE_MAX_DOCUMENTS];

char         g_dom_strs  [WE_MAX_STR];
char         g_dom_texts [WE_MAX_TEXT];

int          g_dom_node_n  = 0;
int          g_dom_attr_n  = 0;
int          g_dom_event_n = 0;
int          g_dom_str_top = 0;
int          g_dom_text_top= 0;

/* ── String pool ────────────────────────────────────────────────── */

int16_t dom_str_intern(const char *s){
    if(!s||!*s) return -1;
    int len=(int)strlen(s)+1;
    /* search existing */
    int i=0;
    while(i<g_dom_str_top){
        if(strcmp(g_dom_strs+i,s)==0) return (int16_t)i;
        i+=(int)strlen(g_dom_strs+i)+1;
    }
    /* add new */
    if(g_dom_str_top+len>=WE_MAX_STR) return -1;
    memcpy(g_dom_strs+g_dom_str_top,s,len);
    int16_t off=(int16_t)g_dom_str_top;
    g_dom_str_top+=len;
    return off;
}

int16_t dom_text_intern(const char *s){
    if(!s) return -1;
    int len=(int)strlen(s)+1;
    if(g_dom_text_top+len>=WE_MAX_TEXT) return -1;
    memcpy(g_dom_texts+g_dom_text_top,s,len);
    int16_t off=(int16_t)g_dom_text_top;
    g_dom_text_top+=len;
    return off;
}

const char *dom_str(int16_t off){
    /* v0.40: check against g_dom_str_top (the actual used portion)
     * rather than WE_MAX_STR. The old `off>=WE_MAX_STR` was always
     * false because int16_t can't represent 32768. Checking against
     * g_dom_str_top catches both negative offsets and offsets past
     * the actual data, and is a meaningful comparison. */
    if(off<0||off>=g_dom_str_top) return "";
    return g_dom_strs+off;
}

const char *dom_text(int32_t off){
    if(off<0||off>=WE_MAX_TEXT) return "";
    return g_dom_texts+off;
}

/* ── Node creation ──────────────────────────────────────────────── */

static void node_init(int16_t idx, uint8_t doc_id, NodeType t){
    DOMNode *n=&g_dom_nodes[idx];
    memset(n,0,sizeof(*n));
    n->type=t;
    n->doc_id=doc_id;
    n->tag_off=-1;
    n->id_attr=-1;
    n->class_attr=-1;
    n->style_attr=-1;
    n->href_attr=-1;
    n->src_attr=-1;
    n->text_off=-1;
    n->parent=-1;
    n->first_child=-1;
    n->last_child=-1;
    n->next_sib=-1;
    n->prev_sib=-1;
    n->attr_start=-1;
    /* default style */
    n->style.opacity=255;
    n->style.visibility=0;
    n->style.display=0; /* block */
    n->style.font_size=11;
    n->style.scale_x=1.f;
    n->style.scale_y=1.f;
    n->visible=1;
    n->dirty=1;
}

int16_t dom_new_node(uint8_t doc_id, NodeType t){
    if(g_dom_node_n>=WE_MAX_NODES) return -1;
    int16_t idx=(int16_t)g_dom_node_n++;
    node_init(idx,doc_id,t);
    return idx;
}

int16_t dom_new_element(uint8_t doc_id, const char *tag){
    int16_t idx=dom_new_node(doc_id,NT_ELEMENT);
    if(idx<0) return -1;
    g_dom_nodes[idx].tag_off=dom_str_intern(tag);
    /* v0.40 audit fix: set default display based on tag.
     *   - script/style/title/head/meta/link are display:none (4) so
     *     their text content is never rendered visibly. The old code
     *     put them in the block list, so <style>foo{}</style> would
     *     render "foo{}" as visible block text on the page.
     *   - block tags get display:block (0)
     *   - everything else gets display:inline (1)
     * This matches browser UA-stylesheet behaviour. */
    if(strcmp(tag,"script")==0||strcmp(tag,"style")==0||
       strcmp(tag,"title")==0||strcmp(tag,"head")==0||
       strcmp(tag,"meta")==0||strcmp(tag,"link")==0||
       strcmp(tag,"base")==0||strcmp(tag,"col")==0||
       strcmp(tag,"param")==0||strcmp(tag,"track")==0){
        g_dom_nodes[idx].style.display=4; /* none */
    } else if(wep_is_block_tag(tag)){
        g_dom_nodes[idx].style.display=0; /* block */
    } else {
        g_dom_nodes[idx].style.display=1; /* inline */
    }
    return idx;
}

int16_t dom_new_text(uint8_t doc_id, const char *content){
    int16_t idx=dom_new_node(doc_id,NT_TEXT);
    if(idx<0) return -1;
    g_dom_nodes[idx].text_off=dom_text_intern(content);
    g_dom_nodes[idx].style.display=1; /* inline text */
    return idx;
}

/* ── Tree manipulation ──────────────────────────────────────────── */

void dom_append_child(int16_t parent, int16_t child){
    if(parent<0||child<0||parent==child) return;
    if(parent>=g_dom_node_n||child>=g_dom_node_n) return;
    /* v0.38 final audit: cycle guard. If `child` is an ancestor of
     * `parent`, appending would create a cycle (a->b->a->...) that
     * hangs the 3DS forever in any tree traversal (layout, render,
     * event bubbling). Walk up from `parent`; if we hit `child`,
     * refuse the operation. Matches the DOM spec's
     * HierarchyRequestError for this case. Also bounded by
     * g_dom_node_n so a corrupted parent chain can't loop forever. */
    {
        int16_t p=parent;
        int guard=0;
        while(p>=0 && guard<g_dom_node_n){
            if(p==child) return;  /* child is an ancestor of parent */
            DOMNode *pn=&g_dom_nodes[p];
            p=pn->parent;
            guard++;
        }
    }
    DOMNode *p=&g_dom_nodes[parent];
    DOMNode *c=&g_dom_nodes[child];
    /* v0.38: if child already has a parent, unlink it from the old
     * parent first. Without this, the old parent's sibling chain
     * still points at the child, creating a corrupt two-parent tree
     * that can cause infinite loops or double-frees in traversal. */
    if(c->parent>=0){
        dom_remove_child(c->parent,child);
    }
    c->parent=parent;
    c->next_sib=-1;
    c->prev_sib=p->last_child;
    if(p->last_child>=0)
        g_dom_nodes[p->last_child].next_sib=child;
    p->last_child=child;
    if(p->first_child<0) p->first_child=child;
    p->dirty=1;
}

void dom_remove_child(int16_t parent, int16_t child){
    if(parent<0||child<0) return;
    DOMNode *c=&g_dom_nodes[child];
    if(c->prev_sib>=0) g_dom_nodes[c->prev_sib].next_sib=c->next_sib;
    if(c->next_sib>=0) g_dom_nodes[c->next_sib].prev_sib=c->prev_sib;
    DOMNode *p=&g_dom_nodes[parent];
    if(p->first_child==child) p->first_child=c->next_sib;
    if(p->last_child==child)  p->last_child=c->prev_sib;
    c->parent=-1;
    c->next_sib=-1;
    c->prev_sib=-1;
    p->dirty=1;
}

void dom_insert_before(int16_t ref, int16_t newnode){
    if(ref<0||newnode<0||ref==newnode) return;
    if(ref>=g_dom_node_n||newnode>=g_dom_node_n) return;
    DOMNode *r=&g_dom_nodes[ref];
    DOMNode *n=&g_dom_nodes[newnode];
    int16_t par=r->parent;
    /* v0.38: same cycle guard as dom_append_child — if newnode is an
     * ancestor of par, inserting would create a cycle. */
    if(par>=0){
        int16_t p=par; int guard=0;
        while(p>=0 && guard<g_dom_node_n){
            if(p==newnode) return;
            DOMNode *pn=&g_dom_nodes[p];
            p=pn->parent;
            guard++;
        }
    }
    /* v0.38: unlink newnode from its current parent if it has one. */
    if(n->parent>=0) dom_remove_child(n->parent,newnode);
    n->parent=par;
    n->next_sib=ref;
    n->prev_sib=r->prev_sib;
    if(r->prev_sib>=0) g_dom_nodes[r->prev_sib].next_sib=newnode;
    r->prev_sib=newnode;
    if(par>=0){
        DOMNode *p=&g_dom_nodes[par];
        if(p->first_child==ref) p->first_child=newnode;
        p->dirty=1;
    }
}

void dom_replace_child(int16_t old_child, int16_t new_child){
    if(old_child<0||new_child<0) return;
    dom_insert_before(old_child,new_child);
    dom_remove_child(g_dom_nodes[old_child].parent,old_child);
}

/* ── Attributes ─────────────────────────────────────────────────── */

int16_t dom_set_attr(int16_t node, const char *name, const char *val){
    if(node<0||!name) return -1;
    DOMNode *n=&g_dom_nodes[node];
    /* check existing */
    int16_t idx=-1;  /* tracks the attr slot used (existing or new) */
    int16_t name_off=dom_str_intern(name);
    if(n->attr_start>=0){
        for(int i=n->attr_start;i<n->attr_start+n->attr_count;i++){
            if(i>=WE_MAX_ATTRS) break;
            if(g_dom_attrs[i].node_id==(uint16_t)node &&
               g_dom_attrs[i].name_off==name_off){
                g_dom_attrs[i].val_off=dom_str_intern(val);
                idx=(int16_t)i;  /* record which index was updated */
                goto update_shortcuts;
            }
        }
    }
    /* add new */
    if(g_dom_attr_n>=WE_MAX_ATTRS) return -1;
    idx=(int16_t)g_dom_attr_n++;
    g_dom_attrs[idx].name_off=name_off;
    g_dom_attrs[idx].val_off=dom_str_intern(val);
    g_dom_attrs[idx].node_id=(uint16_t)node;
    if(n->attr_start<0) n->attr_start=idx;
    n->attr_count++;

update_shortcuts:
    if(strcmp(name,"id")==0)    n->id_attr=name_off;
    if(strcmp(name,"class")==0) n->class_attr=name_off;
    if(strcmp(name,"style")==0) n->style_attr=name_off;
    if(strcmp(name,"href")==0)  n->href_attr=name_off;
    if(strcmp(name,"src")==0)   n->src_attr=name_off;
    n->dirty=1;
    return idx;
}

const char *dom_get_attr(int16_t node, const char *name){
    if(node<0||!name) return NULL;
    DOMNode *n=&g_dom_nodes[node];
    if(n->attr_start<0) return NULL;
    int16_t name_off=dom_str_intern(name);
    for(int i=n->attr_start;i<n->attr_start+n->attr_count;i++){
        if(i>=WE_MAX_ATTRS) break;
        if(g_dom_attrs[i].node_id==(uint16_t)node &&
           g_dom_attrs[i].name_off==name_off)
            return dom_str(g_dom_attrs[i].val_off);
    }
    return NULL;
}

bool dom_has_attr(int16_t node, const char *name){
    return dom_get_attr(node,name)!=NULL;
}

void dom_remove_attr(int16_t node, const char *name){
    if(node<0||!name) return;
    DOMNode *n=&g_dom_nodes[node];
    if(n->attr_start<0) return;
    int16_t name_off=dom_str_intern(name);
    for(int i=n->attr_start;i<n->attr_start+n->attr_count;i++){
        if(i>=WE_MAX_ATTRS) break;
        if(g_dom_attrs[i].node_id==(uint16_t)node &&
           g_dom_attrs[i].name_off==name_off){
            g_dom_attrs[i].name_off=-1; /* tombstone */
            break;
        }
    }
    n->dirty=1;
}

/* ── Query ──────────────────────────────────────────────────────── */

int16_t dom_get_by_id(uint8_t doc_id, const char *id){
    if(!id) return -1;
    int16_t id_off=dom_str_intern(id);
    for(int i=0;i<g_dom_node_n;i++){
        DOMNode *n=&g_dom_nodes[i];
        if(n->doc_id!=doc_id||n->type!=NT_ELEMENT) continue;
        const char *nid=dom_get_attr(i,"id");
        if(nid&&strcmp(nid,id)==0) return (int16_t)i;
    }
    return -1;
}

int16_t dom_get_by_tag(uint8_t doc_id, const char *tag, int16_t start){
    if(!tag) return -1;
    int from=(start>=0)?(int)start+1:0;
    for(int i=from;i<g_dom_node_n;i++){
        DOMNode *n=&g_dom_nodes[i];
        if(n->doc_id!=doc_id||n->type!=NT_ELEMENT) continue;
        if(strcmp(dom_str(n->tag_off),tag)==0) return (int16_t)i;
    }
    return -1;
}

void dom_get_by_class(uint8_t doc_id, const char *cls,
                      int16_t *out, int *out_n, int max){
    *out_n=0;
    if(!cls) return;
    for(int i=0;i<g_dom_node_n;i++){
        if(*out_n>=max) break;
        DOMNode *n=&g_dom_nodes[i];
        if(n->doc_id!=doc_id||n->type!=NT_ELEMENT) continue;
        const char *c=dom_get_attr(i,"class");
        if(!c) continue;
        /* word search in class list */
        char buf[256]; strncpy(buf,c,255); buf[255]=0;
        char *tok=strtok(buf," ");
        while(tok){
            if(strcmp(tok,cls)==0){ out[(*out_n)++]=(int16_t)i; break; }
            tok=strtok(NULL," ");
        }
    }
}

/* Simple single-class/id/tag CSS selector query */
int16_t dom_query_selector(uint8_t doc_id, const char *sel){
    if(!sel||!*sel) return -1;
    if(sel[0]=='#') return dom_get_by_id(doc_id,sel+1);
    if(sel[0]=='.'){
        int16_t out[1]; int n=0;
        dom_get_by_class(doc_id,sel+1,out,&n,1);
        return (n>0)?out[0]:-1;
    }
    return dom_get_by_tag(doc_id,sel,-1);
}

/* ── Convenience ────────────────────────────────────────────────── */

DOMNode *dom_node(int16_t idx){
    if(idx<0||idx>=g_dom_node_n) return NULL;
    return &g_dom_nodes[idx];
}

const char *dom_tag(int16_t idx){
    DOMNode *n=dom_node(idx);
    if(!n||n->type!=NT_ELEMENT) return "";
    return dom_str(n->tag_off);
}

/* Collect text content of subtree into buf (recursive) */
static void collect_text(int16_t node, char *buf, int *pos, int max){
    if(node<0||*pos>=max) return;
    DOMNode *n=&g_dom_nodes[node];
    if(n->type==NT_TEXT){
        const char *t=dom_text(n->text_off);
        int len=(int)strlen(t);
        int copy=(len<max-*pos-1)?len:(max-*pos-1);
        memcpy(buf+*pos,t,copy);
        *pos+=copy;
        buf[*pos]='\0';
    }
    for(int16_t c=n->first_child;c>=0;c=g_dom_nodes[c].next_sib)
        collect_text(c,buf,pos,max);
}

static char s_text_buf[1024];
const char *dom_text_content(int16_t idx){
    s_text_buf[0]='\0'; int pos=0;
    collect_text(idx,s_text_buf,&pos,sizeof(s_text_buf));
    return s_text_buf;
}

bool dom_is_block(int16_t idx){
    DOMNode *n=dom_node(idx); if(!n) return false;
    uint8_t d=n->style.display;
    return d==0||d==5; /* block or grid */
}
bool dom_is_inline(int16_t idx){
    DOMNode *n=dom_node(idx); if(!n) return false;
    uint8_t d=n->style.display;
    return d==1||d==2; /* inline or inline-block */
}

/* ── Document management ────────────────────────────────────────── */

DOMDocument *dom_doc(uint8_t id){
    if(id>=WE_MAX_DOCUMENTS) return NULL;
    return &g_dom_docs[id];
}

uint8_t dom_new_doc(void){
    for(uint8_t i=0;i<WE_MAX_DOCUMENTS;i++){
        if(!g_dom_docs[i].used){
            memset(&g_dom_docs[i],0,sizeof(g_dom_docs[i]));
            g_dom_docs[i].used=true;
            g_dom_docs[i].root_node=-1;
            g_dom_docs[i].head_node=-1;
            g_dom_docs[i].body_node=-1;
            g_dom_docs[i].title_node=-1;
            g_dom_docs[i].focused_node=-1;
            return i;
        }
    }
    return 0xFF; /* no slot */
}

void dom_free_doc(uint8_t id){
    if(id>=WE_MAX_DOCUMENTS) return;
    dom_reset(id);
    if(g_dom_docs[id].js_ctx){
        /* JS context freed by caller */
        g_dom_docs[id].js_ctx=NULL;
    }
    g_dom_docs[id].used=false;
}

/* ── Reset ──────────────────────────────────────────────────────── */

void dom_reset(uint8_t doc_id){
    /* tombstone all nodes/attrs for this doc */
    int wi=0;
    for(int i=0;i<g_dom_node_n;i++){
        if(g_dom_nodes[i].doc_id!=doc_id){
            if(wi!=i) g_dom_nodes[wi]=g_dom_nodes[i];
            wi++;
        }
    }
    g_dom_node_n=wi;
    /* compact attrs */
    wi=0;
    for(int i=0;i<g_dom_attr_n;i++){
        /* check if owning node still exists */
        bool alive=false;
        for(int j=0;j<g_dom_node_n;j++){
            if(g_dom_nodes[j].doc_id!=doc_id &&
               (uint16_t)j==g_dom_attrs[i].node_id){ alive=true; break; }
        }
        if(alive){ if(wi!=i) g_dom_attrs[wi]=g_dom_attrs[i]; wi++; }
    }
    g_dom_attr_n=wi;
    /* reset document slot */
    DOMDocument *d=dom_doc(doc_id);
    if(d){
        bool was_used=d->used;
        void *js=d->js_ctx;
        memset(d,0,sizeof(*d));
        d->used=was_used;
        d->js_ctx=js;
        d->root_node=-1; d->head_node=-1; d->body_node=-1;
        d->title_node=-1; d->focused_node=-1;
    }
}

void dom_reset_all(void){
    g_dom_node_n=0;
    g_dom_attr_n=0;
    g_dom_event_n=0;
    g_dom_str_top=0;
    g_dom_text_top=0;
    memset(g_dom_docs,0,sizeof(g_dom_docs));
    memset(g_dom_nodes,0,sizeof(g_dom_nodes));
    memset(g_dom_attrs,0,sizeof(g_dom_attrs));
    memset(g_dom_events,0,sizeof(g_dom_events));
}

/* ── Dirty propagation ──────────────────────────────────────────── */

void dom_mark_dirty(int16_t node){
    if(node<0||node>=g_dom_node_n) return;
    DOMNode *n=&g_dom_nodes[node];
    n->dirty=1;
    /* mark parent dirty too.
     * v0.40: guard against cycle (bounded by g_dom_node_n). The
     * `if(dirty) break` is an optimization that usually stops the
     * loop early, but a cycle where all nodes are already dirty
     * would still loop forever without the guard. */
    int16_t p=n->parent;
    int guard=0;
    while(p>=0 && guard<g_dom_node_n){
        guard++;
        if(g_dom_nodes[p].dirty) break;
        g_dom_nodes[p].dirty=1;
        p=g_dom_nodes[p].parent;
    }
}

void dom_clear_dirty(uint8_t doc_id){
    for(int i=0;i<g_dom_node_n;i++){
        if(g_dom_nodes[i].doc_id==doc_id)
            g_dom_nodes[i].dirty=0;
    }
}

/* ── Block tag helper (used by dom_new_element) ─────────────────── */
/* v0.40 audit fix: this list determines the default `display` value
 * for newly-created elements (block vs inline). Several entries were
 * wrong or missing:
 *   - script/style/title/head/meta/link should NOT be "block" — they
 *     are display:none by default. Having them in the block list
 *     meant they got display:block, so invisible <style>/<script>
 *     text would render as visible block text. Removed.
 *   - br/hr are void elements that don't really have a display value
 *     of their own; br is inline, hr is block. Adjusted.
 *   - pre was missing (it's block). Added.
 *   - header/footer/main were already present (good).
 *   - picture/source/dialog/menu added for completeness.
 * The renderer's html_render() in ui.c has its own tag list for the
 * fallback text extractor; this function only affects the real DOM
 * layout path (web_layout.c). */
bool wep_is_block_tag(const char *tag){
    if(!tag||!*tag) return false;
    static const char *block[]={
        "div","p","h1","h2","h3","h4","h5","h6",
        "ul","ol","li","blockquote","pre","table",
        "thead","tbody","tfoot","tr","th","td",
        "section","article","aside","nav","header",
        "footer","main","form","fieldset","figure",
        "figcaption","details","summary","address",
        "dl","dt","dd","hr",
        "canvas","video","audio","iframe","noscript",
        "html","body",
        "picture","dialog","menu",NULL
    };
    for(int i=0;block[i];i++)
        if(strcmp(tag,block[i])==0) return true;
    return false;
}
