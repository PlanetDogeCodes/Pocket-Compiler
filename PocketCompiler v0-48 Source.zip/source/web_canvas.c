/*
 * web_canvas.c  —  Canvas 2D API implementation (Citro2D backed)
 *
 * v0.38 BUG FIX: wc_install_bindings' property-accessor setup script
 * was built via snprintf() into a 512-byte buffer, but the literal
 * string is 854 bytes — it was silently truncated mid-statement,
 * breaking every canvas property setter (fillStyle, strokeStyle,
 * lineWidth, globalAlpha, font, textAlign, textBaseline) at runtime.
 * Now passed directly to duk_eval_string as a literal (no buffer,
 * no size limit).
 */
#include "web_canvas.h"
#include "duktape.h"
#include "web_css.h"
#include "web_dom.h"
#include "web_render.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <3ds.h>
#include <citro2d.h>

WCContext2D g_wc_ctx[WE_MAX_CTX2D];

/* Convert RGBA8 → Citro2D */
static u32 to_c2(uint32_t rgba){
    return C2D_Color32((rgba>>24)&0xFF,(rgba>>16)&0xFF,(rgba>>8)&0xFF,rgba&0xFF);
}

/* Parse color from JS string ("red", "#ff0000", "rgb(...)") */
static uint32_t parse_jscol(const char *s){
    extern uint32_t css_parse_color(const char *s);
    return css_parse_color(s);
}

WCContext2D *wc_get_context(uint16_t canvas_id){
    if(canvas_id==0||canvas_id>WE_MAX_CTX2D) return NULL;
    WCContext2D *c=&g_wc_ctx[canvas_id-1];
    if(!c->canvas){
        c->canvas=wrender_canvas(canvas_id);
        c->canvas_id=canvas_id;
        /* default state */
        c->state.fill_color  =0x000000FF;
        c->state.stroke_color=0x000000FF;
        c->state.line_width  =1;
        c->state.global_alpha=1.0f;
        c->state.font_size   =WC_FONT_SIZE_DEFAULT;
        c->state.text_align  =0;
        c->state.text_baseline=0;
        /* identity transform */
        c->state.transform[0]=1; c->state.transform[3]=1;
    }
    return c;
}

void wc_destroy_context(uint16_t canvas_id){
    if(canvas_id==0||canvas_id>WE_MAX_CTX2D) return;
    memset(&g_wc_ctx[canvas_id-1],0,sizeof(WCContext2D));
}

/* ── Scene management: draw into canvas render target ───────────── */
static WCContext2D *s_active_ctx=NULL;

static void canvas_begin(WCContext2D *c){
    if(!c||!c->canvas||!c->canvas->fb) return;
    s_active_ctx=c;
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C2D_TargetClear(c->canvas->fb,to_c2(0x00000000));
    C2D_SceneBegin(c->canvas->fb);
}

static void canvas_end(void){
    C3D_FrameEnd(0);
    s_active_ctx=NULL;
}

/* ── Drawing helpers ─────────────────────────────────────────────── */

void wc_clearRect(WCContext2D *c, float x, float y, float w, float h){
    if(!c) return;
    canvas_begin(c);
    C2D_DrawRectSolid(x,y,0,w,h,to_c2(0x00000000));
    canvas_end();
    c->dirty=true;
}

void wc_fillRect(WCContext2D *c, float x, float y, float w, float h){
    if(!c) return;
    canvas_begin(c);
    float a=c->state.global_alpha;
    uint32_t col=c->state.fill_color;
    uint8_t oa=col&0xFF; col=(col&0xFFFFFF00)|((uint8_t)(oa*a));
    C2D_DrawRectSolid(x,y,0,w,h,to_c2(col));
    canvas_end();
    c->dirty=true;
}

void wc_strokeRect(WCContext2D *c, float x, float y, float w, float h){
    if(!c) return;
    canvas_begin(c);
    float bw=c->state.line_width;
    u32 col=to_c2(c->state.stroke_color);
    C2D_DrawRectSolid(x,y,0,w,bw,col);
    C2D_DrawRectSolid(x,y+h-bw,0,w,bw,col);
    C2D_DrawRectSolid(x,y+bw,0,bw,h-2*bw,col);
    C2D_DrawRectSolid(x+w-bw,y+bw,0,bw,h-2*bw,col);
    canvas_end();
    c->dirty=true;
}

void wc_beginPath(WCContext2D *c){ if(!c) return; c->path_n=0; c->path_closed=false; }
void wc_closePath(WCContext2D *c){ if(!c||c->path_n<1) return; c->path_closed=true; }

void wc_moveTo(WCContext2D *c, float x, float y){
    if(!c||c->path_n>=WC_PATH_MAX_POINTS) return;
    c->path_start=c->path_n;
    c->path[c->path_n].x=x; c->path[c->path_n].y=y; c->path_n++;
}

void wc_lineTo(WCContext2D *c, float x, float y){
    if(!c||c->path_n>=WC_PATH_MAX_POINTS) return;
    c->path[c->path_n].x=x; c->path[c->path_n].y=y; c->path_n++;
}

void wc_arc(WCContext2D *c, float cx, float cy, float r, float start, float end, bool ccw){
    if(!c) return;
    /* approximate with line segments */
    int steps=(int)(r*2+8); if(steps<8)steps=8; if(steps>64)steps=64;
    float range=end-start;
    if(ccw){ if(range>0) range-=2*M_PI; }
    else    { if(range<0) range+=2*M_PI; }
    for(int i=0;i<=steps&&c->path_n<WC_PATH_MAX_POINTS;i++){
        float t=start+range*i/steps;
        float px=cx+r*cosf(t);
        float py=cy+r*sinf(t);
        if(i==0&&c->path_n==0) wc_moveTo(c,px,py);
        else wc_lineTo(c,px,py);
    }
}

void wc_arcTo(WCContext2D *c, float x1, float y1, float x2, float y2, float r){
    /* simplified: just lineTo endpoint */
    wc_lineTo(c,x1,y1); wc_lineTo(c,x2,y2);
    (void)r;
}

void wc_bezierCurveTo(WCContext2D *c, float cp1x, float cp1y,
                      float cp2x, float cp2y, float x, float y){
    /* approximate cubic bezier with 8 steps */
    if(c->path_n<1) return;
    float x0=c->path[c->path_n-1].x, y0=c->path[c->path_n-1].y;
    for(int i=1;i<=8&&c->path_n<WC_PATH_MAX_POINTS;i++){
        float t=(float)i/8;
        float u=1-t;
        float bx=u*u*u*x0+3*u*u*t*cp1x+3*u*t*t*cp2x+t*t*t*x;
        float by=u*u*u*y0+3*u*u*t*cp1y+3*u*t*t*cp2y+t*t*t*y;
        wc_lineTo(c,bx,by);
    }
}

void wc_quadraticCurveTo(WCContext2D *c, float cpx, float cpy, float x, float y){
    if(c->path_n<1) return;
    float x0=c->path[c->path_n-1].x, y0=c->path[c->path_n-1].y;
    for(int i=1;i<=8&&c->path_n<WC_PATH_MAX_POINTS;i++){
        float t=(float)i/8, u=1-t;
        float bx=u*u*x0+2*u*t*cpx+t*t*x;
        float by=u*u*y0+2*u*t*cpy+t*t*y;
        wc_lineTo(c,bx,by);
    }
}

void wc_rect(WCContext2D *c, float x, float y, float w, float h){
    wc_moveTo(c,x,y); wc_lineTo(c,x+w,y);
    wc_lineTo(c,x+w,y+h); wc_lineTo(c,x,y+h); wc_closePath(c);
}

void wc_fill(WCContext2D *c){
    if(!c||c->path_n<3) return;
    canvas_begin(c);
    /* simple fill: find bounding box and draw rect + scanlines */
    float minx=c->path[0].x,maxx=c->path[0].x;
    float miny=c->path[0].y,maxy=c->path[0].y;
    for(int i=1;i<c->path_n;i++){
        if(c->path[i].x<minx) minx=c->path[i].x;
        if(c->path[i].x>maxx) maxx=c->path[i].x;
        if(c->path[i].y<miny) miny=c->path[i].y;
        if(c->path[i].y>maxy) maxy=c->path[i].y;
    }
    /* fill bounding box (simplified polygon fill) */
    u32 col=to_c2(c->state.fill_color);
    C2D_DrawRectSolid(minx,miny,0,maxx-minx,maxy-miny,col);
    canvas_end();
    c->dirty=true;
}

void wc_stroke(WCContext2D *c){
    if(!c||c->path_n<2) return;
    canvas_begin(c);
    /* draw line segments */
    u32 col=to_c2(c->state.stroke_color);
    float bw=c->state.line_width;
    int end_n=c->path_closed?c->path_n:c->path_n-1;
    for(int i=0;i<end_n;i++){
        int j=(i+1)%c->path_n;
        float x0=c->path[i].x, y0=c->path[i].y;
        float x1=c->path[j].x, y1=c->path[j].y;
        float dx=x1-x0, dy=y1-y0;
        float len=sqrtf(dx*dx+dy*dy);
        if(len<0.5f) continue;
        /* draw as thin rect rotated toward direction */
        /* simplified: axis-aligned rect over segment */
        if(fabsf(dx)>=fabsf(dy)){
            float sx=dx>0?x0:x1, ex=dx>0?x1:x0;
            C2D_DrawRectSolid(sx,y0-bw/2,0,ex-sx,bw,col);
        } else {
            float sy=dy>0?y0:y1, ey=dy>0?y1:y0;
            C2D_DrawRectSolid(x0-bw/2,sy,0,bw,ey-sy,col);
        }
        /* dot at endpoints for rounded joins */
        if(c->state.line_join==1||c->state.line_cap==1){
            C2D_DrawCircleSolid(x0,y0,0,bw/2,col);
        }
    }
    canvas_end();
    c->dirty=true;
}

void wc_clip(WCContext2D *c){ (void)c; /* TODO: hardware scissor */ }

void wc_fillText(WCContext2D *c, const char *text, float x, float y){
    if(!c||!text) return;
    canvas_begin(c);
    /* v0.40: updated to match wrender_text's new 10-param signature. */
    extern void wrender_text(const char *s, float x, float y, float w, float size, uint32_t col, uint8_t align, uint8_t weight, uint8_t decoration, uint8_t style);
    wrender_text(text,x,y,0,c->state.font_size,c->state.fill_color,c->state.text_align,0,0,0);
    canvas_end();
    c->dirty=true;
}

void wc_strokeText(WCContext2D *c, const char *text, float x, float y){
    if(!c||!text) return;
    canvas_begin(c);
    wrender_text(text,x,y,0,c->state.font_size,c->state.stroke_color,c->state.text_align,0,0,0);
    canvas_end();
    c->dirty=true;
}

float wc_measureText(WCContext2D *c, const char *text){
    if(!c||!text) return 0;
    int n=(int)strlen(text);
    float scale=c->state.font_size/11.0f;
    return n*6*scale;
}

void wc_drawImage(WCContext2D *c, uint16_t img_id, float dx, float dy, float dw, float dh){
    if(!c||img_id==0) return;
    WEImage *img=&g_we_images[img_id-1];
    if(!img->loaded) return;
    canvas_begin(c);
    C2D_DrawImageAt(img->img,dx,dy,0,NULL,dw/img->w,dh/img->h);
    canvas_end();
    c->dirty=true;
}

/* Transform */
void wc_save(WCContext2D *c){ if(!c||c->save_top>=WC_MAX_SAVE_STACK) return; c->save_stack[c->save_top++]=c->state; }
void wc_restore(WCContext2D *c){ if(!c||c->save_top<=0) return; c->state=c->save_stack[--c->save_top]; }
void wc_scale(WCContext2D *c, float sx, float sy){ if(!c) return; c->state.transform[0]*=sx; c->state.transform[3]*=sy; }
void wc_rotate(WCContext2D *c, float a){ if(!c) return; (void)a; /* simplified */ }
void wc_translate(WCContext2D *c, float tx, float ty){ if(!c) return; c->state.transform[4]+=tx; c->state.transform[5]+=ty; }
void wc_transform(WCContext2D *c, float a, float b, float c2, float d, float e, float f){ if(!c) return; c->state.transform[0]=a;c->state.transform[1]=b;c->state.transform[2]=c2;c->state.transform[3]=d;c->state.transform[4]=e;c->state.transform[5]=f; }
void wc_setTransform(WCContext2D *c, float a, float b, float c2, float d, float e, float f){ wc_transform(c,a,b,c2,d,e,f); }
void wc_resetTransform(WCContext2D *c){ if(!c) return; memset(c->state.transform,0,sizeof(c->state.transform)); c->state.transform[0]=1; c->state.transform[3]=1; }

/* Pixel access (simplified) */
void wc_getImageData(WCContext2D *c, float x, float y, float w, float h, uint8_t *out_rgba, int out_sz){ (void)c;(void)x;(void)y;(void)w;(void)h;if(out_rgba&&out_sz>0) memset(out_rgba,0,out_sz); }
void wc_putImageData(WCContext2D *c, const uint8_t *rgba, int iw, int ih, float dx, float dy){ (void)c;(void)rgba;(void)iw;(void)ih;(void)dx;(void)dy; }

void wc_present(WCContext2D *c){ if(c) c->dirty=false; }

/* ── Duktape bindings ────────────────────────────────────────────── */

static uint16_t get_canvas_id_from_ctx(duk_context *ctx){
    duk_push_this(ctx);
    duk_get_prop_string(ctx,-1,"__canvas_id");
    uint16_t id=(uint16_t)duk_to_int(ctx,-1);
    duk_pop_2(ctx);
    return id;
}

#define CTX_FROM_DUK(ctx) WCContext2D *c=wc_get_context(get_canvas_id_from_ctx(ctx))

static duk_ret_t wc_js_clearRect(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_clearRect(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3)); return 0; }
static duk_ret_t wc_js_fillRect(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_fillRect(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3)); return 0; }
static duk_ret_t wc_js_strokeRect(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_strokeRect(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3)); return 0; }
static duk_ret_t wc_js_beginPath(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_beginPath(c); return 0; }
static duk_ret_t wc_js_closePath(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_closePath(c); return 0; }
static duk_ret_t wc_js_moveTo(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_moveTo(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1)); return 0; }
static duk_ret_t wc_js_lineTo(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_lineTo(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1)); return 0; }
static duk_ret_t wc_js_arc(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_arc(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3),(float)duk_to_number(ctx,4),duk_to_boolean(ctx,5)); return 0; }
static duk_ret_t wc_js_bezierCurveTo(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_bezierCurveTo(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3),(float)duk_to_number(ctx,4),(float)duk_to_number(ctx,5)); return 0; }
static duk_ret_t wc_js_quadraticCurveTo(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_quadraticCurveTo(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3)); return 0; }
static duk_ret_t wc_js_rect(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_rect(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3)); return 0; }
static duk_ret_t wc_js_fill(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_fill(c); return 0; }
static duk_ret_t wc_js_stroke(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_stroke(c); return 0; }
static duk_ret_t wc_js_fillText(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_fillText(c,duk_safe_to_string(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2)); return 0; }
static duk_ret_t wc_js_strokeText(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_strokeText(c,duk_safe_to_string(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2)); return 0; }
static duk_ret_t wc_js_measureText(duk_context *ctx){ CTX_FROM_DUK(ctx); duk_push_object(ctx); duk_push_number(ctx,wc_measureText(c,duk_safe_to_string(ctx,0))); duk_put_prop_string(ctx,-2,"width"); return 1; }
static duk_ret_t wc_js_save(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_save(c); return 0; }
static duk_ret_t wc_js_restore(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_restore(c); return 0; }
static duk_ret_t wc_js_scale(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_scale(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1)); return 0; }
static duk_ret_t wc_js_rotate(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_rotate(c,(float)duk_to_number(ctx,0)); return 0; }
static duk_ret_t wc_js_translate(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_translate(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1)); return 0; }
static duk_ret_t wc_js_transform(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_transform(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3),(float)duk_to_number(ctx,4),(float)duk_to_number(ctx,5)); return 0; }
static duk_ret_t wc_js_setTransform(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_setTransform(c,(float)duk_to_number(ctx,0),(float)duk_to_number(ctx,1),(float)duk_to_number(ctx,2),(float)duk_to_number(ctx,3),(float)duk_to_number(ctx,4),(float)duk_to_number(ctx,5)); return 0; }
static duk_ret_t wc_js_resetTransform(duk_context *ctx){ CTX_FROM_DUK(ctx); wc_resetTransform(c); return 0; }

/* Property setter/getter helpers */
static duk_ret_t wc_js_set_fillStyle(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c) c->state.fill_color=parse_jscol(duk_safe_to_string(ctx,0)); return 0; }
static duk_ret_t wc_js_set_strokeStyle(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c) c->state.stroke_color=parse_jscol(duk_safe_to_string(ctx,0)); return 0; }
static duk_ret_t wc_js_set_lineWidth(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c) c->state.line_width=(float)duk_to_number(ctx,0); return 0; }
static duk_ret_t wc_js_set_globalAlpha(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c) c->state.global_alpha=(float)duk_to_number(ctx,0); return 0; }
static duk_ret_t wc_js_set_font(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c){ const char *f=duk_safe_to_string(ctx,0); float sz=12; sscanf(f,"%fpx",&sz); c->state.font_size=sz; } return 0; }
static duk_ret_t wc_js_set_textAlign(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c){ const char *s=duk_safe_to_string(ctx,0); c->state.text_align=(strcmp(s,"center")==0)?1:(strcmp(s,"right")==0)?2:0; } return 0; }
static duk_ret_t wc_js_set_textBaseline(duk_context *ctx){ CTX_FROM_DUK(ctx); if(c){ const char *s=duk_safe_to_string(ctx,0); c->state.text_baseline=(strcmp(s,"middle")==0)?1:(strcmp(s,"alphabetic")==0)?2:0; } return 0; }

void wc_install_bindings(duk_context *ctx, uint16_t canvas_id){
    duk_push_object(ctx);
    duk_push_int(ctx,(int)canvas_id); duk_put_prop_string(ctx,-2,"__canvas_id");

    #define M(n,f,a) duk_push_c_function(ctx,f,a); duk_put_prop_string(ctx,-2,n)
    M("clearRect",wc_js_clearRect,4); M("fillRect",wc_js_fillRect,4); M("strokeRect",wc_js_strokeRect,4);
    M("beginPath",wc_js_beginPath,0); M("closePath",wc_js_closePath,0);
    M("moveTo",wc_js_moveTo,2); M("lineTo",wc_js_lineTo,2);
    M("arc",wc_js_arc,6); M("bezierCurveTo",wc_js_bezierCurveTo,6);
    M("quadraticCurveTo",wc_js_quadraticCurveTo,4); M("rect",wc_js_rect,4);
    M("fill",wc_js_fill,0); M("stroke",wc_js_stroke,0);
    M("fillText",wc_js_fillText,3); M("strokeText",wc_js_strokeText,3);
    M("measureText",wc_js_measureText,1);
    M("save",wc_js_save,0); M("restore",wc_js_restore,0);
    M("scale",wc_js_scale,2); M("rotate",wc_js_rotate,1);
    M("translate",wc_js_translate,2); M("transform",wc_js_transform,6);
    M("setTransform",wc_js_setTransform,6); M("resetTransform",wc_js_resetTransform,0);
    /* property setters as setter-functions (JS will call them) */
    M("__set_fillStyle",wc_js_set_fillStyle,1);
    M("__set_strokeStyle",wc_js_set_strokeStyle,1);
    M("__set_lineWidth",wc_js_set_lineWidth,1);
    M("__set_globalAlpha",wc_js_set_globalAlpha,1);
    M("__set_font",wc_js_set_font,1);
    M("__set_textAlign",wc_js_set_textAlign,1);
    M("__set_textBaseline",wc_js_set_textBaseline,1);
    #undef M

    /* install a proxy-like wrapper for property assignments */
    /* Use eval to define getters/setters.
     *
     * v0.38 BUG FIX: this used to be built with snprintf() into a
     * char script[512] buffer. The literal string below is 854 bytes
     * — snprintf silently truncated it mid-statement, which broke
     * every canvas property setter (fillStyle, strokeStyle, lineWidth,
     * globalAlpha, font, textAlign, textBaseline) at runtime with no
     * visible error. There is no string interpolation happening here
     * (the content is 100% static), so it goes straight into
     * duk_eval_string as a literal — no buffer, no size limit, no
     * truncation possible. duk_eval_string (not the _noresult variant)
     * leaves the IIFE's return value on the stack, matching what the
     * caller (js_node_getContext, which does `return 1`) expects. */
    duk_put_global_string(ctx,"__canvasCtx__");
    /* v0.47 fix: use duk_peval_string (protected) so OOM doesn't trigger
     * the fatal handler. If eval fails, push the plain context object. */
    if(duk_peval_string(ctx,
        "(function(){"
        "var c=__canvasCtx__;"
        "Object.defineProperty(c,'fillStyle',{set:function(v){c.__set_fillStyle(v);},get:function(){return '#000000';}});"
        "Object.defineProperty(c,'strokeStyle',{set:function(v){c.__set_strokeStyle(v);},get:function(){return '#000000';}});"
        "Object.defineProperty(c,'lineWidth',{set:function(v){c.__set_lineWidth(v);},get:function(){return 1;}});"
        "Object.defineProperty(c,'globalAlpha',{set:function(v){c.__set_globalAlpha(v);},get:function(){return 1;}});"
        "Object.defineProperty(c,'font',{set:function(v){c.__set_font(v);},get:function(){return '12px sans-serif';}});"
        "Object.defineProperty(c,'textAlign',{set:function(v){c.__set_textAlign(v);},get:function(){return 'left';}});"
        "Object.defineProperty(c,'textBaseline',{set:function(v){c.__set_textBaseline(v);},get:function(){return 'alphabetic';}});"
        "delete window.__canvasCtx__;"
        "return c;"
        "})()"
    )!=0){
        /* Eval failed — pop error, push the plain context object */
        duk_pop(ctx);
        duk_push_global_object(ctx);
        duk_get_prop_string(ctx,-1,"__canvasCtx__");
        duk_remove(ctx,-2);
        duk_del_prop_string(ctx,-2,"__canvasCtx__");
    }
    /* result is now on stack = the context object */
}
