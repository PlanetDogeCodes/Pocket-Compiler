/*
 * web_events.c  —  Event system: 3DS input → DOM events
 *
 * v0.38: we_add_listener's js_ref cast fixed from (uint8_t) to
 * (uint16_t) to match DOMEvent.js_ref's widened type (see web_dom.h).
 */
#include "web_events.h"
#include "duktape.h"
#include "web_dom.h"
#include "web_layout.h"
#include "web_js.h"
#include <string.h>
#include <3ds.h>

/* ── Key mappings ──────────────────────────────────────────────────
 * v0.42 audit fix: each 3DS button must have exactly ONE meaning in
 * run mode to avoid conflicts between the app shell (main.c) and the
 * web content event system (web_events.c).
 *
 * Button assignments in RUN MODE:
 *   DPad U/D/L/R  →  Arrow keys (sent to web content)
 *   A             →  mouse left-click  (main.c) — NOT a keyboard event
 *   B             →  mouse right-click (main.c) — NOT a keyboard event
 *   X             →  release cursor lock (main.c) — NOT a keyboard event
 *   Y             →  Space key (sent to web content)
 *   L             →  mouse left-click  (main.c) — NOT a keyboard event
 *   R             →  mouse right-click (main.c) — NOT a keyboard event
 *   START         →  exit run mode (main.c) — NOT sent to web content
 *   SELECT        →  (unused in run mode)
 *
 * So the ONLY buttons that generate keydown/keyup events for web
 * content are: DPad (4 arrows) and Y (Space). A/B/X/L/R/START are
 * all consumed by main.c for mouse/lock/exit and must NOT appear
 * in the key maps below. */

const char *we_key_string(uint32_t ds_key){
    switch(ds_key){
        case KEY_UP:     return "ArrowUp";
        case KEY_DOWN:   return "ArrowDown";
        case KEY_LEFT:   return "ArrowLeft";
        case KEY_RIGHT:  return "ArrowRight";
        case KEY_Y:      return " ";       /* Space */
        /* v0.42 audit: A/B/X/L/R/START/SELECT are NOT keyboard events.
         * They are mouse clicks, cursor lock, or app-shell controls. */
        default:         return "";
    }
}

int16_t we_key_code(uint32_t ds_key){
    switch(ds_key){
        case KEY_UP:     return WE_KEY_UP;
        case KEY_DOWN:   return WE_KEY_DOWN;
        case KEY_LEFT:   return WE_KEY_LEFT;
        case KEY_RIGHT:  return WE_KEY_RIGHT;
        case KEY_Y:      return WE_KEY_SPACE;
        /* v0.42 audit: same as we_key_string — only DPad + Y generate
         * key events for web content. */
        default:         return 0;
    }
}

/* ── Dispatch helpers ────────────────────────────────────────────── */

void we_dispatch(uint8_t doc_id, int16_t target, WEEvent *ev){
    if(!ev) return;
    ev->doc_id=doc_id;
    ev->target=target;
    /* bubble up from target.
     * v0.38 final audit: added a guard counter bounded by g_dom_node_n
     * so a corrupted parent chain (which shouldn't exist after the
     * dom_append_child cycle guard, but could theoretically arise from
     * a pre-existing state or a bug in dom_remove_child) can't cause
     * an infinite loop that hangs the 3DS. */
    int16_t node=target;
    int guard=0;
    while(node>=0 && guard<g_dom_node_n){
        guard++;
        we_invoke_js(doc_id,node,ev);
        /* check if inline handler exists */
        DOMNode *n=dom_node(node);
        if(!n) break;
        /* check for onclick etc. attribute handlers */
        const char *attr=NULL;
        switch(ev->type){
            case WE_EV_CLICK:     attr=dom_get_attr(node,"onclick"); break;
            case WE_EV_MOUSEDOWN: attr=dom_get_attr(node,"onmousedown"); break;
            case WE_EV_MOUSEUP:   attr=dom_get_attr(node,"onmouseup"); break;
            case WE_EV_MOUSEMOVE: attr=dom_get_attr(node,"onmousemove"); break;
            case WE_EV_KEYDOWN:   attr=dom_get_attr(node,"onkeydown"); break;
            case WE_EV_KEYUP:     attr=dom_get_attr(node,"onkeyup"); break;
            case WE_EV_FOCUS:     attr=dom_get_attr(node,"onfocus"); break;
            case WE_EV_BLUR:      attr=dom_get_attr(node,"onblur"); break;
            case WE_EV_CHANGE:    attr=dom_get_attr(node,"onchange"); break;
            case WE_EV_INPUT:     attr=dom_get_attr(node,"oninput"); break;
            case WE_EV_SUBMIT:    attr=dom_get_attr(node,"onsubmit"); break;
            case WE_EV_SCROLL:    attr=dom_get_attr(node,"onscroll"); break;
            default: break;
        }
        if(attr&&*attr){
            DOMDocument *d=dom_doc(doc_id);
            if(d&&d->js_ctx) wjs_eval((duk_context*)d->js_ctx,attr);
        }
        /* stop bubbling for certain events */
        if(ev->type==WE_EV_FOCUS||ev->type==WE_EV_BLUR) break;
        node=n->parent;
    }
}

void we_add_listener(int16_t node, WEEventType t, int js_ref){
    if(g_dom_event_n>=WE_MAX_EVENTS) return;
    g_dom_events[g_dom_event_n].node_id=(uint16_t)node;
    g_dom_events[g_dom_event_n].event_type=(uint8_t)t;
    g_dom_events[g_dom_event_n].js_ref=(uint16_t)js_ref; /* v0.38: was (uint8_t) */
    g_dom_event_n++;
}

void we_remove_listener(int16_t node, WEEventType t){
    for(int i=0;i<g_dom_event_n;i++){
        if(g_dom_events[i].node_id==(uint16_t)node&&
           g_dom_events[i].event_type==(uint8_t)t){
            /* tombstone */
            g_dom_events[i].event_type=WE_EV_NONE;
        }
    }
}

void we_invoke_js(uint8_t doc_id, int16_t node, const WEEvent *ev){
    DOMDocument *d=dom_doc(doc_id);
    if(!d||!d->js_ctx||!d->js_ready) return;
    duk_context *ctx=(duk_context*)d->js_ctx;
    for(int i=0;i<g_dom_event_n;i++){
        if(g_dom_events[i].event_type==(uint8_t)ev->type&&
           g_dom_events[i].node_id==(uint16_t)node&&
           g_dom_events[i].event_type!=WE_EV_NONE){
            wjs_fire_event(ctx,g_dom_events[i].js_ref,ev);
        }
    }
}

/* ── Focus ───────────────────────────────────────────────────────── */

void we_focus(uint8_t doc_id, int16_t node){
    DOMDocument *d=dom_doc(doc_id);
    if(!d) return;
    int16_t prev=d->focused_node;
    if(prev==node) return;
    /* blur previous.
     * v0.41: mark dirty so :focus styles re-cascade. */
    if(prev>=0){
        g_dom_nodes[prev].focused=0;
        dom_mark_dirty(prev);
        WEEvent blr={0}; blr.type=WE_EV_BLUR; blr.target=prev;
        we_dispatch(doc_id,prev,&blr);
    }
    d->focused_node=node;
    if(node>=0){
        g_dom_nodes[node].focused=1;
        dom_mark_dirty(node);
        WEEvent foc={0}; foc.type=WE_EV_FOCUS; foc.target=node;
        we_dispatch(doc_id,node,&foc);
    }
}

void we_blur(uint8_t doc_id){
    we_focus(doc_id,-1);
}

/* ── Scroll ──────────────────────────────────────────────────────── */

void we_scroll_by(int16_t node_id, int16_t dx, int16_t dy){
    DOMNode *n=dom_node(node_id); if(!n) return;
    int16_t msx,msy; layout_scroll_extents(node_id,&msx,&msy);
    n->scroll_x+=dx; if(n->scroll_x<0)n->scroll_x=0; if(n->scroll_x>msx)n->scroll_x=msx;
    n->scroll_y+=dy; if(n->scroll_y<0)n->scroll_y=0; if(n->scroll_y>msy)n->scroll_y=msy;
}

void we_scroll_to(int16_t node_id, int16_t x, int16_t y){
    DOMNode *n=dom_node(node_id); if(!n) return;
    int16_t msx,msy; layout_scroll_extents(node_id,&msx,&msy);
    n->scroll_x=x; if(n->scroll_x<0)n->scroll_x=0; if(n->scroll_x>msx)n->scroll_x=msx;
    n->scroll_y=y; if(n->scroll_y<0)n->scroll_y=0; if(n->scroll_y>msy)n->scroll_y=msy;
}

/* ── Frame event update ──────────────────────────────────────────── */

static int16_t s_prev_hover=-1;
static bool    s_left_down=false;
static bool    s_right_down=false;
static double  s_last_click_time=0;
static int16_t s_last_click_node=-1;
static int     s_click_count=0;

/* v0.38 final audit: reset all internal event state. Called from
 * we_load_html after a recompile so stale node indices from the
 * previous page don't get dereferenced on the next frame. Without
 * this, s_prev_hover could point at a now-different element (the DOM
 * pool is reused), causing the hover-clear code to write .hover=0
 * onto an unrelated node. Must be defined AFTER the statics above. */
void we_events_reset(void){
    s_prev_hover=-1;
    s_left_down=false;
    s_right_down=false;
    s_last_click_time=0;
    s_last_click_node=-1;
    s_click_count=0;
}

/* v0.41: Open the 3DS software keyboard for arbitrary text entry.
 * Uses SwkbdState (libctru's software keyboard). Returns true if the
 * user pressed CONFIRM and `out` is filled, false if cancelled.
 * The keyboard blocks the main loop while open — that's fine on 3DS
 * since the game loop pauses naturally during swkbd. */
bool we_text_input(const char *initial, const char *hint,
                   char *out, int out_sz){
    if(!out||out_sz<=0) return false;
    SwkbdState sw;
    swkbdInit(&sw, SWKBD_TYPE_NORMAL, 2, out_sz-1);
    if(initial) swkbdSetInitialText(&sw, initial);
    if(hint) swkbdSetHintText(&sw, hint);
    SwkbdButton btn = swkbdInputText(&sw, out, (size_t)out_sz);
    return btn == SWKBD_BUTTON_CONFIRM;
}

/* v0.41: Open the software keyboard for a focused <input>/<textarea>.
 * Reads the current "value" attribute, shows the keyboard with it as
 * the initial text, writes the result back, and fires 'input' and
 * 'change' events. Returns true if confirmed, false if cancelled. */
bool we_input_prompt(uint8_t doc_id, int16_t node){
    if(node<0||node>=g_dom_node_n) return false;
    DOMNode *n=&g_dom_nodes[node];
    if(n->type!=NT_ELEMENT) return false;
    const char *tag=dom_tag(node);
    if(strcmp(tag,"input")!=0 && strcmp(tag,"textarea")!=0) return false;

    /* Read current value (or placeholder as initial text) */
    const char *cur = dom_get_attr(node, "value");
    if(!cur) cur = dom_get_attr(node, "placeholder");
    if(!cur) cur = "";

    /* Open the keyboard */
    static char buf[512];
    bool ok = we_text_input(cur, "Enter text", buf, sizeof(buf));
    if(!ok) return false;

    /* Write the new value back to the DOM */
    dom_set_attr(node, "value", buf);

    /* Mark dirty so the renderer shows the new text */
    dom_mark_dirty(node);

    /* Fire 'input' event (fires on every value change) */
    WEEvent iev={0}; iev.type=WE_EV_INPUT;
    we_dispatch(doc_id, node, &iev);

    /* Fire 'change' event (fires when value is committed) */
    WEEvent cev={0}; cev.type=WE_EV_CHANGE;
    we_dispatch(doc_id, node, &cev);

    return true;
}

void we_events_update(uint8_t doc_id, const WEInputState *inp){
    if(!inp) return;

    /* ── cursor move ──────────────────────────────────────────── */
    float cx=inp->cursor_x, cy=inp->cursor_y;
    int16_t hover=layout_hit(doc_id,(int16_t)cx,(int16_t)cy);

    /* mouseleave / mouseenter.
     * v0.41: when hover changes, mark the old AND new nodes dirty so
     * the CSS cascade re-runs and :hover styles apply dynamically. */
    if(hover!=s_prev_hover){
        if(s_prev_hover>=0){
            g_dom_nodes[s_prev_hover].hover=0;
            dom_mark_dirty(s_prev_hover);
            WEEvent ev={0}; ev.type=WE_EV_MOUSELEAVE;
            ev.client_x=cx; ev.client_y=cy;
            we_dispatch(doc_id,s_prev_hover,&ev);
        }
        if(hover>=0){
            g_dom_nodes[hover].hover=1;
            dom_mark_dirty(hover);
            WEEvent ev={0}; ev.type=WE_EV_MOUSEENTER;
            ev.client_x=cx; ev.client_y=cy;
            we_dispatch(doc_id,hover,&ev);
        }
        s_prev_hover=hover;
    }

    /* mousemove */
    if(inp->cursor_x!=inp->prev_x||inp->cursor_y!=inp->prev_y){
        WEEvent ev={0}; ev.type=WE_EV_MOUSEMOVE;
        ev.client_x=cx; ev.client_y=cy;
        ev.target=hover;
        if(hover>=0){
            DOMNode *n=dom_node(hover);
            ev.offset_x=cx-n->lay_x;
            ev.offset_y=cy-n->lay_y;
        }
        we_dispatch(doc_id,hover>=0?hover:0,&ev);
    }

    /* ── mouse buttons ────────────────────────────────────────── */
    bool left_now  =(inp->down&KEY_A)||(inp->down&KEY_L)?true:
                    (inp->held&KEY_A)||(inp->held&KEY_L)?s_left_down:false;
    bool right_now =(inp->down&KEY_B)||(inp->down&KEY_R)?true:
                    (inp->held&KEY_B)||(inp->held&KEY_R)?s_right_down:false;

    /* mousedown left */
    if(((inp->down&KEY_A)||(inp->down&KEY_L))&&!s_left_down){
        s_left_down=true;
        if(hover>=0){
            g_dom_nodes[hover].active=1;
            WEEvent ev={0}; ev.type=WE_EV_MOUSEDOWN;
            ev.client_x=cx; ev.client_y=cy; ev.button=0;
            we_dispatch(doc_id,hover,&ev);
            we_focus(doc_id,layout_find_focusable(hover));
        }
    }
    /* mouseup left → click */
    if(s_left_down&&!((inp->held&KEY_A)||(inp->held&KEY_L))){
        s_left_down=false;
        if(hover>=0){
            g_dom_nodes[hover].active=0;
            WEEvent ev={0}; ev.type=WE_EV_MOUSEUP;
            ev.client_x=cx; ev.client_y=cy; ev.button=0;
            we_dispatch(doc_id,hover,&ev);
            /* click */
            WEEvent cev={0}; cev.type=WE_EV_CLICK;
            cev.client_x=cx; cev.client_y=cy; cev.button=0;
            we_dispatch(doc_id,hover,&cev);
            /* v0.41: if the clicked element (or an ancestor) is an
             * <input>/<textarea>, open the software keyboard so the
             * user can type into it. This makes forms work. */
            {
                int16_t check=hover;
                int guard=0;
                while(check>=0 && guard<g_dom_node_n){
                    guard++;
                    const char *t=dom_tag(check);
                    if(strcmp(t,"input")==0||strcmp(t,"textarea")==0){
                        we_input_prompt(doc_id, check);
                        break;
                    }
                    check=g_dom_nodes[check].parent;
                }
            }
            /* v0.42 audit: form submission via click. If the clicked
             * element (or an ancestor) is a <button type=submit> or
             * <input type=submit>, walk up to the parent <form> and
             * fire its onsubmit handler + 'submit' event. This
             * replaces the old START-key approach which conflicted
             * with START=exit-run-mode. */
            {
                int16_t check=hover;
                int guard=0;
                bool is_submit=false;
                while(check>=0 && guard<g_dom_node_n){
                    guard++;
                    const char *t=dom_tag(check);
                    if(strcmp(t,"button")==0||strcmp(t,"input")==0){
                        const char *type=dom_get_attr(check,"type");
                        if(type && (strcmp(type,"submit")==0)){
                            is_submit=true;
                        }
                    }
                    if(strcmp(t,"form")==0 && is_submit){
                        /* Found the form. Fire onsubmit attribute. */
                        DOMDocument *d=dom_doc(doc_id);
                        const char *onsub=dom_get_attr(check,"onsubmit");
                        if(onsub && *onsub && d && d->js_ctx){
                            wjs_eval((duk_context*)d->js_ctx, onsub);
                        }
                        /* Fire a 'submit' event on the form. */
                        WEEvent sev={0}; sev.type=WE_EV_SUBMIT;
                        sev.target=check;
                        we_dispatch(doc_id, check, &sev);
                        break;
                    }
                    check=g_dom_nodes[check].parent;
                }
            }
            /* handle <a href="..."> navigation */
            const char *href=dom_get_attr(hover,"href");
            if(!href){
                /* check parent chain for <a>.
                 * v0.38: guard against cycle (bounded by g_dom_node_n). */
                int16_t pa=g_dom_nodes[hover].parent;
                int guard=0;
                while(pa>=0 && guard<g_dom_node_n){
                    guard++;
                    if(strcmp(dom_tag(pa),"a")==0){
                        href=dom_get_attr(pa,"href");
                        break;
                    }
                    pa=g_dom_nodes[pa].parent;
                }
            }
            /* href navigation handled by web_engine.c */
            (void)href;
        }
        left_now=false;
    }
    (void)left_now;

    /* mousedown/up right */
    if(((inp->down&KEY_B)||(inp->down&KEY_R))&&!s_right_down){
        s_right_down=true;
        if(hover>=0){
            WEEvent ev={0}; ev.type=WE_EV_MOUSEDOWN;
            ev.client_x=cx; ev.client_y=cy; ev.button=2;
            we_dispatch(doc_id,hover,&ev);
            WEEvent cev={0}; cev.type=WE_EV_CONTEXTMENU;
            cev.client_x=cx; cev.client_y=cy;
            we_dispatch(doc_id,hover,&cev);
        }
    }
    if(s_right_down&&!((inp->held&KEY_B)||(inp->held&KEY_R))){
        s_right_down=false;
        right_now=false;
        if(hover>=0){
            WEEvent ev={0}; ev.type=WE_EV_MOUSEUP;
            ev.client_x=cx; ev.client_y=cy; ev.button=2;
            we_dispatch(doc_id,hover,&ev);
        }
    }
    (void)right_now;

    /* ── keyboard (DPad + Y only) ─────────────────────────────
     * v0.42 audit fix: ONLY DPad and Y generate key events for web
     * content. A/B/X/L/R/START are all consumed by main.c for mouse
     * clicks, cursor lock, and exit-run-mode — they must NOT appear
     * here or they'll fire spurious keydown events alongside their
     * mouse/shell functions.
     *
     * Form submission: since START exits run mode (main.c), the user
     * submits a form by clicking a submit button (A on a <button
     * type=submit> or <input type=submit>), not by pressing START.
     * The click handler in we_events_update already fires 'click'
     * which bubbles to the form and triggers onsubmit. */
    static const uint32_t KEY_MAP[]={
        KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,
        KEY_Y,   /* Y = space (for scrolling, activating buttons) */
        0
    };
    for(int ki=0;KEY_MAP[ki];ki++){
        uint32_t k=KEY_MAP[ki];
        if(inp->down&k){
            DOMDocument *d=dom_doc(doc_id);
            int16_t focused=d?d->focused_node:-1;
            WEEvent ev={0}; ev.type=WE_EV_KEYDOWN;
            ev.key_code=we_key_code(k);
            strncpy(ev.key_str,we_key_string(k),sizeof(ev.key_str)-1);
            ev.key_str[sizeof(ev.key_str)-1]='\0';
            we_dispatch(doc_id,focused>=0?focused:0,&ev);
            /* keypress for printable keys */
            if(ev.key_code==WE_KEY_SPACE){
                WEEvent kp={0}; kp.type=WE_EV_KEYPRESS;
                kp.key_code=ev.key_code;
                strncpy(kp.key_str,ev.key_str,sizeof(kp.key_str)-1);
                kp.key_str[sizeof(kp.key_str)-1]='\0';
                we_dispatch(doc_id,focused>=0?focused:0,&kp);
            }
        }
        if(inp->up&k){
            DOMDocument *d=dom_doc(doc_id);
            int16_t focused=d?d->focused_node:-1;
            WEEvent ev={0}; ev.type=WE_EV_KEYUP;
            ev.key_code=we_key_code(k);
            strncpy(ev.key_str,we_key_string(k),sizeof(ev.key_str)-1);
            ev.key_str[sizeof(ev.key_str)-1]='\0';
            we_dispatch(doc_id,focused>=0?focused:0,&ev);
        }
    }

    /* ── touch (stylus on bottom screen — if applicable) ──────── */
    /* Note: on 3DS, bottom screen is blocked in run_mode.
       If we ever extend to bottom-screen web content, touch events
       would fire here from hidTouchRead().                        */
    if(inp->touched&&!inp->was_touched){
        WEEvent ev={0}; ev.type=WE_EV_TOUCHSTART;
        ev.client_x=inp->touch.px; ev.client_y=inp->touch.py;
        ev.touch_id=0;
        we_dispatch(doc_id,hover>=0?hover:0,&ev);
    }
    if(!inp->touched&&inp->was_touched){
        WEEvent ev={0}; ev.type=WE_EV_TOUCHEND;
        ev.client_x=inp->prev_touch.px; ev.client_y=inp->prev_touch.py;
        ev.touch_id=0;
        we_dispatch(doc_id,hover>=0?hover:0,&ev);
    }
}
