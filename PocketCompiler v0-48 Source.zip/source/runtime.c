/*
 * runtime.c — stub for Pocket Compiler v0.33
 *
 * All runtime logic lives in source/runtime_features.c.
 * This file exists only for build-system compatibility and contains
 * no function definitions, preventing duplicate-symbol link errors.
 */
#include "runtime_features.h"
