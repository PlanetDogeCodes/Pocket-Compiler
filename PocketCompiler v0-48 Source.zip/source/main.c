/*
 * main.c — Entry point for Pocket Compiler v0.39
 *
 * v0.39 changes (feature pass over v0.38):
 *  - R now opens a new MODE_ACTIONS menu (was: direct MODE_FIND entry).
 *    The menu is the gateway to Find/Replace (row 0, unchanged behavior),
 *    Go-to-line, Duplicate line, Comment toggle, Rename file, Delete file,
 *    Sort cycling, and Export console log. Necessary because every face/
 *    shoulder button in the editor tab was already assigned.
 *  - MODE_GOTO: numeric keyboard → editor_scroll_to_line. Mirrors the
 *    find-bar overlay geometry.
 *  - MODE_DELETE: file explorer with a two-step confirm (A arms, A again
 *    deletes; B cancels the arm or exits). Mirrors MODE_LOAD.
 *  - MODE_RENAME: file explorer; A on a row opens the rename keyboard
 *    (pre-filled with the current name, .html auto-appended). Mirrors
 *    MODE_DELETE's geometry but single-step (the keyboard itself is the
 *    cancel path).
 *  - MODE_ACTIONS cursor fix: the OLD max_scroll formula
 *    (row_count - PANEL_VISIBLE_ROWS) clamped to 0 when there were
 *    fewer rows than visible (the common case here: 8 rows < 10
 *    visible), making the DOWN button a no-op and leaving the cursor
 *    stuck on row 0 (Find/Replace). Now uses row_count - 1 as the
 *    cursor max, matching how draw_actions reads actions_scroll.
 *  - Auto-save draft: writes the buffer to FE_AUTOSAVE on every compile
 *    and after ~10s of input idle. Pure addition; never touches the
 *    normal save/load path.
 *  - On startup, the last-opened file is auto-restored from config.txt.
 *  - Multi-level undo ring (5 steps) lives in editor.c; this file's
 *    three editor_snapshot()/editor_undo() call sites are unchanged.
 *
 * v0.37 changes (bug-fix / UX pass over v0.36):
 *
 *  - REAL TOUCHSCREEN SUPPORT. Previously the bottom-screen cursor only
 *    moved via the Circle Pad — touching the screen did nothing at all,
 *    which made the EDITOR/CONSOLE tab buttons (and everything else)
 *    impossible to tap. Now:
 *      • While the screen is being touched, the cursor snaps to the
 *        touch position every frame (touch takes priority over the
 *        Circle Pad; releasing the screen returns control to the
 *        Circle Pad from wherever the cursor was left).
 *      • A tap (the first frame of a touch) on the EDITOR/CONSOLE tab
 *        bar switches tabs directly — the original bug report.
 *      • A tap on a code line in the editor tab edits that line
 *        (same action as pressing A while hovering it).
 *      • A tap on a row in the Save/Load file list selects and acts
 *        on that row (same action as pressing A/X or A/Y).
 *    Touch is intentionally NOT wired into the Console tab's content
 *    area (eval is a global action, not a location on screen — A is
 *    still how you open the eval keyboard) or into Find mode (A has a
 *    different, non-positional meaning there: set the search string).
 *
 *  - CONTROLS HELP SCREEN NOW SCROLLS. It previously had no scroll
 *    state at all, and its 12 fixed rows (12 * 17px = 204px) silently
 *    overflowed the ~178px-tall panel — several rows were drawn
 *    underneath/behind the hint bar. DPad Up/Down now scrolls it
 *    (consistent with every other scrollable view in the app), and a
 *    scrollbar is drawn so the user can see there's more content.
 *
 *  - PANEL_VISIBLE_ROWS (app.h) replaces the old CONSOLE_VISIBLE_LINES
 *    constant, which was 12 here but 10 in ui.c's actual render loop.
 *    That mismatch made the console under-scroll: scrolling to the
 *    "bottom" left the 2 newest log lines permanently unreachable.
 *    Both files now agree on the single correct value (10).
 *
 *  - Helper functions (do_edit_line_action, do_save_dialog_action,
 *    do_load_file_action, do_switch_to_editor_tab/console_tab) were
 *    extracted so the exact same code path runs whether the action is
 *    triggered by a button press or by a touch tap — no duplicated
 *    logic that could drift out of sync between the two input methods.
 *
 * v0.35 / v0.36 features (retained):
 *  - Auto-indent on empty-line edit.
 *  - JS Console tab (L button, or tap the tab) with live eval.
 *  - Find / Replace (R button) with next/prev/replace-one/replace-all.
 *  - Duktape context stays alive after START-stop so the console
 *    remains usable without recompiling.
 *
 * Input model (edit mode, editor tab):
 *   Circle / Touch → move bottom-screen cursor (touch = absolute jump)
 *   Tap code line  → edit that line (same as A)
 *   Tap tab bar    → switch EDITOR/CONSOLE tab (same as L)
 *   DPad U/D       → scroll code vertically
 *   DPad L/R       → scroll code horizontally
 *   A              → edit hovered line (auto-indent pre-fill if empty)
 *   B              → undo
 *   X              → save explorer
 *   Y              → load explorer
 *   L              → toggle JS console tab
 *   R              → open Actions menu (find/replace, go-to-line,
 *                    duplicate, comment, rename, delete, sort, export log)
 *   START          → compile + run
 *   SELECT         → controls reference
 *
 * Input model (edit mode, console tab):
 *   DPad U/D  → scroll console log
 *   A         → type & eval JS expression
 *   B         → clear console log
 *   L / tap EDITOR tab → back to editor tab
 *   X/Y/START/SELECT work as normal
 *
 * Input model (find/replace mode):
 *   A         → set / update search string
 *   DPad D/U  → find next / previous
 *   Y         → set replacement & replace current match
 *   X         → replace all
 *   B         → close find mode
 *
 * Input model (controls / help screen):
 *   DPad U/D       → scroll the list
 *   SELECT or B    → close
 *
 * Input model (run mode):
 *   START     → stop output, return to edit mode
 *   Circle    → move top-screen cursor (no touch — 3DS top screen has
 *               no touch hardware)
 *   DPad U/D  → scroll output
 *   A / L     → left-click
 *   B / R     → right-click
 *   X         → release cursor lock
 */
#include <3ds.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>   /* v0.39: atoi for go-to-line parsing */

#include "app.h"
#include "editor.h"
#include "file_explorer.h"
#include "runtime_features.h"
#include "web_engine.h"
#include "web_js.h"
#include "ui.h"

static AppState       g_app;
static Editor         g_editor;
static FeatureRuntime g_runtime;

#define CURSOR_SPEED  0.08f
#define DEADZONE      14

/* ── Layout constants (must match ui.c exactly) ──────────────────── */
#define LAYOUT_MAR        6.0f
#define LAYOUT_TAB_H     26.0f
#define LAYOUT_TAB_W    152.0f   /* (320-2*MAR)*0.5 - 2  */
#define LAYOUT_TAB_GAP_X 162.0f  /* MAR + TAB_W + 4       */
#define LAYOUT_TAB_Y0     3.0f
#define LAYOUT_TAB_Y1    24.0f   /* TAB_H - 2             */

#define LAYOUT_ED_Y      28.0f
#define LAYOUT_ED_PAD     5.0f
#define LAYOUT_LH_ED     15.0f
#define LAYOUT_ED_X       6.0f
#define LAYOUT_ED_W     308.0f
#define LAYOUT_ED_H     178.0f   /* height of editor panel (240-28-34) */

#define LAYOUT_FE_X       6.0f
#define LAYOUT_FE_Y      28.0f
#define LAYOUT_FE_W     308.0f
#define LAYOUT_FE_H     178.0f
#define LAYOUT_FE_PAD     5.0f
#define LAYOUT_LH_FE     23.0f

#define LAYOUT_OUT_X0     8.0f
#define LAYOUT_OUT_X1   392.0f
#define LAYOUT_OUT_Y0    40.0f
#define LAYOUT_OUT_Y1   234.0f

static char g_fname[FE_FILENAME_MAX];

static void ensure_html_ext(char *buf, int sz){
    size_t len=strlen(buf);
    if(!len)return;
    if(len<5||strcmp(buf+len-5,".html")!=0)
        if((int)(len+5)<sz) strncat(buf, ".html", (size_t)(sz - (int)len - 1));
}

static bool kbd(const char *fill,const char *hint,char *out,int out_sz){
    SwkbdState s;
    swkbdInit(&s,SWKBD_TYPE_NORMAL,2,out_sz-1);
    if(fill)swkbdSetInitialText(&s,fill);
    if(hint)swkbdSetHintText(&s,hint);
    return swkbdInputText(&s,out,(size_t)out_sz)==SWKBD_BUTTON_CONFIRM;
}

static float clampf(float v,float lo,float hi){
    return v<lo?lo:(v>hi?hi:v);
}

/* ── Auto-indent helper ──────────────────────────────────────────── */
static void compute_auto_indent(const Editor *e, int line,
                                char *out, int out_sz){
    out[0] = '\0';
    if(line <= 0) return;

    char indent[ED_LINE_MAX];
    editor_get_indent(e, line - 1, indent, sizeof(indent));

    char prev[ED_LINE_MAX];
    editor_get_line(e, line - 1, prev, sizeof(prev));
    int plen = (int)strlen(prev);

    int li = plen - 1;
    while(li >= 0 && prev[li] == ' ') li--;
    char last = (li >= 0) ? prev[li] : '\0';

    bool add_extra = (last == '{' || last == '(' || last == '[');

    if(!add_extra && last == '>' && li >= 1 && prev[li-1] != '/'){
        int bt = li - 1;
        while(bt >= 0 && prev[bt] != '<') bt--;
        if(bt >= 0 && prev[bt+1] != '/'){
            char tn[32] = {0};
            const char *tp = prev + bt + 1;
            int ti = 0;
            while(*tp && *tp != '>' && *tp != ' ' && *tp != '/' && ti < 31){
                char c = *tp++;
                tn[ti++] = (c>='A'&&c<='Z') ? c+32 : c;
            }
            tn[ti] = '\0';
            static const char *voids[] = {
                "area","base","br","col","embed","hr","img","input",
                "link","meta","param","source","track","wbr",NULL
            };
            bool is_void = false;
            for(int vi = 0; voids[vi]; vi++)
                if(strcmp(tn, voids[vi]) == 0){ is_void = true; break; }
            if(!is_void) add_extra = true;
        }
    }

    int ilen = (int)strlen(indent);
    if(add_extra){
        int total = ilen + 2;
        if(total >= out_sz) total = out_sz - 1;
        int copy = ilen < total ? ilen : total;
        memcpy(out, indent, copy);
        if(copy < out_sz - 1) out[copy++] = ' ';
        if(copy < out_sz - 1) out[copy++] = ' ';
        out[copy < out_sz ? copy : out_sz - 1] = '\0';
    } else {
        strncpy(out, indent, out_sz - 1);
        out[out_sz - 1] = '\0';
    }
}

static void editor_scroll_to_line(int line){
    if(line < g_editor.scroll_offset){
        g_editor.scroll_offset = line;
    } else if(line >= g_editor.scroll_offset + CODE_AREA_H){
        g_editor.scroll_offset = line - CODE_AREA_H / 2;
        if(g_editor.scroll_offset < 0) g_editor.scroll_offset = 0;
    }
    g_editor.cursor_line = line;
}

/* ══════════════════════════════════════════════════════════════════
   SHARED ACTION HELPERS
   These are called from BOTH the button-press handlers and the
   touch-tap handler below, so there is exactly one implementation of
   each action regardless of which input method triggered it.
   ══════════════════════════════════════════════════════════════════ */

/* Edit the line currently under the editor-tab cursor (auto-indent
 * pre-fill on empty lines). Equivalent to pressing A in the editor tab. */
static void do_edit_line_action(void){
    int target = g_editor.scroll_offset + g_app.code_cursor_line;
    int total  = editor_line_count(&g_editor);
    if(target < 0)      target = 0;
    if(target >= total) target = total - 1;
    g_editor.cursor_line = target;

    char lt[ED_LINE_MAX], nt[ED_LINE_MAX];
    editor_get_line(&g_editor, target, lt, sizeof(lt));

    char pre_fill[ED_LINE_MAX];
    if(lt[0] == '\0' && target > 0){
        compute_auto_indent(&g_editor, target, pre_fill, sizeof(pre_fill));
    } else {
        strncpy(pre_fill, lt, ED_LINE_MAX - 1);
        pre_fill[ED_LINE_MAX - 1] = '\0';
    }

    if(kbd(pre_fill, "Edit line", nt, sizeof(nt))){
        editor_snapshot(&g_editor);
        editor_set_line(&g_editor, target, nt);
    }
}

/* Open the save-filename keyboard for whatever fe.cursor currently
 * points at, and save if confirmed. Equivalent to pressing A or X in
 * MODE_SAVE. */
static void do_save_dialog_action(void){
    const char *pf = (g_app.fe.cursor > 0)
                     ? g_app.fe.names[g_app.fe.cursor - 1] : "";
    memset(g_fname, 0, sizeof(g_fname));
    if(kbd(pf, "Filename (.html)", g_fname, sizeof(g_fname))
       && strlen(g_fname) > 0){
        ensure_html_ext(g_fname, sizeof(g_fname));
        if(fe_save_named(&g_editor, g_fname)){
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     "Saved: %s", g_fname);
            snprintf(g_runtime.last_message, sizeof(g_runtime.last_message),
                     "Saved: %s", g_fname);
            fe_save_last(g_fname);   /* v0.39: remember for next launch */
            g_app.mode = MODE_EDIT;
        } else {
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     "Save FAILED: %s", g_fname);
        }
    }
}

/* Load whatever fe.cursor currently points at. Equivalent to pressing
 * A or Y in MODE_LOAD. */
static void do_load_file_action(void){
    if(g_app.fe.count > 0 &&
       g_app.fe.cursor >= 0 &&
       g_app.fe.cursor < g_app.fe.count){
        const char *fn = g_app.fe.names[g_app.fe.cursor];
        if(fe_load_named(&g_editor, fn)){
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     "Loaded: %s", fn);
            snprintf(g_runtime.last_message, sizeof(g_runtime.last_message),
                     "Loaded: %s", fn);
            fe_save_last(fn);   /* v0.39: remember for next launch */
            g_app.mode = MODE_EDIT;
        } else {
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     "Load FAILED: %s", fn);
        }
    }
}

/* Switch the bottom-screen tab. Equivalent to pressing L. Guards
 * against redundant resets if the already-active tab is "switched to"
 * again (e.g. tapping CONSOLE while already on the console tab would
 * otherwise needlessly snap the scroll position back to the bottom). */
static void do_switch_to_editor_tab(void){
    g_app.console_tab = false;
}
static void do_switch_to_console_tab(void){
    g_app.console_tab    = true;
    int max_s = g_wjs_log_n - PANEL_VISIBLE_ROWS;
    if(max_s < 0) max_s = 0;
    g_app.console_scroll = max_s;
}

/* ══════════════════════════════════════════════════════════════════
   v0.39 — ACTION HELPERS
   Used by the MODE_ACTIONS handler (entered via R from the editor tab).
   Each does one of: enter a sub-mode, run an editor op, or cycle state.
   All snapshot the editor first where the action is destructive, so the
   v0.39 multi-level undo ring can roll it back.
   ══════════════════════════════════════════════════════════════════ */

/* Run the action at the given row index. Returns true if the action
 * leaves MODE_ACTIONS (so the caller can drop back to MODE_EDIT). Row
 * indices come from ui.h's ACT_* defines. */
static bool do_action_run(int row){
    switch(row){
        case ACT_FIND:
            /* Find/Replace moved here from R-direct. Enter MODE_FIND. */
            g_app.mode            = MODE_FIND;
            g_app.find_has_match  = false;
            g_app.find_match_line = -1;
            g_app.find_match_col  = 0;
            return true;
        case ACT_GOTO:
            g_app.mode       = MODE_GOTO;
            g_app.goto_buf[0]= '\0';
            g_app.goto_target= -1;
            return true;
        case ACT_DUPLICATE:
            editor_snapshot(&g_editor);
            editor_duplicate_line(&g_editor);
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     "Duplicated line %d", g_editor.cursor_line);
            return false; /* stay in MODE_ACTIONS for another action */
        case ACT_COMMENT:
            editor_snapshot(&g_editor);
            editor_toggle_comment(&g_editor);
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     "Toggled comment on line %d", g_editor.cursor_line + 1);
            return false;
        case ACT_DELETE:
            fe_scan(&g_app.fe);
            g_app.fe.cursor   = 0;
            g_app.fe.scroll   = 0;
            g_app.delete_confirm = false;
            g_app.mode        = MODE_DELETE;
            return true;
        case ACT_RENAME:
            /* v0.39: mirror MODE_DELETE's entry path. The actual rename
             * keyboard + fe_rename_named call happens in the MODE_RENAME
             * A-press handler below. */
            fe_scan(&g_app.fe);
            g_app.fe.cursor   = 0;
            g_app.fe.scroll   = 0;
            g_app.mode        = MODE_RENAME;
            return true;
        case ACT_SORT: {
            int nm = (g_app.fe.sort_mode + 1) % FE_SORT_COUNT;
            g_app.fe.sort_mode = nm;
            fe_scan(&g_app.fe);
            g_app.fe.cursor = 0; g_app.fe.scroll = 0;
            return false; /* stay; let user see the new order / pick again */
        }
        case ACT_EXPORT_LOG: {
            bool ok = wjs_export_log();
            snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                     ok ? "Log exported to console_log.txt"
                        : "Log export FAILED");
            return false;
        }
        case ACT_RECOVER: {
            /* v0.39: load the crash-recovery draft (FE_AUTOSAVE) into
             * the editor. The user gets back whatever the idle/compile
             * autosave last wrote. Does NOT touch config.txt (the
             * recovered buffer might not belong to any named file). */
            if(fe_load_autosave(&g_editor)){
                snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                         "Recovered autosave draft");
            } else {
                snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                         "No autosave found");
            }
            return false; /* stay in Actions so user can immediately save */
        }
        default:
            return false;
    }
}

/* Auto-save the current editor buffer to FE_AUTOSAVE. Called from the
 * main loop on compile (force=true) and after 10s of input idle
 * (force=false). Non-fatal.
 *
 * v0.39 audit fix: the idle path now checks autosave_dirty so it only
 * writes ONCE per idle window. Without this, the first idle autosave
 * set autosave_dirty=true but nothing ever checked or reset it, so
 * every subsequent 10s of idle wrote the same buffer again — wasteful
 * SD I/O that repeats forever as long as the user is idle. Now:
 *   - any input resets autosave_dirty=false (alongside idle_frames=0)
 *   - the idle path skips writing if autosave_dirty is already true
 *   - the compile path (force=true) always writes regardless */
static void do_autosave_if_due(bool force){
    /* 10 seconds at ~60 fps = 600 frames. */
    if(force || (g_app.idle_frames >= 600 && !g_app.autosave_dirty)){
        if(fe_save_autosave(&g_editor)){
            g_app.autosave_dirty = true;
        }
        g_app.idle_frames = 0;
    }
}

int main(void){
    ui_init();
    runtime_init(&g_runtime);
    editor_init(&g_editor);

    memset(&g_app,0,sizeof(g_app));
    fe_init(&g_app.fe);
    we_init();
    g_app.mode            = MODE_EDIT;
    g_app.cursor_x        = 160.f;
    g_app.cursor_y        = 120.f;
    g_app.top_cursor_x    = 200.f;
    g_app.top_cursor_y    = 130.f;
    g_app.find_match_line = -1;
    g_app.goto_target     = -1;   /* v0.39: no go-to-line target yet */

    /* v0.39: auto-load the last-opened file, if any. If the file is
     * missing (deleted via MODE_DELETE, deleted externally, SD card
     * swapped, etc.), show a "not found" message and clear the stale
     * config entry so subsequent launches start fresh instead of
     * repeatedly trying to load a nonexistent file. Uses a static
     * scratch buffer to keep this off the stack. */
    {
        static char last_fn[FE_FILENAME_MAX];
        if(fe_load_last(last_fn, sizeof(last_fn))){
            if(fe_load_named(&g_editor, last_fn)){
                snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                         "Restored: %s", last_fn);
            } else {
                /* File gone — surface a message and clear stale config. */
                snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                         "File not found: %s — starting fresh", last_fn);
                fe_clear_last();
            }
        }
    }

    /* Seed code_cursor_line from initial cursor position */
    {
        float code_top = LAYOUT_ED_Y + LAYOUT_ED_PAD;
        int   vr       = (int)((g_app.cursor_y - code_top) / LAYOUT_LH_ED);
        if(vr < 0)           vr = 0;
        if(vr >= CODE_AREA_H) vr = CODE_AREA_H - 1;
        g_app.code_cursor_line = vr;
    }

    ui_draw(&g_app, &g_editor, &g_runtime);

    while(aptMainLoop()){
        hidScanInput();
        u32 down = hidKeysDown();

        circlePosition cp;
        hidCircleRead(&cp);
        if(cp.dx > -DEADZONE && cp.dx < DEADZONE) cp.dx = 0;
        if(cp.dy > -DEADZONE && cp.dy < DEADZONE) cp.dy = 0;

        touchPosition touch;
        hidTouchRead(&touch);
        bool touching = (hidKeysHeld() & KEY_TOUCH) != 0;
        bool tap      = (down         & KEY_TOUCH) != 0; /* rising edge */

        bool dirty = false;

        /* v0.39: idle-frame counter for the auto-save draft. Resets on
         * any button press, any touch, or any non-deadzone Circle-Pad
         * movement. do_autosave_if_due() below writes the draft once the
         * counter crosses 600 frames (~10 s @ 60 fps) of true idle.
         *
         * autosave_dirty is also reset on any input so the idle path
         * writes at most once per idle window (see do_autosave_if_due). */
        if(down || touching || cp.dx || cp.dy){
            g_app.idle_frames    = 0;
            g_app.autosave_dirty = false;
        } else {
            g_app.idle_frames++;
        }
        /* Only auto-save on idle when in edit/normal modes (not while a
         * keyboard is open or in run mode — kbd blocks the loop anyway). */
        if(!g_app.run_mode){
            do_autosave_if_due(false);
        }

        if(g_app.click_flash > 0){ g_app.click_flash--; dirty = true; }

        /* ═══════════════════════════════════════════════════════
           RUN MODE  (3DS top screen has no touch — Circle Pad only)
           ═══════════════════════════════════════════════════════ */
        if(g_app.run_mode){

            if(down & KEY_START){
                g_app.run_mode      = false;
                g_app.cursor_locked = false;
                dirty = true;
            }

            if(cp.dx || cp.dy){
                g_app.top_cursor_x += cp.dx * CURSOR_SPEED;
                g_app.top_cursor_y -= cp.dy * CURSOR_SPEED;
                if(g_app.cursor_locked){
                    g_app.top_cursor_x = clampf(g_app.top_cursor_x,
                                                LAYOUT_OUT_X0, LAYOUT_OUT_X1);
                    g_app.top_cursor_y = clampf(g_app.top_cursor_y,
                                                LAYOUT_OUT_Y0, LAYOUT_OUT_Y1);
                } else {
                    g_app.top_cursor_x = clampf(g_app.top_cursor_x, 0.f, 399.f);
                    g_app.top_cursor_y = clampf(g_app.top_cursor_y, 0.f, 239.f);
                }
                dirty = true;
            }

            if(down & KEY_X){ g_app.cursor_locked = false; dirty = true; }
            if(down & KEY_Y){ dirty = true; }

            /* v0.44: DPad scrolls the page. When the web engine is
             * loaded, DPad scrolls the web page via we_page_scroll_by.
             * When it's not (fallback text mode), DPad scrolls the
             * text output. Circle Pad is always cursor-only — it
             * never scrolls. */
            if(g_web_engine.loaded){
                /* Web engine mode: scroll the actual web page */
                int scroll_amount = 30;
                if(down & KEY_UP){
                    we_page_scroll_by(0, -scroll_amount);
                    dirty = true;
                }
                if(down & KEY_DOWN){
                    we_page_scroll_by(0, scroll_amount);
                    dirty = true;
                }
                if(down & KEY_LEFT){
                    we_page_scroll_by(-scroll_amount, 0);
                    dirty = true;
                }
                if(down & KEY_RIGHT){
                    we_page_scroll_by(scroll_amount, 0);
                    dirty = true;
                }
            } else {
                /* Fallback text mode: scroll the text output */
                if(down & KEY_UP){
                    if(g_app.out_scroll > 0) g_app.out_scroll--;
                    dirty = true;
                }
                if(down & KEY_DOWN){
                    int out_max = ui_get_out_count() - 1;
                    if(out_max < 0) out_max = 0;
                    if(g_app.out_scroll < out_max) g_app.out_scroll++;
                    dirty = true;
                }
            }

            if((down & KEY_A) || (down & KEY_L)){
                bool over_out = (g_app.top_cursor_x >= LAYOUT_OUT_X0 &&
                                 g_app.top_cursor_x <= LAYOUT_OUT_X1 &&
                                 g_app.top_cursor_y >= LAYOUT_OUT_Y0 &&
                                 g_app.top_cursor_y <= LAYOUT_OUT_Y1);
                if(over_out && !g_app.cursor_locked){
                    g_app.cursor_locked = true;
                    g_app.top_cursor_x  = clampf(g_app.top_cursor_x,
                                                 LAYOUT_OUT_X0, LAYOUT_OUT_X1);
                    g_app.top_cursor_y  = clampf(g_app.top_cursor_y,
                                                 LAYOUT_OUT_Y0, LAYOUT_OUT_Y1);
                }
                float content_y0 = 26.0f;
                float avg_lh     = 14.0f;
                int   clicked    = (int)((g_app.top_cursor_y - content_y0) / avg_lh);
                clicked += g_app.out_scroll;
                if(clicked < 0) clicked = 0;
                g_app.click_line  = clicked;
                g_app.click_flash = 10;
                dirty = true;
            }
            if((down & KEY_B) || (down & KEY_R)){
                g_app.click_flash = 5;
                dirty = true;
            }

        /* ═══════════════════════════════════════════════════════
           NORMAL (EDIT / SAVE / LOAD / CONTROLS / FIND) MODE
           ═══════════════════════════════════════════════════════ */
        } else {

            /* ── Bottom-screen cursor: touch takes priority ─────
             * While the screen is being touched, snap the cursor to
             * the touch position every frame. When not touching,
             * fall back to relative Circle Pad movement from wherever
             * the cursor was last left. */
            if(touching){
                g_app.cursor_x = clampf((float)touch.px, 0.f, 319.f);
                g_app.cursor_y = clampf((float)touch.py, 0.f, 239.f);
                dirty = true;
            } else if(cp.dx || cp.dy){
                g_app.cursor_x = clampf(g_app.cursor_x + cp.dx * CURSOR_SPEED,
                                        0.f, 319.f);
                g_app.cursor_y = clampf(g_app.cursor_y - cp.dy * CURSOR_SPEED,
                                        0.f, 239.f);
                dirty = true;
            }

            /* Update hovered code row (used by editor A-press / tap) */
            {
                float code_top   = LAYOUT_ED_Y + LAYOUT_ED_PAD;
                float code_bot   = LAYOUT_ED_Y + LAYOUT_ED_H;
                float code_left  = LAYOUT_ED_X;
                float code_right = LAYOUT_ED_X + LAYOUT_ED_W;

                if(g_app.cursor_y >= code_top  && g_app.cursor_y < code_bot &&
                   g_app.cursor_x >= code_left && g_app.cursor_x < code_right){
                    int vr = (int)((g_app.cursor_y - code_top) / LAYOUT_LH_ED);
                    if(vr < 0)            vr = 0;
                    if(vr >= CODE_AREA_H) vr = CODE_AREA_H - 1;
                    if(vr != g_app.code_cursor_line){
                        g_app.code_cursor_line = vr;
                        dirty = true;
                    }
                }
            }

            /* ── EDIT mode ──────────────────────────────────── */
            if(g_app.mode == MODE_EDIT){

                /* Tab-bar tap → switch tabs (the original bug report).
                 * Only active in MODE_EDIT, matching the L button's
                 * existing scope. Guarded so tapping the tab that is
                 * already active is a no-op (avoids an unwanted
                 * scroll-to-bottom reset on a redundant CONSOLE tap). */
                if(tap){
                    bool in_tab_y = (g_app.cursor_y >= LAYOUT_TAB_Y0 &&
                                     g_app.cursor_y <  LAYOUT_TAB_Y1);
                    if(in_tab_y){
                        bool in_editor_tab =
                            g_app.cursor_x >= LAYOUT_MAR &&
                            g_app.cursor_x <  LAYOUT_MAR + LAYOUT_TAB_W;
                        bool in_console_tab =
                            g_app.cursor_x >= LAYOUT_TAB_GAP_X &&
                            g_app.cursor_x <  LAYOUT_TAB_GAP_X + LAYOUT_TAB_W;
                        if(in_editor_tab && g_app.console_tab){
                            do_switch_to_editor_tab();
                            dirty = true;
                        } else if(in_console_tab && !g_app.console_tab){
                            do_switch_to_console_tab();
                            dirty = true;
                        }
                    }
                }

                /* ── CONSOLE TAB ───────────────────────────── */
                if(g_app.console_tab){

                    if(down & KEY_UP){
                        if(g_app.console_scroll > 0) g_app.console_scroll--;
                        dirty = true;
                    }
                    if(down & KEY_DOWN){
                        int max_s = g_wjs_log_n - PANEL_VISIBLE_ROWS;
                        if(max_s < 0) max_s = 0;
                        if(g_app.console_scroll < max_s) g_app.console_scroll++;
                        dirty = true;
                    }
                    if(down & KEY_A){
                        char js_in[ED_LINE_MAX];
                        js_in[0] = '\0';
                        if(kbd("","Enter JS expression",js_in,sizeof(js_in))
                           && js_in[0]){
                            char echo[ED_LINE_MAX + 2];
                            snprintf(echo, sizeof(echo), "> %s", js_in);
                            wjs_log_push(echo);
                            we_eval_js(js_in);
                            int max_s = g_wjs_log_n - PANEL_VISIBLE_ROWS;
                            if(max_s < 0) max_s = 0;
                            g_app.console_scroll = max_s;
                        }
                        dirty = true;
                    }
                    if(down & KEY_B){
                        wjs_log_clear();
                        g_app.console_scroll = 0;
                        dirty = true;
                    }
                    if(down & KEY_L){
                        do_switch_to_editor_tab();
                        dirty = true;
                    }

                /* ── EDITOR TAB ─────────────────────────────── */
                } else {

                    if(down & KEY_UP){
                        if(g_editor.scroll_offset > 0) g_editor.scroll_offset--;
                        dirty = true;
                    }
                    if(down & KEY_DOWN){
                        int total = editor_line_count(&g_editor);
                        int max_s = total - CODE_AREA_H;
                        if(max_s < 0) max_s = 0;
                        if(g_editor.scroll_offset < max_s) g_editor.scroll_offset++;
                        dirty = true;
                    }
                    if(down & KEY_LEFT){
                        if(g_app.view_left > 0) g_app.view_left--;
                        dirty = true;
                    }
                    if(down & KEY_RIGHT){
                        if(g_app.view_left < ED_LINE_MAX - CODE_AREA_W)
                            g_app.view_left++;
                        dirty = true;
                    }

                    /* A button, or a tap landing on a code line, both
                     * edit the hovered line via the same helper. */
                    bool tap_in_code =
                        tap &&
                        g_app.cursor_x >= LAYOUT_ED_X &&
                        g_app.cursor_x <  LAYOUT_ED_X + LAYOUT_ED_W &&
                        g_app.cursor_y >= LAYOUT_ED_Y + LAYOUT_ED_PAD &&
                        g_app.cursor_y <  LAYOUT_ED_Y + LAYOUT_ED_H;

                    if((down & KEY_A) || tap_in_code){
                        do_edit_line_action();
                        dirty = true;
                    }

                    /* B → undo */
                    if(down & KEY_B){ editor_undo(&g_editor); dirty = true; }

                    /* L → toggle JS console tab (tab-bar tap handled above) */
                    if(down & KEY_L){
                        do_switch_to_console_tab();
                        dirty = true;
                    }

                    /* v0.39: R now opens the Actions menu (was: direct
                     * MODE_FIND entry). Find/Replace is row 0 of that
                     * menu, so nothing is lost — just one extra tap when
                     * the user specifically wants find. This frees up R
                     * as the gateway to all secondary editor operations,
                     * which was necessary because every face/shoulder
                     * button in the editor tab was already taken. */
                    if(down & KEY_R){
                        g_app.mode          = MODE_ACTIONS;
                        g_app.actions_scroll= 0;
                        dirty = true;
                    }
                }

                /* ── Shared controls (work in both tabs) ─────── */
                if(down & KEY_X){
                    fe_scan(&g_app.fe);
                    g_app.fe.cursor = 0; g_app.fe.scroll = 0;
                    g_app.mode = MODE_SAVE; dirty = true;
                }
                if(down & KEY_Y){
                    fe_scan(&g_app.fe);
                    g_app.fe.cursor = 0; g_app.fe.scroll = 0;
                    g_app.mode = MODE_LOAD; dirty = true;
                }
                if(down & KEY_START){
                    wjs_log_clear();
                    g_app.console_scroll = 0;
                    runtime_scan_html(&g_runtime, g_editor.buf);
                    ui_set_compiled(g_editor.buf);
                    we_load_html(g_editor.buf);
                    /* v0.39: snapshot draft on every compile, so a crash
                     * or power loss never costs more than one editing
                     * session since the last compile. */
                    do_autosave_if_due(true);
                    g_app.run_mode      = true;
                    g_app.cursor_locked = false;
                    g_app.out_scroll    = 0;
                    g_app.click_flash   = 0;
                    g_app.top_cursor_x  = 200.f;
                    g_app.top_cursor_y  = 130.f;
                    dirty = true;
                }
                if(down & KEY_SELECT){
                    g_app.mode            = MODE_CONTROLS;
                    g_app.controls_scroll = 0;
                    dirty = true;
                }

            /* ── SAVE ─────────────────────────────────────────── */
            } else if(g_app.mode == MODE_SAVE){
                int total = g_app.fe.count + 1;
                if(down & KEY_UP)  { fe_move_up(&g_app.fe);         dirty = true; }
                if(down & KEY_DOWN){ fe_move_down(&g_app.fe, total); dirty = true; }

                /* Tap a row → select it and open the save dialog,
                 * exactly as if A/X had been pressed on that row. */
                bool tap_in_fe =
                    tap &&
                    g_app.cursor_x >= LAYOUT_FE_X &&
                    g_app.cursor_x <  LAYOUT_FE_X + LAYOUT_FE_W &&
                    g_app.cursor_y >= LAYOUT_FE_Y &&
                    g_app.cursor_y <  LAYOUT_FE_Y + LAYOUT_FE_H;
                if(tap_in_fe){
                    int row = g_app.fe.scroll +
                        (int)((g_app.cursor_y - (LAYOUT_FE_Y + LAYOUT_FE_PAD))
                              / LAYOUT_LH_FE);
                    if(row >= 0 && row < total){
                        g_app.fe.cursor = row;
                        do_save_dialog_action();
                    }
                    dirty = true;
                }

                if((down & KEY_A) || (down & KEY_X)){
                    do_save_dialog_action();
                    dirty = true;
                }
                if(down & KEY_B){ g_app.mode = MODE_EDIT; dirty = true; }

            /* ── LOAD ─────────────────────────────────────────── */
            } else if(g_app.mode == MODE_LOAD){
                if(down & KEY_UP)  { fe_move_up(&g_app.fe);                  dirty = true; }
                if(down & KEY_DOWN){ fe_move_down(&g_app.fe, g_app.fe.count); dirty = true; }

                bool tap_in_fe =
                    tap &&
                    g_app.cursor_x >= LAYOUT_FE_X &&
                    g_app.cursor_x <  LAYOUT_FE_X + LAYOUT_FE_W &&
                    g_app.cursor_y >= LAYOUT_FE_Y &&
                    g_app.cursor_y <  LAYOUT_FE_Y + LAYOUT_FE_H;
                if(tap_in_fe){
                    int row = g_app.fe.scroll +
                        (int)((g_app.cursor_y - (LAYOUT_FE_Y + LAYOUT_FE_PAD))
                              / LAYOUT_LH_FE);
                    if(row >= 0 && row < g_app.fe.count){
                        g_app.fe.cursor = row;
                        do_load_file_action();
                    }
                    dirty = true;
                }

                if((down & KEY_A) || (down & KEY_Y)){
                    do_load_file_action();
                    dirty = true;
                }
                if(down & KEY_B){ g_app.mode = MODE_EDIT; dirty = true; }

            /* ── CONTROLS ─────────────────────────────────────── */
            } else if(g_app.mode == MODE_CONTROLS){
                /* v0.37 bug fix: this screen previously had no scroll
                 * state at all, so its 12+ rows silently overflowed
                 * the panel and several were drawn underneath the
                 * hint bar with no way to reach them. */
                int row_count = ui_get_controls_row_count();
                int max_scroll = row_count - PANEL_VISIBLE_ROWS;
                if(max_scroll < 0) max_scroll = 0;

                if(down & KEY_UP){
                    if(g_app.controls_scroll > 0) g_app.controls_scroll--;
                    dirty = true;
                }
                if(down & KEY_DOWN){
                    if(g_app.controls_scroll < max_scroll) g_app.controls_scroll++;
                    dirty = true;
                }
                if((down & KEY_SELECT) || (down & KEY_B)){
                    g_app.mode = MODE_EDIT; dirty = true;
                }

            /* ── FIND / REPLACE ───────────────────────────────── */
            } else if(g_app.mode == MODE_FIND){

                if(down & KEY_A){
                    char nt[ED_LINE_MAX];
                    if(kbd(g_app.find_buf, "Search for", nt, sizeof(nt))){
                        strncpy(g_app.find_buf, nt, sizeof(g_app.find_buf) - 1);
                        g_app.find_buf[sizeof(g_app.find_buf) - 1] = '\0';
                        int sl = g_editor.cursor_line;
                        int sc = g_app.find_has_match ? g_app.find_match_col : -1;
                        if(g_app.find_buf[0]){
                            g_app.find_has_match = editor_find(
                                &g_editor, g_app.find_buf, sl, sc,
                                &g_app.find_match_line, &g_app.find_match_col);
                            if(g_app.find_has_match)
                                editor_scroll_to_line(g_app.find_match_line);
                            else
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Not found: %s", g_app.find_buf);
                        }
                    }
                    dirty = true;
                }

                if((down & KEY_DOWN) && g_app.find_buf[0]){
                    int sl = g_app.find_has_match ? g_app.find_match_line
                                                  : g_editor.cursor_line;
                    int sc = g_app.find_has_match ? g_app.find_match_col : -1;
                    g_app.find_has_match = editor_find(
                        &g_editor, g_app.find_buf, sl, sc,
                        &g_app.find_match_line, &g_app.find_match_col);
                    if(g_app.find_has_match)
                        editor_scroll_to_line(g_app.find_match_line);
                    else
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg),
                                 "No more matches.");
                    dirty = true;
                }

                if((down & KEY_UP) && g_app.find_buf[0]){
                    int sl = g_app.find_has_match ? g_app.find_match_line
                                                  : g_editor.cursor_line;
                    int sc = g_app.find_has_match ? g_app.find_match_col : 0;
                    g_app.find_has_match = editor_find_prev(
                        &g_editor, g_app.find_buf, sl, sc,
                        &g_app.find_match_line, &g_app.find_match_col);
                    if(g_app.find_has_match)
                        editor_scroll_to_line(g_app.find_match_line);
                    else
                        snprintf(g_runtime.status_msg,
                                 sizeof(g_runtime.status_msg),
                                 "No more matches.");
                    dirty = true;
                }

                if(down & KEY_Y){
                    char nt[ED_LINE_MAX];
                    if(kbd(g_app.replace_buf, "Replace with", nt, sizeof(nt))){
                        strncpy(g_app.replace_buf, nt,
                                sizeof(g_app.replace_buf) - 1);
                        g_app.replace_buf[sizeof(g_app.replace_buf) - 1] = '\0';
                        if(g_app.find_has_match && g_app.find_buf[0]){
                            editor_snapshot(&g_editor);
                            int nlen = (int)strlen(g_app.find_buf);
                            bool ok = editor_replace_at(
                                &g_editor,
                                g_app.find_match_line,
                                g_app.find_match_col,
                                nlen,
                                g_app.replace_buf);
                            if(ok){
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Replaced at ln %d",
                                         g_app.find_match_line + 1);
                                int next_col = g_app.find_match_col
                                    + (int)strlen(g_app.replace_buf);
                                g_app.find_has_match = editor_find(
                                    &g_editor, g_app.find_buf,
                                    g_app.find_match_line, next_col - 1,
                                    &g_app.find_match_line,
                                    &g_app.find_match_col);
                                if(g_app.find_has_match)
                                    editor_scroll_to_line(g_app.find_match_line);
                            }
                        }
                    }
                    dirty = true;
                }

                if((down & KEY_X) && g_app.find_buf[0]){
                    editor_snapshot(&g_editor);
                    int count = 0;
                    int fl, fc;
                    int nlen = (int)strlen(g_app.find_buf);
                    bool found = editor_find(&g_editor, g_app.find_buf,
                                             0, -1, &fl, &fc);
                    while(found && count < 2000){
                        if(!editor_replace_at(&g_editor, fl, fc, nlen,
                                              g_app.replace_buf)) break;
                        count++;
                        int next_c = fc + (int)strlen(g_app.replace_buf);
                        found = editor_find(&g_editor, g_app.find_buf,
                                            fl, next_c - 1, &fl, &fc);
                    }
                    snprintf(g_runtime.status_msg,
                             sizeof(g_runtime.status_msg),
                             "Replaced %d occurrence%s",
                             count, count == 1 ? "" : "s");
                    g_app.find_has_match  = false;
                    g_app.find_match_line = -1;
                    {
                        int sc_max = editor_line_count(&g_editor) - CODE_AREA_H;
                        if(sc_max < 0) sc_max = 0;
                        if(g_editor.scroll_offset > sc_max)
                            g_editor.scroll_offset = sc_max;
                    }
                    dirty = true;
                }

                if(down & KEY_B){
                    g_app.mode           = MODE_EDIT;
                    g_app.find_has_match = false;
                    dirty = true;
                }

            /* ── ACTIONS MENU (v0.39, entered via R) ─────────── */
            } else if(g_app.mode == MODE_ACTIONS){
                int row_count = ui_get_actions_row_count();
                /* v0.39 fix: actions_scroll doubles as the selection
                 * cursor (draw_actions reads it that way). When the row
                 * count fits inside PANEL_VISIBLE_ROWS (the common case
                 * here — 7 rows < 10 visible), the OLD formula
                 * "row_count - PANEL_VISIBLE_ROWS" clamped to 0 and the
                 * DOWN button became a no-op, leaving the cursor stuck
                 * on row 0 (Find/Replace). The cursor needs to be able
                 * to reach every row index 0..row_count-1, so the max
                 * is row_count - 1 (clamped to 0 for the empty case). */
                int max_cursor = row_count - 1;
                if(max_cursor < 0) max_cursor = 0;

                if(down & KEY_UP){
                    if(g_app.actions_scroll > 0) g_app.actions_scroll--;
                    dirty = true;
                }
                if(down & KEY_DOWN){
                    if(g_app.actions_scroll < max_cursor) g_app.actions_scroll++;
                    dirty = true;
                }
                if(down & KEY_A){
                    bool leaves = do_action_run(g_app.actions_scroll);
                    (void)leaves; /* do_action_run sets g_app.mode itself */
                    dirty = true;
                }
                if(down & KEY_B){
                    g_app.mode = MODE_EDIT; dirty = true;
                }

            /* ── GO-TO-LINE (v0.39) ───────────────────────────── */
            } else if(g_app.mode == MODE_GOTO){
                if(down & KEY_A){
                    char nt[24];
                    if(kbd(g_app.goto_buf, "Line number", nt, sizeof(nt))){
                        strncpy(g_app.goto_buf, nt, sizeof(g_app.goto_buf) - 1);
                        g_app.goto_buf[sizeof(g_app.goto_buf) - 1] = '\0';
                    }
                    dirty = true;
                }
                if((down & KEY_START) || (down & KEY_Y)){
                    int n = atoi(g_app.goto_buf);
                    if(n >= 1){
                        int total = editor_line_count(&g_editor);
                        if(n > total) n = total;
                        editor_scroll_to_line(n - 1);   /* 1-based → 0-based */
                        snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                                 "Jumped to line %d", n);
                        g_app.mode = MODE_EDIT;
                    } else {
                        snprintf(g_runtime.status_msg, sizeof(g_runtime.status_msg),
                                 "Invalid line number");
                    }
                    dirty = true;
                }
                if(down & KEY_B){
                    g_app.mode = MODE_EDIT; dirty = true;
                }

            /* ── DELETE FILE (v0.39, two-step confirm) ────────── */
            } else if(g_app.mode == MODE_DELETE){
                if(down & KEY_UP){ fe_move_up(&g_app.fe);                  dirty = true; }
                if(down & KEY_DOWN){ fe_move_down(&g_app.fe, g_app.fe.count); dirty = true; }

                /* Tap a row → select it (does NOT delete; A or the
                 * confirm step does). Same hit-test as MODE_LOAD. */
                bool tap_in_fe =
                    tap &&
                    g_app.cursor_x >= LAYOUT_FE_X &&
                    g_app.cursor_x <  LAYOUT_FE_X + LAYOUT_FE_W &&
                    g_app.cursor_y >= LAYOUT_FE_Y &&
                    g_app.cursor_y <  LAYOUT_FE_Y + LAYOUT_FE_H;
                if(tap_in_fe){
                    int row = g_app.fe.scroll +
                        (int)((g_app.cursor_y - (LAYOUT_FE_Y + LAYOUT_FE_PAD))
                              / LAYOUT_LH_FE);
                    if(row >= 0 && row < g_app.fe.count){
                        g_app.fe.cursor = row;
                        g_app.delete_confirm = false; /* tap selects, A arms */
                    }
                    dirty = true;
                }

                if(g_app.fe.count > 0 &&
                   g_app.fe.cursor >= 0 && g_app.fe.cursor < g_app.fe.count){
                    if((down & KEY_A) || (down & KEY_X)){
                        if(!g_app.delete_confirm){
                            /* First press: arm. Show red CONFIRM hint. */
                            g_app.delete_confirm = true;
                        } else {
                            /* Second press: actually delete. */
                            const char *fn = g_app.fe.names[g_app.fe.cursor];
                            if(fe_delete_named(fn)){
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Deleted: %s", fn);
                                /* v0.39 audit fix: if the deleted file
                                 * was the last-opened one, clear config.txt
                                 * so the next launch doesn't try to load a
                                 * nonexistent file. Without this, every
                                 * subsequent launch would silently fail the
                                 * fe_load_named call and show the default
                                 * template with no explanation. */
                                {
                                    static char cur_last[FE_FILENAME_MAX];
                                    if(fe_load_last(cur_last, sizeof(cur_last))
                                       && strcmp(cur_last, fn) == 0){
                                        fe_clear_last();
                                    }
                                }
                                fe_scan(&g_app.fe);
                                g_app.fe.cursor = 0; g_app.fe.scroll = 0;
                                g_app.delete_confirm = false;
                                g_app.mode = MODE_EDIT;
                            } else {
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Delete FAILED: %s", fn);
                                g_app.delete_confirm = false;
                            }
                        }
                        dirty = true;
                    }
                }
                if(down & KEY_B){
                    if(g_app.delete_confirm){
                        g_app.delete_confirm = false;   /* cancel armed */
                    } else {
                        g_app.mode = MODE_EDIT;         /* exit screen   */
                    }
                    dirty = true;
                }

            /* ── RENAME FILE (v0.39, single-step via keyboard) ── */
            } else if(g_app.mode == MODE_RENAME){
                if(down & KEY_UP){ fe_move_up(&g_app.fe);                  dirty = true; }
                if(down & KEY_DOWN){ fe_move_down(&g_app.fe, g_app.fe.count); dirty = true; }

                /* Tap a row → select it (does NOT rename; A does).
                 * Same hit-test geometry as MODE_LOAD / MODE_DELETE. */
                bool tap_in_fe =
                    tap &&
                    g_app.cursor_x >= LAYOUT_FE_X &&
                    g_app.cursor_x <  LAYOUT_FE_X + LAYOUT_FE_W &&
                    g_app.cursor_y >= LAYOUT_FE_Y &&
                    g_app.cursor_y <  LAYOUT_FE_Y + LAYOUT_FE_H;
                if(tap_in_fe){
                    int row = g_app.fe.scroll +
                        (int)((g_app.cursor_y - (LAYOUT_FE_Y + LAYOUT_FE_PAD))
                              / LAYOUT_LH_FE);
                    if(row >= 0 && row < g_app.fe.count){
                        g_app.fe.cursor = row;
                    }
                    dirty = true;
                }

                if(g_app.fe.count > 0 &&
                   g_app.fe.cursor >= 0 && g_app.fe.cursor < g_app.fe.count){
                    if((down & KEY_A) || (down & KEY_X)){
                        const char *old = g_app.fe.names[g_app.fe.cursor];
                        char nn[FE_FILENAME_MAX];
                        /* Pre-fill with the current name (sans extension
                         * is friendlier, but matching save's behavior of
                         * showing the full name keeps the codebase
                         * consistent — the user can edit it freely). */
                        strncpy(nn, old, FE_FILENAME_MAX - 1);
                        nn[FE_FILENAME_MAX - 1] = '\0';
                        if(kbd(nn, "New filename (.html)", nn, sizeof(nn))
                           && strlen(nn) > 0){
                            ensure_html_ext(nn, sizeof(nn));
                            if(fe_rename_named(old, nn)){
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Renamed: %s → %s", old, nn);
                                /* v0.39 audit fix: only update config.txt
                                 * if the renamed file WAS the last-opened
                                 * one. The previous code called
                                 * fe_save_last(nn) unconditionally, which
                                 * would overwrite config.txt with a file
                                 * the user never opened if they renamed
                                 * an unrelated file. Now reads the current
                                 * config and compares against `old`. */
                                {
                                    static char cur_last[FE_FILENAME_MAX];
                                    if(fe_load_last(cur_last, sizeof(cur_last))
                                       && strcmp(cur_last, old) == 0){
                                        fe_save_last(nn);
                                    }
                                }
                                fe_scan(&g_app.fe);
                                g_app.fe.cursor = 0; g_app.fe.scroll = 0;
                                g_app.mode = MODE_EDIT;
                            } else {
                                snprintf(g_runtime.status_msg,
                                         sizeof(g_runtime.status_msg),
                                         "Rename FAILED: %s", nn);
                            }
                        }
                        dirty = true;
                    }
                }
                if(down & KEY_B){
                    g_app.mode = MODE_EDIT; dirty = true;
                }

            /* ── PREVIEW ──────────────────────────────────────── */
            } else if(g_app.mode == MODE_PREVIEW){
                if((down & KEY_B) || (down & KEY_START)){
                    g_app.mode = MODE_EDIT; dirty = true;
                }
            }
        } /* end normal mode */

        /* Drive the web engine each frame in run mode */
        if(g_app.run_mode && g_web_engine.loaded){
            WEInputState we_inp = {0};
            we_inp.held         = (uint32_t)hidKeysHeld();
            we_inp.down         = (uint32_t)down;
            we_inp.up           = (uint32_t)hidKeysUp();
            we_inp.cursor_x     = g_app.top_cursor_x;
            we_inp.cursor_y     = g_app.top_cursor_y;
            we_inp.prev_x       = g_app.top_cursor_x;
            we_inp.prev_y       = g_app.top_cursor_y;
            we_inp.cursor_locked= g_app.cursor_locked;
            we_update(&we_inp,
                      g_app.top_cursor_x, g_app.top_cursor_y,
                      g_app.cursor_locked, 16.67);
            dirty = true;
        }

        if(dirty) ui_draw(&g_app, &g_editor, &g_runtime);
    }

    we_exit();
    ui_exit();
    return 0;
}
