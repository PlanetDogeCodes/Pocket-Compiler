/*
 * web_fetch.c  —  Fetch / XHR API for Pocket Compiler v0.36
 *
 * v0.36 bugfixes:
 *  - js_xhr_send: copy the __url string to a local static buffer BEFORE
 *    calling duk_pop().  The previous code kept a duk_safe_to_string()
 *    pointer while the owning value was off the stack — technically a
 *    dangling pointer that could become invalid on the next GC cycle.
 *  - wf_install_xhr: bind setRequestHeader() stub so JS that calls it
 *    does not throw "not a function".
 *
 * v0.35 improvements (retained):
 *  - response.text() / response.json() return proper thenables.
 *  - fetch() .then() properly forwards the inner thenable so chains like
 *      fetch(u).then(r=>r.json()).then(data=>...)  work correctly.
 *  - fetch(url, options) accepted; options.method is logged (informational).
 *  - One-time advisory pushed to JS console when https:// is first used.
 *
 * Note on HTTPS: the 3DS has no network stack in this build.  All
 * http:// and https:// URLs resolve against the SD card under WF_SD_ROOT.
 */
#include "web_fetch.h"
#include "duktape.h"
#include "web_js.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

WFRequest g_wf_requests[WF_MAX_REQUESTS];

static bool s_https_noted = false;   /* log advisory only once */

/* ── URL resolution ──────────────────────────────────────────────── */

bool wf_resolve_url(const char *url, const char *base, char *out, int sz) {
    if (!url || !out || sz <= 0) return false;

    if (strncmp(url, "sdmc:/", 6) == 0) {
        strncpy(out, url, sz - 1); out[sz - 1] = '\0'; return true;
    }
    if (strncmp(url, "file://", 7) == 0) {
        strncpy(out, url + 7, sz - 1); out[sz - 1] = '\0'; return true;
    }
    if (strncmp(url, "3ds://", 6) == 0) {
        snprintf(out, sz, "%s/%s", WF_SD_ROOT, url + 6); return true;
    }

    int scheme_len = 0;
    if (strncmp(url, "https://", 8) == 0) {
        scheme_len = 8;
        if (!s_https_noted) {
            s_https_noted = true;
            wjs_log_push("[Fetch] Note: https:// URLs are served from the SD"
                         " card (" WF_SD_ROOT "). Place files there to"
                         " simulate a server.");
        }
    } else if (strncmp(url, "http://", 7) == 0) {
        scheme_len = 7;
    }

    if (scheme_len > 0) {
        const char *start = strchr(url + scheme_len, '/');
        char host[128]; int hl;
        if (start) {
            hl = (int)(start - (url + scheme_len));
            if (hl >= 128) hl = 127;
            memcpy(host, url + scheme_len, hl); host[hl] = '\0';
            snprintf(out, sz, "%s/%s%s", WF_SD_ROOT, host, start);
        } else {
            strncpy(host, url + scheme_len, 127); host[127] = '\0';
            snprintf(out, sz, "%s/%s/index.html", WF_SD_ROOT, host);
        }
        return true;
    }

    if (url[0] == '/') {
        snprintf(out, sz, "%s%s", WF_SD_ROOT, url); return true;
    }

    if (base && *base) {
        const char *last = strrchr(base, '/');
        if (last) {
            int blen = (int)(last - base + 1);
            int ulen = (int)strlen(url);
            if (blen + ulen >= sz) blen = sz - ulen - 1;
            if (blen < 0) blen = 0;
            memcpy(out, base, blen); out[blen] = '\0';
            strncat(out, url, sz - blen - 1);
        } else {
            snprintf(out, sz, "%s/%s", WF_SD_ROOT, url);
        }
    } else {
        snprintf(out, sz, "%s/%s", WF_SD_ROOT, url);
    }
    return true;
}

bool wf_can_serve(const char *url) {
    char path[WF_MAX_URL];
    if (!wf_resolve_url(url, NULL, path, sizeof(path))) return false;
    FILE *f = fopen(path, "r");
    if (!f) return false;
    fclose(f); return true;
}

const char *wf_sniff_type(const char *path) {
    if (!path) return "application/octet-stream";
    const char *ext = strrchr(path, '.');
    if (!ext) return "application/octet-stream";
    if (strcmp(ext, ".html") == 0 || strcmp(ext, ".htm") == 0) return "text/html";
    if (strcmp(ext, ".css")  == 0) return "text/css";
    if (strcmp(ext, ".js")   == 0) return "application/javascript";
    if (strcmp(ext, ".json") == 0) return "application/json";
    if (strcmp(ext, ".txt")  == 0) return "text/plain";
    if (strcmp(ext, ".png")  == 0) return "image/png";
    if (strcmp(ext, ".jpg")  == 0 || strcmp(ext, ".jpeg") == 0) return "image/jpeg";
    if (strcmp(ext, ".gif")  == 0) return "image/gif";
    if (strcmp(ext, ".wav")  == 0) return "audio/wav";
    if (strcmp(ext, ".mp3")  == 0) return "audio/mpeg";
    if (strcmp(ext, ".xml")  == 0) return "text/xml";
    if (strcmp(ext, ".svg")  == 0) return "image/svg+xml";
    return "application/octet-stream";
}

bool wf_fetch_sync(const char *url, WFResponse *out) {
    if (!url || !out) return false;
    memset(out, 0, sizeof(*out));

    char path[WF_MAX_URL];
    if (!wf_resolve_url(url, NULL, path, sizeof(path))) {
        out->status = 400; return false;
    }
    FILE *f = fopen(path, "rb");
    if (!f) { out->status = 404; out->ok = false; return false; }

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0) { fclose(f); out->status = 204; out->ok = true; return true; }
    /* v0.38 final audit: cap at WF_MAX_BODY-1 to leave room for the
     * NUL terminator written below. The old code used WF_MAX_BODY,
     * so a response exactly 64KB would write body[65536] = '\0' —
     * one byte past the end of body[65536]. A one-byte heap overflow. */
    if (sz >= WF_MAX_BODY) sz = WF_MAX_BODY - 1;

    out->body_len = (int)fread(out->body, 1, (size_t)sz, f);
    fclose(f);
    out->body[out->body_len] = '\0';
    out->status = 200;
    out->ok = true;
    strncpy(out->content_type, wf_sniff_type(path), 63);
    out->content_type[63] = '\0';
    return true;
}

int wf_fetch_async(uint8_t doc_id, const char *url,
                   int resolve_ref, int reject_ref) {
    for (int i = 0; i < WF_MAX_REQUESTS; i++) {
        if (!g_wf_requests[i].used) {
            strncpy(g_wf_requests[i].url, url, WF_MAX_URL - 1);
            g_wf_requests[i].url[WF_MAX_URL - 1] = '\0';
            g_wf_requests[i].doc_id          = doc_id;
            g_wf_requests[i].js_resolve_ref  = resolve_ref;
            g_wf_requests[i].js_reject_ref   = reject_ref;
            g_wf_requests[i].used            = true;
            g_wf_requests[i].done            = false;
            return i;
        }
    }
    return -1;
}

void wf_tick(duk_context *ctx) {
    for (int i = 0; i < WF_MAX_REQUESTS; i++) {
        if (!g_wf_requests[i].used || g_wf_requests[i].done) continue;

        bool ok = wf_fetch_sync(g_wf_requests[i].url, &g_wf_requests[i].resp);
        g_wf_requests[i].done = true;

        duk_push_heap_stash(ctx);                      /* [stash] */

        if (ok && g_wf_requests[i].resp.ok) {
            char key[32];
            snprintf(key, sizeof(key), "fetch_r%d",
                     g_wf_requests[i].js_resolve_ref);
            duk_get_prop_string(ctx, -1, key);         /* [stash, fn] */
            if (duk_is_function(ctx, -1)) {
                duk_push_object(ctx);
                duk_push_boolean(ctx, 1);
                duk_put_prop_string(ctx, -2, "ok");
                duk_push_int(ctx, 200);
                duk_put_prop_string(ctx, -2, "status");
                duk_push_lstring(ctx,
                    (const char *)g_wf_requests[i].resp.body,
                    (duk_size_t)g_wf_requests[i].resp.body_len);
                duk_put_prop_string(ctx, -2, "__body");
                if (duk_pcall(ctx, 1) != 0)
                    wjs_log_push(duk_safe_to_string(ctx, -1));
                duk_pop(ctx);
            } else {
                duk_pop(ctx);
            }
        } else {
            char key[32];
            snprintf(key, sizeof(key), "fetch_j%d",
                     g_wf_requests[i].js_reject_ref);
            duk_get_prop_string(ctx, -1, key);         /* [stash, fn] */
            if (duk_is_function(ctx, -1)) {
                char errmsg[64];
                snprintf(errmsg, sizeof(errmsg), "HTTP %d",
                         g_wf_requests[i].resp.status);
                duk_push_string(ctx, errmsg);
                if (duk_pcall(ctx, 1) != 0)
                    wjs_log_push(duk_safe_to_string(ctx, -1));
                duk_pop(ctx);
            } else {
                duk_pop(ctx);
            }
        }

        duk_pop(ctx);          /* pop stash */
        g_wf_requests[i].used = false;
    }
}

/* ── Duktape fetch() binding ─────────────────────────────────────── */
/*
 * fetch(url [, options]) → thenable
 *
 * Supports proper chaining:
 *   fetch(url)
 *     .then(res => res.json())   ← res.json() is itself a thenable
 *     .then(data => ...)         ← data is the parsed JSON
 *
 * Response:  .ok .status .text() .json()
 */
static duk_ret_t js_fetch(duk_context *ctx) {
    const char *url = duk_safe_to_string(ctx, 0);

    /* Log options.method if provided */
    if (duk_is_object(ctx, 1)) {
        duk_get_prop_string(ctx, 1, "method");
        if (duk_is_string(ctx, -1)) {
            char mb[80];
            snprintf(mb, sizeof(mb),
                     "[Fetch] method=%s (SD-backed; option noted but unused)",
                     duk_get_string(ctx, -1));
            wjs_log_push(mb);
        }
        duk_pop(ctx);
    }

    static WFResponse resp;
    memset(&resp, 0, sizeof(resp));
    bool ok = wf_fetch_sync(url, &resp);

    /* Build response + outer thenable in JS (single eval keeps stack clean).
     * v0.48: use duk_peval_string so OOM doesn't trigger fatal handler. */
    if(duk_peval_string(ctx,
        "(function(ok,status,body){"
        "  var resp={"
        "    ok:ok,status:status,__body:body,"
        "    text:function(){"
        "      var b=this.__body;"
        "      return{then:function(fn){if(fn)fn(b);return this;},"
        "             'catch':function(fn){return this;}};"
        "    },"
        "    json:function(){"
        "      var b=this.__body,r,_ok=true;"
        "      try{r=JSON.parse(b);}catch(e){r=e;_ok=false;}"
        "      return{"
        "        then:function(fn){if(_ok&&fn)fn(r);return this;},"
        "        'catch':function(fn){if(!_ok&&fn)fn(r);return this;}"
        "      };"
        "    }"
        "  };"
        "  return{"
        "    __r:resp,__ok:ok,"
        "    then:function(fn,rej){"
        "      if(!this.__ok){"
        "        if(rej)rej(new Error('HTTP '+status));"
        "        return this;"
        "      }"
        "      var r=fn?fn(this.__r):undefined;"
        "      if(r&&typeof r.then==='function')return r;"
        "      var v=r;"
        "      return{then:function(f){if(f)f(v);return this;},"
        "             'catch':function(f){return this;}};"
        "    },"
        "    'catch':function(fn){"
        "      if(!this.__ok&&fn)fn(new Error('HTTP '+status));"
        "      return this;"
        "    }"
        "  };"
        "})"
    )!=0){
        /* v0.48: eval failed (OOM) — push a rejected thenable as fallback.
         * Use duk_peval_string here too — if even this fails, push null. */
        duk_pop(ctx); /* pop error */
        if(duk_peval_string(ctx,
            "({then:function(f,r){if(r)r(new Error('fetch eval failed'));return this;},"
            " 'catch':function(f){if(f)f(new Error('fetch eval failed'));return this;}})"
        )!=0){
            duk_pop(ctx);
            duk_push_null(ctx);
        }
        return 1;
    }
    /* Stack: [...args..., factory_fn] */
    duk_push_boolean(ctx, ok && resp.ok);
    duk_push_int(ctx, resp.status);
    duk_push_lstring(ctx, (const char *)resp.body,
                     (duk_size_t)resp.body_len);

    if (duk_pcall(ctx, 3) != 0) {
        wjs_log_push(duk_safe_to_string(ctx, -1));
        duk_pop(ctx);
        /* Fallback: empty rejected thenable */
        duk_peval_string(ctx,
            "({then:function(f,r){"
            "  if(r)r(new Error('fetch error'));return this;},"
            " 'catch':function(f){"
            "  if(f)f(new Error('fetch error'));return this;}})");
    }
    return 1;
}

/* ── XMLHttpRequest bindings ─────────────────────────────────────── */

static duk_ret_t js_xhr_open(duk_context *ctx) {
    /* open(method, url [, async]) — store method and url on 'this' */
    duk_push_this(ctx);
    if (duk_is_string(ctx, 0)) {
        duk_dup(ctx, 0);
        duk_put_prop_string(ctx, -2, "__method");
    }
    if (duk_is_string(ctx, 1)) {
        duk_dup(ctx, 1);
        duk_put_prop_string(ctx, -2, "__url");
    }
    duk_pop(ctx);
    return 0;
}

static duk_ret_t js_xhr_send(duk_context *ctx) {
    /* BUG FIX (v0.36): copy the URL string to a static local buffer
     * BEFORE calling duk_pop().  duk_safe_to_string returns a pointer
     * into Duktape's internal heap; popping the value removes the stack
     * reference so the string could theoretically be GC'd.  Copying
     * first is always safe. */
    duk_push_this(ctx);                                 /* [this] */
    duk_get_prop_string(ctx, -1, "__url");              /* [this, url_str] */
    {
        const char *raw = duk_safe_to_string(ctx, -1);
        static char url_buf[WF_MAX_URL];
        strncpy(url_buf, raw ? raw : "", WF_MAX_URL - 1);
        url_buf[WF_MAX_URL - 1] = '\0';
        duk_pop(ctx);                                   /* [this] */

        static WFResponse resp;
        memset(&resp, 0, sizeof(resp));
        wf_fetch_sync(url_buf, &resp);

        duk_push_int(ctx, resp.status);
        duk_put_prop_string(ctx, -2, "status");
        duk_push_lstring(ctx, (const char *)resp.body,
                         (duk_size_t)resp.body_len);
        duk_put_prop_string(ctx, -2, "responseText");
        duk_push_lstring(ctx, (const char *)resp.body,
                         (duk_size_t)resp.body_len);
        duk_put_prop_string(ctx, -2, "response");
        duk_push_int(ctx, 4);
        duk_put_prop_string(ctx, -2, "readyState");

        /* Fire onreadystatechange */
        duk_get_prop_string(ctx, -1, "onreadystatechange"); /* [this, fn] */
        if (duk_is_function(ctx, -1)) {
            if (duk_pcall(ctx, 0) != 0)
                wjs_log_push(duk_safe_to_string(ctx, -1));
            duk_pop(ctx);
        } else { duk_pop(ctx); }

        /* Fire onload or onerror */
        if (resp.ok) {
            duk_get_prop_string(ctx, -1, "onload");
            if (duk_is_function(ctx, -1)) {
                if (duk_pcall(ctx, 0) != 0)
                    wjs_log_push(duk_safe_to_string(ctx, -1));
                duk_pop(ctx);
            } else { duk_pop(ctx); }
        } else {
            duk_get_prop_string(ctx, -1, "onerror");
            if (duk_is_function(ctx, -1)) {
                if (duk_pcall(ctx, 0) != 0)
                    wjs_log_push(duk_safe_to_string(ctx, -1));
                duk_pop(ctx);
            } else { duk_pop(ctx); }
        }
    }
    duk_pop(ctx);    /* pop 'this' */
    return 0;
}

static duk_ret_t js_xhr_setRequestHeader(duk_context *ctx) {
    /* no-op stub: prevents "not a function" when callers use it */
    (void)ctx; return 0;
}

void wf_install_fetch(duk_context *ctx, uint8_t doc_id) {
    (void)doc_id;
    duk_push_global_object(ctx);
    duk_push_c_function(ctx, js_fetch, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "fetch");
    duk_pop(ctx);
}

void wf_install_xhr(duk_context *ctx, uint8_t doc_id) {
    (void)doc_id;
    /* Define XMLHttpRequest constructor */
    duk_peval_string_noresult(ctx,
        "function XMLHttpRequest(){"
        "  this.status=0;this.responseText='';this.response=null;"
        "  this.onload=null;this.onerror=null;this.onreadystatechange=null;"
        "  this.readyState=0;this.__url='';this.__method='GET';"
        "}");

    duk_push_global_object(ctx);
    duk_get_prop_string(ctx, -1, "XMLHttpRequest");
    if (duk_is_function(ctx, -1)) {
        duk_get_prop_string(ctx, -1, "prototype");
        duk_push_c_function(ctx, js_xhr_open, DUK_VARARGS);
        duk_put_prop_string(ctx, -2, "open");
        duk_push_c_function(ctx, js_xhr_send, DUK_VARARGS);
        duk_put_prop_string(ctx, -2, "send");
        duk_push_c_function(ctx, js_xhr_setRequestHeader, 2);
        duk_put_prop_string(ctx, -2, "setRequestHeader");
        duk_pop(ctx);   /* prototype */
    }
    duk_pop_2(ctx);     /* XMLHttpRequest + global */
}
