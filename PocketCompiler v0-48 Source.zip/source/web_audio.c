/*
 * web_audio.c  —  Web Audio API (NDSP backed)
 */
#include "web_audio.h"
#include "duktape.h"
#include "web_js.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <3ds.h>

WAAudioContext g_wa_ctx;

/* NDSP wave buffers (2 per channel for double buffering) */
#define WA_BUF_SAMPLES 1024
static ndspWaveBuf s_wave_bufs[24][2]; /* up to 12 channels × 2 */
static int16_t     s_pcm_bufs [24][2][WA_BUF_SAMPLES];
static int         s_buf_idx  [24]; /* which buffer to fill next */

/* Oscillator phase accumulators */
static float s_phase[WA_MAX_NODES];

/* ── Init / exit ─────────────────────────────────────────────────── */

/* ── NDSP guard ─ set true only after a successful ndspInit() ── */
static bool s_ndsp_ok = false;

void wa_init(uint8_t doc_id){
    if(g_wa_ctx.initialized) return;
    memset(&g_wa_ctx,0,sizeof(g_wa_ctx));
    g_wa_ctx.doc_id=doc_id;
    g_wa_ctx.master_gain=0.7f;
    /* Try to init NDSP; if DSP firmware is unavailable, audio is silently disabled */
    if(!s_ndsp_ok){
        Result rc = ndspInit();
        s_ndsp_ok = (R_SUCCEEDED(rc));
        /* ndspInit can succeed silently even without dsp firm on some CFW — guard anyway */
    }
    g_wa_ctx.initialized=true;
    /* destination node is node 0 */
    g_wa_ctx.nodes[0].type=WAN_DESTINATION;
    g_wa_ctx.nodes[0].used=true;
    g_wa_ctx.nodes[0].dest_node=-1;
    g_wa_ctx.nodes[0].ndsp_channel=-1;
    g_wa_ctx.node_n=1;
    memset(s_phase,0,sizeof(s_phase));
    memset(s_buf_idx,0,sizeof(s_buf_idx));
}

void wa_exit(void){
    if(!g_wa_ctx.initialized) return;
    /* stop all channels */
    for(int i=0;i<g_wa_ctx.node_n;i++){
        WAAudioNode *n=&g_wa_ctx.nodes[i];
        if(s_ndsp_ok&&n->used&&n->ndsp_channel>=0){
            ndspChnReset(n->ndsp_channel);
        }
        if(n->pcm_data){ free(n->pcm_data); n->pcm_data=NULL; }
    }
    if(s_ndsp_ok){ ndspExit(); s_ndsp_ok=false; }
    g_wa_ctx.initialized=false;
}

/* ── Oscillator synthesis ────────────────────────────────────────── */

static int16_t synth_sample(WAAudioNode *n, int node_idx, float t){
    float dp=2*M_PI*n->frequency/WA_SAMPLE_RATE;
    s_phase[node_idx]+=dp;
    if(s_phase[node_idx]>2*M_PI) s_phase[node_idx]-=2*M_PI;
    float ph=s_phase[node_idx];
    float v=0;
    switch(n->osc_type){
        case WA_SINE:     v=sinf(ph); break;
        case WA_SQUARE:   v=(ph<M_PI)?1.f:-1.f; break;
        case WA_SAWTOOTH: v=ph/M_PI-1.f; break;
        case WA_TRIANGLE: v=(ph<M_PI)?(ph/M_PI*2-1):(3-ph/M_PI*2); break;
        default: v=0;
    }
    (void)t;
    return (int16_t)(v*32767.f);
}

/* ── Frame tick ──────────────────────────────────────────────────── */

void wa_tick(double dt){
    if(!g_wa_ctx.initialized) return;
    if(!s_ndsp_ok) return;  /* NDSP not available — skip audio */
    g_wa_ctx.current_time+=dt;
    /* For each active oscillator, fill and queue NDSP buffers */
    for(int i=0;i<g_wa_ctx.node_n;i++){
        WAAudioNode *n=&g_wa_ctx.nodes[i];
        if(!n->used||!n->playing) continue;
        /* stop check */
        if(n->stop_time>0&&g_wa_ctx.current_time>=n->stop_time){
            n->playing=false;
            if(n->ndsp_channel>=0){ ndspChnReset(n->ndsp_channel); n->ndsp_channel=-1; }
            continue;
        }
        if(n->type!=WAN_OSCILLATOR&&n->type!=WAN_BUFFER_SRC) continue;
        /* find an NDSP channel */
        if(n->ndsp_channel<0){
            for(int ch=1;ch<24;ch++){
                bool taken=false;
                for(int j=0;j<g_wa_ctx.node_n;j++)
                    if(g_wa_ctx.nodes[j].ndsp_channel==ch){ taken=true; break; }
                if(!taken){ n->ndsp_channel=ch; break; }
            }
            if(n->ndsp_channel<0) continue;
            int ch=n->ndsp_channel;
            ndspChnReset(ch);
            ndspChnSetInterp(ch,NDSP_INTERP_LINEAR);
            ndspChnSetRate(ch,(float)WA_SAMPLE_RATE);
            ndspChnSetFormat(ch,NDSP_FORMAT_MONO_PCM16);
            float mix[12]={0}; mix[0]=g_wa_ctx.master_gain; mix[1]=g_wa_ctx.master_gain;
            ndspChnSetMix(ch,mix);
        }
        int ch=n->ndsp_channel;
        /* check if buffer slot is free */
        int bi=s_buf_idx[ch];
        ndspWaveBuf *wb=&s_wave_bufs[ch][bi];
        if(wb->status==NDSP_WBUF_QUEUED||wb->status==NDSP_WBUF_PLAYING) continue;
        /* fill buffer */
        int16_t *buf=s_pcm_bufs[ch][bi];
        if(n->type==WAN_OSCILLATOR){
            for(int s=0;s<WA_BUF_SAMPLES;s++){
                buf[s]=synth_sample(n,i,(float)g_wa_ctx.current_time);
            }
        } else if(n->type==WAN_BUFFER_SRC&&n->pcm_data){
            int16_t *src=(int16_t*)n->pcm_data;
            for(int s=0;s<WA_BUF_SAMPLES;s++){
                if(n->pcm_pos>=n->pcm_samples){
                    if(n->loop) n->pcm_pos=0;
                    else { buf[s]=0; continue; }
                }
                buf[s]=src[n->pcm_pos++];
            }
            if(n->pcm_pos>=n->pcm_samples&&!n->loop) n->playing=false;
        }
        DSP_FlushDataCache(buf,WA_BUF_SAMPLES*2);
        memset(wb,0,sizeof(*wb));
        wb->data_vaddr=buf;
        wb->nsamples=WA_BUF_SAMPLES;
        wb->looping=false;
        ndspChnWaveBufAdd(ch,wb);
        s_buf_idx[ch]=(bi+1)%2;
    }
}

/* ── Node management ─────────────────────────────────────────────── */

int wa_new_node(WANodeType t){
    if(!g_wa_ctx.initialized) return -1;
    if(g_wa_ctx.node_n>=WA_MAX_NODES) return -1;
    int i=g_wa_ctx.node_n++;
    WAAudioNode *n=&g_wa_ctx.nodes[i];
    memset(n,0,sizeof(*n));
    n->type=(uint8_t)t;
    n->used=true;
    n->gain=1.0f;
    n->frequency=440.0f;
    n->dest_node=-1;
    n->ndsp_channel=-1;
    return i;
}

bool wa_connect(int src, int dst){
    if(src<0||src>=g_wa_ctx.node_n) return false;
    g_wa_ctx.nodes[src].dest_node=(int8_t)dst;
    return true;
}

void wa_free_node(int idx){
    if(idx<0||idx>=g_wa_ctx.node_n) return;
    WAAudioNode *n=&g_wa_ctx.nodes[idx];
    if(s_ndsp_ok&&n->ndsp_channel>=0){ ndspChnReset(n->ndsp_channel); n->ndsp_channel=-1; }
    if(n->pcm_data){ free(n->pcm_data); n->pcm_data=NULL; }
    n->used=false; n->playing=false;
}

/* ── Oscillator ──────────────────────────────────────────────────── */
int  wa_create_oscillator(void){ int i=wa_new_node(WAN_OSCILLATOR); if(i>=0) g_wa_ctx.nodes[i].osc_type=WA_SINE; return i; }
void wa_osc_set_type(int i, WAOscType t){ if(i>=0&&i<g_wa_ctx.node_n) g_wa_ctx.nodes[i].osc_type=(uint8_t)t; }
void wa_osc_set_freq(int i, float hz){ if(i>=0&&i<g_wa_ctx.node_n) g_wa_ctx.nodes[i].frequency=hz; }
void wa_osc_set_detune(int i, float c){ if(i>=0&&i<g_wa_ctx.node_n) g_wa_ctx.nodes[i].detune=c; }
void wa_osc_start(int i, double when){
    if(i<0||i>=g_wa_ctx.node_n) return;
    WAAudioNode *n=&g_wa_ctx.nodes[i];
    if(g_wa_ctx.current_time>=when) n->playing=true;
    else n->start_time=when; /* TODO: schedule */
}
void wa_osc_stop(int i, double when){
    if(i<0||i>=g_wa_ctx.node_n) return;
    g_wa_ctx.nodes[i].stop_time=when>0?when:g_wa_ctx.current_time;
}

/* ── Gain ────────────────────────────────────────────────────────── */
int  wa_create_gain(void){ return wa_new_node(WAN_GAIN); }
void wa_gain_set(int i, float g){ if(i>=0&&i<g_wa_ctx.node_n) g_wa_ctx.nodes[i].gain=g; }

/* ── Buffer source ───────────────────────────────────────────────── */
int wa_create_buffer_source(void){ return wa_new_node(WAN_BUFFER_SRC); }

bool wa_buffer_set_pcm(int i, const uint8_t *data, uint32_t n_samples, int channels, int rate){
    /* v0.38 final audit: guard against integer overflow in the malloc
     * size. n_samples*channels*2 could wrap around to a small value if
     * n_samples and channels are both large (e.g. from a malicious WAV
     * header), leading to a small malloc followed by a huge memcpy =
     * heap overflow. Cap the total allocation at a sane maximum and
     * reject anything larger. Also reject channels<=0 or bits-related
     * zero-denominator cases at the call sites (wa_buffer_load_wav
     * validates before calling). */
    if(i<0||i>=g_wa_ctx.node_n||!data) return false;
    if(channels<=0||channels>2) return false;   /* only mono/stereo */
    /* max 5 minutes of stereo 48kHz 16-bit = ~57MB; cap at 4MB to be
     * conservative on 3DS memory. 4MB / (channels*2) = max samples. */
    uint32_t max_bytes = 4u * 1024u * 1024u;
    uint64_t need = (uint64_t)n_samples * (uint64_t)channels * 2u;
    if(need > max_bytes) return false;
    WAAudioNode *n=&g_wa_ctx.nodes[i];
    if(n->pcm_data) free(n->pcm_data);
    n->pcm_data=(uint8_t*)malloc((size_t)need);
    if(!n->pcm_data) return false;
    memcpy(n->pcm_data,data,(size_t)need);
    n->pcm_samples=n_samples;
    n->pcm_pos=0;
    (void)rate;
    return true;
}

bool wa_buffer_load_wav(int i, const char *path){
    if(i<0||!path) return false;
    FILE *f=fopen(path,"rb");
    if(!f) return false;
    /* minimal WAV parser.
     * v0.38 final audit: comprehensive hardening against malformed
     * WAV files — previously, a malformed header with channels=0 or
     * bits=0 would cause a division by zero crash, and unchecked
     * fread on a short file would read uninitialized header bytes. */
    uint8_t hdr[44];
    size_t got=fread(hdr,1,44,f);
    if(got<44){ fclose(f); return false; }   /* file too short */
    if(hdr[0]!='R'||hdr[1]!='I'||hdr[2]!='F'||hdr[3]!='F'){
        fclose(f); return false;
    }
    /* channels at byte 22, sample rate at 24, bits at 34 */
    int channels =hdr[22]|(hdr[23]<<8);
    uint32_t rate=hdr[24]|(hdr[25]<<8)|(hdr[26]<<16)|(hdr[27]<<24);
    int bits     =hdr[34]|(hdr[35]<<8);
    /* v0.38: validate before dividing — channels=0 or bits=0 (or
     * bits<8) would crash on the n_samples division below. */
    if(channels<=0||channels>2){ fclose(f); return false; }
    if(bits!=8&&bits!=16){ fclose(f); return false; }
    int bytes_per_sample = channels * (bits/8);
    if(bytes_per_sample<=0){ fclose(f); return false; }
    /* find data chunk */
    long data_start=44;
    uint32_t data_sz=0;
    memcpy(&data_sz,hdr+40,4);
    /* v0.38: cap data_sz at 4MB to match wa_buffer_set_pcm's limit.
     * Also guard against data_sz==0 (malloc(0) is impl-defined). */
    if(data_sz==0||data_sz>4u*1024u*1024u){ fclose(f); return false; }
    uint8_t *data=(uint8_t*)malloc(data_sz);
    if(!data){ fclose(f); return false; }
    fseek(f,data_start,SEEK_SET);
    /* v0.38: check fread return — file may be shorter than data_sz
     * claims, in which case the buffer would have uninitialized bytes
     * that get memcpy'd into pcm_data. */
    size_t rd=fread(data,1,data_sz,f);
    fclose(f);
    if(rd!=data_sz){ free(data); return false; }
    uint32_t n_samples=data_sz/(uint32_t)bytes_per_sample;
    bool ok=wa_buffer_set_pcm(i,data,n_samples,channels,(int)rate);
    free(data); return ok;
}

void wa_buffer_start(int i, double when){ wa_osc_start(i,when); }
void wa_buffer_stop (int i, double when){ wa_osc_stop(i,when); }
void wa_buffer_loop (int i, bool en, double s, double e){
    if(i<0||i>=g_wa_ctx.node_n) return;
    g_wa_ctx.nodes[i].loop=en;
    g_wa_ctx.nodes[i].loop_start=s;
    g_wa_ctx.nodes[i].loop_end=e;
}

int wa_get_destination(void){ return 0; }

/* ── Duktape bindings ────────────────────────────────────────────── */

static duk_ret_t wa_js_createOscillator(duk_context *ctx){
    int i=wa_create_oscillator();
    duk_push_object(ctx);
    duk_push_int(ctx,i); duk_put_prop_string(ctx,-2,"__node_id");
    /* type property */
    duk_push_string(ctx,"sine"); duk_put_prop_string(ctx,-2,"type");
    /* frequency AudioParam stub */
    duk_push_object(ctx);
    duk_push_int(ctx,i); duk_put_prop_string(ctx,-2,"__node_id");
    duk_push_number(ctx,440); duk_put_prop_string(ctx,-2,"value");
    duk_put_prop_string(ctx,-2,"frequency");
    /* detune stub */
    duk_push_object(ctx); duk_push_number(ctx,0); duk_put_prop_string(ctx,-2,"value");
    duk_put_prop_string(ctx,-2,"detune");
    return 1;
}

static duk_ret_t wa_js_createGain(duk_context *ctx){
    int i=wa_create_gain();
    duk_push_object(ctx);
    duk_push_int(ctx,i); duk_put_prop_string(ctx,-2,"__node_id");
    duk_push_object(ctx); duk_push_number(ctx,1); duk_put_prop_string(ctx,-2,"value");
    duk_put_prop_string(ctx,-2,"gain");
    return 1;
}

static duk_ret_t wa_js_createBufferSource(duk_context *ctx){
    int i=wa_create_buffer_source();
    duk_push_object(ctx);
    duk_push_int(ctx,i); duk_put_prop_string(ctx,-2,"__node_id");
    return 1;
}

static duk_ret_t wa_js_destination(duk_context *ctx){
    duk_push_object(ctx);
    duk_push_int(ctx,0); duk_put_prop_string(ctx,-2,"__node_id");
    return 1;
}

void wa_install_bindings(duk_context *ctx, uint8_t doc_id){
    (void)doc_id;
    /* AudioContext constructor */
    duk_peval_string_noresult(ctx,
        "function AudioContext() {"
        "  this.__doc_id = 0;"
        "}"
    );
    /* Install methods on global so new AudioContext() works */
    duk_push_global_object(ctx);
    duk_get_prop_string(ctx,-1,"AudioContext");
    if(duk_is_function(ctx,-1)){
        duk_get_prop_string(ctx,-1,"prototype");
        /* methods on prototype */
        duk_push_c_function(ctx,wa_js_createOscillator,0);
        duk_put_prop_string(ctx,-2,"createOscillator");
        duk_push_c_function(ctx,wa_js_createGain,0);
        duk_put_prop_string(ctx,-2,"createGain");
        duk_push_c_function(ctx,wa_js_createBufferSource,0);
        duk_put_prop_string(ctx,-2,"createBufferSource");
        /* destination getter */
        duk_push_c_function(ctx,wa_js_destination,0);
        duk_put_prop_string(ctx,-2,"destination");
        /* currentTime */
        duk_push_number(ctx,0); duk_put_prop_string(ctx,-2,"currentTime");
        duk_pop(ctx); /* prototype */
    }
    duk_pop_2(ctx); /* AudioContext, global */
    /* Also WebAudioContext alias */
    duk_peval_string_noresult(ctx,"var webkitAudioContext=AudioContext;");
}
