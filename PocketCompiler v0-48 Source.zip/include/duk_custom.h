/*
 * duk_custom.h — Duktape custom config for 3DS ARM11
 * Included via DUK_OPT_HAVE_CUSTOM_H if defined.
 */
#ifndef DUK_CUSTOM_H
#define DUK_CUSTOM_H

/* Reduce memory footprint for 3DS */
#undef  DUK_USE_JSON_STRINGIFY_FASTPATH
#define DUK_USE_HEAPPTR16
/* No CBOR/JX/JC extensions — save code size */
#undef DUK_USE_JX
#undef DUK_USE_JC
/* Reduce regexp engine size */
#undef  DUK_USE_REGEXP_CANON_WORKAROUND

/* 3DS has no /dev/urandom; use svcGetSystemTick for randomness */
#undef DUK_USE_GET_RANDOM_DOUBLE
#define DUK_USE_GET_RANDOM_DOUBLE(ctx) \
    ((double)(svcGetSystemTick() ^ (u64)(ctx)) / (double)0xFFFFFFFFFFFFFFFFULL)

#endif /* DUK_CUSTOM_H */
