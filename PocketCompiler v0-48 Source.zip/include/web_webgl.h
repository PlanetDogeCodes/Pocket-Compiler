#pragma once
/*  web_webgl.h  — limited WebGL 1.0-like API over Citro3D
 *  PocketCompiler v0.33
 *
 *  Maps a subset of WebGL 1.0 to Citro3D primitives.
 *  Only the most common draw-call patterns are supported.
 *  Unsupported calls are silently ignored or return 0/null.
 *
 *  Limits:
 *   - WGL_MAX_PROGRAMS   : 8   (vertex+fragment shader programs)
 *   - WGL_MAX_BUFFERS    : 16  (VBO/IBO)
 *   - WGL_MAX_TEXTURES   : 8   (2D textures, mipmaps not supported)
 *   - WGL_MAX_UNIFORMS   : 16  (per program)
 *   - Viewport fixed to top screen (400×240)
 *   - No stencil, no depth texture, no MRT
 *   - Shader source strings are ignored; PICA200 DVLE provided separately
 */

#ifndef WEB_WEBGL_H
#define WEB_WEBGL_H

#ifdef __3DS__
#  include <3ds.h>
#  include <citro3d.h>
#endif

#include <stdint.h>
#include <stdbool.h>
#include "web_dom.h"   /* for doc_id */
#include "duktape.h"   /* for duk_context */

/* ─── WebGL-compatible type aliases ─────────────────────────────────────── */
typedef uint32_t WGLuint;
typedef int32_t  WGLint;
typedef float    WGLfloat;
typedef uint32_t WGLenum;
typedef bool     WGLboolean;
typedef uint8_t  WGLubyte;

/* ─── WebGL-compatible constants ─────────────────────────────────────────── */
/* Buffer targets */
#define WGL_ARRAY_BUFFER          0x8892
#define WGL_ELEMENT_ARRAY_BUFFER  0x8893

/* Buffer usage */
#define WGL_STATIC_DRAW           0x88B4
#define WGL_DYNAMIC_DRAW          0x88E8
#define WGL_STREAM_DRAW           0x88E0

/* Texture targets / units */
#define WGL_TEXTURE_2D            0x0DE1
#define WGL_TEXTURE0              0x84C0

/* Texture parameters */
#define WGL_NEAREST               0x2600
#define WGL_LINEAR                0x2601
#define WGL_CLAMP_TO_EDGE         0x812F
#define WGL_REPEAT                0x2901
#define WGL_TEXTURE_MIN_FILTER    0x2801
#define WGL_TEXTURE_MAG_FILTER    0x2800
#define WGL_TEXTURE_WRAP_S        0x2802
#define WGL_TEXTURE_WRAP_T        0x2803

/* Pixel formats */
#define WGL_RGBA                  0x1908
#define WGL_RGB                   0x1907
#define WGL_UNSIGNED_BYTE         0x1401
#define WGL_FLOAT                 0x1406

/* Clear bits */
#define WGL_COLOR_BUFFER_BIT      0x4000
#define WGL_DEPTH_BUFFER_BIT      0x0100

/* Primitive types */
#define WGL_TRIANGLES             0x0004
#define WGL_TRIANGLE_STRIP        0x0005
#define WGL_TRIANGLE_FAN          0x0006
#define WGL_LINES                 0x0001
#define WGL_LINE_STRIP            0x0003
#define WGL_POINTS                0x0000

/* Blend */
#define WGL_BLEND                 0x0BE2
#define WGL_ONE                   1
#define WGL_ZERO                  0
#define WGL_SRC_ALPHA             0x0302
#define WGL_ONE_MINUS_SRC_ALPHA   0x0303

/* Depth test */
#define WGL_DEPTH_TEST            0x0B71
#define WGL_LESS                  0x0201
#define WGL_LEQUAL                0x0203

/* Cull face */
#define WGL_CULL_FACE             0x0B44
#define WGL_BACK                  0x0405
#define WGL_FRONT                 0x0404

/* Shader types (source is ignored, but constants kept for JS compat) */
#define WGL_VERTEX_SHADER         0x8B31
#define WGL_FRAGMENT_SHADER       0x8B30

/* Error codes */
#define WGL_NO_ERROR              0
#define WGL_INVALID_ENUM          0x0500
#define WGL_INVALID_VALUE         0x0501
#define WGL_INVALID_OPERATION     0x0502
#define WGL_OUT_OF_MEMORY         0x0505

/* Framebuffer status */
#define WGL_FRAMEBUFFER_COMPLETE  0x8CD5

/* Uniform types */
#define WGL_FLOAT_VEC2            0x8B50
#define WGL_FLOAT_VEC3            0x8B51
#define WGL_FLOAT_VEC4            0x8B52
#define WGL_FLOAT_MAT4            0x8B5C
#define WGL_INT                   0x1404
#define WGL_SAMPLER_2D            0x8B5E

/* ─── Internal structures ─────────────────────────────────────────────────── */

#define WGL_MAX_PROGRAMS  8
#define WGL_MAX_BUFFERS   8      /* reduced: 16→8 further cuts BSS */
#define WGL_MAX_TEXTURES  8
#define WGL_MAX_UNIFORMS  16
#define WGL_BUF_CAP       4096   /* reduced: 64KB→4KB per VBO saves ~2MB BSS */   /* bytes per buffer */

typedef struct {
    bool      used;
    WGLenum   target;   /* ARRAY_BUFFER or ELEMENT_ARRAY_BUFFER */
    WGLenum   usage;
    uint8_t   data[WGL_BUF_CAP];
    uint32_t  size;     /* bytes currently stored */
} WGLBuffer;

typedef struct {
    char   name[32];
    WGLint location;   /* matches DVLE uniform index */
    WGLenum type;
    float  fval[16];   /* up to mat4 */
    int    ival;
} WGLUniform;

typedef struct {
    bool       used;
    /* In real WebGL shaders would be compiled; here we just track state */
    WGLUniform uniforms[WGL_MAX_UNIFORMS];
    int        uniform_n;
#ifdef __3DS__
    shaderProgram_s  sh;
    DVLB_s          *dvlb;
#endif
    bool        linked;
} WGLProgram;

typedef struct {
    bool        used;
    int         w, h;
    WGLenum     format;       /* WGL_RGBA / WGL_RGB */
    WGLenum     min_filter;
    WGLenum     mag_filter;
    WGLenum     wrap_s;
    WGLenum     wrap_t;
#ifdef __3DS__
    C3D_Tex     tex;
#endif
    bool        loaded;
} WGLTexture;

/* ─── Per-canvas WebGL context ───────────────────────────────────────────── */
typedef struct {
    bool        used;
    int         doc_id;
    int         canvas_id;   /* index into g_we_canvas[] */

    /* State machine */
    WGLProgram  programs[WGL_MAX_PROGRAMS];
    WGLBuffer   buffers[WGL_MAX_BUFFERS];
    WGLTexture  textures[WGL_MAX_TEXTURES];

    WGLuint     bound_vbo;
    WGLuint     bound_ibo;
    WGLuint     active_program;
    WGLuint     active_texture_unit;  /* 0..7 */
    WGLuint     bound_textures[8];    /* per unit */

    /* Clear color */
    float       clear_r, clear_g, clear_b, clear_a;

    /* Viewport */
    int         vp_x, vp_y, vp_w, vp_h;

    /* Caps */
    bool        blend_enabled;
    WGLenum     blend_src, blend_dst;
    bool        depth_test;
    WGLenum     depth_func;
    bool        cull_face;
    WGLenum     cull_mode;

    WGLenum     last_error;
} WGLContext;

#define WGL_MAX_CTX 2
extern WGLContext g_wgl_ctx[WGL_MAX_CTX];

/* ─── Context management ─────────────────────────────────────────────────── */
WGLContext *wgl_new_context(int doc_id, int canvas_id);
void        wgl_free_context(WGLContext *ctx);
void        wgl_install_bindings(duk_context *duk_ctx, int canvas_id, int doc_id);

/* ─── WebGL API (mirrors JS WebGLRenderingContext) ──────────────────────── */

/* Error */
WGLenum  wgl_getError(WGLContext *c);

/* Clear */
void     wgl_clearColor(WGLContext *c, float r, float g, float b, float a);
void     wgl_clear(WGLContext *c, WGLuint mask);

/* Viewport */
void     wgl_viewport(WGLContext *c, int x, int y, int w, int h);

/* Buffers */
WGLuint  wgl_createBuffer(WGLContext *c);
void     wgl_bindBuffer(WGLContext *c, WGLenum target, WGLuint buf);
void     wgl_bufferData(WGLContext *c, WGLenum target, const void *data,
                        uint32_t size, WGLenum usage);
void     wgl_deleteBuffer(WGLContext *c, WGLuint buf);

/* Programs / Shaders (source ignored; PICA200 shaders loaded separately) */
WGLuint  wgl_createProgram(WGLContext *c);
WGLuint  wgl_createShader(WGLContext *c, WGLenum type);
void     wgl_shaderSource(WGLContext *c, WGLuint shader, const char *src);
void     wgl_compileShader(WGLContext *c, WGLuint shader);
void     wgl_attachShader(WGLContext *c, WGLuint prog, WGLuint shader);
void     wgl_linkProgram(WGLContext *c, WGLuint prog);
void     wgl_useProgram(WGLContext *c, WGLuint prog);
void     wgl_deleteProgram(WGLContext *c, WGLuint prog);
void     wgl_deleteShader(WGLContext *c, WGLuint shader);

/* Uniforms */
WGLint   wgl_getUniformLocation(WGLContext *c, WGLuint prog, const char *name);
void     wgl_uniform1i(WGLContext *c, WGLint loc, int v);
void     wgl_uniform1f(WGLContext *c, WGLint loc, float v);
void     wgl_uniform2f(WGLContext *c, WGLint loc, float x, float y);
void     wgl_uniform3f(WGLContext *c, WGLint loc, float x, float y, float z);
void     wgl_uniform4f(WGLContext *c, WGLint loc, float x, float y,
                       float z, float w);
void     wgl_uniformMatrix4fv(WGLContext *c, WGLint loc, bool transpose,
                              const float *m);

/* Attributes */
WGLint   wgl_getAttribLocation(WGLContext *c, WGLuint prog, const char *name);
void     wgl_enableVertexAttribArray(WGLContext *c, WGLuint idx);
void     wgl_disableVertexAttribArray(WGLContext *c, WGLuint idx);
void     wgl_vertexAttribPointer(WGLContext *c, WGLuint idx, int size,
                                 WGLenum type, bool normalized,
                                 int stride, int offset);

/* Draw */
void     wgl_drawArrays(WGLContext *c, WGLenum mode, int first, int count);
void     wgl_drawElements(WGLContext *c, WGLenum mode, int count,
                          WGLenum type, int offset);

/* Textures */
WGLuint  wgl_createTexture(WGLContext *c);
void     wgl_bindTexture(WGLContext *c, WGLenum target, WGLuint tex);
void     wgl_activeTexture(WGLContext *c, WGLenum unit);
void     wgl_texImage2D(WGLContext *c, WGLenum target, int level,
                        WGLenum internalfmt, int w, int h, int border,
                        WGLenum format, WGLenum type, const void *pixels);
void     wgl_texParameteri(WGLContext *c, WGLenum target,
                           WGLenum pname, WGLint param);
void     wgl_generateMipmap(WGLContext *c, WGLenum target);
void     wgl_deleteTexture(WGLContext *c, WGLuint tex);

/* Caps */
void     wgl_enable(WGLContext *c, WGLenum cap);
void     wgl_disable(WGLContext *c, WGLenum cap);
void     wgl_blendFunc(WGLContext *c, WGLenum sfactor, WGLenum dfactor);
void     wgl_depthFunc(WGLContext *c, WGLenum fn);
void     wgl_cullFace(WGLContext *c, WGLenum mode);

/* Flush / finish */
void     wgl_flush(WGLContext *c);
void     wgl_finish(WGLContext *c);

#endif /* WEB_WEBGL_H */
