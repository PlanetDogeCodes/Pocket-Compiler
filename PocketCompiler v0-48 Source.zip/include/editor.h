#pragma once
#include <stdbool.h>

#define EDITOR_MAX        65536
#define EDITOR_MAX_LINES    512
#define ED_LINE_MAX         256   /* renamed from LINE_MAX to avoid
                                   * conflict with syslimits.h */

/* v0.39: multi-level undo ring. Each step holds a full EDITOR_MAX snapshot
 * of the buffer plus the cursor_line at snapshot time. Ring memory:
 * 5 * 64 KB = 320 KB. g_editor lives in .bss (static, main.c), so this is
 * safe — but no Editor may ever be stack-allocated (the ring would blow
 * the 3DS's 256 KB main-thread stack instantly). All existing Editor
 * instances are static/file-scope; do not change that. */
#define EDITOR_UNDO_STEPS 5

typedef struct {
    char  buf[EDITOR_MAX];
    int   cursor_line;
    int   scroll_offset;
    /* v0.39 undo ring. undo_head = next slot to WRITE; undo_count = number
     * of valid restorable slots (0..STEPS). editor_snapshot() writes at
     * [head] then advances head mod STEPS, capping count at STEPS.
     * editor_undo() steps back to the most-recently-written slot, restores
     * it, and decrements count — repeated presses walk back up to STEPS
     * times, then undo becomes a no-op until the next snapshot. */
    char  undo_buf[EDITOR_UNDO_STEPS][EDITOR_MAX];
    int   undo_cursor[EDITOR_UNDO_STEPS];
    int   undo_head;
    int   undo_count;
} Editor;

void editor_init(Editor *e);
void editor_snapshot(Editor *e);   /* push current state onto undo ring */
void editor_undo(Editor *e);       /* pop one step off the undo ring */
int  editor_line_count(const Editor *e);
void editor_get_line(const Editor *e, int line, char *out, int out_sz);
void editor_set_line(Editor *e, int line, const char *text);
void editor_insert_line(Editor *e, int line, const char *text);
void editor_delete_line(Editor *e, int line);
void editor_scroll_up(Editor *e);
void editor_scroll_down(Editor *e);

/* ── v0.39 editor helpers ─────────────────────────────────────────── */
/* Duplicate the line at e->cursor_line: inserts a copy as a new line
 * directly below it and advances cursor_line to the new line. Caller
 * should editor_snapshot() first if undo is wanted. */
void editor_duplicate_line(Editor *e);

/* Toggle a line comment on the line at e->cursor_line. Context-aware:
 * if the buffer looks like an HTML document (contains <!DOCTYPE or <html,
 * case-insensitive), wraps/unwraps the line in <!-- -->; otherwise
 * (JS/CSS context) toggles a leading "// ". Idempotent. Caller should
 * editor_snapshot() first if undo is wanted. */
void editor_toggle_comment(Editor *e);

/* ── Auto-indent ─────────────────────────────────────────────────── */
/* Copy the leading whitespace of 'line' into 'out' (null-terminated).
 * Returns the number of indent characters copied. */
int  editor_get_indent(const Editor *e, int line, char *out, int out_sz);

/* ── Find / Replace ──────────────────────────────────────────────── */

/* Find the next occurrence of 'needle' starting search just after
 * (start_line, start_col).  Wraps around the buffer.
 * Returns true and sets fl/fc if found, false if not found. */
bool editor_find(const Editor *e, const char *needle,
                 int start_line, int start_col,
                 int *fl, int *fc);

/* Find the previous occurrence of 'needle' before (start_line, start_col).
 * Wraps around from the beginning to the end of the buffer. */
bool editor_find_prev(const Editor *e, const char *needle,
                      int start_line, int start_col,
                      int *fl, int *fc);

/* Replace exactly needle_len characters at (line, col) with 'replacement'.
 * Caller should call editor_snapshot() first if undo is needed.
 * Returns true on success, false if the replacement would overflow. */
bool editor_replace_at(Editor *e, int line, int col,
                       int needle_len, const char *replacement);
