/*
 * web_layout.h  —  Layout engine for Pocket Compiler Web Engine
 * Implements block, inline, inline-block, flex, absolute, fixed.
 */
#pragma once
#include "web_dom.h"

/* Top-screen viewport */
#define WE_VIEWPORT_W   400
#define WE_VIEWPORT_H   240

/* ── Layout context passed recursively ─────────────────────────── */
typedef struct {
    int16_t  avail_w;     /* available width  from parent */
    int16_t  avail_h;     /* available height from parent */
    int16_t  base_x;      /* absolute x of parent content */
    int16_t  base_y;      /* absolute y of parent content */
    int16_t  cursor_x;    /* inline cursor x              */
    int16_t  cursor_y;    /* block cursor y               */
    int16_t  line_h;      /* current line height          */
    uint8_t  doc_id;
} LayoutCtx;

/* ── API ────────────────────────────────────────────────────────── */

/* Run full layout pass for a document (sets lay_x/y/w/h on all nodes) */
void  layout_document(uint8_t doc_id);

/* Layout a single subtree with given context */
void  layout_node(int16_t node_id, LayoutCtx *ctx);

/* Flex layout for a flex container */
void  layout_flex(int16_t node_id, LayoutCtx *ctx);

/* v0.42: Grid layout for a grid container */
void  layout_grid(int16_t node_id, LayoutCtx *ctx);

/* Get scroll extents for a node (scrollable area vs viewport) */
void  layout_scroll_extents(int16_t node_id, int16_t *max_sx, int16_t *max_sy);

/* Hit test: find topmost node at (x,y) screen coords */
int16_t layout_hit(uint8_t doc_id, int16_t x, int16_t y);

/* Find nearest focusable ancestor/self */
int16_t layout_find_focusable(int16_t node_id);
