#pragma once
#include <stdbool.h>

/*
 * FeatureRuntime — unified struct used by ALL source files.
 *
 * Contains BOTH the short field names (dom, fetch, audio …) used by
 * runtime.c / ui.c AND the extended names (dom_events, api_fetch …)
 * used by runtime_features.c from earlier phase builds.
 * They are kept in sync by runtime_scan_html().
 *
 * Status string is available under BOTH names:
 *   status_msg   — used by ui.c / main.c
 *   last_message — used by runtime_features.c
 */
typedef struct {
    /* ---- basic feature flags (used by ui.c / main.c) ---- */
    bool dom;
    bool fetch;
    bool images;        /* <img> detected  — NOT 'image' */
    bool audio;
    bool storage;
    bool canvas;
    bool webgl;
    bool iframe;
    bool indexeddb;

    /* ---- extended feature flags (used by runtime_features.c) ---- */
    bool dom_events;    /* mirrors dom    */
    bool api_fetch;     /* mirrors fetch  */
    bool web_audio;     /* mirrors audio  */
    bool local_storage; /* mirrors storage */
    bool cache_api;     /* caches. API    */

    /* ---- runtime counters (used by runtime_features.c) ---- */
    int  compile_count;
    int  draw_count;
    int  storage_count;
    int  event_count;

    /* ---- status string available under both names ---- */
    char status_msg[128];    /* used by ui.c / main.c — NOT 'message' */
    char last_message[128];  /* used by runtime_features.c            */
} FeatureRuntime;

/* Backwards-compat alias */
typedef FeatureRuntime RuntimeInfo;

/* --- function declarations --- */
void runtime_init(FeatureRuntime *rt);
void runtime_scan_html(FeatureRuntime *rt, const char *html);
void runtime_tick(FeatureRuntime *rt);
void runtime_mark_event(FeatureRuntime *rt, const char *event_name);
