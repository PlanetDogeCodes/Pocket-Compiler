#pragma once
/* Thin compatibility shim — always include runtime_features.h for the real definitions */
#include "runtime_features.h"
