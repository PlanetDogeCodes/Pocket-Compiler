/*
 * web_canvas.h  —  Canvas 2D API for Pocket Compiler Web Engine
 * Backed by Citro2D draw calls into a per-canvas render target.
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "duktape.h"
#include "web_render.h"

/* ── Canvas 2D context state ────────────────────────────────────── */
#define WC_FONT_SIZE_DEFAULT  12
#define WC_MAX_SAVE_STACK      8
#define WC_PATH_MAX_POINTS   256

typedef struct {
    float    x, y;
} WCPoint;

typedef struct {
    uint32_t fill_color;
    uint32_t stroke_color;
    float    line_width;
    uint8_t  line_cap;       /* 0=butt 1=round 2=square */
    uint8_t  line_join;      /* 0=miter 1=round 2=bevel */
    float    global_alpha;
    uint8_t  composite_op;   /* 0=source-over, etc.     */
    float    font_size;
    uint8_t  text_align;     /* 0=left 1=center 2=right */
    uint8_t  text_baseline;  /* 0=top 1=middle 2=alphabetic */
    float    shadow_blur;
    uint32_t shadow_color;
    float    shadow_x, shadow_y;
    float    transform[6];   /* [a,b,c,d,e,f] 2D matrix */
} WCState;

typedef struct {
    WECanvas *canvas;     /* linked render target */
    uint16_t  canvas_id;

    WCState   state;
    WCState   save_stack[WC_MAX_SAVE_STACK];
    int       save_top;

    /* current path */
    WCPoint   path[WC_PATH_MAX_POINTS];
    int       path_n;
    int       path_start; /* index of move-to start */
    bool      path_closed;

    bool      dirty;
} WCContext2D;

#define WE_MAX_CTX2D  WE_MAX_CANVAS

extern WCContext2D g_wc_ctx[WE_MAX_CTX2D];

/* ── API ────────────────────────────────────────────────────────── */

/* Get or create a 2D context for a canvas */
WCContext2D *wc_get_context(uint16_t canvas_id);
void         wc_destroy_context(uint16_t canvas_id);

/* ── Drawing ────────────────────────────────────────────────────── */
void wc_clearRect     (WCContext2D *c, float x, float y, float w, float h);
void wc_fillRect      (WCContext2D *c, float x, float y, float w, float h);
void wc_strokeRect    (WCContext2D *c, float x, float y, float w, float h);

/* Paths */
void wc_beginPath     (WCContext2D *c);
void wc_closePath     (WCContext2D *c);
void wc_moveTo        (WCContext2D *c, float x, float y);
void wc_lineTo        (WCContext2D *c, float x, float y);
void wc_arc           (WCContext2D *c, float cx, float cy, float r,
                       float start, float end, bool ccw);
void wc_arcTo         (WCContext2D *c, float x1, float y1, float x2, float y2, float r);
void wc_bezierCurveTo (WCContext2D *c, float cp1x, float cp1y,
                       float cp2x, float cp2y, float x, float y);
void wc_quadraticCurveTo(WCContext2D *c, float cpx, float cpy, float x, float y);
void wc_rect          (WCContext2D *c, float x, float y, float w, float h);
void wc_fill          (WCContext2D *c);
void wc_stroke        (WCContext2D *c);
void wc_clip          (WCContext2D *c);

/* Text */
void wc_fillText      (WCContext2D *c, const char *text, float x, float y);
void wc_strokeText    (WCContext2D *c, const char *text, float x, float y);
float wc_measureText  (WCContext2D *c, const char *text);

/* Images */
void wc_drawImage     (WCContext2D *c, uint16_t img_id,
                       float dx, float dy, float dw, float dh);

/* Transform */
void wc_save          (WCContext2D *c);
void wc_restore       (WCContext2D *c);
void wc_scale         (WCContext2D *c, float sx, float sy);
void wc_rotate        (WCContext2D *c, float angle);
void wc_translate     (WCContext2D *c, float tx, float ty);
void wc_transform     (WCContext2D *c, float a, float b, float c2,
                       float d, float e, float f);
void wc_setTransform  (WCContext2D *c, float a, float b, float c2,
                       float d, float e, float f);
void wc_resetTransform(WCContext2D *c);

/* Pixel access */
void wc_getImageData  (WCContext2D *c, float x, float y, float w, float h,
                       uint8_t *out_rgba, int out_sz);
void wc_putImageData  (WCContext2D *c, const uint8_t *rgba,
                       int iw, int ih, float dx, float dy);

/* Present (flush canvas to its render target, then use as texture) */
void wc_present       (WCContext2D *c);

/* Install Duktape bindings for HTMLCanvasElement.getContext('2d') */
void wc_install_bindings(duk_context *ctx, uint16_t canvas_id);
