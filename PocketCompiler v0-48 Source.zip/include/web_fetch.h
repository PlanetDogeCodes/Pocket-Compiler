/*
 * web_fetch.h  —  Fetch / XHR API for Pocket Compiler Web Engine
 * Reads from SD card (file://...) or same-origin relative paths.
 * No network stack on 3DS; all "HTTP" is file-based.
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "duktape.h"

/* ── SD-card "server" root ──────────────────────────────────────── */
/* Relative URLs resolve against this base */
#define WF_SD_ROOT      "sdmc:/3ds/pocketcompiler/www"
#define WF_MAX_URL      256
#define WF_MAX_BODY     65536   /* max response body (64KB)       */
#define WF_MAX_REQUESTS  8      /* concurrent "async" requests    */

/* ── Simple response struct ─────────────────────────────────────── */
typedef struct {
    int     status;         /* 200, 404, etc.                     */
    char    content_type[64];
    uint8_t body[WF_MAX_BODY];
    int     body_len;
    bool    ok;
} WFResponse;

/* ── Pending async request ──────────────────────────────────────── */
typedef struct {
    char      url[WF_MAX_URL];
    uint8_t   doc_id;
    int       js_resolve_ref;   /* Duktape stash ref for resolve  */
    int       js_reject_ref;    /* Duktape stash ref for reject   */
    bool      used;
    bool      done;
    WFResponse resp;
} WFRequest;

extern WFRequest g_wf_requests[WF_MAX_REQUESTS];

/* ── URL resolution ─────────────────────────────────────────────── */
/* Resolve a relative URL or 3ds:// URL to SD path */
bool wf_resolve_url(const char *url, const char *base, char *out, int sz);

/* Check if a URL is servable (exists on SD) */
bool wf_can_serve(const char *url);

/* ── Synchronous fetch (for simple use) ─────────────────────────── */
bool wf_fetch_sync(const char *url, WFResponse *out);

/* ── Async fetch (returns immediately, fulfills next tick) ──────── */
int  wf_fetch_async(uint8_t doc_id, const char *url,
                    int resolve_ref, int reject_ref);

/* Pump: complete any pending async fetches (call once per frame) */
void wf_tick(duk_context *ctx);

/* ── Content-type sniffing ──────────────────────────────────────── */
const char *wf_sniff_type(const char *path);

/* ── Duktape bindings ───────────────────────────────────────────── */
void wf_install_fetch(duk_context *ctx, uint8_t doc_id);
void wf_install_xhr  (duk_context *ctx, uint8_t doc_id);
