/*
 * web_html_parser.h  —  HTML5-subset parser for Pocket Compiler Web Engine
 * Tokenizes HTML and builds a DOM tree.
 */
#pragma once
#include "web_dom.h"

/* ── Parse options ──────────────────────────────────────────────── */
typedef struct {
    uint8_t doc_id;
    bool    fragment_mode;  /* true = parse as fragment, no doc/html/body */
    int16_t fragment_parent; /* node to attach fragment children to */
} WEParseOpts;

/* ── Tokenizer state ────────────────────────────────────────────── */
typedef enum {
    PT_DATA = 0,       /* character data (outside tags)      */
    PT_TAG_OPEN,       /* < seen                             */
    PT_END_TAG_OPEN,   /* </ seen                            */
    PT_TAG_NAME,       /* reading tag name                   */
    PT_BEFORE_ATTR,    /* whitespace before attr             */
    PT_ATTR_NAME,      /* reading attr name                  */
    PT_AFTER_ATTR_EQ,  /* after = before value               */
    PT_ATTR_VAL_DQ,    /* double-quoted attr value           */
    PT_ATTR_VAL_SQ,    /* single-quoted attr value           */
    PT_ATTR_VAL_UQ,    /* unquoted attr value                */
    PT_SELF_CLOSE,     /* / in /> seen                       */
    PT_END_TAG_NAME,   /* reading end tag name               */
    PT_COMMENT,        /* <!-- ... -->                       */
    PT_SCRIPT,         /* inside <script> ... </script>      */
    PT_STYLE,          /* inside <style>  ... </style>       */
    PT_DOCTYPE,        /* <!DOCTYPE...>                      */
    PT_CDATA,          /* <![CDATA[ ... ]]>                  */
} PTState;

/* ── API ────────────────────────────────────────────────────────── */

/* Parse a full HTML document string, build DOM tree, return body node */
int16_t wep_parse(const char *html, const WEParseOpts *opts);

/* Parse a CSS-only string and append rules */
void    wep_parse_css(const char *css, uint8_t doc_id);

/* Extract <script> blocks and evaluate them via web_js */
void    wep_run_scripts(uint8_t doc_id);

/* Extract <style> blocks and parse them */
void    wep_run_styles(uint8_t doc_id);

/* Unescape HTML entities: &amp; &lt; &gt; &quot; &apos; &#NNN; */
void    wep_unescape(const char *in, char *out, int out_sz);

/* Void elements that cannot have children */
bool    wep_is_void(const char *tag);

/* Block-level elements (default display:block) */
bool    wep_is_block(const char *tag);
