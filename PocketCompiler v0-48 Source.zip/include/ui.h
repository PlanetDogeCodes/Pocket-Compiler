#pragma once
#include "app.h"
#include "editor.h"
#include "runtime_features.h"

void ui_init(void);
void ui_draw(const AppState *app, const Editor *e, const FeatureRuntime *rt);

/* Called from main.c when START is pressed to commit the compiled HTML.
 * Passing NULL resets to the "not yet compiled" state.                  */
void ui_set_compiled(const char *html);

/* Returns the number of output lines produced by the last compile.
 * Used by main.c to clamp out_scroll correctly.                         */
int  ui_get_out_count(void);

/* Returns the number of rows in the Controls help screen's key/desc
 * table. Used by main.c to clamp controls_scroll correctly without
 * duplicating the row count as a separately-maintained constant.        */
int  ui_get_controls_row_count(void);

/* v0.39: Returns the number of rows in the Actions menu's table.
 * Used by main.c to clamp actions_scroll. */
int  ui_get_actions_row_count(void);

/* v0.39: Action-menu row indices. Defined here (not in ui.c) so that
 * main.c's MODE_ACTIONS handler can switch on them by name, keeping
 * a single source of truth for the row order. If s_action_rows in
 * ui.c is ever reordered, these must move with it. */
#define ACT_FIND        0
#define ACT_GOTO        1
#define ACT_DUPLICATE   2
#define ACT_COMMENT     3
#define ACT_RENAME      4   /* v0.39: file rename (mirrors MODE_DELETE UX) */
#define ACT_DELETE      5
#define ACT_SORT        6
#define ACT_EXPORT_LOG  7
#define ACT_RECOVER     8   /* v0.39: load FE_AUTOSAVE into the editor */

/* v0.39: Returns a short label for the current sort mode (for the
 * "Sort" row of the actions menu and the explorer headers). */
const char *ui_sort_label(int sort_mode);

void ui_exit(void);
