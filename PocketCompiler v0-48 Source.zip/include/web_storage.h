/*
 * web_storage.h  —  localStorage / IndexedDB-like storage
 * Backed by JSON files on SD:/3ds/pocketcompiler/storage/
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "duktape.h"

/* ── Storage paths ──────────────────────────────────────────────── */
#define WS_BASE_PATH      "sdmc:/3ds/pocketcompiler/storage"
#define WS_LOCAL_FILE     WS_BASE_PATH "/local_%s.json"
#define WS_SESSION_FILE   WS_BASE_PATH "/session_%s.json"
#define WS_IDB_DIR        WS_BASE_PATH "/idb/%s/"
#define WS_COOKIE_FILE    WS_BASE_PATH "/cookies.json"

#define WS_MAX_KEY        128
#define WS_MAX_VAL        4096
#define WS_MAX_ENTRIES    256   /* per store */

/* ── Simple KV store (in-memory + persisted to JSON) ───────────── */
typedef struct {
    char key[WS_MAX_KEY];
    char val[WS_MAX_VAL];
    bool used;
} WSEntry;

typedef struct {
    char       origin[64];     /* domain name or doc-id string  */
    WSEntry    entries[WS_MAX_ENTRIES];
    int        count;
    bool       dirty;          /* needs flush to SD             */
} WSStore;

#define WS_MAX_STORES  4

extern WSStore g_ws_local[WS_MAX_STORES];
extern WSStore g_ws_session[WS_MAX_STORES];

/* ── IndexedDB-adjacent API ─────────────────────────────────────── */
#define WS_IDB_MAX_STORES  8

typedef struct {
    char   name[64];
    char   origin[64];
    bool   used;
} WSIDBDatabase;

extern WSIDBDatabase g_ws_idb[WS_IDB_MAX_STORES];

/* ── API ────────────────────────────────────────────────────────── */

/* localStorage / sessionStorage */
bool  ws_local_set  (const char *origin, const char *key, const char *val);
bool  ws_local_get  (const char *origin, const char *key, char *out, int sz);
bool  ws_local_del  (const char *origin, const char *key);
void  ws_local_clear(const char *origin);
int   ws_local_count(const char *origin);
bool  ws_local_key  (const char *origin, int idx, char *out, int sz);
bool  ws_local_flush(const char *origin);
bool  ws_local_load (const char *origin);

bool  ws_session_set  (const char *origin, const char *key, const char *val);
bool  ws_session_get  (const char *origin, const char *key, char *out, int sz);
bool  ws_session_del  (const char *origin, const char *key);
void  ws_session_clear(const char *origin);

/* Cookie helpers */
bool  ws_cookie_set(const char *name, const char *val, int max_age_s);
bool  ws_cookie_get(const char *name, char *out, int sz);
void  ws_cookie_clear(void);

/* IndexedDB-like */
int   ws_idb_open   (const char *origin, const char *name);
bool  ws_idb_put    (int db, const char *store, const char *key, const char *json);
bool  ws_idb_get    (int db, const char *store, const char *key, char *out, int sz);
bool  ws_idb_delete (int db, const char *store, const char *key);
bool  ws_idb_clear  (int db, const char *store);
void  ws_idb_close  (int db);

/* Ensure SD directories exist */
bool  ws_init(void);

/* Duktape bindings */
void  ws_install_local  (duk_context *ctx, const char *origin);
void  ws_install_session(duk_context *ctx, const char *origin);
void  ws_install_idb    (duk_context *ctx, const char *origin);
void  ws_install_cookies(duk_context *ctx);
