#pragma once
#include <stdbool.h>
#include "editor.h"

/* ---- SD card project directory ---- */
#define FE_DIR          "sdmc:/3ds/PocketCompiler/projects"
/* v0.39: app-level config/autosave live one level above the projects
 * dir, parallel to www/ and storage/. Created lazily on first write. */
#define FE_APP_DIR      "sdmc:/3ds/PocketCompiler"
#define FE_CONFIG_FILE  "sdmc:/3ds/PocketCompiler/config.txt"
#define FE_AUTOSAVE     "sdmc:/3ds/PocketCompiler/autosave.html"
#define FE_LOG_FILE     "sdmc:/3ds/PocketCompiler/console_log.txt"
#define FE_MAX_FILES    64
#define FE_FILENAME_MAX 64
/* files visible at once in the scroll window.
 * v0.37 bug fix: this was 8, left over from when the file-list row
 * height (LH_FE in ui.c) was 21px. v0.36 enlarged LH_FE to 23px for
 * readability but didn't recompute this — 8 rows * 23px = 184px did
 * not fit in the panel's ~168px usable height, so the bottom-most row
 * silently overflowed past the panel border into the hint bar. With
 * the 23px row height, 7 rows (161px) is the correct fit. */
#define FE_VISIBLE_ROWS  7

/* v0.39 sort modes for fe_scan(). 0 = name ascending (the new default,
 * fixes the old arbitrary FAT-directory-order listing), 1 = size
 * ascending, 2 = date (falls back to directory order on FAT since
 * readdir mtime is unreliable on the 3DS SD card). */
#define FE_SORT_NAME 0
#define FE_SORT_SIZE 1
#define FE_SORT_DATE 2
#define FE_SORT_COUNT 3

typedef struct {
    char names[FE_MAX_FILES][FE_FILENAME_MAX];
    long sizes[FE_MAX_FILES];   /* file size in bytes; -1 = unknown */
    int  count;                 /* number of .html files found */
    int  cursor;                /* current selection index */
    int  scroll;                /* first visible row (for scrolling) */
    int  sort_mode;             /* v0.39: FE_SORT_* — applied in fe_scan */
} FileExplorer;

/* Initialise to empty/zero state. */
void fe_init(FileExplorer *fe);

/* Scan FE_DIR and populate names[]/sizes[]/count.
 * Resets cursor and scroll to 0.
 * Sorts results according to fe->sort_mode (default name-ascending).
 * Attempts to create FE_DIR if it does not exist. */
void fe_scan(FileExplorer *fe);

/* Move cursor up/down.
 * total_rows: pass (count+1) for save mode, count for load mode.
 * Adjusts scroll so cursor is always in the visible window. */
void fe_move_up(FileExplorer *fe);
void fe_move_down(FileExplorer *fe, int total_rows);

/* Format file size into buf as human-readable string (e.g. "1.2 KB"). */
void fe_format_size(long bytes, char *buf, int buf_sz);

/* Save editor buffer to FE_DIR/<filename>.
 * Returns true on success. */
bool fe_save_named(const Editor *e, const char *filename);

/* Load FE_DIR/<filename> into editor.
 * Returns true on success. */
bool fe_load_named(Editor *e, const char *filename);

/* ---- v0.39: file management ---- */

/* Delete FE_DIR/<filename>. Returns true on success. Caller should
 * rescan afterwards. */
bool fe_delete_named(const char *filename);

/* Rename FE_DIR/<oldname> to FE_DIR/<newname>. Validates newname is
 * non-empty and ends in .html (appends .html if missing, matching
 * ensure_html_ext's behaviour). Returns true on success. */
bool fe_rename_named(const char *oldname, const char *newname);

/* ---- v0.39: last-opened file memory ---- */
/* Persist the last successfully opened/saved filename to FE_CONFIG_FILE
 * (a single line). Silent no-op on failure. */
void fe_save_last(const char *filename);
/* Read the last filename into out (null-terminated). Returns true if a
 * non-empty name was read. Returns false (out untouched) on any error. */
bool fe_load_last(char *out, int out_sz);
/* v0.39: remove FE_CONFIG_FILE so the next launch starts fresh. Used
 * when the last-opened file is deleted (via MODE_DELETE or externally)
 * so config.txt doesn't point at a nonexistent file forever. Silent
 * no-op if the file doesn't exist. */
void fe_clear_last(void);

/* ---- v0.39: auto-save draft ---- */
/* Write the editor buffer to FE_AUTOSAVE. Non-fatal: returns true on
 * success, false on any I/O error (caller ignores). Does NOT touch the
 * last-opened-file config or the normal save path. */
bool fe_save_autosave(const Editor *e);
/* Load FE_AUTOSAVE into the editor buffer. Returns true on success,
 * false on any error (file missing, read error, too large). Resets
 * the undo ring (matching fe_load_named's behaviour) so the recovered
 * buffer starts with a clean undo history. */
bool fe_load_autosave(Editor *e);

/* ---- Legacy slot API — kept for backwards compatibility ---- */
#define NUM_SLOTS 5
const char *fe_slot_name(int slot);
bool fe_save_slot(const Editor *e, int slot);
bool fe_load_slot(Editor *e, int slot);
