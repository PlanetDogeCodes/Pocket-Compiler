#pragma once
#include <stdbool.h>
#include "file_explorer.h"

/* CODE_AREA_H must match the number of lines the Citro2D editor actually
 * displays. The editor scroll logic uses this to advance the viewport. */
#define CODE_AREA_W   42
#define CODE_AREA_H   10    /* visible lines in the Citro2D editor panel */

/*
 * PANEL_VISIBLE_ROWS — number of 17px-tall rows that fit cleanly inside
 * the standard 178px-tall bottom-screen content panel (TAB_H+2 to
 * BOT_H-HINT_H in ui.c). Shared by BOTH the JS Console log and the
 * Controls help screen so their scroll-clamping logic (here, in main.c)
 * always agrees with what ui.c actually renders.
 *
 * v0.37 bug fix: previously main.c used a different, larger constant
 * (CONSOLE_VISIBLE_LINES = 12) than ui.c's rendering used (CON_VISIBLE
 * = 10), which under-scrolled the console by 2 rows — the newest log
 * entries could become permanently unreachable once the log grew long
 * enough. Both files now reference this single constant.
 *
 * If the panel height or row height in ui.c ever changes, update this
 * value to match (panel_usable_height / row_height, rounded down).
 */
#define PANEL_VISIBLE_ROWS 10

typedef enum {
    MODE_EDIT = 0,
    MODE_SAVE,
    MODE_LOAD,
    MODE_CONTROLS,
    MODE_PREVIEW,
    MODE_FIND,        /* find/replace overlay — row 1 of MODE_ACTIONS */
    MODE_ACTIONS,     /* v0.39: secondary-operations menu, entered via R */
    MODE_GOTO,        /* v0.39: go-to-line overlay */
    MODE_DELETE,      /* v0.39: delete-file explorer (mirrors MODE_SAVE) */
    MODE_RENAME       /* v0.39: rename-file explorer (mirrors MODE_DELETE) */
} AppMode;

typedef struct {
    AppMode      mode;
    bool         running;
    int          slot_cursor;   /* legacy */
    FileExplorer fe;            /* proper file explorer state */

    /* Bottom-screen cursor. Updated by either the Circle Pad (relative
     * nudge) or the touchscreen (absolute placement — touch takes
     * priority over the Circle Pad whenever the screen is being
     * touched). See main.c's main loop for the touch-vs-circle-pad
     * arbitration logic. */
    float        cursor_x;
    float        cursor_y;

    /* Code view: horizontal scroll offset in characters */
    int          view_left;

    /* Which visual row (0..CODE_AREA_H-1) the cursor dot is hovering
     * in the code area.  Used by A-press (and by a touch tap) to
     * target the correct line. */
    int          code_cursor_line;

    /* Run mode: toggled by START.  While true, output is shown on the
     * top screen and the bottom screen is locked. */
    bool         run_mode;

    /* Top-screen cursor (only active in run_mode) */
    float        top_cursor_x;
    float        top_cursor_y;

    /* Cursor / pointer lock: constrains cursor to the output panel */
    bool         cursor_locked;

    /* Output scroll offset (DPad scrolls in run_mode) */
    int          out_scroll;

    /* Click feedback animation */
    int          click_flash;   /* frames remaining */
    int          click_line;    /* which s_out[] row was clicked */

    /* ── Console tab (L toggles in edit mode, or tap the tab) ─── */
    bool         console_tab;      /* true = bottom screen shows JS console */
    int          console_scroll;   /* scroll offset into g_wjs_log */

    /* ── Find/Replace (R enters MODE_FIND) ──────────────────── */
    char         find_buf[256];    /* current search string */
    char         replace_buf[256]; /* current replacement string */
    int          find_match_line;  /* -1 = no current match */
    int          find_match_col;   /* column of current match start */
    bool         find_has_match;   /* true when last search succeeded */

    /* ── Controls help screen scrolling (v0.37) ───────────────── */
    int          controls_scroll;  /* first visible row in MODE_CONTROLS */

    /* ── v0.39: Actions menu (R), Go-to-line, Autosave ─────────── */
    int          actions_scroll;   /* first visible row in MODE_ACTIONS */
    char         goto_buf[24];     /* go-to-line input string */
    int          goto_target;      /* parsed target line, or -1 */
    int          idle_frames;      /* frames since last input (autosave) */
    bool         autosave_dirty;   /* true once an idle/compile autosave fires */
    bool         delete_confirm;   /* MODE_DELETE: armed second A press */
} AppState;
