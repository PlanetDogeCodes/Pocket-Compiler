/*
 * web_audio.h  —  Web Audio API for Pocket Compiler Web Engine
 * NDSP-backed oscillators, gain nodes, and PCM sample playback.
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "duktape.h"

/* ── Audio graph nodes ──────────────────────────────────────────── */
#define WA_MAX_NODES    32
#define WA_MAX_CHANNELS  2   /* stereo                             */
#define WA_SAMPLE_RATE  22050

typedef enum {
    WAN_NONE         = 0,
    WAN_OSCILLATOR   = 1,
    WAN_GAIN         = 2,
    WAN_DESTINATION  = 3,   /* the NDSP output                    */
    WAN_BUFFER_SRC   = 4,   /* AudioBufferSourceNode              */
    WAN_ANALYSER     = 5,
    WAN_DYNAMICS_COMP= 6,
    WAN_BIQUAD       = 7,
    WAN_PANNER       = 8,
    WAN_DELAY        = 9,
} WANodeType;

typedef enum {
    WA_SINE     = 0,
    WA_SQUARE   = 1,
    WA_SAWTOOTH = 2,
    WA_TRIANGLE = 3,
    WA_CUSTOM   = 4,
} WAOscType;

/* Biquad filter types */
typedef enum {
    WA_BQ_LOWPASS  = 0,
    WA_BQ_HIGHPASS = 1,
    WA_BQ_BANDPASS = 2,
    WA_BQ_NOTCH    = 3,
    WA_BQ_ALLPASS  = 4,
} WABiquadType;

typedef struct {
    uint8_t   type;       /* WANodeType */
    bool      used;
    bool      playing;
    double    start_time;   /* AudioContext.currentTime when started */
    double    stop_time;    /* 0 = not scheduled to stop            */

    /* Oscillator fields */
    uint8_t   osc_type;   /* WAOscType */
    float     frequency;  /* Hz                                    */
    float     detune;     /* cents                                 */
    float     phase;      /* current oscillator phase 0..2π       */

    /* Gain fields */
    float     gain;

    /* Buffer source fields */
    uint8_t  *pcm_data;   /* malloc'd PCM s16LE buffer            */
    uint32_t  pcm_samples;
    uint32_t  pcm_pos;
    bool      loop;
    double    loop_start, loop_end;

    /* Biquad */
    uint8_t   bq_type;
    float     bq_freq, bq_Q, bq_gain;

    /* Delay (simple) */
    float     delay_time;

    /* connection: which node we feed into */
    int8_t    dest_node;  /* -1 = output */

    /* NDSP channel (-1 = not assigned) */
    int8_t    ndsp_channel;
} WAAudioNode;

/* ── AudioContext ───────────────────────────────────────────────── */
typedef struct {
    bool          initialized;
    double        current_time;  /* seconds since context created  */
    uint8_t       doc_id;
    WAAudioNode   nodes[WA_MAX_NODES];
    int           node_n;
    float         master_gain;   /* 0.0–1.0                        */
} WAAudioContext;

extern WAAudioContext g_wa_ctx;

/* ── API ────────────────────────────────────────────────────────── */

void    wa_init(uint8_t doc_id);
void    wa_exit(void);
void    wa_tick(double dt);          /* call once per frame  */

int     wa_new_node(WANodeType t);
bool    wa_connect(int src, int dst);/* connect src → dst    */
void    wa_free_node(int idx);

/* Oscillator */
int     wa_create_oscillator(void);
void    wa_osc_set_type(int idx, WAOscType t);
void    wa_osc_set_freq(int idx, float hz);
void    wa_osc_set_detune(int idx, float cents);
void    wa_osc_start(int idx, double when);
void    wa_osc_stop (int idx, double when);

/* Gain */
int     wa_create_gain(void);
void    wa_gain_set(int idx, float gain);

/* Buffer source */
int     wa_create_buffer_source(void);
bool    wa_buffer_set_pcm(int idx, const uint8_t *data,
                           uint32_t n_samples, int channels, int rate);
bool    wa_buffer_load_wav(int idx, const char *path);
void    wa_buffer_start(int idx, double when);
void    wa_buffer_stop (int idx, double when);
void    wa_buffer_loop (int idx, bool enable, double start, double end);

/* Destination */
int     wa_get_destination(void);   /* always node 0       */

/* Duktape bindings */
void    wa_install_bindings(duk_context *ctx, uint8_t doc_id);
