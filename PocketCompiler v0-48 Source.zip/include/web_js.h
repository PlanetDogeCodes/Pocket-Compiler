/*
 * web_js.h  —  Duktape JS runtime bindings for Pocket Compiler Web Engine
 */
#pragma once
#include "web_dom.h"
#include "web_events.h"
#include "duktape.h"

/* ── JS context management ──────────────────────────────────────── */

/* Create a Duktape context for a document, install all bindings */
duk_context *wjs_create_context(uint8_t doc_id);

/* Destroy a context */
void  wjs_destroy_context(duk_context *ctx);

/* Evaluate a script string in a context */
bool  wjs_eval(duk_context *ctx, const char *script);

/* Evaluate a script file from SD card */
bool  wjs_eval_file(duk_context *ctx, const char *path);

/* Call JS function by name (0 args) */
bool  wjs_call(duk_context *ctx, const char *fn);

/* ── Binding installation ───────────────────────────────────────── */

/* Install all DOM bindings: document, window, Element, etc. */
void  wjs_install_dom(duk_context *ctx, uint8_t doc_id);

/* Install console.log/warn/error (outputs to top-screen log) */
void  wjs_install_console(duk_context *ctx);

/* Install window object: setTimeout, setInterval, requestAnimationFrame */
void  wjs_install_window(duk_context *ctx, uint8_t doc_id);

/* Install fetch() / XMLHttpRequest (SD-card backed) */
void  wjs_install_fetch(duk_context *ctx, uint8_t doc_id);

/* Install localStorage / sessionStorage (SD-card JSON) */
void  wjs_install_storage(duk_context *ctx, uint8_t doc_id);

/* Install Canvas 2D API (for <canvas> elements) */
void  wjs_install_canvas(duk_context *ctx, uint8_t doc_id);

/* Install Web Audio API (NDSP backed oscillators + samples) */
void  wjs_install_audio(duk_context *ctx, uint8_t doc_id);

/* Install navigator, screen, location objects */
void  wjs_install_navigator(duk_context *ctx);

/* ── Timer pump ─────────────────────────────────────────────────── */
/* Call once per frame to fire expired setTimeout/setInterval */
void  wjs_tick_timers(duk_context *ctx);

/* ── rAF pump ───────────────────────────────────────────────────── */
/* Call once per frame to fire requestAnimationFrame callbacks */
void  wjs_tick_raf(duk_context *ctx, double timestamp_ms);

/* ── Event firing ───────────────────────────────────────────────── */
/* Called by we_invoke_js: push event object, call JS handler */
void  wjs_fire_event(duk_context *ctx, int js_ref, const WEEvent *ev);

/* ── Heap stash key for doc_id lookup ──────────────────────────── */
#define WJS_STASH_DOCID  "\xFF" "doc_id"

/* ── Log buffer (console.log output) ───────────────────────────── */
#define WJS_LOG_MAX_LINES  64
#define WJS_LOG_LINE_LEN  128

extern char g_wjs_log[WJS_LOG_MAX_LINES][WJS_LOG_LINE_LEN];
extern int  g_wjs_log_n;

void  wjs_log_push(const char *line);
void  wjs_log_clear(void);

/* v0.39: Append the entire current console log (g_wjs_log[0..n-1]) to
 * FE_LOG_FILE on the SD card, with a timestamped header. Returns true
 * on success. Used by the Actions menu's "Export log" row. */
bool  wjs_export_log(void);
