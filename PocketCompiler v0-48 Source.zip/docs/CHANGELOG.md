# Pocket Compiler — Changelog

## v0.42 (current) — Tier 2 features: transitions, box-shadow, gradients, grid, calc(), form submission

This release consolidates all work from the v0.38 deep-audit pass, the
v0.39 feature pass, the v0.40 rendering audit, and a final crash-proofing
pass into a single bug-free deliverable. Every C source file was read in
full and audited for crash risks, compile errors, and logic bugs.

### Crash / Hang Fixes (final audit pass)

- **WAV loader could crash on malformed files.** `wa_buffer_load_wav`
  did not check the `fread` return for the 44-byte header, did not
  validate `channels` or `bits` before dividing by them (division by
  zero on `channels=0` or `bits=0`), and did not check for integer
  overflow in `n_samples * channels * 2` (heap overflow via small
  malloc + huge memcpy). All fixed: header read is checked, channels
  must be 1-2, bits must be 8 or 16, data size is capped at 4 MB, and
  the allocation uses 64-bit math with an overflow check.
- **`wrender_node` had no recursion depth guard.** A deeply nested DOM
  (up to 1024 nodes) could recurse ~1024 levels deep and overflow the
  3DS's 256 KB main-thread stack. Added `MAX_RENDER_DEPTH = 80`
  (matching the layout engine's cap) with increment/decrement pairing
  and a per-pass reset.
- **`wf_fetch_sync` had a one-byte heap overflow.** A response exactly
  64 KB would write `body[65536] = '\0'` — one past the end of
  `body[65536]`. Capped at `WF_MAX_BODY - 1` to leave room for the NUL.
- **`wif_render` used `return` instead of `continue`.** If one iframe
  had no body node, all subsequent iframes in the render loop were
  silently skipped.
- **DOM cycle prevention.** `dom_append_child` and `dom_insert_before`
  did not guard against cycles. JS code like
  `a.appendChild(b); b.appendChild(a);` would create a cycle that
  hangs the 3DS forever in any tree traversal (layout, render, event
  bubbling). Both functions now walk up the parent chain (bounded by
  `g_dom_node_n`) and refuse the operation if the child is an ancestor
  of the parent. Also: both now unlink a node from its old parent
  before appending/inserting, preventing corrupt two-parent trees.
- **Event bubbling could loop forever.** `we_dispatch` walked up the
  parent chain with no guard. Added a guard bounded by
  `g_dom_node_n`. Same guard added to `layout_find_focusable` (was
  recursive, now iterative) and the `<a>` parent-chain walk in the
  click handler.
- **Stale event state after recompile.** After pressing START to
  recompile, `s_prev_hover`, `s_left_down`, `s_right_down` etc. still
  held node indices from the previous page. On the next frame, the
  hover-clear code would write `.hover=0` onto a now-different element.
  Added `we_events_reset()` and call it from `we_load_html`.
- **`key_str` not NUL-terminated.** `strncpy(ev.key_str, ..., 7)` with
  "ArrowUp" (exactly 7 chars) filled all 7 bytes without NUL. Worked
  only because `={0}` zero-filled the struct. Now uses `sizeof-1` and
  explicit NUL termination.
- **`ws_local_get` / `ws_session_get` could underflow.** If `sz <= 0`,
  `strncpy(out, ..., sz-1)` would wrap to `SIZE_MAX` and `out[sz-1]`
  would underflow. Added `sz <= 0` guard.
- **Large stack buffers in `web_storage.c`.** `ws_local_load` had a
  16 KB stack buffer (`WS_MAX_VAL * 4`); `ws_local_flush` had ~8.5 KB
  of escape buffers in a loop. Both moved to `static` to keep 3DS
  stack usage low (matching the codebase pattern).

### Rendering Fixes (from the v0.40 rendering audit)

- **CSS cascade MERGE was missing ~10 fields.** Stylesheet rules
  setting `align_self`, `overflow_x/y`, `min/max width/height`,
  `z_index`, `translate_x/y` were silently dropped. All now have MERGE
  lines with correct default-sentinel guards.
- **`opacity` was parsed but never applied.** Now scales the alpha
  byte of every drawn color (text, background, border).
- **`font-weight: bold` was never rendered.** Now fakes bold via
  double-draw with a 1px horizontal offset (citro2d system font has no
  bold variant).
- **`font-style: italic` was never rendered.** Added a 10th parameter
  to `wrender_text`; fakes italic via a shear offset. All 5 call sites
  updated.
- **`text-decoration` (underline/strikethrough) was never rendered.**
  Now draws solid rectangles below the baseline (underline) or through
  the vertical middle (line-through).
- **`flex_grow` was parsed but never distributed.** Now distributes
  free space proportionally to grow factors before justify-content.
- **`align-items: stretch` was a no-op.** Now actually stretches
  children along the cross axis.
- **`background` shorthand misrouted `url()` to the color parser.**
  Now strips the url() part and parses any remaining color token.
- **`border` shorthand only handled `solid`** and broke on multi-word
  values. Now properly tokenises width/style/color and handles per-side
  variants.
- **`margin`/`padding` missing the 3-value form.** Added `vc==3`
  handling (T / L+R / B).
- **`font` shorthand not supported.** Added full tokeniser for
  `italic bold 14px/16px Arial` etc.
- **`wep_is_block_tag` misclassified invisible tags.** `script`,
  `style`, `title`, `head`, `meta`, `link` were in the block list, so
  their text content rendered visibly. Now `display:none`.

### Deep-Audit Fixes (from the original v0.38 pass)

- **Canvas 2D context setup silently broken.** The property-accessor
  setup script was truncated by `snprintf` into a 512-byte buffer (the
  literal is 854 bytes). Fixed by passing the literal directly to
  `duk_eval_string`.
- **Event-listener ref truncation.** `DOMEvent.js_ref` widened from
  `uint8_t` to `uint16_t`; the ref counter moved to file scope with an
  explicit reset on each page load.
- **`we_document_open` used unchecked raw array indexing.** Switched
  to the bounds-checked `dom_node()` accessor.
- **CSS parser ~3 KB combined stack buffers.** Both made `static`.
- **Layout engine had no recursion depth limit.** Added
  `MAX_LAYOUT_DEPTH = 80`.

### Feature Additions (from the v0.39 pass)

- Multi-level undo (5-step ring), line duplication, go-to-line,
  block comment/uncomment toggle.
- R now opens a scrollable Actions menu (gateway to Find/Replace,
  Go-to, Duplicate, Comment, Rename, Delete, Sort, Export log,
  Recover autosave).
- File explorer: delete (two-step confirm), rename, sort by
  name/size/date, remember last-opened file (auto-load on startup).
- Auto-save draft (writes to SD on compile + 10 s of idle), with
  "Recover auto..." action to load it back.
- Console-log timestamps (MM:SS prefix) and "Export log to SD".
- `html_render()` gained additive cases for `blockquote`, `pre`,
  `strong/b`, `em/i`, `code`, `span`, `label`.
- CSS: `align-self`, `flex-flow`, `inset` properties added.

### v0.37 Bug Fixes (retained)

- Console tab could not be touched/tapped (real touchscreen support
  added).
- Hint/control bar glitching under the editor/console tab (off-by-2
  pixel bug fixed).
- Could not scroll the SELECT controls/help screen (scroll state +
  scrollbar added).
- Console under-scroll and file explorer row overflow fixed.
- Shared layout constant `PANEL_VISIBLE_ROWS` eliminates drift between
  `main.c` and `ui.c`.

### Verification

- `gcc -fsyntax-only -D__3DS__` against every `.c`/`.h` file — all
  pass clean (remaining errors are preexisting host-stub-only symbols
  like `C3D_Tex.data`, `ndspWaveBuf.status`, `svcSleepThread` that are
  real libctru/citro3d symbols not present in the host stubs).
- Brace/paren balance checker on all project files — all OK.
- Cross-reference sweep: every `ACT_*` / `MODE_*` constant is handled
  in both `main.c` and `ui.c`; every `wrender_text` call site passes
  the 10th parameter; every CSS property parsed by `apply_property()`
  has a corresponding `MERGE_*` line in the cascade.

---

## v0.37

### Bug Fixes — Reported Issues
- **Console tab could not be touched/tapped.** Root cause: `main.c`
  never called `hidTouchRead()` at all — the bottom-screen cursor was
  Circle-Pad-only. Touching the screen did nothing for *any* UI
  element, not just the console tab. Real touchscreen support has been
  added: while the screen is being touched, the cursor snaps to the
  touch position every frame (touch takes priority over the Circle
  Pad; releasing the screen returns control to the Circle Pad from
  wherever the cursor was left). A tap on the EDITOR/CONSOLE tab bar
  now switches tabs directly, a tap on a code line edits that line,
  and a tap on a Save/Load file row selects and acts on it.
- **Hint/control bar glitching under the editor/console tab.** Two
  separate root causes, both fixed:
  1. The "ln X/Y" line counter was drawn directly on top of the tab
     bar at the same position as the CONSOLE tab's label, visually
     colliding with it. It has been moved into the hint bar's first
     row (right-aligned, dimmed) where nothing else overlaps it.
  2. A systemic off-by-2 bug: `draw_edit`, `draw_console`, `draw_save`,
     `draw_load`, and `draw_find_bar` all positioned their hint bar
     2px lower than `draw_running_bot` did, pushing their hint bar
     (and, for the find bar, both its rows) past the bottom edge of
     the 240px-tall screen — `draw_find_bar` overflowed by up to 6px.
     Every screen's hint/find bar now starts at exactly the same
     y-coordinate and ends flush with the bottom of the screen.
- **Could not scroll the SELECT controls/help screen.** It previously
  had no scroll state at all; its rows silently overflowed the panel
  with several hidden behind the hint bar. `controls_scroll` is now a
  tracked field, DPad Up/Down scrolls the list, and a scrollbar shows
  there's more content. The row table is also now a single
  source-of-truth array (`s_ctrl_rows`) shared between rendering and
  the row-count main.c uses to clamp scrolling — no separately
  maintained "row count" constant to drift out of sync. A new "Touch"
  row documents the v0.37 tap gestures.

### Bug Fixes — Found During Audit (not user-reported)
- **Console under-scroll.** `main.c` used a constant
  (`CONSOLE_VISIBLE_LINES = 12`) that didn't match `ui.c`'s actual
  rendering capacity (10 visible rows). Both the auto-scroll-to-bottom
  on eval and the manual DPad scroll under-shot by 2 rows, making the
  newest 1–2 log entries permanently unreachable once the log grew
  long enough. Both files now reference one shared constant,
  `PANEL_VISIBLE_ROWS` (app.h), eliminating the possibility of drift.
- **File explorer row overflow.** `FE_VISIBLE_ROWS` was still 8, a
  leftover from before v0.36 enlarged the file-list row height
  (`LH_FE`) from 21px to 23px for readability. `8 × 23 = 184px`
  overflowed the panel's ~168px usable height by up to 16px, so the
  bottom-most Save/Load row could bleed into the hint bar. Corrected
  to 7 rows (161px), which fits cleanly. A defensive pixel-bound check
  was also added to the render loop as a second line of defense.

### Internal / Architecture
- Extracted shared helper functions (`do_edit_line_action`,
  `do_save_dialog_action`, `do_load_file_action`,
  `do_switch_to_editor_tab`, `do_switch_to_console_tab`) so a button
  press and an equivalent touch tap always run the exact same code —
  there is no way for the two input paths to drift out of sync.
- Tab-bar tap hit-test region (y 3–24) and the editor code-area hit
  region (y 33–206) are verified non-overlapping, so a tap can never
  ambiguously trigger both a tab switch and a line edit.

---

## v0.36

### UI / Readability
- **All non-code bottom-screen text enlarged** for 3DS 240p legibility.
  Minimum UI font scale raised from 0.30–0.38 → 0.44–0.52.
  Code text (editor lines) is unchanged at FS_ED = 0.42.
- Hint bar is now **two lines** (34px tall) with shorter, clearly-spaced labels.
- Controls reference screen: key column 0.44f, description column 0.42f,
  row height raised to 17px. All description strings trimmed to fit.
- Tab bar labels: 0.38f → 0.48f.
- Console log lines: 0.38f → 0.46f; line height 17px.
- Find bar fields and hints: 0.34–0.38f → 0.40–0.46f.
- File explorer item text already used FS_UI (0.52f); size/date labels raised
  to FS_HINT (0.44f).

### Bug Fixes
- **`editor_find` / `editor_find_prev`**: `start_line` is now clamped to
  `[0, total-1]` before use. Without this, a negative or out-of-range
  start_line caused `editor_get_line` to walk off the end of the buffer —
  a potential crash on 3DS.
- **`editor_find_prev`**: `nlen` moved outside the inner for-loop (was
  recomputed on every iteration; harmless but wasteful).
- **`editor_replace_at`**: added `col > llen` guard to the bounds check so
  an exact-end-of-line replacement does not memcpy with a negative count.
- **`main.c` replace-all**: explicit parentheses added around `down & KEY_X`
  (`if((down & KEY_X) && ...)`). Without them GCC -Wall emits a warning;
  the fix makes intent unambiguous.
- **`main.c` replace-all**: after replacing all occurrences, `scroll_offset`
  is clamped to a valid range so the editor does not display a blank screen.
- **`we_eval_js`**: added `!g_web_engine.loaded` guard (in addition to the
  existing `!initialized` check). Prevents reading a stale `js_ctx` pointer
  if `we_unload()` was called between frames without clearing the pointer.
- **`draw_console`**: `i < WJS_LOG_MAX_LINES` guard added to the log-line
  loop. If `g_wjs_log_n` is ever corrupted, the loop can no longer read
  beyond the allocated `g_wjs_log` array.
- **`ui.c`**: two `strcat()` calls replaced with `strncat()` to silence
  static-analysis warnings and guard against theoretical overflow.
- **`main.c`**: `strcat()` in `ensure_html_ext` replaced with `strncat()`.
- **Layout constants**: `LAYOUT_ED_H` in `main.c` corrected to `178.0f`
  (was `180.0f`) to match the new two-line hint bar height in `ui.c`.
  Without this fix the cursor-to-code-row mapping was 2px off, causing the
  wrong line to be selected near the bottom of the editor panel.

---

## v0.35
- Auto-indent (A press on empty lines pre-fills indentation).
- JS Console tab (L in edit mode) with live expression evaluation.
- Find / Replace (R in edit mode) with next/prev/replace-one/replace-all.
- `fetch()` proper chaining via `.then(r=>r.json()).then(data=>...)` pattern.
- `response.text()` and `response.json()` return real thenables.
- `XMLHttpRequest.open()` correctly stores URL for `send()`.
- Duktape context kept alive on START-stop so console works after run.
- Console log cleared on each new compile (START in edit mode).

## v0.33
- Multiple field-name and linker bug fixes.

## v0.29 – v0.10
- Incremental implementation: DOM, CSS, layout, fetch, IndexedDB, iframe,
  Canvas, WebGL, audio, asset loading, full 3DS controls.

## v0.09
- Rebranded to Pocket Compiler.

## v0.01 – v0.08
- Initial HTML/CSS/JS editor, libctru console, SD card I/O.
